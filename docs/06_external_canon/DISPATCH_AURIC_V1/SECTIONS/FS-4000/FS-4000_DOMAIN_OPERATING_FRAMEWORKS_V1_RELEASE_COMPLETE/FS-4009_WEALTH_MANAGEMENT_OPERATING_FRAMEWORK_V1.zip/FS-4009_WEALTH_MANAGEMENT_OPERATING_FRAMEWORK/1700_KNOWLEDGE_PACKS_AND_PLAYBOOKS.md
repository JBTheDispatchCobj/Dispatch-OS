# Knowledge Packs & Playbooks

## Knowledge Packs

### Wealth Foundation Pack

- terminology
- account types
- advisory models
- product taxonomy
- workflow maps
- KPI definitions

### Financial Planning Pack

- discovery
- goals
- cash flow
- retirement
- estate
- tax
- insurance
- scenarios

### Portfolio Management Pack

- asset allocation
- IPS
- rebalancing
- performance
- tax loss harvesting
- restrictions
- model portfolios

### Compliance Pack

- fiduciary duty
- Reg BI
- suitability
- disclosures
- supervision
- complaint handling
- marketing review

### Credit Union Wealth Pack

- member referrals
- branch referral model
- CUSO wealth model
- business owner wealth
- rollover capture
- non-interest income

### Practice Management Pack

- segmentation
- service model
- advisor productivity
- pipeline
- client reviews
- succession

## Playbooks

- Prospect to Client Playbook
- Discovery Meeting Playbook
- Financial Plan Playbook
- Client Review Playbook
- Portfolio Review Playbook
- Account Opening Playbook
- Transfer of Assets Playbook
- Advisory Billing Playbook
- Referral Playbook
- Credit Union Wealth Buildout Playbook
- Advisor Practice Optimization Playbook
- Senior Investor Protection Playbook

## Dispatch Truth Statement

Wealth knowledge packs turn advisory expertise into repeatable client service and institutional economics.
