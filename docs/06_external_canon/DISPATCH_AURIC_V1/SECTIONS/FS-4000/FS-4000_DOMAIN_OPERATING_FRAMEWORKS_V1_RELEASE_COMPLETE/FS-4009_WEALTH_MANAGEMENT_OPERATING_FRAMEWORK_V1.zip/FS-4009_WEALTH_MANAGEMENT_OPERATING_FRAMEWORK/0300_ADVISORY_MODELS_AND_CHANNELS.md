# Advisory Models & Channels

## Purpose

This document defines wealth advisory business models, channels, and delivery structures.

## Advisory Models

- RIA Fiduciary Advisory
- Broker-Dealer Brokerage
- Dual-Registered Advisor
- Bank Wealth Program
- Credit Union Wealth Program
- Trust Company
- Private Bank
- Family Office
- Robo Advisor
- Hybrid Advisor
- Retirement Plan Advisor
- Insurance-Based Advisor
- Independent Advisor
- Captive Advisor
- Platform Advisor

## Revenue Models

- AUM Fee
- Advisory Fee
- Planning Fee
- Subscription Fee
- Hourly Fee
- Commission
- Trail Commission
- Insurance Commission
- Annuity Commission
- Revenue Sharing
- Referral Fee
- Trust Fee
- Custody Economics
- Lending Spread
- Banking Referral Economics

## Channel Objects

- Branch Referral
- Digital Lead
- Advisor Referral
- CPA Referral
- Attorney Referral
- Business Owner Referral
- Retirement Plan Referral
- Credit Union Member Referral
- Bank Customer Referral
- Seminar/Event
- Social Media
- Existing Client Referral
- Executive Network
- Employer Channel

## Referral Object

Fields:
- referral_id
- source
- referred_client
- advisor
- opportunity
- status
- expected_AUM
- expected_revenue
- compliance_status
- disclosure_required
- referral_agreement
- outcome
- follow_up

## Credit Union Wealth Program Lens

Common models:

- third-party broker-dealer partnership
- CUSO wealth platform
- in-house RIA
- hybrid referral model
- trust referral partnership
- insurance referral partnership
- financial wellness-to-advice funnel
- business owner wealth capture

Key opportunity:
Credit unions often own the member trust and relationship but outsource much of the economics and intelligence.

## Channel KPIs

- referrals
- referral conversion
- AUM from channel
- revenue from channel
- client acquisition cost
- advisor productivity
- cross-sell
- branch participation
- digital conversion
- referral aging
- compliance exceptions

## AI Opportunities

- referral routing
- opportunity scoring
- advisor matching
- referral follow-up
- branch training content
- lead summary
- channel performance analysis
- credit union member wealth opportunity detection

## Dispatch Truth Statement

Advisory channels determine who owns the client relationship, who captures economics, and where trust compounds.
