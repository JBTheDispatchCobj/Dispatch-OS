# Wealth Workflow Library

## Required Workflows

### Prospect to Client

Lead → Discovery → Qualification → Proposal → Agreement → Account Opening → Transfer → Implementation

### Financial Planning

Discovery → Data Collection → Goals → Scenarios → Recommendations → Meeting → Implementation → Review

### Portfolio Review

Holdings → Performance → Allocation → Drift → Risk → Recommendations → Client Review

### Account Opening

Client Data → KYC → Agreement → Custodian Forms → Signatures → Approval → Account Setup

### Transfer of Assets

Request → Custodian Forms → Submission → Follow-Up → Settlement → Reconciliation

### Advisory Billing

Valuation → Fee Calculation → Exception Review → Approval → Debit/Invoice → Revenue Posting

### Client Review

Segment Queue → Prep → Meeting → Notes → Recommendations → Tasks → Follow-Up

### Compliance Review

Trigger → Evidence → Review → Exception → Remediation → Archive

### Referral

Opportunity → Consent → Advisor Match → Referral → Follow-Up → Outcome

### Life Event

Detection → Advisor Alert → Planning Impact → Recommendation → Implementation

## Workflow KPIs

- cycle time
- completion rate
- review timeliness
- service SLA
- conversion rate
- compliance exception rate
- revenue impact
- client satisfaction

## Dispatch Truth Statement

Wealth workflows convert relationship trust into organized advice, service, implementation, and review.
