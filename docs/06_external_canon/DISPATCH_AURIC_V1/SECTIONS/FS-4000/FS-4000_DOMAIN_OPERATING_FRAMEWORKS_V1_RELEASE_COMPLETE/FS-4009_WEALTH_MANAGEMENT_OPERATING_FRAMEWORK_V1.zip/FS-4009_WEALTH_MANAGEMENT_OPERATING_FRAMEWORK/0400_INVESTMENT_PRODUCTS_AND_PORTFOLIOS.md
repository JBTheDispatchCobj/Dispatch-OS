# Investment Products & Portfolios

## Purpose

This document defines investment products, portfolio construction, allocation, and monitoring.

## Product Types

- Individual Stocks
- Bonds
- Mutual Funds
- ETFs
- SMAs
- UMAs
- Model Portfolios
- Alternatives
- Private Equity
- Private Credit
- Venture Capital
- Real Estate
- Hedge Funds
- Structured Notes
- Annuities
- CDs
- Money Market Funds
- Treasuries
- Municipal Bonds
- Corporate Bonds
- Insurance Products
- Retirement Products

## Portfolio Object

Fields:

- portfolio_id
- client
- account_ids
- strategy
- objective
- risk_profile
- time_horizon
- asset_allocation
- holdings
- cash
- cost_basis
- market_value
- performance
- benchmark
- restrictions
- tax_constraints
- liquidity_needs
- rebalancing_status
- drift
- fees
- advisor
- model

## Investment Policy Statement

Sections:
- client objectives
- risk tolerance
- time horizon
- liquidity needs
- tax considerations
- asset allocation
- restrictions
- benchmarks
- rebalancing rules
- review cadence
- roles and responsibilities

## Asset Allocation Categories

- cash
- fixed income
- equities
- real estate
- alternatives
- private markets
- commodities
- insurance/annuities
- concentrated positions
- employer stock

## Portfolio Workflows

- portfolio proposal
- account funding
- trade implementation
- model assignment
- rebalancing
- tax loss harvesting
- cash raise
- restriction review
- performance review
- investment policy update

## Portfolio KPIs

- AUM
- performance
- benchmark variance
- volatility
- drawdown
- Sharpe ratio
- income
- yield
- allocation drift
- cash drag
- tax impact
- realized gain/loss
- unrealized gain/loss
- fee rate
- client goal progress

## AI Opportunities

- portfolio summary
- allocation drift alert
- rebalancing recommendation
- tax loss harvesting support
- investment policy draft
- client-friendly performance commentary
- concentrated position analysis
- alternative allocation review

## Dispatch Truth Statement

A portfolio is not a collection of holdings. It is an implementation of client goals, risk tolerance, time horizon, tax constraints, income needs, and fiduciary judgment.
