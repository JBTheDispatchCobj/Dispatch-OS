# Banking, Lending & Liquidity Integration

## Purpose

This document defines how wealth management connects to banking, lending, deposits, credit unions, and liquidity.

## Banking Integration Opportunities

- deposits
- cash management
- CDs
- money market
- securities-backed lending
- mortgage
- HELOC
- business lending
- commercial treasury
- private banking
- trust
- insurance
- retirement rollovers
- business succession
- liquidity event capture

## Wealth-Banking Relationship Object

Fields:
- relationship_id
- client
- household
- bank_or_credit_union
- advisor
- banker
- deposits
- loans
- investments
- trust
- insurance
- business_relationships
- referrals
- cross_sell_opportunities
- consent
- compliance_status

## Credit Union Wealth Lens

Credit unions can use wealth management to:

- retain affluent members
- capture rollover assets
- deepen business owner relationships
- expand retirement guidance
- increase non-interest income
- serve executives and board members
- improve member financial wellness
- build CUSO-based economics
- reduce member leakage to outside advisors

## Liquidity Planning

Objects:
- emergency fund
- cash reserve
- investment cash
- tax reserve
- business liquidity
- line of credit
- mortgage liquidity
- securities-backed line
- planned distribution
- RMD
- charitable gift

## Referral Workflow

Trigger → Opportunity Detection → Consent → Advisor Match → Referral → Discovery → Proposal → Onboarding → Outcome → Revenue Attribution

## KPIs

- referrals generated
- referral conversion
- wealth AUM from banking channel
- banking balances from wealth channel
- loan referrals
- trust referrals
- insurance referrals
- business owner relationships
- wallet share
- non-interest income

## AI Opportunities

- referral opportunity detection
- business owner wealth brief
- liquidity planning summary
- rollover detection
- deposit-to-investment opportunity
- lending need detection
- credit union member wealth segmentation

## Dispatch Truth Statement

Wealth, banking, lending, and liquidity are not separate client needs. They are one household balance sheet.
