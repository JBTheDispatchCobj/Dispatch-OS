# Wealth Management Agent Workforce

## Advisor Agents

- Advisor Assistant
- Client Review Prep Agent
- Household Summary Agent
- Meeting Notes Agent
- Next Best Action Agent
- Referral Opportunity Agent
- Client Follow-Up Agent

## Planning Agents

- Financial Planning Assistant
- Retirement Planning Agent
- Estate Planning Checklist Agent
- Insurance Gap Agent
- Tax Planning Prompt Agent
- RMD Monitor
- Beneficiary Review Agent

## Investment Agents

- Portfolio Analyst
- Allocation Drift Agent
- Rebalancing Support Agent
- Performance Commentary Agent
- Concentrated Position Agent
- Tax Loss Harvesting Agent
- Alternative Investment Review Agent

## Operations Agents

- Account Opening Agent
- Transfer Tracking Agent
- Billing Review Agent
- Custodian Exception Agent
- Document Checklist Agent
- Client Service Queue Agent

## Compliance Agents

- Suitability Review Agent
- Fiduciary Evidence Agent
- Trade Review Agent
- Advertising Review Agent
- Complaint Review Agent
- Senior Investor Protection Agent
- Disclosure Delivery Agent

## Institutional Integration Agents

- Credit Union Wealth Opportunity Agent
- Branch Referral Agent
- Business Owner Wealth Agent
- Banking/Lending Cross-Sell Agent
- Trust Referral Agent

## Governance

Human approval required for:
- investment recommendations
- trades
- insurance recommendations
- fee changes
- client-facing advice
- compliance conclusions
- referral fee arrangements
- external communications where policy requires

## Dispatch Truth Statement

Wealth agents are governed advisory staff that support planning, service, compliance, operations, and relationship growth.
