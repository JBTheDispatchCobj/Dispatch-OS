# Reporting, Billing & Performance

## Purpose

This document defines client reporting, advisory billing, performance measurement, and revenue operations.

## Reporting Objects

- Client Statement
- Performance Report
- Household Report
- Portfolio Review
- Financial Plan Report
- Tax Report
- Fee Report
- Capital Gains Report
- Realized Gain/Loss
- Asset Allocation Report
- Holdings Report
- Benchmark Report

## Billing Object

Fields:
- billing_id
- client
- household
- account
- billing_period
- billing_method
- billable_assets
- fee_rate
- fee_amount
- custodian
- invoice
- debit_status
- revenue_share
- advisor_payout
- exception_status

## Performance Object

Fields:
- performance_id
- portfolio
- period
- beginning_value
- ending_value
- contributions
- withdrawals
- income
- fees
- return
- benchmark
- relative_performance
- volatility
- notes

## Billing Workflow

Asset Valuation → Fee Calculation → Exception Review → Approval → Custodian Debit / Invoice → Revenue Posting → Advisor Payout → Archive

## Client Review Package

- household summary
- goals
- plan progress
- portfolio performance
- allocation
- risk
- fees
- tax items
- liquidity
- estate/insurance reminders
- recommendations
- action items

## KPIs

- billing accuracy
- billing exceptions
- revenue
- fee rate
- AUM billed
- performance report timeliness
- client review completion
- benchmark variance
- advisory revenue
- payout
- household profitability

## AI Opportunities

- performance commentary
- client review package
- fee explanation
- billing exception detection
- benchmark variance summary
- household report generation
- tax-aware summary
- advisor talking points

## Dispatch Truth Statement

Reporting and billing are where advice becomes measurable, transparent, and economically sustainable.
