# Financial Planning

## Purpose

This document defines financial planning operations.

## Financial Plan Object

Fields:

- plan_id
- client
- household
- advisor
- planning_scope
- goals
- assets
- liabilities
- income
- expenses
- taxes
- insurance
- retirement
- estate
- education
- business
- assumptions
- scenarios
- recommendations
- implementation_tasks
- review_date
- status

## Planning Domains

- Retirement
- Cash Flow
- Budget
- Debt
- Education
- Tax
- Insurance
- Estate
- Charitable
- Business Succession
- Concentrated Stock
- Equity Compensation
- Real Estate
- Healthcare
- Long-Term Care
- Social Security
- Medicare
- Required Minimum Distributions

## Goal Object

Fields:
- goal_id
- household
- category
- target_amount
- target_date
- priority
- funding_source
- current_progress
- probability_of_success
- assumptions
- recommendation
- status

## Planning Workflow

Discovery → Data Collection → Goal Definition → Assumptions → Analysis → Scenarios → Recommendations → Client Meeting → Implementation → Review

## Planning Scenarios

- base case
- early retirement
- delayed retirement
- market downturn
- longevity
- inflation
- healthcare shock
- business sale
- inheritance
- tax change
- college funding
- long-term care
- death/disability

## Planning KPIs

- plans completed
- plans updated
- goals funded
- probability of success
- implementation tasks complete
- planning revenue
- client retention
- referral generation
- insurance gaps closed
- estate documents updated

## AI Opportunities

- discovery summary
- planning gap detection
- scenario explanation
- recommendation draft
- meeting agenda
- implementation checklist
- client-friendly plan summary
- annual update prompt

## Dispatch Truth Statement

Financial planning is the translation of a household's life into decisions, tradeoffs, scenarios, and actions.
