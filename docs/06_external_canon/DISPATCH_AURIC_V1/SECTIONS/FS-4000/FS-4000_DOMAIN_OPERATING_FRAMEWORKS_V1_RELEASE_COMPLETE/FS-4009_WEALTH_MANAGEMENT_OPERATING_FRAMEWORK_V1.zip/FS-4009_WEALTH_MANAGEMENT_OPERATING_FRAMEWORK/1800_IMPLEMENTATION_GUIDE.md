# Wealth Management Implementation Guide

## Phase 1 — Setup

- create wealth business unit
- configure advisory model
- configure broker-dealer/RIA/trust relationships
- configure advisor roles
- configure service tiers
- configure compliance model
- configure account/product taxonomy
- configure referral sources

## Phase 2 — Objects

- clients
- households
- advisors
- accounts
- portfolios
- financial plans
- goals
- recommendations
- insurance policies
- trust/estate objects
- referrals
- reviews
- billing events

## Phase 3 — Connectors

- CRM
- custodian data
- planning system
- portfolio reporting
- billing
- document storage
- email/calendar
- e-signature
- compliance platform
- AI provider

## Phase 4 — Workflows

Activate:
- prospect to client
- financial planning
- account opening
- transfer of assets
- portfolio review
- client review
- billing
- compliance review
- referral
- life event

## Phase 5 — Agents

Deploy:
- Advisor Assistant
- Household Summary Agent
- Client Review Prep Agent
- Financial Planning Assistant
- Portfolio Analyst
- Billing Review Agent
- Suitability Review Agent
- Credit Union Wealth Opportunity Agent

## Phase 6 — Dashboards

Configure:
- wealth executive
- advisor
- household
- portfolio
- planning
- compliance
- billing
- referral
- credit union wealth

## Demo Flow

1. Open household profile.
2. Show accounts and goals.
3. Generate client review brief.
4. Identify planning gaps.
5. Summarize portfolio performance.
6. Detect referral/cross-sell opportunity.
7. Generate meeting follow-up.
8. Show advisor dashboard.
9. Show compliance evidence.
10. Show credit union wealth opportunity map.

## Dispatch Truth Statement

Wealth implementation begins with household truth, then connects advice, accounts, portfolios, planning, compliance, and economics.
