# Wealth Operating Model

## Definition

Wealth management is the institutional process of advising clients on financial life decisions, investing assets, managing risk, coordinating planning, and delivering ongoing service under fiduciary, suitability, or brokerage standards.

## Operating Layers

### 1. Client Relationship Layer

Captures households, family members, business ownership, goals, assets, liabilities, income, risk tolerance, planning needs, referral sources, and lifecycle events.

### 2. Advice & Planning Layer

Includes financial planning, retirement planning, estate planning, tax coordination, insurance planning, education planning, charitable planning, business succession, and liquidity planning.

### 3. Investment Layer

Includes investment policy, portfolio construction, asset allocation, manager selection, trading, rebalancing, alternatives, performance, and risk.

### 4. Product & Platform Layer

Includes brokerage, advisory, custody, annuities, insurance, banking, lending, trust, alternatives, model portfolios, and third-party managers.

### 5. Compliance Layer

Includes fiduciary duty, suitability, Reg BI, disclosures, advisory agreements, KYC, AML, privacy, marketing, supervision, trade review, and documentation.

### 6. Service & Review Layer

Includes onboarding, account opening, transfers, beneficiary updates, required minimum distributions, annual reviews, client meetings, reporting, billing, and retention.

### 7. Institutional Integration Layer

For banks and credit unions, includes referrals, member/customer segmentation, deposit relationships, lending relationships, trust referrals, business owner planning, and wealth economics.

## Departments / Functions

- Wealth Management
- Financial Advisors
- Investment Management
- Portfolio Management
- Financial Planning
- Trust Services
- Brokerage Operations
- Insurance
- Retirement Services
- Client Service
- Compliance
- Supervision
- Trading
- Billing
- Performance Reporting
- Marketing
- Practice Management
- Advisor Recruiting
- Platform Operations

## Operating Cadence

Daily:
- client requests
- trades
- account openings
- cash needs
- compliance alerts
- market events
- advisor tasks

Weekly:
- advisor pipeline
- client reviews
- portfolio drift
- service issues
- referrals
- compliance exceptions

Monthly:
- AUM/AUA
- billing
- performance
- production
- cash flows
- client activity
- referral conversion

Quarterly:
- client reports
- household reviews
- investment committee
- model updates
- compliance testing
- advisor scorecards

Annual:
- financial plan update
- risk profile update
- estate beneficiary review
- tax planning
- RMD review
- client segmentation
- compensation review
- policy review

## Dispatch Truth Statement

Wealth management is a relationship and advice operating system. Assets are the measurable output, but trust, advice, planning, and service are the real product.
