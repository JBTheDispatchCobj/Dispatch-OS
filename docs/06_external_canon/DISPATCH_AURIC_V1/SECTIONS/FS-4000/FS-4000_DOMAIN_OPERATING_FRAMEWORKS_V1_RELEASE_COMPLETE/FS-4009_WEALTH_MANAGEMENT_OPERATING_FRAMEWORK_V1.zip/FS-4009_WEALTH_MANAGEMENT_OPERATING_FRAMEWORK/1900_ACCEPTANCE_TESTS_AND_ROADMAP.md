# Acceptance Tests & Roadmap

## Object Tests

- Can create Client.
- Can create Household.
- Can create Advisor.
- Can create Account.
- Can create Portfolio.
- Can create Financial Plan.
- Can create Goal.
- Can create Recommendation.
- Can create Insurance Policy.
- Can create Trust.
- Can create Referral.
- Can create Client Review.
- Can create Billing Event.
- Can create Compliance Review.

## Relationship Tests

- Household HAS Client.
- Client OWNS Account.
- Account HOLDS Security.
- Portfolio IMPLEMENTS Plan.
- Advisor SERVES Household.
- Recommendation SUPPORTS Goal.
- Referral SOURCED_BY Institution.
- Insurance Policy PROTECTS Risk.
- Trust BENEFITS Beneficiary.
- Billing Event CHARGES Account.

## Workflow Tests

- Prospect workflow creates client.
- Financial planning workflow produces recommendations.
- Account opening workflow creates account.
- Transfer workflow tracks assets.
- Portfolio review workflow identifies drift.
- Billing workflow calculates fee.
- Compliance review workflow preserves evidence.
- Referral workflow attributes outcome.

## Agent Tests

- Household Summary Agent creates brief.
- Client Review Prep Agent creates meeting agenda.
- Portfolio Analyst explains performance.
- Financial Planning Assistant identifies gaps.
- Billing Review Agent detects exception.
- Suitability Review Agent reviews recommendation.
- Credit Union Wealth Opportunity Agent identifies member opportunity.

## Roadmap

Priority 1:
- machine-readable wealth object registry
- fixture household
- fixture advisor
- fixture portfolio
- fixture financial plan
- fixture client review

Priority 2:
- workflows
- dashboards
- agents
- connectors
- referral engine

Priority 3:
- credit union wealth economics
- trust services extension
- insurance extension
- alternative investments extension
- advisor recruiting/practice valuation extension

## Dispatch Truth Statement

The Wealth Management cartridge is accepted when Dispatch can connect household relationships, advice, accounts, portfolios, planning, compliance, referrals, and economics into one institutional operating system.
