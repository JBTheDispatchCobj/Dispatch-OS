# Custody, Brokerage & Platform Operations

## Purpose

This document defines wealth operations across custodians, broker-dealers, platforms, trading, and accounts.

## Custodian Object

Fields:
- custodian_id
- name
- platform
- account_types
- trading_capabilities
- reporting
- fees
- integrations
- service_model
- restrictions
- documents
- contacts
- operational_risk

## Broker-Dealer Object

Fields:
- broker_dealer_id
- name
- registrations
- advisors
- supervisory_structure
- product_shelf
- compliance_model
- clearing_firm
- payout_model
- platform_fees
- approved_products
- supervision_rules

## Platform Operations

- account opening
- transfer of assets
- ACATS
- trading
- rebalancing
- cash management
- billing
- performance
- statements
- tax documents
- corporate actions
- restrictions
- householding
- beneficiary updates

## Trade Object

Fields:
- trade_id
- account
- security
- action
- quantity
- price
- order_type
- advisor
- discretion
- suitability_status
- approval
- execution
- settlement
- exception

## Operational Workflows

- account opening
- transfer of assets
- trade review
- restriction review
- model rebalance
- cash raise
- distribution request
- beneficiary update
- fee billing
- performance reporting
- corporate action

## KPIs

- account opening time
- transfer time
- trade exceptions
- billing errors
- performance report completion
- custodian service issues
- operational backlog
- ACATS aging
- account restriction exceptions
- settlement issues

## AI Opportunities

- account opening checklist
- transfer follow-up
- trade rationale summary
- restriction detection
- custodian issue summary
- billing exception review
- corporate action summary
- operational queue prioritization

## Dispatch Truth Statement

Custody and brokerage operations are the infrastructure layer that makes advice implementable, reportable, billable, and compliant.
