# Wealth Management Schema & Object Standard

## Purpose

This document defines canonical wealth management objects used by Dispatch.

## Universal Wealth Relationship Object

Fields:

- relationship_id
- client_id
- household_id
- advisor_id
- institution_id
- relationship_type
- relationship_status
- AUM
- AUA
- net_worth
- investable_assets
- accounts
- portfolios
- plans
- risk_profile
- objectives
- time_horizon
- liquidity_needs
- tax_profile
- estate_profile
- insurance_profile
- suitability_profile
- fiduciary_status
- next_review_date
- service_model
- revenue
- profitability
- referrals
- documents
- workflows
- communications
- KPIs
- AI_context
- audit_history

## Core Wealth Objects

- Client
- Household
- Advisor
- RIA
- Broker Dealer
- Trust Company
- Custodian
- Portfolio
- Account
- Investment Policy Statement
- Financial Plan
- Retirement Plan
- Estate Plan
- Trust
- Beneficiary
- Risk Profile
- Goal
- Recommendation
- Trade
- Model Portfolio
- Asset Allocation
- Security
- Fund
- Alternative Investment
- Insurance Policy
- Annuity
- Advisory Agreement
- Brokerage Account
- Billing Event
- Performance Report
- Client Review
- Compliance Review
- Referral

## Account Types

- Individual
- Joint
- IRA
- Roth IRA
- SEP IRA
- SIMPLE IRA
- 401(k)
- 403(b)
- Trust
- Estate
- Custodial
- UTMA/UGMA
- Business Account
- Corporate Account
- Foundation
- Endowment
- Donor-Advised Fund
- HSA
- Brokerage
- Advisory
- Managed Account

## Dispatch Rule

A wealth client must be modeled as a household relationship, not merely an account or portfolio.

## Dispatch Truth Statement

Wealth management objects connect people, goals, assets, accounts, portfolios, products, plans, taxes, risk, fiduciary obligations, and family relationships into one advisory graph.
