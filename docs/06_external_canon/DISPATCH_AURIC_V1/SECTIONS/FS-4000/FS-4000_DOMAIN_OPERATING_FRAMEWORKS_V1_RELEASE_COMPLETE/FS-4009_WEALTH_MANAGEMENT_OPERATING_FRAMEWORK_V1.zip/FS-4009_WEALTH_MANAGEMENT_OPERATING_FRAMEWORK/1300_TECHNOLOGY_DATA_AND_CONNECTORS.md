# Technology, Data & Connectors

## Purpose

This document defines wealth technology, data, and connector priorities.

## Technology Categories

- CRM
- Financial Planning
- Portfolio Management
- Performance Reporting
- Billing
- Trading / Rebalancing
- Custody Platform
- Broker-Dealer Platform
- Risk Profiling
- Document Management
- E-Signature
- Compliance Review
- Marketing Automation
- Data Warehouse
- Client Portal
- Meeting Notes
- AI Platform

## Common Platforms

Examples:
- Salesforce
- Redtail
- Wealthbox
- Orion
- Black Diamond
- Envestnet
- Addepar
- eMoney
- MoneyGuide
- RightCapital
- Morningstar
- Riskalyze / Nitrogen
- DocuSign
- Schwab
- Fidelity
- Pershing
- LPL
- Raymond James
- Cetera
- AssetMark
- SEI

## Data Objects

- client
- household
- account
- holding
- portfolio
- transaction
- performance
- fee
- advisor
- plan
- goal
- recommendation
- document
- compliance review
- referral
- meeting
- task

## Connector Priorities

Tier 1:
- CRM
- custodian exports
- planning system
- document storage
- email/calendar
- spreadsheets
- AI provider

Tier 2:
- portfolio accounting
- performance reporting
- billing
- broker-dealer platform
- e-signature
- compliance platform

Tier 3:
- trading/rebalancing
- risk profiling
- client portal
- tax systems
- insurance platforms
- trust accounting

## AI Opportunities

- data normalization
- householding
- account reconciliation
- meeting note extraction
- client profile enrichment
- review queue generation
- compliance evidence mapping
- referral opportunity detection

## Dispatch Truth Statement

Wealth data is fragmented across advisor tools, custodians, platforms, documents, and communications. Dispatch turns it into household intelligence.
