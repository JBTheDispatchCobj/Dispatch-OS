# Client, Household & Relationship Lifecycle

## Purpose

This document defines wealth client and household lifecycle management.

## Client Object

Fields:

- client_id
- name
- age
- occupation
- employer
- income
- net_worth
- investable_assets
- risk_tolerance
- objectives
- tax_profile
- estate_profile
- insurance_needs
- accounts
- products
- advisor
- service_tier
- communication_preferences
- review_cadence
- life_events
- beneficiaries
- trusted_contacts
- compliance_status

## Household Object

Fields:

- household_id
- primary_client
- spouse_partner
- children
- parents
- businesses
- trusts
- foundations
- accounts
- combined_AUM
- combined_net_worth
- goals
- family_roles
- estate_plan
- succession_plan
- next_generation_relationships
- retention_risk

## Relationship Lifecycle

Lead → Prospect → Discovery → Proposal → Onboarding → Account Opening → Asset Transfer → Plan Creation → Portfolio Implementation → Ongoing Review → Life Event Management → Next Generation Planning → Retention / Transition

## Discovery Framework

Dispatch captures:

- personal background
- family
- business interests
- income sources
- assets
- liabilities
- goals
- concerns
- time horizon
- risk tolerance
- liquidity needs
- tax situation
- estate documents
- insurance
- current advisors
- banking relationships
- lending needs
- philanthropic interests
- decision-makers

## Life Events

- marriage
- divorce
- birth/adoption
- college
- home purchase
- business sale
- inheritance
- job change
- retirement
- death
- disability
- major illness
- liquidity event
- tax event
- relocation
- lawsuit
- market stress

## Relationship KPIs

- client growth
- household growth
- retention
- referrals
- AUM
- AUA
- net flows
- wallet share
- financial plan completion
- review completion
- service tier compliance
- next generation capture
- client satisfaction
- complaint rate

## AI Opportunities

- client briefing
- household summary
- life event detection
- next best action
- review prep
- planning gap detection
- beneficiary review reminder
- referral opportunity detection
- retention risk alert
- meeting follow-up draft

## Dispatch Truth Statement

A wealth relationship is a family, goal, and decision graph. Dispatch must understand who matters, what they own, what they want, what risks exist, and what advice has been given.
