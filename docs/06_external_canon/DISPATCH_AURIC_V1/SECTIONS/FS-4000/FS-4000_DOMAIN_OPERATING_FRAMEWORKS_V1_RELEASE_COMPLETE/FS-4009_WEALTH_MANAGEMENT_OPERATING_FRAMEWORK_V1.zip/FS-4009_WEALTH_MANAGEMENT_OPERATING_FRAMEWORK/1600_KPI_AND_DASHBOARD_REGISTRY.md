# KPI & Dashboard Registry

## Growth KPIs

- AUM
- AUA
- net new assets
- gross inflows
- outflows
- new households
- lost households
- referrals
- referral conversion
- revenue
- fee rate
- advisor production

## Relationship KPIs

- client retention
- household penetration
- review completion
- financial plans completed
- next generation relationships
- wallet share
- client satisfaction
- complaints
- service SLA

## Investment KPIs

- performance
- benchmark variance
- allocation drift
- volatility
- drawdown
- cash drag
- income yield
- realized gains
- tax loss harvesting
- model adherence

## Operations KPIs

- account opening time
- transfer time
- billing accuracy
- billing exceptions
- service queue aging
- custodian exceptions
- report timeliness

## Compliance KPIs

- suitability exceptions
- trade review exceptions
- disclosure delivery
- advertising review
- complaint resolution
- senior investor alerts
- training completion
- books and records completeness

## Dashboards

- Wealth Executive Dashboard
- Advisor Dashboard
- Household Dashboard
- Portfolio Dashboard
- Planning Dashboard
- Compliance Dashboard
- Billing Dashboard
- Referral Dashboard
- Credit Union Wealth Dashboard
- AI Operations Dashboard

## Dispatch Truth Statement

Wealth KPIs must measure trust, service, advice, assets, revenue, compliance, and household progress.
