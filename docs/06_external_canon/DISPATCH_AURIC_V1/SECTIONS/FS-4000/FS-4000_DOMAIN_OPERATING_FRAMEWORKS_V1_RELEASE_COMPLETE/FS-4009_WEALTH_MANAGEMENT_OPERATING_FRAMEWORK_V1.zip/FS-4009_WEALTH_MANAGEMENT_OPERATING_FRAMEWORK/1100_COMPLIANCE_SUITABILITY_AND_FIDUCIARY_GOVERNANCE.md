# Compliance, Suitability & Fiduciary Governance

## Purpose

This document defines wealth compliance, fiduciary, suitability, and supervisory operations.

## Compliance Domains

- Fiduciary Duty
- Reg BI
- Suitability
- Form ADV
- Form CRS
- Advisory Agreements
- Disclosures
- KYC
- AML
- OFAC
- Privacy
- Advertising / Marketing
- Testimonials
- Solicitation / Referrals
- Best Execution
- Trade Review
- Personal Trading
- Gifts and Entertainment
- Outside Business Activities
- Complaints
- Cybersecurity
- Books and Records
- Custody Rule where applicable
- Senior Investor Protection

## Recommendation Object

Fields:
- recommendation_id
- client
- advisor
- product
- rationale
- alternatives
- costs
- risks
- suitability_basis
- fiduciary_basis
- disclosures
- approval_required
- client_acknowledgment
- implementation_status
- review_date

## Compliance Review Object

Fields:
- review_id
- type
- client
- advisor
- account
- transaction
- issue
- severity
- evidence
- reviewer
- status
- remediation
- audit_history

## Supervisory Workflows

- new account review
- trade review
- annuity review
- alternative investment review
- advertising review
- complaint review
- outside business activity review
- correspondence review
- client review monitoring
- fee billing review

## Compliance KPIs

- open reviews
- overdue reviews
- trade exceptions
- suitability exceptions
- complaint count
- advertising review time
- client review completion
- disclosure completion
- Form ADV delivery
- training completion
- senior investor alerts
- OBA exceptions

## AI Opportunities

- recommendation rationale drafting
- disclosure checklist
- trade exception review
- complaint summary
- senior investor risk alert
- advertising review support
- Form ADV/CRS delivery tracking
- suitability gap detection

## Dispatch Truth Statement

Wealth compliance is the evidence layer proving that advice, products, fees, communications, and supervision aligned with client interest and regulatory duties.
