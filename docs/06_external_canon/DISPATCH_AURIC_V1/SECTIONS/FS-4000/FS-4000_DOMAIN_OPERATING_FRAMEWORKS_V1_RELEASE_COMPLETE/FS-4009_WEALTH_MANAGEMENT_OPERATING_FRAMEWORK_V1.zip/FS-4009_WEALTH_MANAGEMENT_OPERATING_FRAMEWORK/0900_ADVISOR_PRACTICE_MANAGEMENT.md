# Advisor Practice Management

## Purpose

This document defines advisor productivity, service models, segmentation, pipeline, and practice operations.

## Advisor Object

Fields:
- advisor_id
- name
- licenses
- registrations
- firm
- branch
- clients
- households
- AUM
- revenue
- production
- service_tier_mix
- pipeline
- referrals
- compliance_status
- review_completion
- client_satisfaction
- growth_goals

## Practice Segmentation

Segments:
- Emerging
- Mass Affluent
- Affluent
- High Net Worth
- Ultra High Net Worth
- Business Owner
- Executive
- Retiree
- Accumulator
- Institutional
- Trust/Fiduciary

## Service Model Object

Fields:
- service_tier
- review_frequency
- planning_scope
- reporting_frequency
- advisor_touchpoints
- team_members
- minimum_AUM
- fee_schedule
- deliverables
- client_expectations

## Practice Management Workflows

- prospecting
- referral follow-up
- discovery
- proposal
- onboarding
- review prep
- annual planning
- client segmentation
- fee review
- service calendar
- succession planning
- book transition
- advisor recruiting

## Advisor KPIs

- AUM
- net new assets
- revenue
- households
- new clients
- retention
- referrals
- reviews completed
- plans completed
- client satisfaction
- compliance exceptions
- pipeline conversion
- production per advisor
- revenue per household
- service capacity

## AI Opportunities

- advisor dashboard
- client review prep
- service calendar automation
- pipeline prioritization
- segmentation analysis
- advisor succession planning
- book optimization
- referral follow-up drafts
- client meeting notes

## Dispatch Truth Statement

Advisor practice management is the operating system for converting trust, advice, relationships, and service capacity into durable enterprise value.
