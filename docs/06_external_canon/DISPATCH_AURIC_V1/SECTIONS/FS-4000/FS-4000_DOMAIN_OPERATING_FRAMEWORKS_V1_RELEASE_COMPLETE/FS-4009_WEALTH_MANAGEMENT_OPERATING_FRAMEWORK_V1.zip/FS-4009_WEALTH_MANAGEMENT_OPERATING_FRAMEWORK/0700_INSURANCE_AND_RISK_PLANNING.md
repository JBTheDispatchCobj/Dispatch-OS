# Insurance & Risk Planning

## Purpose

This document defines insurance and personal risk planning inside wealth management.

## Insurance Product Types

- Life Insurance
- Term Life
- Whole Life
- Universal Life
- Variable Universal Life
- Disability Insurance
- Long-Term Care
- Annuity
- Fixed Annuity
- Variable Annuity
- Indexed Annuity
- Property & Casualty Referral
- Umbrella Liability
- Key Person Insurance
- Buy-Sell Insurance
- Business Overhead Insurance

## Insurance Policy Object

Fields:
- policy_id
- client
- carrier
- product_type
- coverage_amount
- premium
- cash_value
- surrender_value
- beneficiaries
- owner
- insured
- issue_date
- renewal
- riders
- commission
- suitability_status
- review_date

## Risk Planning Areas

- premature death
- disability
- longevity
- long-term care
- liability
- business continuity
- estate liquidity
- key person risk
- healthcare cost risk
- income replacement
- market risk
- tax risk

## Insurance Review Workflow

Discovery → Existing Coverage → Needs Analysis → Gap Analysis → Product Options → Suitability Review → Application → Underwriting → Placement → Annual Review

## Annuity Review

Inputs:
- income need
- liquidity
- fees
- surrender schedule
- guarantees
- rider costs
- tax status
- replacement analysis
- suitability
- client understanding

## KPIs

- insurance reviews completed
- coverage gaps identified
- gaps closed
- policies placed
- premiums
- commissions
- annuity assets
- replacement reviews
- suitability exceptions
- lapse risk

## AI Opportunities

- insurance gap analysis
- policy summary
- beneficiary review
- annuity feature summary
- replacement checklist
- suitability support
- client-friendly explanation
- annual insurance review

## Dispatch Truth Statement

Insurance planning is not product placement. It is the protection layer for household continuity, income, liquidity, estate goals, and business risk.
