# Data Ingestion & Connector Strategy

## Purpose

This document defines how data enters the product.

## Ingestion Types

### Manual Upload

Files:
- PDFs
- Word docs
- Excel
- CSV
- PowerPoint
- images
- emails
- zip files

### Scheduled Export

Sources:
- core reports
- LOS exports
- CRM exports
- accounting reports
- ERP exports
- EHR/RCM reports
- vendor reports
- board packets
- compliance calendars

### Live Connector

Sources:
- Gmail / email
- calendar
- cloud storage
- CRM
- document management
- spreadsheets
- databases
- APIs
- dashboards

### Public / External Data

Sources:
- regulator sites
- call reports
- SEC filings
- state databases
- vendor websites
- startup databases
- market data
- news
- public records

## Ingestion Pipeline

Source → Upload/Connector → Classification → Object Extraction → Entity Resolution → Relationship Mapping → Workflow Routing → Evidence Storage → Dashboard Update

## Classification Labels

- institution profile
- policy
- procedure
- financial statement
- call report
- credit memo
- board packet
- vendor document
- exam request
- regulatory filing
- startup deck
- customer list
- AR aging
- inventory report
- loan package
- portfolio report
- contract
- insurance policy

## Connector Priority Matrix

Tier 1:
- documents
- email/calendar
- spreadsheets/CSV
- CRM
- core exports
- AI providers

Tier 2:
- LOS
- compliance/GRC
- vendor management
- accounting/GL
- fund accounting
- portfolio monitoring
- treasury platform

Tier 3:
- ERP
- EHR/RCM
- market data
- regulator portals
- specialized vendor systems
- real-time APIs

## Data Quality Rules

- preserve source file
- preserve source timestamp
- preserve source owner
- never overwrite without versioning
- map to canonical object
- flag unresolved entities
- flag stale data
- flag missing required fields
- generate evidence trail

## Dispatch Truth Statement

The product should work with messy reality: exports, PDFs, emails, spreadsheets, partial data, and eventually live integrations.
