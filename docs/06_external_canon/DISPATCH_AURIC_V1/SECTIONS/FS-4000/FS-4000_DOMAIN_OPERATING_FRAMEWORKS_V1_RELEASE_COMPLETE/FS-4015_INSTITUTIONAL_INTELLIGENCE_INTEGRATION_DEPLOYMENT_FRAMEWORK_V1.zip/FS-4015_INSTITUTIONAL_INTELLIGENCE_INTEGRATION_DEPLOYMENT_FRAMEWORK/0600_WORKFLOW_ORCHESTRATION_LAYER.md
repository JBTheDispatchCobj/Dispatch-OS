# Workflow Orchestration Layer

## Purpose

This document defines how workflows are routed across domains.

## Workflow Router Inputs

- user request
- institution profile
- object type
- domain
- urgency
- required evidence
- approval need
- regulatory sensitivity
- connected systems
- available data
- output requested

## Workflow Router Output

- domain cartridge
- workflow
- agents
- required objects
- required documents
- steps
- owner
- approval path
- evidence plan
- dashboard updates

## Cross-Domain Workflow Examples

### Fintech Pilot Review

Input:
- startup
- institution
- use case

Route:
- Venture Capital
- Credit Unions
- Regulation
- Vendor Oversight
- Technology Connectors

Output:
- startup profile
- institution readiness
- vendor risk checklist
- pilot plan
- board memo
- success metrics

### Loan Participation Opportunity

Input:
- loan package
- selling institution
- buyer universe

Route:
- Capital Markets
- Commercial Banking
- Private Credit
- Credit Unions
- Regulation

Output:
- participation package
- buyer match
- risk summary
- compliance checklist
- settlement workflow

### Wealth/Insurance Member Opportunity

Input:
- member profile
- life event
- product gaps

Route:
- Wealth Management
- Insurance
- Banking
- Credit Unions
- Compliance

Output:
- opportunity brief
- referral workflow
- consent/disclosure checklist
- advisor/producer match

### Regulatory Exam Request

Input:
- exam request list
- institution profile

Route:
- Regulation
- Banking / Credit Union
- domain-specific cartridge

Output:
- task list
- evidence map
- response drafts
- owner assignments
- board status

## Orchestration Rules

- never execute a regulated workflow without evidence and approval mapping
- always preserve source data
- always identify domain owner
- always create audit trail
- always route external commitments to human approval
- always map outputs to one or more objects

## Dispatch Truth Statement

Workflow orchestration is how institutional intelligence becomes action.
