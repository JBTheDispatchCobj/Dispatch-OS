# Master Object Registry

## Purpose

This document defines the cross-domain master object registry.

## Top-Level Objects

### Institution

Fields:
- institution_id
- name
- type
- charter
- assets
- geography
- regulators
- executives
- vendors
- systems
- products
- risk_profile
- strategic_priorities
- opportunities
- dashboards

### Executive

Fields:
- executive_id
- name
- title
- institution
- responsibilities
- committees
- decision_authority
- relationships
- priorities
- communications
- opportunities
- risk_ownership

### Customer / Member / Client

Fields:
- person_or_business_id
- type
- relationship
- products
- needs
- risk_profile
- opportunities
- documents
- workflows
- consent_status

### Vendor / Partner

Fields:
- vendor_id
- name
- category
- product
- institutions_using
- risk_tier
- compliance_status
- integrations
- contracts
- renewal
- opportunity_links

### Product

Fields:
- product_id
- name
- domain
- institution_owner
- customer_segment
- revenue_model
- regulatory_profile
- workflow_links
- vendor_links
- KPI_links

### Workflow

Fields:
- workflow_id
- name
- domain
- trigger
- owner
- agents
- inputs
- outputs
- evidence
- approvals
- KPIs

### Opportunity

Fields:
- opportunity_id
- institution
- domain
- source_signal
- customer_or_business
- problem
- proposed_solution
- value
- risk
- required_workflows
- owner
- status
- next_action

### Risk

Fields:
- risk_id
- institution
- domain
- category
- description
- severity
- likelihood
- owner
- controls
- evidence
- remediation

### Evidence

Fields:
- evidence_id
- object
- workflow
- owner
- source
- period
- document
- status
- retention
- audit_history

## Object Normalization Rules

- A credit union, bank, CUSO, fintech, vendor, and fund are all Organization objects with different subtypes.
- A member, borrower, client, founder, executive, and owner are all Person objects with different roles.
- A loan, investment, policy, account, and contract are all Financial Relationship objects with different economics and obligations.
- A report, policy, procedure, filing, memo, and deck are all Document objects with different governance rules.
- A task, request, review, approval, remediation, and workflow step are all Action objects.

## Object ID Rules

Format:
- ORG-#####
- PER-#####
- PROD-#####
- WF-#####
- OPP-#####
- RISK-#####
- EVID-#####
- DOC-#####
- AGENT-#####

## Dispatch Truth Statement

The master object registry prevents the product from becoming a folder system. It makes institutional intelligence queryable and executable.
