# Cross-Domain Product Architecture

## Purpose

This document defines the product architecture that turns the FS-4000 volume library into a working institutional intelligence platform.

## Core Architecture

The system has seven layers:

1. Institution Profile Layer
2. Domain Cartridge Layer
3. Object Registry Layer
4. Relationship Graph Layer
5. Workflow Orchestration Layer
6. Agent Workforce Layer
7. Evidence & Governance Layer

## 1. Institution Profile Layer

Stores the canonical profile of each institution.

Objects:
- institution
- charter
- executives
- board
- products
- vendors
- systems
- risk profile
- strategic priorities
- regulatory profile
- market footprint
- known opportunities
- current pain points

## 2. Domain Cartridge Layer

Each FS-4000 volume becomes a cartridge.

Cartridges:
- Banking
- Credit Unions
- Commercial Banking
- Mortgage
- Private Credit
- Private Equity
- Venture Capital
- Capital Markets
- Wealth Management
- Insurance
- Construction Finance
- Manufacturing Finance
- Healthcare Finance
- Regulation / Reporting / Examination

## 3. Object Registry Layer

Maintains canonical object definitions across domains.

Examples:
- Institution
- Executive
- Customer
- Vendor
- Product
- Workflow
- Policy
- Control
- Evidence
- Deal
- Loan
- Investment
- Portfolio
- Relationship
- Opportunity
- Risk
- Report

## 4. Relationship Graph Layer

Connects objects across domains.

Examples:
- Credit Union HAS Vendor
- Vendor ENABLES Product
- Product CREATES Opportunity
- Opportunity REQUIRES Workflow
- Workflow REQUIRES Evidence
- Regulation GOVERNS Product
- Executive OWNS Decision
- Member NEEDS Product
- Startup SOLVES Problem
- CUSO CAN_HOLD Investment

## 5. Workflow Orchestration Layer

Routes requests into executable workflows.

Examples:
- fintech pilot review
- credit opportunity review
- vendor review
- exam evidence request
- wealth referral
- insurance gap detection
- mortgage package review
- construction draw review
- manufacturing borrowing base review
- healthcare revenue cycle review

## 6. Agent Workforce Layer

Routes tasks to governed domain agents.

Examples:
- Obligation Extractor
- Credit Memo Writer
- Vendor Risk Reviewer
- Relationship Brief Agent
- Opportunity Detection Agent
- Board Report Writer
- Investor Matching Agent
- Pilot Readiness Agent

## 7. Evidence & Governance Layer

Preserves evidence, approvals, audit trails, policy links, and decision history.

## Product Principle

Every output must resolve to one of four product actions:

1. Understand
2. Decide
3. Execute
4. Prove

## Dispatch Truth Statement

The integrated product is not a chatbot. It is an institutional intelligence operating system that converts context into governed workflows, decisions, and evidence.
