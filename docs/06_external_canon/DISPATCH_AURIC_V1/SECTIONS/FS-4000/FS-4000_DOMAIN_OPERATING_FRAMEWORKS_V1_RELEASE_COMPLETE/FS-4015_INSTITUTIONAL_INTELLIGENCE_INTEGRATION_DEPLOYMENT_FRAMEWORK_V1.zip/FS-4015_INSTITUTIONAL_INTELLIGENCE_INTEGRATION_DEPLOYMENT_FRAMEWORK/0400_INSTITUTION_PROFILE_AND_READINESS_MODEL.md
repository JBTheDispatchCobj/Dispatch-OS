# Institution Profile & Readiness Model

## Purpose

This document defines the institutional profile and readiness scoring model.

## Institution Profile Sections

1. Identity
2. Charter and Regulation
3. Balance Sheet
4. Products
5. Members / Customers
6. Executives
7. Board / Committees
8. Vendors
9. Core Systems
10. Digital Systems
11. Lending Systems
12. Compliance Stack
13. Wealth / Insurance Relationships
14. Innovation Appetite
15. Strategic Priorities
16. Pain Points
17. Open Risks
18. Opportunities

## Readiness Categories

### Product Readiness

Can the institution support the product operationally?

Signals:
- business owner exists
- workflow exists
- staffing exists
- policy supports it
- vendor/system path exists
- customer/member demand exists

### Compliance Readiness

Can the institution support the product under its regulatory environment?

Signals:
- obligation map
- policy map
- vendor review
- board awareness
- evidence requirements
- complaint path
- controls

### Integration Readiness

Can the product connect to the institution's systems?

Signals:
- core system
- digital banking
- LOS
- CRM
- data export ability
- API availability
- manual import path
- security requirements

### Adoption Readiness

Will the institution actually use it?

Signals:
- executive sponsor
- budget authority
- urgent pain point
- workflow owner
- low training burden
- measurable ROI
- cultural fit

### Investment Readiness

Can the institution invest, participate, or join an SPV/CUSO opportunity?

Signals:
- investment authority
- board appetite
- policy permission
- accreditation / eligibility
- capital availability
- risk appetite
- reporting needs

## Readiness Score Object

Fields:
- score_id
- institution
- product_or_opportunity
- product_readiness
- compliance_readiness
- integration_readiness
- adoption_readiness
- investment_readiness
- blockers
- evidence
- next_actions

## AI Opportunities

- institutional readiness brief
- blocker detection
- executive sponsor recommendation
- policy gap analysis
- vendor/integration map
- adoption playbook
- investment readiness memo

## Dispatch Truth Statement

Readiness is what separates a good idea from an executable institutional opportunity.
