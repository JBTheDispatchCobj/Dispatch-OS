# Agent Routing & Workforce Control

## Purpose

This document defines how agents are selected, governed, and coordinated.

## Agent Routing Inputs

- task type
- domain
- object
- evidence
- sensitivity
- user role
- required output
- approval need
- confidence threshold
- audit requirement

## Agent Classes

### Research Agents

Find, summarize, classify, and map information.

### Analysis Agents

Calculate, compare, score, and explain.

### Workflow Agents

Create tasks, checklists, calendars, status, and routing.

### Drafting Agents

Draft memos, reports, responses, summaries, and board packets.

### Control Agents

Check requirements, evidence, policies, and approvals.

### Monitoring Agents

Detect changes, exceptions, aging, and early warning signals.

## Agent Control Rules

Agents may:
- summarize evidence
- draft documents
- recommend next actions
- classify objects
- identify missing items
- score readiness
- prepare internal memos
- create workflow tasks

Agents may not autonomously:
- approve credit
- approve investments
- communicate with regulators
- file regulatory reports
- commit capital
- bind insurance
- execute trades
- provide legal opinions
- issue final compliance conclusions
- send external commitments
- override policy

## Agent Output Standard

Every agent output must include:

- task performed
- objects used
- evidence used
- confidence
- assumptions
- missing information
- recommended next action
- human approval required
- audit trail

## Routing Examples

Request: “Can this CU pilot this fintech?”
Agents:
- Startup Profile Agent
- Institution Readiness Agent
- Vendor Risk Reviewer
- Compliance Checklist Agent
- Pilot Plan Agent

Request: “Prepare this exam response.”
Agents:
- Exam Request Parser
- Evidence Finder
- Response Drafter
- Compliance Owner Router
- Approval Tracker

Request: “Find wealth/insurance opportunities in this member base.”
Agents:
- Household Segmentation Agent
- Life Event Detection Agent
- Wealth Opportunity Agent
- Insurance Gap Agent
- Referral Compliance Agent

## Dispatch Truth Statement

The agent workforce is powerful only when governed. The platform's credibility depends on routing work to agents without letting agents exceed institutional authority.
