# Opportunity Detection Engine

## Purpose

This document defines how Dispatch detects opportunities across the institutional network.

## Opportunity Sources

- call report data
- institution profile
- vendor stack
- product gaps
- exam findings
- regulatory changes
- executive priorities
- balance sheet signals
- loan portfolio data
- deposit trends
- treasury patterns
- member/customer lifecycle events
- fintech startup capabilities
- capital needs
- market movements
- relationship graph signals
- documents and meeting notes

## Opportunity Types

- fintech pilot
- vendor replacement
- product expansion
- compliance remediation
- lending opportunity
- deposit growth
- treasury management
- mortgage improvement
- wealth referral
- insurance referral
- private credit participation
- loan participation
- capital markets transaction
- CUSO investment
- startup investment
- board reporting improvement
- exam readiness
- AI workflow automation

## Opportunity Object

Fields:
- opportunity_id
- type
- domain
- institution
- source_signal
- problem_statement
- recommended_action
- estimated_value
- estimated_risk
- required_workflow
- required_evidence
- owner
- priority
- status
- next_action
- confidence

## Detection Rules

### Gap Detection

If institution lacks product but peer institutions offer it, create opportunity.

### Pain Detection

If repeated issue, complaint, exam finding, or manual workflow appears, create opportunity.

### Revenue Detection

If member/customer behavior indicates wallet leakage, create opportunity.

### Risk Detection

If obligation has weak evidence or open finding, create remediation opportunity.

### Innovation Detection

If startup solves mapped pain and institution readiness is sufficient, create pilot opportunity.

### Capital Detection

If credit, investment, or participation need matches investor appetite, create capital opportunity.

## Prioritization

Score using:
- value
- urgency
- feasibility
- readiness
- regulatory burden
- integration burden
- sponsor strength
- time to execute
- relationship importance

## AI Opportunities

- opportunity scoring
- next action generation
- executive brief
- ROI estimate
- blocker analysis
- workflow recommendation
- outbound memo generation

## Dispatch Truth Statement

The platform wins when it finds the next institutional action before the institution knows what to ask for.
