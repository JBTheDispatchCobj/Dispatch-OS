# Implementation Sprint Plan

## Purpose

This document defines the sprint plan to convert the FS-4000 library into a working product.

## Sprint 1 — Registry Consolidation

Outputs:
- master object registry JSON
- domain cartridge manifest
- workflow registry
- agent registry
- KPI registry
- relationship taxonomy

Acceptance:
- every volume maps to objects, workflows, agents, dashboards

## Sprint 2 — Institution Profile

Outputs:
- institution profile schema
- sample credit union profile
- executive profile schema
- vendor stack schema
- regulatory profile schema
- readiness score schema

Acceptance:
- one institution can be represented end-to-end

## Sprint 3 — Evidence System

Outputs:
- evidence object
- document classification labels
- evidence-to-control map
- source preservation rules
- audit trail schema

Acceptance:
- uploaded docs can be classified and linked to objects

## Sprint 4 — Workflow Router

Outputs:
- workflow selection rules
- domain router
- workflow templates
- approval rules
- task object schema

Acceptance:
- a user request routes to correct cartridge, workflow, agents, and required evidence

## Sprint 5 — Agent Registry

Outputs:
- agent catalog
- agent permissions
- output standard
- human approval gates
- error/uncertainty rules

Acceptance:
- agents cannot exceed authority and outputs are audit-ready

## Sprint 6 — Opportunity Engine

Outputs:
- opportunity object
- detection rules
- prioritization score
- opportunity dashboard
- executive brief template

Acceptance:
- institution profile produces prioritized opportunities

## Sprint 7 — Fintech Pilot Demo

Outputs:
- startup profile
- CU readiness score
- pilot workflow
- vendor risk checklist
- board memo template

Acceptance:
- one startup can be matched to one institution with pilot plan and governance packet

## Sprint 8 — Exam Readiness Demo

Outputs:
- exam request parser
- evidence map
- response tracker
- finding/remediation workflow
- board status template

Acceptance:
- sample exam request list becomes tasks, evidence, responses, and dashboard

## Sprint 9 — Participation / Capital Markets Demo

Outputs:
- loan package schema
- investor/buyer profile
- matching criteria
- participation workflow
- settlement/reporting checklist

Acceptance:
- one asset can be packaged and matched to potential buyers

## Sprint 10 — Product Packaging

Outputs:
- demo narrative
- onboarding checklist
- pricing hypothesis
- implementation playbook
- sales one-pager
- product architecture deck outline

Acceptance:
- product can be shown, sold, and implemented in a controlled pilot

## Dispatch Truth Statement

The next build phase is not more documentation. It is registry, routing, evidence, demo, and deployment.
