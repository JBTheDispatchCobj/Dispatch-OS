# Cross-Domain Relationship Graph

## Purpose

This document defines how the system connects intelligence across domains.

## Relationship Types

### Organization Relationships

- OWNS
- MANAGES
- REGULATED_BY
- PARTNERS_WITH
- VENDS_TO
- INVESTS_IN
- LENDS_TO
- BORROWS_FROM
- REFERS_TO
- SERVICES
- CUSTODIES
- SPONSORS
- PARTICIPATES_IN

### Person Relationships

- WORKS_AT
- OWNS
- ADVISES
- SERVES
- APPROVES
- REPORTS_TO
- INTRODUCED_BY
- BOARD_MEMBER_OF
- FOUNDED
- GUARANTEES
- BENEFITS_FROM

### Product Relationships

- ENABLED_BY
- SOLD_TO
- USED_BY
- GOVERNS
- REQUIRES
- CREATES_REVENUE
- CREATES_RISK
- SOLVES
- COMPETES_WITH
- INTEGRATES_WITH

### Workflow Relationships

- TRIGGERED_BY
- REQUIRES_EVIDENCE
- REQUIRES_APPROVAL
- ASSIGNED_TO
- PRODUCES
- ESCALATES_TO
- SATISFIES_CONTROL
- CLOSES_FINDING

### Opportunity Relationships

- DETECTED_FROM
- OWNED_BY
- SOLVED_BY
- ROUTED_TO
- DEPENDS_ON
- BLOCKED_BY
- MEASURED_BY

## Graph Examples

### Fintech Pilot

Startup SOLVES Problem  
Problem EXISTS_AT Credit Union  
Credit Union USES Core Vendor  
Startup INTEGRATES_WITH Core Vendor  
Pilot REQUIRES Vendor Review  
Vendor Review REQUIRES Evidence  
Board Report SUMMARIZES Pilot  
Strategic Investment MAY_FOLLOW Pilot

### Manufacturing Relationship

Manufacturer NEEDS Working Capital  
Working Capital Line SECURED_BY AR and Inventory  
AR OWED_BY Customer  
Inventory PROVIDED_BY Supplier  
Treasury Service IMPROVES Cash Conversion  
Owner HAS Wealth Opportunity

### Healthcare Practice

Practice BILLS Payer  
Payer REIMBURSES Claim  
Claim CREATES AR  
AR SUPPORTS Credit Facility  
Provider Productivity DRIVES Revenue  
Equipment SUPPORTS Procedure  
Owner HAS Succession Need

### Regulatory Exam

Regulator EXAMINES Institution  
Exam Request REQUIRES Evidence  
Evidence PROVES Control  
Control SATISFIES Obligation  
Finding CREATES Remediation Plan  
Board Report SUMMARIZES Status

## Graph Queries

The system should answer:

- Which institutions have a problem this startup solves?
- Which vendors create regulatory risk for this product?
- Which executives own this opportunity?
- Which policies control this workflow?
- Which customers fit this lending product?
- Which credit unions could participate in this asset?
- Which exam findings indicate a market need?
- Which relationships create the best introduction path?

## Dispatch Truth Statement

The relationship graph is the moat. It lets the platform see opportunities, risks, and execution paths that individual systems cannot see.
