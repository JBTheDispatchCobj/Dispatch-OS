# Acceptance Tests & Roadmap

## Object Tests

- Can create Institution.
- Can create Executive.
- Can create Vendor.
- Can create Product.
- Can create Workflow.
- Can create Opportunity.
- Can create Risk.
- Can create Evidence.
- Can create Approval.
- Can create Readiness Score.
- Can create Agent.
- Can create Board Report.

## Relationship Tests

- Institution HAS Executive.
- Institution USES Vendor.
- Institution OFFERS Product.
- Product REQUIRES Workflow.
- Workflow REQUIRES Evidence.
- Evidence PROVES Control.
- Opportunity DETECTED_FROM Signal.
- Agent PERFORMS Task.
- Approval AUTHORIZES Output.
- Board Report SUMMARIZES Risk.

## Router Tests

- Fintech pilot request routes to Venture, Credit Union, Vendor Risk, and Regulation.
- Exam request routes to Regulation and Evidence Management.
- Loan participation request routes to Capital Markets, Commercial Banking, Private Credit, and Regulation.
- Wealth referral request routes to Wealth, Insurance, Banking, and Compliance.
- Manufacturing finance request routes to Manufacturing, Commercial Banking, Treasury, and Regulation.
- Healthcare finance request routes to Healthcare, Treasury, Credit, and Compliance.

## Agent Tests

- Opportunity Detection Agent creates prioritized opportunities.
- Institution Profile Agent creates readiness score.
- Evidence Collector maps document to control.
- Workflow Router selects correct workflow.
- Board Report Writer summarizes status.
- Vendor Risk Reviewer creates review brief.
- Pilot Plan Agent creates pilot workflow.

## Demo Acceptance Tests

### Demo 1 — Credit Union Terminal

Passes if:
- profile loads
- vendors map
- obligations map
- opportunities appear
- board summary generates

### Demo 2 — Fintech Pilot

Passes if:
- startup profile generates
- institution readiness score generates
- pilot workflow generates
- vendor/compliance checklist generates
- board memo generates

### Demo 3 — Exam Response

Passes if:
- request list converts to tasks
- evidence links
- responses draft
- status dashboard updates
- remediation workflow starts if finding appears

### Demo 4 — Participation Market

Passes if:
- asset package is standardized
- buyer profile matching runs
- risk summary generates
- compliance checklist appears
- settlement/reporting workflow starts

## Roadmap

Priority 1:
- master registry
- institution profile
- evidence system
- workflow router
- agent permission model

Priority 2:
- opportunity engine
- readiness scoring
- CU terminal demo
- fintech pilot demo
- exam readiness demo

Priority 3:
- capital markets / participation demo
- member wallet expansion demo
- vendor risk demo
- board package generator
- deployment onboarding kit

Priority 4:
- live connectors
- network intelligence
- institutional marketplace
- strategic investment workflows
- cooperative capital network

## Dispatch Truth Statement

The integrated platform is accepted when it can take fragmented institutional context and convert it into structured objects, routed workflows, governed agents, evidence, decisions, and board-ready outputs.
