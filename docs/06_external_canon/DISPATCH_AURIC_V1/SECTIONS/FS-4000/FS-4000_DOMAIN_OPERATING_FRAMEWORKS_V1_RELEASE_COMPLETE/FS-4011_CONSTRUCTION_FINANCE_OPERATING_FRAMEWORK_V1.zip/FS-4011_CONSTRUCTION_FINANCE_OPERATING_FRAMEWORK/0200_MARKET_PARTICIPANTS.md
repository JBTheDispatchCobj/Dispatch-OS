# Market Participants

## Purpose

This document defines the construction finance participant ecosystem.

## Participant Types

- Contractor
- General Contractor
- Subcontractor
- Developer
- Sponsor
- Borrower
- Guarantor
- Architect
- Engineer
- Inspector
- Appraiser
- Title Company
- Surveyor
- Environmental Consultant
- Attorney
- CPA
- Surety
- Insurance Agent
- Equipment Dealer
- Material Supplier
- Municipality
- Planning Department
- Building Department
- Zoning Authority
- Lender
- Credit Union
- Bank
- Corporate Credit Union
- Participation Buyer
- Permanent Lender
- Takeout Lender
- Realtor / Broker
- Tenant
- Buyer

## Contractor Object

Fields:
- contractor_id
- legal_name
- license_status
- trade
- experience
- project_history
- financials
- backlog
- bonding_capacity
- insurance
- equipment
- employees
- subcontractor_network
- bank_relationship
- treasury_services
- credit_facilities
- claims_history
- lien_history
- litigation
- safety_record
- performance_score

## Developer Object

Fields:
- developer_id
- legal_name
- principals
- track_record
- project_history
- equity_capacity
- liquidity
- lender_relationships
- investor_relationships
- market_focus
- entitlement_experience
- execution_score
- default_history

## Surety Object

Fields:
- surety_id
- carrier
- contractor
- bond_capacity
- single_project_limit
- aggregate_limit
- underwriting_status
- bond_history
- claims_history
- relationship_contact

## Relationship Types

- CONTRACTOR_BUILDS Project
- DEVELOPER_SPONSORS Project
- BORROWER_OWNS Project
- LENDER_FINANCES Project
- INSPECTOR_VERIFIES Progress
- TITLE_COMPANY_UPDATES Title
- SUBCONTRACTOR_PERFORMS Work
- SUPPLIER_PROVIDES Materials
- SURETY_BONDS Contractor
- MUNICIPALITY_ISSUES Permit
- TAKEOUT_LENDER_REFINANCES Loan

## AI Opportunities

- participant profile
- contractor performance scoring
- developer track record summary
- subcontractor risk summary
- surety/bonding status
- relationship map
- referral opportunity detection

## Dispatch Truth Statement

Construction finance is multi-party execution risk. Every participant can accelerate, delay, protect, or impair the credit.
