# Construction Finance Agent Workforce

## Relationship Agents

- Contractor Relationship Agent
- Developer Profile Agent
- Treasury Opportunity Agent
- Equipment Finance Opportunity Agent
- Bonding Referral Agent

## Underwriting Agents

- Project Underwriting Agent
- Budget Review Agent
- Sources & Uses Analyst
- Contractor Risk Agent
- Takeout Source Agent
- Credit Memo Writer
- Market Risk Agent

## Draw Agents

- Draw Package Reviewer
- Inspection Summary Agent
- Lien Waiver Agent
- Title Update Agent
- Budget Variance Agent
- Funding Recommendation Agent
- Change Order Agent

## Monitoring Agents

- Project Status Agent
- Permit Tracker
- Insurance Certificate Agent
- Bond Status Agent
- Schedule Risk Agent
- Completion Risk Agent
- Takeout Readiness Agent

## Workout Agents

- Distressed Project Agent
- Collateral Recovery Agent
- Budget Completion Agent
- Sponsor Support Agent
- Legal/Lien Risk Agent

## Governance

Human approval required for:
- credit approval
- draw funding
- change order approval
- contingency use
- collateral release
- lien exception waiver
- title exception waiver
- workout strategy
- charge-off or foreclosure

## Dispatch Truth Statement

Construction finance agents are governed project-control staff that support relationship, underwriting, draws, monitoring, and recovery.
