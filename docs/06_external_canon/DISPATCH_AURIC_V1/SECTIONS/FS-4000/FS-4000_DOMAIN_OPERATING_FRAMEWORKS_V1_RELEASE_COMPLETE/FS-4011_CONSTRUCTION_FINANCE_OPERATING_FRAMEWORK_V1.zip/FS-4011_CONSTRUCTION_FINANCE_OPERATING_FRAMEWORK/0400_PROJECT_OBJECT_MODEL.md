# Project Object Model

## Purpose

This document defines the canonical project object used in construction finance.

## Project Object Fields

- project_id
- name
- project_type
- address
- parcel
- borrower
- sponsor
- contractor
- architect
- engineer
- municipality
- zoning
- permits
- plans
- specifications
- budget
- schedule
- contract
- total_project_cost
- loan_amount
- equity
- contingency
- interest_reserve
- completion_percentage
- draws
- inspections
- change_orders
- liens
- title
- insurance
- bonds
- risks
- takeout
- exit_status

## Project Lifecycle

Concept → Site Control → Entitlement → Plans/Specs → Budget → Financing → Closing → Mobilization → Construction → Draws → Inspections → Completion → CO → Stabilization/Sale/Refi → Closeout

## Project Statuses

- Proposed
- Under Review
- Approved
- Closed
- Pre-Construction
- Active Construction
- Delayed
- Over Budget
- Watchlist
- Completed
- Stabilizing
- Sold
- Refinanced
- Defaulted
- Archived

## Project Risk Fields

- budget_risk
- schedule_risk
- permit_risk
- title_risk
- lien_risk
- contractor_risk
- environmental_risk
- market_risk
- takeout_risk
- completion_risk
- fraud_risk
- insurance_risk

## Project Documents

- purchase agreement
- site control
- plans
- specifications
- construction contract
- permits
- zoning approval
- budget
- sources and uses
- appraisal
- environmental
- title commitment
- survey
- insurance
- bond
- draw requests
- inspection reports
- lien waivers
- CO
- lease/sale/refinance evidence

## AI Opportunities

- project summary
- document completeness
- project risk score
- budget/schedule comparison
- permit checklist
- takeout readiness
- project status report

## Dispatch Truth Statement

The Project Object is the center of construction finance. Every draw, document, participant, risk, and credit decision must resolve back to the project.
