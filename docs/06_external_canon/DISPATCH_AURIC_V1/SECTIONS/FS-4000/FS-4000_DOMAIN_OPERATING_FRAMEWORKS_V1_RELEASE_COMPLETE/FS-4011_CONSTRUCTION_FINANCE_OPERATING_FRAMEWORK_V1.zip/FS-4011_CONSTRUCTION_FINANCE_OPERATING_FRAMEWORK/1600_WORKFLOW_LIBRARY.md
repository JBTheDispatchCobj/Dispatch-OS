# Construction Finance Workflow Library

## Required Workflows

### Contractor Relationship Onboarding

Prospect → Discovery → Financials → Deposits/Treasury → Credit Needs → Relationship Plan

### Project Underwriting

Project Intake → Budget Review → Sponsor Review → Contractor Review → Collateral → Takeout → Credit Memo → Approval

### Construction Loan Closing

Approval → Conditions → Legal Docs → Title → Insurance → Equity → Funding Setup → Closing

### Draw Administration

Draw Request → Document Intake → Budget Review → Inspection → Lien/Title Review → Approval → Funding → Archive

### Change Order

Request → Budget Impact → Schedule Impact → Sponsor Approval → Lender Approval → Budget Update

### Permit Tracking

Requirement → Submission → Approval → Inspection → CO

### Insurance/Bonding Review

Requirement → Certificate/Bond → Review → Exception → Approval → Monitoring

### Project Monitoring

Schedule → Budget → Draws → Inspections → Risks → Takeout → Portfolio Update

### Takeout / Conversion

Completion → CO → Lease/Sale/Refi Evidence → Permanent Loan → Payoff/Conversion → Closeout

### Construction Workout

Delay/Default → Risk Review → Collateral → Budget → Sponsor → Strategy → Recovery

## Workflow KPIs

- cycle time
- exception rate
- draw aging
- inspection timing
- funding timing
- budget variance
- lien exceptions
- permit delays
- takeout readiness
- completion risk

## Dispatch Truth Statement

Construction workflows are the control rails for releasing capital into unfinished collateral.
