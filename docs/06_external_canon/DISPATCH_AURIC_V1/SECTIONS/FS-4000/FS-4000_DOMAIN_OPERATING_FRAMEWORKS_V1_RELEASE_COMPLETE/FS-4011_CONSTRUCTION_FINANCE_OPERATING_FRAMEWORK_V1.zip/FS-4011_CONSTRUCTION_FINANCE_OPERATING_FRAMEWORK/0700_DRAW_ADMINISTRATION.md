# Draw Administration

## Purpose

This document defines construction draw control and funding workflows.

## Draw Request Object

Fields:
- draw_id
- project
- loan
- borrower
- request_number
- request_date
- requested_amount
- approved_amount
- budget_line_items
- prior_draws
- current_draw
- retainage
- contingency_use
- inspection_required
- inspection_status
- lien_waivers
- title_update
- invoices
- approval_status
- funding_status
- wire_details
- audit_history

## Draw Lifecycle

Borrower Request → Document Intake → Budget Review → Inspection → Lien Waiver Review → Title Update → Equity Verification → Approval → Funding → Budget Update → Archive

## Required Draw Evidence

- draw request form
- updated budget
- invoices
- pay applications
- lien waivers
- inspection report
- title update
- proof of equity
- change order approvals
- insurance status
- photos
- contingency approval if used

## Draw Controls

- do not exceed budget line item
- verify work-in-place
- verify prior lien waivers
- confirm no title exceptions
- confirm permits remain valid
- confirm insurance current
- confirm equity contribution
- confirm retainage
- confirm availability
- confirm approval authority

## Draw Exceptions

- missing invoice
- missing lien waiver
- failed inspection
- title exception
- budget overrun
- contingency request
- change order unapproved
- retainage mismatch
- excessive front-loading
- equity shortfall
- expired insurance
- permit issue

## Draw KPIs

- draws requested
- draws funded
- average draw cycle time
- exception rate
- funding delays
- inspection exceptions
- title exceptions
- lien waiver exceptions
- budget overruns
- contingency usage
- retainage held

## AI Opportunities

- draw package review
- missing document detection
- budget line variance
- lien waiver checklist
- inspection summary
- funding recommendation
- exception memo
- draw status update

## Dispatch Truth Statement

Draw administration is the lender's primary control system for construction risk.
