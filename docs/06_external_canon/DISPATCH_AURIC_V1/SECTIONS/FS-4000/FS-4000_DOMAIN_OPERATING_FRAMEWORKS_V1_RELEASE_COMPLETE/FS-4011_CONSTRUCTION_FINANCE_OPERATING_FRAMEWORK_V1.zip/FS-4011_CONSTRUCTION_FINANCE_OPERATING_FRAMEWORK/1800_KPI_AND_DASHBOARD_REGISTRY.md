# KPI & Dashboard Registry

## Relationship KPIs

- contractor relationships
- developer relationships
- deposits
- treasury revenue
- equipment loans
- project loans
- relationship profitability
- repeat projects

## Project KPIs

- active projects
- total project cost
- loan exposure
- completion percentage
- budget variance
- schedule variance
- contingency remaining
- interest reserve remaining
- permits complete
- CO status

## Draw KPIs

- draw requests
- draws funded
- average draw cycle time
- draw exceptions
- funding holds
- retainage
- title exceptions
- lien waiver exceptions
- inspection exceptions

## Risk KPIs

- delayed projects
- over-budget projects
- watchlist projects
- contractor exposure
- sponsor exposure
- maturity risk
- takeout readiness
- lien claims
- insurance exceptions
- default rate
- loss rate

## Dashboards

- Construction Finance Executive Dashboard
- Contractor Relationship Dashboard
- Project Dashboard
- Draw Dashboard
- Budget Dashboard
- Inspection Dashboard
- Lien/Title Dashboard
- Permit Dashboard
- Insurance/Bonding Dashboard
- Portfolio Risk Dashboard
- Takeout Readiness Dashboard

## Dispatch Truth Statement

Construction finance KPIs must show whether capital, budget, schedule, collateral, lien control, and completion remain aligned.
