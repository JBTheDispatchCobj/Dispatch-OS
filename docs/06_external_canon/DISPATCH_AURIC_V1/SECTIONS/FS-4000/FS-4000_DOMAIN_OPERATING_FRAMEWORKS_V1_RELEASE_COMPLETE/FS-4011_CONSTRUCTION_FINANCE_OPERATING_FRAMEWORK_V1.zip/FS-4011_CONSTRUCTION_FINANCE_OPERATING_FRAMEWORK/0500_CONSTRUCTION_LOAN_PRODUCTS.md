# Construction Loan Products

## Purpose

This document defines construction finance product taxonomy.

## Product Types

- Residential Construction Loan
- Custom Home Construction
- Spec Home Line
- Builder Line
- Land Development Loan
- Lot Acquisition Loan
- Acquisition, Development & Construction Loan
- Commercial Construction Loan
- Owner-Occupied Construction Loan
- CRE Construction Loan
- Multifamily Construction Loan
- Tenant Improvement Loan
- Renovation Loan
- Adaptive Reuse Loan
- Bridge-to-Perm Loan
- Construction-to-Permanent Loan
- Equipment Loan
- Contractor Working Capital Line
- Borrowing Base Facility
- Retainage Financing
- Mobilization Financing

## Construction Loan Object

Fields:
- loan_id
- borrower
- project
- product_type
- loan_amount
- total_project_cost
- LTC
- LTV
- term
- interest_rate
- interest_reserve
- repayment_source
- takeout_source
- draw_schedule
- equity_requirement
- collateral
- guarantees
- covenants
- approval_authority
- conditions
- budget
- contingency
- maturity
- extension_options

## Structure Inputs

- project type
- borrower experience
- contractor experience
- pre-sales/pre-leasing
- collateral value
- total project cost
- equity
- guarantor support
- market demand
- takeout source
- budget confidence
- permit status
- title status
- lien risk
- interest reserve adequacy

## Common Covenants

- completion date
- budget adherence
- no additional liens
- equity first
- reporting
- inspection access
- insurance maintenance
- permit compliance
- no material changes
- minimum presales/preleasing
- takeout commitment
- guarantor liquidity

## KPIs

- loans approved
- funded draws
- outstanding exposure
- unused commitments
- LTC
- LTV
- completion percentage
- interest reserve remaining
- budget variance
- maturity risk
- delinquency
- default rate
- loss rate

## AI Opportunities

- structure recommendation
- covenant package
- term sheet draft
- repayment source analysis
- interest reserve adequacy
- takeout source review
- construction loan summary

## Dispatch Truth Statement

A construction loan is a controlled funding mechanism, not a lump-sum advance.
