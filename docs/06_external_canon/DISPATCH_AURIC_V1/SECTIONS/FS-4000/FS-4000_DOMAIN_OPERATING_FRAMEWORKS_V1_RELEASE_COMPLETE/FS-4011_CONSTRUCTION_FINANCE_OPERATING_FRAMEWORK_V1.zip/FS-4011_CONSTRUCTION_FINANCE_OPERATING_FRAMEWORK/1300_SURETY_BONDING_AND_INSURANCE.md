# Surety, Bonding & Insurance

## Purpose

This document defines surety, bonding, and insurance requirements in construction finance.

## Bond Types

- Bid Bond
- Performance Bond
- Payment Bond
- Maintenance Bond
- Supply Bond
- Subdivision Bond
- License and Permit Bond

## Bond Object

Fields:
- bond_id
- surety
- principal
- obligee
- project
- bond_type
- bond_amount
- effective_date
- expiration
- status
- claims
- conditions
- documents

## Insurance Requirements

- builder's risk
- general liability
- workers compensation
- commercial auto
- umbrella
- professional liability
- pollution liability
- property
- equipment
- flood
- course of construction
- lender's loss payable
- additional insured
- waiver of subrogation

## Insurance Certificate Object

Fields:
- certificate_id
- insured
- carrier
- policy
- coverage
- limits
- effective_date
- expiration_date
- certificate_holder
- additional_insured
- lender_loss_payable
- status
- exceptions

## Surety Underwriting Factors

- contractor financials
- working capital
- net worth
- backlog
- project size
- experience
- credit
- claims history
- banking relationship
- owner/principal support
- accounting quality

## Bonding Workflow

Project Need → Surety Review → Bond Request → Underwriting → Bond Issued → Lender Review → Monitoring → Release/Expiration

## KPIs

- bonded projects
- bond capacity
- insurance exceptions
- expired certificates
- claims
- uninsured exposure
- bonding denials
- renewal status

## AI Opportunities

- insurance requirement checklist
- certificate review
- bond status summary
- surety capacity summary
- coverage gap detection
- expiration alerts
- lender insurance compliance memo

## Dispatch Truth Statement

Bonding and insurance are external risk controls that protect completion, payment, collateral, workers, third parties, and lenders.
