# Construction Finance Implementation Guide

## Phase 1 — Setup

- create construction finance business unit
- configure project types
- configure loan products
- configure approval authority
- configure draw rules
- configure inspection requirements
- configure lien/title requirements
- configure insurance/bonding requirements
- configure risk ratings

## Phase 2 — Objects

- contractors
- developers
- borrowers
- projects
- properties
- budgets
- loans
- draws
- inspections
- lien waivers
- title updates
- permits
- change orders
- equipment
- insurance
- bonds

## Phase 3 — Connectors

- LOS
- document storage
- email/calendar
- spreadsheets
- construction loan admin
- inspection platform
- title provider
- appraisal system
- accounting/GL
- core system
- AI provider

## Phase 4 — Workflows

Activate:
- contractor onboarding
- project underwriting
- loan closing
- draw administration
- change order
- permit tracking
- insurance/bonding review
- project monitoring
- takeout/conversion
- workout

## Phase 5 — Agents

Deploy:
- Contractor Relationship Agent
- Project Underwriting Agent
- Budget Review Agent
- Draw Package Reviewer
- Inspection Summary Agent
- Lien Waiver Agent
- Title Update Agent
- Completion Risk Agent

## Phase 6 — Dashboards

Configure:
- executive
- contractor relationship
- project
- draw
- budget
- inspection
- lien/title
- permit
- insurance/bonding
- portfolio risk
- takeout readiness

## Demo Flow

1. Open contractor profile.
2. Show project object.
3. Review budget and sources/uses.
4. Submit draw request.
5. Review inspection report.
6. Match lien waivers.
7. Check title update.
8. Approve or hold funding.
9. Show project dashboard.
10. Generate takeout readiness report.

## Dispatch Truth Statement

Construction finance implementation should begin with project truth, then budget controls, then draw workflow, then lien/title evidence, then portfolio monitoring.
