# Acceptance Tests & Roadmap

## Object Tests

- Can create Contractor.
- Can create Developer.
- Can create Project.
- Can create Construction Loan.
- Can create Budget.
- Can create Budget Line Item.
- Can create Draw Request.
- Can create Inspection Report.
- Can create Lien Waiver.
- Can create Title Update.
- Can create Permit.
- Can create Change Order.
- Can create Equipment Asset.
- Can create Bond.
- Can create Insurance Certificate.

## Relationship Tests

- Contractor BUILDS Project.
- Developer SPONSORS Project.
- Borrower OWNS Project.
- Loan FINANCES Project.
- Budget GOVERNS Draw.
- Inspection VERIFIES Draw.
- Lien Waiver SUPPORTS Funding.
- Title Update CLEARS Funding.
- Permit AUTHORIZES Work.
- Bond PROTECTS Project.
- Insurance COVERS Risk.

## Workflow Tests

- Project underwriting workflow creates credit memo.
- Loan closing workflow tracks conditions.
- Draw workflow detects missing evidence.
- Inspection workflow updates progress.
- Lien/title workflow identifies exceptions.
- Change order workflow updates budget.
- Permit workflow tracks CO.
- Takeout workflow tracks exit.
- Workout workflow creates recovery plan.

## Agent Tests

- Budget Review Agent identifies variance.
- Draw Package Reviewer lists missing documents.
- Inspection Summary Agent summarizes progress.
- Lien Waiver Agent detects unmatched waiver.
- Title Update Agent identifies exception.
- Completion Risk Agent scores project.
- Takeout Readiness Agent creates closeout report.

## Roadmap

Priority 1:
- machine-readable construction object registry
- fixture contractor
- fixture project
- fixture budget
- fixture draw package
- fixture inspection/title/lien set

Priority 2:
- draw workflow
- budget engine
- lien waiver matching
- title update checklist
- permit tracker
- dashboards

Priority 3:
- contractor banking intelligence
- equipment finance extension
- bonding/insurance extension
- distressed project module
- municipal/project data connectors

## Dispatch Truth Statement

The Construction Finance cartridge is accepted when Dispatch can control the release of capital against project progress while preserving budget, lien, title, permit, insurance, and completion evidence.
