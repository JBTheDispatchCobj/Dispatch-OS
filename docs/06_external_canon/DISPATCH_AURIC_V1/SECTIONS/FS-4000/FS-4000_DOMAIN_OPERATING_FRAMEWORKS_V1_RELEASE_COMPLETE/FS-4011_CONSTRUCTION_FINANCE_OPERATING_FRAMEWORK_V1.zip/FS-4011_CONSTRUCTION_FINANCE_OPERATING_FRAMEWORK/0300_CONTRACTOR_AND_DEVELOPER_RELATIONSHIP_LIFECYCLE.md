# Contractor & Developer Relationship Lifecycle

## Purpose

This document defines how institutions originate, manage, and deepen contractor and developer relationships.

## Relationship Lifecycle

Prospect → Discovery → Qualification → Financial Review → Project Review → Deposit/Treasury Onboarding → Credit Facility → Project Financing → Monitoring → Repeat Projects → Strategic Relationship → Watchlist / Exit

## Contractor Discovery

Dispatch captures:

- trade/specialty
- years in business
- owner/principals
- licensing
- bonding
- insurance
- project types
- average project size
- largest completed project
- backlog
- employees
- subcontractor dependence
- equipment
- working capital cycle
- receivables
- payables
- payroll
- job costing system
- accounting quality
- tax status
- lien history
- claims history
- litigation
- safety record
- banking needs

## Developer Discovery

Dispatch captures:

- property type focus
- geography
- track record
- capital partners
- lender history
- entitlement experience
- project pipeline
- equity capacity
- liquidity
- guarantor support
- construction management model
- exit strategy
- leasing/sales capability
- prior delays/defaults

## Relationship Plan Object

Fields:
- plan_id
- contractor_or_developer
- relationship_manager
- current_products
- deposits
- loans
- treasury
- bonding_referrals
- equipment_needs
- project_pipeline
- risk_profile
- profitability
- next_actions
- opportunities
- review_date

## Relationship Opportunities

- business deposits
- payroll account
- ACH
- wire
- remote deposit
- positive pay
- equipment loans
- working capital line
- construction loans
- owner-occupied CRE
- commercial credit card
- merchant services
- insurance/bonding referral
- wealth management for owner
- succession planning
- tax/payment workflow

## KPIs

- contractor relationships
- developer relationships
- deposits
- treasury services
- project loans
- equipment loans
- relationship profitability
- repeat project rate
- lien exceptions
- project performance
- credit losses
- referrals

## AI Opportunities

- contractor profile
- developer profile
- relationship plan
- project pipeline summary
- treasury opportunity detection
- equipment finance opportunity
- owner wealth opportunity
- risk change alert

## Dispatch Truth Statement

A contractor or developer is not just a borrower. It is a recurring operating relationship with deposits, treasury, equipment, project finance, bonding, risk, and owner-level wealth opportunities.
