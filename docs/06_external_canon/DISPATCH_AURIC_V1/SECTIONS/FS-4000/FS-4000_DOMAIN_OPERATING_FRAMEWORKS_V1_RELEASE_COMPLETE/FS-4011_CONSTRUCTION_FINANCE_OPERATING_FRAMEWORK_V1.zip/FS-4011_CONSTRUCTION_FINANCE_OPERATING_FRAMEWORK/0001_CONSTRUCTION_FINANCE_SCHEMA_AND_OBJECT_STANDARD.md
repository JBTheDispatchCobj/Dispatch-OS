# Construction Finance Schema & Object Standard

## Purpose

This document defines canonical construction finance objects used by Dispatch.

## Universal Construction Project Object

Fields:

- project_id
- project_name
- project_type
- sponsor_id
- borrower_id
- contractor_id
- property_id
- location
- scope
- total_project_cost
- loan_amount
- equity_required
- equity_contributed
- contingency
- budget
- sources_and_uses
- permits
- plans_and_specs
- schedule
- completion_percentage
- draw_status
- inspection_status
- lien_status
- title_status
- insurance_status
- bonding_status
- risk_status
- takeout_source
- documents
- workflows
- KPIs
- AI_context
- audit_history

## Core Construction Finance Objects

- Contractor
- Developer
- Sponsor
- Borrower
- Guarantor
- Project
- Property
- Construction Loan
- Construction Budget
- Sources & Uses
- Draw Request
- Inspection Report
- Work-in-Place
- Plans and Specifications
- Permit
- Entitlement
- Change Order
- Contractor Contract
- Subcontractor
- Supplier
- Lien Waiver
- Title Update
- Survey
- Appraisal
- Environmental Report
- Insurance Certificate
- Builder's Risk Policy
- Performance Bond
- Payment Bond
- Completion Guaranty
- Equipment Asset
- Retainage
- Contingency
- Interest Reserve
- Takeout Commitment
- Stabilization Plan

## Project Types

- Residential Construction
- Single-Family Construction
- Spec Home
- Custom Home
- Multifamily
- Commercial Real Estate
- Owner-Occupied Facility
- Industrial
- Retail
- Office
- Mixed-Use
- Medical Office
- Municipal / Public Works
- Infrastructure
- Tenant Improvement
- Renovation
- Adaptive Reuse
- Land Development
- Subdivision
- Contractor Working Capital
- Equipment-Heavy Project

## Dispatch Rule

Construction finance must never release capital solely because a borrower requests a draw. Capital release must connect to budget, inspection, lien control, title status, equity verification, permits, documents, loan availability, and approval authority.

## Dispatch Truth Statement

Construction finance objects connect capital, physical progress, legal control, contractor execution, collateral, budget, and exit risk into one governed operating model.
