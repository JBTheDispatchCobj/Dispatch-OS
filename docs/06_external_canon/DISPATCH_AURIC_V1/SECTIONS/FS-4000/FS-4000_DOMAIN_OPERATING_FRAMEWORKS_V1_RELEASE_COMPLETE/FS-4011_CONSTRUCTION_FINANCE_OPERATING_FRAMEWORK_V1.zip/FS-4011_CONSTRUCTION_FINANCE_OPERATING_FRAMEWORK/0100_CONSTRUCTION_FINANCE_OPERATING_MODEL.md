# Construction Finance Operating Model

## Definition

Construction finance is the institutional process of financing construction activity while controlling completion, collateral, budget, lien, contractor, documentation, and repayment risk.

## Operating Layers

### 1. Relationship Layer

Defines the contractor, developer, sponsor, borrower, guarantor, project owner, subcontractors, vendors, referral sources, and institutional relationship.

### 2. Project Layer

Defines the asset, location, scope, schedule, plans, permits, budget, sources and uses, contracts, inspections, progress, and completion.

### 3. Credit Layer

Defines borrower capacity, contractor capability, guarantor support, collateral, loan structure, interest reserve, equity, DSCR, LTV, LTC, and takeout source.

### 4. Control Layer

Defines draw process, inspection, lien waivers, title updates, retainage, contingency, change orders, legal documents, insurance, bonding, and approval authority.

### 5. Treasury & Working Capital Layer

Defines contractor deposits, payroll, AP/AR, job costing, project cash flow, bonding capacity, equipment needs, treasury services, and liquidity.

### 6. Risk & Monitoring Layer

Defines delay risk, cost overrun, lien risk, fraud risk, permit risk, market risk, contractor default, change order risk, environmental risk, title risk, and takeout risk.

### 7. Completion & Exit Layer

Defines certificate of occupancy, stabilization, lease-up, sale, refinance, permanent loan conversion, project closeout, retainage release, and collateral release.

## Construction Finance Functions

- Relationship Management
- Contractor Banking
- Project Underwriting
- Credit Administration
- Construction Loan Administration
- Draw Administration
- Inspection Coordination
- Title Review
- Lien Waiver Review
- Appraisal Review
- Environmental Review
- Loan Operations
- Portfolio Monitoring
- Special Assets / Workout
- Treasury Management
- Equipment Finance
- Insurance / Bonding Referral
- Compliance
- Risk Management

## Operating Cadence

Daily:
- draw requests
- project exceptions
- title/lien alerts
- inspection schedules
- funding deadlines
- overdraft/liquidity issues
- weather or permit delays

Weekly:
- construction pipeline
- active draws
- project status
- budget variance
- change orders
- contractor exposure
- loan availability

Monthly:
- portfolio dashboard
- projects by completion
- draws funded
- exceptions
- lien waiver status
- title updates
- interest reserve
- takeout readiness
- risk migration

Quarterly:
- concentration review
- contractor performance review
- CRE/project exposure
- board lending package
- policy exceptions
- market conditions

Annual:
- construction lending policy review
- contractor relationship review
- concentration limits
- vendor/inspector review
- market strategy
- loss history

## Dispatch Truth Statement

Construction finance is a real-time control system. The lender is not financing an object that already exists; it is financing execution risk until collateral becomes complete and repayable.
