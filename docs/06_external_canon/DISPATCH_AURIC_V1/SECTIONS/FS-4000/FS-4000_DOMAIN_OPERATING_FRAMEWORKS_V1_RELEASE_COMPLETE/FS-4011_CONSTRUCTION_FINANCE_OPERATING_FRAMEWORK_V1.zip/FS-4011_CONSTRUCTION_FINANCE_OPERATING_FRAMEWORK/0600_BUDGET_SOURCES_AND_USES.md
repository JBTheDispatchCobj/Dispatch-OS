# Budget, Sources & Uses

## Purpose

This document defines construction budgets, sources and uses, equity, contingency, and cost control.

## Budget Object

Fields:
- budget_id
- project
- total_budget
- hard_costs
- soft_costs
- land_cost
- financing_costs
- interest_reserve
- contingency
- retainage
- line_items
- approved_changes
- draws_to_date
- remaining_budget
- variance
- owner

## Budget Line Item Object

Fields:
- line_item_id
- budget
- category
- original_amount
- revised_amount
- prior_draws
- current_draw
- total_drawn
- remaining
- percentage_complete
- variance
- notes

## Common Budget Categories

### Hard Costs

- site work
- excavation
- foundation
- framing
- roofing
- exterior
- windows/doors
- mechanical
- electrical
- plumbing
- HVAC
- drywall
- finishes
- flooring
- landscaping
- paving
- utilities
- equipment

### Soft Costs

- architecture
- engineering
- permits
- legal
- appraisal
- environmental
- title
- insurance
- taxes
- development fee
- leasing/sales
- marketing
- project management
- financing fees
- interest reserve

## Sources & Uses Object

Fields:
- source_id
- project
- borrower_equity
- sponsor_equity
- senior_debt
- mezzanine_debt
- grants
- tax_credits
- seller_financing
- investor_equity
- total_sources
- land
- hard_costs
- soft_costs
- contingency
- fees
- reserves
- total_uses

## Equity Verification

Evidence:
- bank statements
- wire confirmations
- paid invoices
- land equity
- contributed costs
- equity ledger
- accountant confirmation

## Budget Risk

- insufficient contingency
- missing soft costs
- underestimated site work
- material inflation
- labor shortage
- change orders
- interest reserve shortfall
- equity not fully contributed
- developer fee timing
- offsite improvements omitted

## AI Opportunities

- budget completeness review
- sources and uses validation
- variance detection
- contingency adequacy
- interest reserve analysis
- equity verification checklist
- line-item draw review

## Dispatch Truth Statement

The budget is the financial blueprint of the project. If the budget is wrong, the loan structure is wrong.
