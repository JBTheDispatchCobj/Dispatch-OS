# Risk, Compliance & Documentation

## Purpose

This document defines construction finance risk, compliance, controls, and documentation.

## Risk Domains

- completion risk
- cost overrun risk
- contractor risk
- sponsor risk
- equity risk
- lien risk
- title risk
- collateral risk
- market risk
- absorption risk
- takeout risk
- permit risk
- environmental risk
- fraud risk
- documentation risk
- inspection risk
- insurance risk
- concentration risk

## Compliance Areas

- lending policy
- appraisal rules
- environmental diligence
- flood determination
- fair lending where applicable
- HMDA where applicable
- RESPA/TILA where applicable
- UDAAP
- beneficial ownership
- BSA/KYB
- state construction lending rules
- lien laws
- title insurance requirements
- records retention
- adverse action where applicable

## Required Documents

- application
- credit memo
- borrower financials
- guarantor financials
- project budget
- sources and uses
- plans/specs
- permits
- construction contract
- appraisal
- environmental
- title commitment
- survey
- insurance
- bond
- loan agreement
- note
- mortgage/deed of trust
- security agreement
- completion guaranty
- draw agreement
- inspection reports
- lien waivers
- CO
- takeout evidence

## Control Object

Fields:
- control_id
- project
- risk
- requirement
- evidence
- frequency
- owner
- status
- exception
- remediation

## AI Opportunities

- documentation checklist
- policy exception detection
- environmental summary
- flood checklist
- lien law checklist
- compliance evidence mapping
- credit file completeness review

## Dispatch Truth Statement

Construction finance compliance is the evidence that the institution controlled a loan whose collateral was being created over time.
