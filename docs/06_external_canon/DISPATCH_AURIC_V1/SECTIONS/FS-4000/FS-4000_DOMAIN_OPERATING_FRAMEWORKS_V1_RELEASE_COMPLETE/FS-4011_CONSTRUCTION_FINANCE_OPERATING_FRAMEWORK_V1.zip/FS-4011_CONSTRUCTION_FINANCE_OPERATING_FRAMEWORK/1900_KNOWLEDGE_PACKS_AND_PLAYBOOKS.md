# Knowledge Packs & Playbooks

## Knowledge Packs

### Construction Finance Foundation Pack

- terminology
- project taxonomy
- participant taxonomy
- product taxonomy
- workflow maps
- KPI definitions

### Draw Administration Pack

- draw checklist
- inspection
- lien waivers
- title updates
- budget controls
- funding approval

### Contractor Banking Pack

- contractor cash cycle
- deposits
- treasury
- working capital
- equipment
- bonding referrals

### Project Underwriting Pack

- sponsor review
- contractor review
- budget review
- takeout review
- collateral review
- credit memo

### Lien & Title Pack

- lien waiver types
- title updates
- mechanic liens
- legal control
- exception handling

### Permits & Entitlements Pack

- zoning
- permits
- inspections
- CO
- municipal conditions

### Insurance & Bonding Pack

- builder's risk
- GL
- workers comp
- surety
- certificates
- coverage gaps

## Playbooks

- Contractor Onboarding Playbook
- Construction Loan Underwriting Playbook
- Draw Review Playbook
- Budget Variance Playbook
- Change Order Playbook
- Lien Waiver Playbook
- Permit Tracking Playbook
- Takeout Readiness Playbook
- Distressed Construction Loan Playbook
- Contractor Treasury Buildout Playbook
- Equipment Finance Playbook

## Dispatch Truth Statement

Construction finance knowledge packs turn project control expertise into repeatable lending execution.
