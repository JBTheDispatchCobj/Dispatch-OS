# Contractor Banking, Treasury & Working Capital

## Purpose

This document defines the banking relationship surrounding contractors and construction businesses.

## Contractor Banking Products

- Business Checking
- Payroll Account
- Tax Account
- Operating Account
- Project Account
- Escrow Account
- ACH
- Wire
- Remote Deposit
- Positive Pay
- Business Credit Card
- Equipment Loan
- Working Capital Line
- ABL
- Invoice Finance
- Merchant Services
- Payroll Services
- Owner Wealth Referral
- Insurance/Bonding Referral

## Working Capital Object

Fields:
- contractor
- cash
- receivables
- payables
- inventory
- WIP
- backlog
- payroll
- tax_obligations
- line_availability
- liquidity
- borrowing_base
- covenant_status
- stress_status

## Contractor Cash Cycle

Bid → Contract → Mobilization → Materials → Labor → Pay Application → Retainage → Collection → Closeout

## Contractor Risks

- slow collections
- retainage drag
- payroll pressure
- tax arrears
- project concentration
- underbid jobs
- change order disputes
- bonding constraints
- equipment downtime
- subcontractor issues
- fraud
- commingled project funds

## Treasury Opportunities

- project account structure
- positive pay
- ACH payroll
- wire controls
- cash forecasting
- vendor payments
- tax reserve account
- retainage tracking
- receivables monitoring
- integrated AP/AR

## KPIs

- deposits
- average balances
- line utilization
- borrowing base availability
- receivables aging
- payables aging
- WIP
- backlog
- payroll volume
- treasury fee income
- overdrafts
- NSF events
- tax delinquencies

## AI Opportunities

- working capital summary
- contractor cash forecast
- receivables aging alert
- project account recommendation
- treasury needs assessment
- tax reserve reminder
- deposit opportunity detection
- payment fraud risk alert

## Dispatch Truth Statement

Contractor banking is the operating account layer beneath construction finance. Understanding the contractor's cash cycle can prevent credit losses before the project fails.
