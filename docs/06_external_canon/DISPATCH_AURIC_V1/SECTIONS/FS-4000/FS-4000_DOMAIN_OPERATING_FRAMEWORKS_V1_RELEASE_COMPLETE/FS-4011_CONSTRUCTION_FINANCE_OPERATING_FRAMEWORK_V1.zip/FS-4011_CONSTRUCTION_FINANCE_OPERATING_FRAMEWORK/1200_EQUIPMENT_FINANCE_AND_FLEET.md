# Equipment Finance & Fleet

## Purpose

This document defines equipment finance and fleet operations for construction-related borrowers.

## Equipment Asset Object

Fields:
- equipment_id
- borrower
- type
- make
- model
- year
- serial_number
- purchase_price
- current_value
- appraised_value
- loan_balance
- lien_status
- insurance
- location
- utilization
- maintenance
- condition
- resale_value

## Equipment Product Types

- Equipment Loan
- Equipment Lease
- Capital Lease
- Operating Lease
- Fleet Finance
- Titled Vehicle Loan
- Yellow Iron Finance
- Rental Fleet Line
- Vendor Finance
- Refinance
- Sale-Leaseback

## Equipment Categories

- trucks
- trailers
- excavators
- loaders
- bulldozers
- cranes
- forklifts
- skid steers
- paving equipment
- concrete equipment
- generators
- compressors
- tools
- specialty vehicles

## Underwriting Factors

- borrower cash flow
- equipment purpose
- useful life
- resale market
- utilization
- collateral value
- maintenance history
- insurance
- title/lien
- vendor
- operator capability
- project dependency

## Fleet Monitoring

- title
- insurance
- location
- maintenance
- utilization
- condition
- resale value
- lien perfection
- replacement schedule

## KPIs

- equipment exposure
- LTV
- utilization
- collateral exceptions
- insurance exceptions
- title exceptions
- delinquency
- repossessions
- recovery
- resale value variance

## AI Opportunities

- equipment valuation summary
- fleet inventory review
- insurance/title exception detection
- replacement need forecast
- utilization analysis
- collateral monitoring

## Dispatch Truth Statement

Equipment finance supports the productive capacity of contractors. The equipment is both collateral and operating infrastructure.
