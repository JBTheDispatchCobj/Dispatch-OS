# Technology, Data & Connectors

## Purpose

This document defines the technology stack and connector priorities for construction finance.

## Technology Categories

- LOS
- Core Banking
- CRM
- Construction Loan Administration
- Draw Management
- Inspection Platform
- Document Management
- Title Platform
- Appraisal Platform
- Environmental Reports
- Accounting / GL
- Contractor Accounting
- Job Costing
- Project Management
- Treasury Platform
- Equipment Finance System
- Insurance Tracking
- BI Dashboard
- AI Platform

## Data Objects

- contractor
- developer
- project
- loan
- budget
- line item
- draw
- inspection
- photo
- lien waiver
- title update
- permit
- change order
- invoice
- subcontractor
- equipment
- insurance
- bond
- KPI

## Connector Priorities

Tier 1:
- document storage
- email/calendar
- spreadsheet/CSV
- LOS
- core exports
- CRM
- AI provider

Tier 2:
- construction loan administration
- inspection vendors
- title companies
- appraisal systems
- accounting/GL
- treasury platform

Tier 3:
- contractor accounting systems
- project management platforms
- municipal permit portals
- insurance tracking
- equipment valuation
- UCC/lien search

## Data Quality Rules

- every draw must link to project and budget
- every inspection must link to draw
- every lien waiver must link to invoice/payee
- every title update must link to project
- every permit must link to project
- every change order must update budget
- every equipment asset must link to borrower and lien

## AI Opportunities

- data room/project file indexing
- draw package classification
- permit data extraction
- invoice/waiver matching
- project status dashboard
- budget variance analysis
- connector exception summary

## Dispatch Truth Statement

Construction finance data lives across lender systems, title files, inspectors, borrowers, contractors, municipalities, and spreadsheets. Dispatch makes it controllable.
