# Lien Waivers, Title & Legal Control

## Purpose

This document defines lien, title, legal control, and collateral protection in construction finance.

## Lien Waiver Object

Fields:
- waiver_id
- project
- contractor
- subcontractor
- supplier
- amount
- period
- conditional_or_unconditional
- partial_or_final
- related_invoice
- draw_number
- signed_date
- notarized_if_required
- status
- exception

## Title Update Object

Fields:
- title_update_id
- project
- title_company
- effective_date
- exceptions
- liens
- endorsements
- pending_items
- mechanic_lien_status
- insured_amount
- lender_coverage
- status

## Legal Control Documents

- construction mortgage/deed of trust
- assignment of rents
- security agreement
- UCC
- construction loan agreement
- completion guaranty
- payment guaranty
- indemnity
- disbursement agreement
- title policy
- endorsements
- lien waivers
- contractor consent
- assignment of contracts
- architect consent
- plans/specs assignment

## Lien Risk Events

- unpaid subcontractor
- unpaid supplier
- missing waiver
- conditional waiver unresolved
- notice of lien
- mechanic's lien filing
- title exception
- dispute over work
- change order dispute
- retainage dispute

## Lien Review Workflow

Pay App → Subcontractor/Supplier List → Waiver Collection → Title Update → Exception Review → Funding Approval → Archive

## KPIs

- lien waivers received
- waiver exceptions
- title exceptions
- mechanic liens
- funding holds
- legal exceptions
- unresolved subcontractor disputes
- title update cycle time

## AI Opportunities

- lien waiver matching
- title exception summary
- waiver completeness check
- legal exception alert
- subcontractor payment risk
- funding hold recommendation
- closing/legal checklist

## Dispatch Truth Statement

Construction collateral can be impaired by people who are not borrowers. Lien and title control protect the lender from hidden claims against the project.
