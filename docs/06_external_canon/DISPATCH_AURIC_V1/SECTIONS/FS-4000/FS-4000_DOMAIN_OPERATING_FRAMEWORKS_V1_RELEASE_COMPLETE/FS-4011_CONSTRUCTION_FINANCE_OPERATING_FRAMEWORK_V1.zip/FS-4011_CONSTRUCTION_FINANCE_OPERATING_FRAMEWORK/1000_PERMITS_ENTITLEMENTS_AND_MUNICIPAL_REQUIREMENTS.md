# Permits, Entitlements & Municipal Requirements

## Purpose

This document defines permits, entitlements, zoning, approvals, and municipal requirements.

## Permit Object

Fields:
- permit_id
- project
- municipality
- permit_type
- application_date
- issue_date
- expiration_date
- status
- inspections_required
- conditions
- fees
- responsible_party
- documents

## Entitlement Object

Fields:
- entitlement_id
- project
- zoning
- use
- approvals
- variances
- planning_commission
- city_council
- public_hearing
- conditions
- expiration
- status

## Approval Types

- zoning approval
- variance
- conditional use permit
- building permit
- demolition permit
- grading permit
- utility permit
- stormwater approval
- environmental approval
- fire marshal approval
- health department approval
- occupancy permit
- certificate of occupancy

## Municipal Risk

- permit delay
- zoning denial
- public opposition
- utility delay
- inspection failure
- code violation
- occupancy delay
- expired permit
- unapproved change
- offsite improvement requirement

## Permit Workflow

Requirement Map → Application → Submission → Review → Conditions → Approval → Inspection Schedule → Final Approval → Certificate of Occupancy

## KPIs

- permits required
- permits issued
- permit delays
- inspection failures
- CO status
- municipal conditions
- approval cycle time
- expired permits
- code exceptions

## AI Opportunities

- permit checklist
- municipal requirement summary
- entitlement risk summary
- inspection schedule tracker
- CO readiness checklist
- permit delay alert
- public approval timeline

## Dispatch Truth Statement

Permits and entitlements are legal permission to create the collateral. Without them, construction finance is exposed to delay, cost, and completion risk.
