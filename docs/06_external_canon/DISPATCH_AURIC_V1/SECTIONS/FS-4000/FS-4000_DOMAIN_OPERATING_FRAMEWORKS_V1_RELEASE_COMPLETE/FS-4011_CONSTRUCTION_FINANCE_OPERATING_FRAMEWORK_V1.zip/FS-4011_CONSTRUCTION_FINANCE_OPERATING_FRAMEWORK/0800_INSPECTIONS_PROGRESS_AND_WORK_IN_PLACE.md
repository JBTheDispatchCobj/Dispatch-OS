# Inspections, Progress & Work-in-Place

## Purpose

This document defines inspection, progress verification, and work-in-place monitoring.

## Inspection Object

Fields:
- inspection_id
- project
- inspector
- inspection_date
- requested_draw
- observed_work
- completion_percentage
- line_item_progress
- photos
- issues
- recommended_funding
- exceptions
- reinspection_required
- report

## Work-in-Place Object

Fields:
- WIP_id
- project
- line_item
- percentage_complete
- value_complete
- prior_value
- current_value
- variance
- inspector_notes
- confidence
- photos

## Inspection Types

- pre-closing site inspection
- foundation inspection
- framing inspection
- mechanical/electrical/plumbing inspection
- progress inspection
- draw inspection
- final inspection
- certificate of occupancy verification
- reinspection
- post-completion inspection

## Progress Risks

- inflated progress
- poor workmanship
- unapproved substitutions
- incomplete work
- weather delay
- material delay
- labor shortage
- failed inspection
- hidden defects
- nonconforming work
- abandoned site

## Progress Monitoring Workflow

Draw Request → Inspection Order → Site Visit → Photo Evidence → WIP Estimate → Exception Notes → Funding Recommendation → Archive

## KPIs

- completion percentage
- inspection cycle time
- failed inspections
- reinspection rate
- WIP variance
- progress vs schedule
- progress vs draws
- project delay
- funding withheld
- photo evidence completeness

## AI Opportunities

- inspection report summary
- progress vs budget analysis
- progress vs schedule alert
- photo evidence labeling
- exception detection
- WIP confidence scoring
- borrower progress update
- board/committee project summary

## Dispatch Truth Statement

Work-in-place is the bridge between physical construction and credit availability.
