# Acceptance Tests & Roadmap

## Object Tests

- Can create Carrier.
- Can create Agency.
- Can create Producer.
- Can create Policyholder.
- Can create Policy.
- Can create Coverage.
- Can create Premium.
- Can create Commission.
- Can create Claim.
- Can create Renewal.
- Can create Referral.
- Can create License.
- Can create Appointment.
- Can create Compliance Review.

## Relationship Tests

- Carrier ISSUES Policy.
- Producer SELLS Policy.
- Agency CONTRACTS_WITH Carrier.
- Policyholder OWNS Policy.
- Insured COVERED_BY Policy.
- Claim FILED_UNDER Policy.
- Premium PAID_FOR Policy.
- Commission GENERATED_BY Premium.
- Referral SOURCED_BY Institution.
- License AUTHORIZES Producer.

## Workflow Tests

- Risk discovery workflow identifies gap.
- Referral workflow routes to producer.
- Quote-to-bind workflow issues policy.
- Renewal workflow tracks expiration.
- Claim workflow creates claim file.
- Commission workflow reconciles statement.
- Licensing workflow verifies authority.

## Agent Tests

- Coverage Gap Agent identifies missing coverage.
- Quote Prep Agent creates carrier-ready summary.
- Policy Summary Agent explains coverage.
- Claim Intake Agent summarizes loss.
- Commission Reconciliation Agent detects mismatch.
- Licensing Monitor flags expired license.
- Suitability Review Agent checks annuity recommendation.

## Roadmap

Priority 1:
- machine-readable insurance object registry
- fixture household insurance profile
- fixture business insurance profile
- fixture referral workflow
- fixture policy and claim

Priority 2:
- workflows
- dashboards
- agents
- commission reconciliation
- license monitoring

Priority 3:
- credit union insurance program economics
- carrier appetite engine
- claims intelligence engine
- embedded insurance triggers
- insurtech vendor marketplace

## Dispatch Truth Statement

The Insurance cartridge is accepted when Dispatch can connect risk, coverage, policyholder, carrier, producer, premium, claim, compliance, referral, and relationship economics into one institutional operating system.
