# Insurance Schema & Object Standard

## Purpose

This document defines canonical insurance objects used by Dispatch.

## Universal Insurance Policy Object

Fields:

- policy_id
- policy_number
- carrier_id
- agency_id
- producer_id
- policyholder_id
- insured_ids
- product_type
- line_of_business
- coverage
- limits
- deductibles
- riders
- exclusions
- endorsements
- effective_date
- expiration_date
- renewal_date
- premium
- billing_status
- commission
- underwriting_status
- claim_status
- compliance_status
- documents
- workflows
- KPIs
- AI_context
- audit_history

## Core Insurance Objects

- Carrier
- Agency
- Broker
- Producer
- MGA
- MGU
- Reinsurer
- Policyholder
- Insured
- Beneficiary
- Policy
- Coverage
- Rider
- Endorsement
- Exclusion
- Premium
- Commission
- Claim
- Adjuster
- Loss Event
- Reserve
- Underwriting File
- Quote
- Application
- Renewal
- Cancellation
- Reinstatement
- Referral
- Compliance Review
- License
- Appointment
- Product Shelf

## Product Families

- Life Insurance
- Annuities
- Disability Insurance
- Long-Term Care
- Health Supplemental
- Property & Casualty
- Homeowners
- Auto
- Umbrella
- Commercial Property
- General Liability
- Workers Compensation
- Professional Liability
- Cyber Insurance
- Directors & Officers
- Credit Insurance
- Debt Protection
- GAP
- Warranty
- Collateral Protection
- Mortgage Protection

## Dispatch Rule

Insurance must be modeled as risk, coverage, contract, premium, distribution, compliance, claims, and relationship context—not merely as a policy record.

## Dispatch Truth Statement

Insurance objects connect customers, risks, carriers, coverages, premiums, producers, claims, regulations, and protection outcomes into one operating graph.
