# KPI & Dashboard Registry

## Sales KPIs

- referrals
- quotes
- applications
- policies issued
- quote-to-bind
- premium
- commission
- cross-sell
- producer productivity
- channel conversion

## Policy KPIs

- policy count
- in-force premium
- renewals
- retention
- lapse rate
- cancellations
- reinstatements
- endorsements
- service requests

## Claims KPIs

- claims count
- frequency
- severity
- loss ratio
- closure time
- reserve accuracy
- denied claims
- reopened claims
- subrogation recovery
- customer satisfaction

## Compliance KPIs

- licenses current
- appointments current
- CE completion
- suitability exceptions
- replacement exceptions
- complaints
- disclosure completion
- regulatory findings

## Finance KPIs

- earned premium
- unearned premium
- commission revenue
- renewal commission
- chargebacks
- billing exceptions
- producer payout accuracy
- referral attribution

## Dashboards

- Insurance Executive Dashboard
- Agency Dashboard
- Producer Dashboard
- Referral Dashboard
- Policyholder Dashboard
- Renewal Dashboard
- Claims Dashboard
- Commission Dashboard
- Compliance Dashboard
- Credit Union / Bank Insurance Dashboard

## Dispatch Truth Statement

Insurance KPIs must show growth, protection, retention, claims, compliance, and economics.
