# Reinsurance & Risk Transfer

## Purpose

This document defines reinsurance, risk sharing, and capital protection.

## Reinsurance Types

- Treaty Reinsurance
- Facultative Reinsurance
- Quota Share
- Surplus Share
- Excess of Loss
- Catastrophe Cover
- Stop Loss
- Aggregate Excess
- Risk Pool
- Fronting Arrangement
- Captive Insurance
- Retrocession

## Reinsurance Object

Fields:
- reinsurance_id
- cedent
- reinsurer
- treaty_type
- covered_business
- attachment_point
- limit
- retention
- cession_percentage
- premium
- effective_date
- expiration_date
- claims_reporting
- collateral
- accounting
- documents

## Risk Transfer Workflow

Portfolio Review → Exposure Analysis → Reinsurance Need → Broker/Market Review → Terms → Placement → Documentation → Premium → Claims Reporting → Renewal

## Captive / Risk Pool Object

Fields:
- entity
- participants
- covered_risks
- capital
- premiums
- claims
- reserves
- reinsurance
- governance
- reporting

## KPIs

- ceded premium
- retained risk
- loss recovery
- reinsurance recoverables
- attachment utilization
- catastrophe exposure
- capital relief
- reinsurer credit risk
- treaty profitability

## AI Opportunities

- exposure summary
- treaty summary
- claims recovery tracker
- renewal briefing
- reinsurance structure comparison
- risk pool analysis

## Dispatch Truth Statement

Reinsurance is insurance for the insurance balance sheet. Dispatch must model it as capital protection, exposure transfer, and contractual recovery.
