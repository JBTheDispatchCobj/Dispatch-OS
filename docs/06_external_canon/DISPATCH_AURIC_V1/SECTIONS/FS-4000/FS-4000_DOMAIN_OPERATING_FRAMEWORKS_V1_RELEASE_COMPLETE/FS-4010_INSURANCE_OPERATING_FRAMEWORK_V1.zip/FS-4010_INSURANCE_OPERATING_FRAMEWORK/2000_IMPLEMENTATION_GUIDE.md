# Insurance Implementation Guide

## Phase 1 — Setup

- create insurance business unit
- configure agency/carrier model
- configure producer roles
- configure product taxonomy
- configure states and license rules
- configure referral sources
- configure commission rules
- configure compliance model

## Phase 2 — Objects

- policyholders
- households
- businesses
- producers
- carriers
- policies
- coverages
- premiums
- commissions
- claims
- renewals
- referrals
- licenses
- appointments

## Phase 3 — Connectors

- CRM
- document storage
- email/calendar
- agency management system
- carrier statements
- quoting platform
- claims system
- e-signature
- compliance/licensing
- bank/credit union referral data

## Phase 4 — Workflows

Activate:
- risk discovery
- referral
- quote-to-bind
- policy issuance
- renewal review
- endorsement
- claim
- commission reconciliation
- producer licensing

## Phase 5 — Agents

Deploy:
- Insurance Opportunity Agent
- Coverage Gap Agent
- Quote Prep Agent
- Renewal Review Agent
- Claim Intake Agent
- Commission Reconciliation Agent
- Licensing Monitor
- Suitability Review Agent

## Phase 6 — Dashboards

Configure:
- executive
- agency
- producer
- policyholder
- referral
- renewal
- claims
- commission
- compliance
- credit union/bank insurance

## Demo Flow

1. Open member/customer profile.
2. Detect protection gaps.
3. Create insurance referral.
4. Generate risk discovery summary.
5. Compare products/carriers.
6. Track quote-to-bind.
7. Issue policy.
8. Reconcile commission.
9. Handle claim intake.
10. Show insurance dashboard.

## Dispatch Truth Statement

Insurance implementation begins with risk and relationship truth, then connects products, carriers, producers, policies, claims, and economics.
