# Product Taxonomy

## Purpose

This document defines insurance product categories.

## Life Insurance

- Term Life
- Whole Life
- Universal Life
- Variable Universal Life
- Indexed Universal Life
- Survivorship Life
- Final Expense
- Group Life
- Key Person Life
- Buy-Sell Life
- Mortgage Protection

## Annuities

- Fixed Annuity
- Variable Annuity
- Indexed Annuity
- Immediate Annuity
- Deferred Annuity
- Qualified Longevity Annuity
- Registered Index-Linked Annuity

## Health / Income Protection

- Disability Income
- Long-Term Disability
- Short-Term Disability
- Long-Term Care
- Hybrid Life/LTC
- Critical Illness
- Accident
- Hospital Indemnity
- Medicare Supplement where applicable

## Personal P&C

- Homeowners
- Renters
- Condo
- Auto
- Motorcycle
- Boat
- RV
- Umbrella
- Flood
- Earthquake
- Personal Articles
- Pet Insurance

## Commercial Lines

- Commercial Property
- General Liability
- Business Owner Policy
- Workers Compensation
- Commercial Auto
- Professional Liability
- E&O
- D&O
- Employment Practices Liability
- Cyber
- Crime
- Inland Marine
- Builder's Risk
- Surety / Bonds
- Key Person
- Business Interruption

## Credit / Collateral Insurance

- Debt Protection
- Credit Life
- Credit Disability
- GAP
- Warranty
- Collateral Protection
- Mortgage Insurance
- Force-Placed Insurance

## Product Object Fields

- product_id
- carrier
- line
- coverage
- eligibility
- underwriting
- pricing
- limits
- deductibles
- exclusions
- riders
- commissions
- surrender_terms
- suitability_requirements
- disclosures
- renewal_rules
- claims_process

## AI Opportunities

- product comparison
- coverage explanation
- suitability checklist
- premium comparison
- policy summary
- rider explanation
- product shelf analysis

## Dispatch Truth Statement

Insurance products are contractual protection systems. Each product must be understood through coverage, exclusions, pricing, risk, distribution, service, and compliance.
