# Credit Union / Bank Insurance Integration

## Purpose

This document defines how insurance integrates into credit unions, banks, lending, wealth, and member/customer relationships.

## Integration Models

- Referral Partnership
- Owned Agency
- CUSO Insurance Agency
- Bank Insurance Agency
- Embedded Insurance Marketplace
- Wealth Insurance Desk
- Lending Protection Products
- Collateral Protection Program
- Financial Wellness Protection Review
- Business Insurance Referral Desk

## Credit Union Insurance Opportunities

- member life insurance
- debt protection
- GAP
- warranty
- collateral protection
- homeowners insurance
- auto insurance
- disability
- long-term care
- annuities
- business owner insurance
- commercial insurance
- key person
- buy-sell
- cyber for business members

## Trigger Events

- new loan
- mortgage application
- auto loan
- business loan
- HELOC
- new child
- home purchase
- retirement planning
- business formation
- commercial loan collateral review
- wealth review
- beneficiary review
- insurance expiration
- claim event

## Insurance Opportunity Object

Fields:
- opportunity_id
- customer/member
- trigger
- risk_gap
- product_category
- referral_source
- producer
- consent_status
- disclosure_status
- expected_premium
- expected_commission
- status
- outcome

## Governance Requirements

- referral disclosures
- licensing boundaries
- compensation disclosures
- privacy/consent
- suitability where applicable
- vendor/carrier oversight
- complaint handling
- board/program oversight
- compliance monitoring

## KPIs

- insurance referrals
- conversion
- premium
- commission
- non-interest income
- protection gaps closed
- member retention
- loan-attached products
- wealth-attached products
- business insurance referrals

## AI Opportunities

- insurance gap detection
- referral trigger monitoring
- consent workflow
- branch/team prompts
- business member insurance scan
- lending collateral insurance review
- non-interest income dashboard

## Dispatch Truth Statement

For credit unions and banks, insurance is a protection and relationship-depth layer, not just ancillary revenue.
