# Distribution, Agency & Referral Models

## Purpose

This document defines how insurance products reach customers.

## Distribution Models

- Captive Agency
- Independent Agency
- Broker
- MGA Program
- Direct-to-Consumer
- Embedded Insurance
- Bank Insurance Program
- Credit Union Insurance Program
- Wealth Advisor Referral
- Employer Channel
- Affinity Group
- Digital Marketplace
- CUSO Insurance Platform

## Referral Object

Fields:
- referral_id
- source_institution
- source_person
- customer
- insurance_need
- producer
- agency
- carrier
- status
- consent
- disclosure_required
- expected_premium
- expected_commission
- outcome
- attribution

## Credit Union / Bank Distribution

Models:
- referral to third-party agency
- owned agency
- CUSO agency
- insurance marketplace
- wealth advisor insurance desk
- lending-attached protection
- collateral insurance program
- digital embedded offers
- member financial wellness review

## Producer Compensation

- first-year commission
- renewal commission
- trail
- override
- bonus
- referral fee
- revenue share
- agency spread
- carrier incentive

## Distribution Workflow

Risk Trigger → Referral Consent → Producer Assignment → Discovery → Quote → Application → Underwriting → Policy → Commission Attribution → Renewal Review

## KPIs

- referrals
- referral conversion
- quotes
- applications
- issued policies
- premium
- commission
- retention
- producer productivity
- channel profitability
- compliance exceptions

## AI Opportunities

- referral opportunity detection
- channel performance analysis
- producer matching
- quote follow-up
- consent/disclosure checklist
- commission attribution
- cross-sell recommendation

## Dispatch Truth Statement

Insurance distribution determines who owns the relationship, who captures economics, and whether protection gaps are found before loss occurs.
