# Underwriting & Risk Selection

## Purpose

This document defines insurance underwriting operations.

## Underwriting Object

Fields:
- underwriting_id
- application
- applicant
- product
- risk_class
- rating_factors
- evidence
- exclusions
- premium
- decision
- conditions
- underwriter
- date
- approval
- audit_history

## Underwriting Categories

### Life / Health

- age
- health history
- medications
- labs
- medical records
- occupation
- hobbies
- lifestyle
- family history
- financial justification
- insurable interest

### P&C

- property location
- construction type
- claims history
- occupancy
- protection class
- driving record
- assets
- liability exposure
- catastrophe exposure

### Commercial

- industry
- revenue
- payroll
- employees
- loss runs
- safety practices
- contracts
- cyber posture
- property values
- vehicles
- professional exposure

## Underwriting Decisions

- Approved
- Approved Standard
- Preferred
- Rated
- Excluded
- Modified
- Declined
- Postponed
- Additional Evidence Required

## Evidence Types

- application
- medical exam
- prescription history
- MVR
- claims history
- loss runs
- inspections
- financial statements
- property reports
- cyber questionnaire
- safety reports
- certificates

## KPIs

- underwriting turn time
- approval rate
- decline rate
- rated policy rate
- evidence aging
- quote-to-bind
- loss ratio by class
- underwriting exceptions
- premium adequacy

## AI Opportunities

- underwriting summary
- evidence checklist
- risk factor extraction
- loss run summary
- cyber questionnaire review
- property risk summary
- decision support
- underwriting question generation

## Dispatch Truth Statement

Underwriting is the conversion of uncertain risk into priced acceptance, modified terms, exclusion, or decline.
