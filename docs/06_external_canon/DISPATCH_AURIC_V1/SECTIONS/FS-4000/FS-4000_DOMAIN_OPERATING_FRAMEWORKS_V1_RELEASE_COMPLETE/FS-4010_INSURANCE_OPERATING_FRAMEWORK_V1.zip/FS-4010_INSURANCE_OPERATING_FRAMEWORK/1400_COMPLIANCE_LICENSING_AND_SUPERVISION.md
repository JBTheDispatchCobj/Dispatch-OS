# Compliance, Licensing & Supervision

## Purpose

This document defines insurance compliance, producer licensing, appointments, suitability, advertising, and supervision.

## Compliance Domains

- Producer Licensing
- Carrier Appointments
- Continuing Education
- Product Training
- Suitability
- Best Interest Standards where applicable
- Replacement Rules
- Advertising
- Referral Disclosures
- Privacy
- AML for covered products
- OFAC
- Unfair Trade Practices
- Claims Handling Rules
- Complaint Handling
- Records Retention
- State Insurance Department Rules
- Annuity Suitability
- Senior Protection

## License Object

Fields:
- license_id
- producer
- state
- line_of_authority
- issue_date
- expiration_date
- CE_status
- appointment_status
- restrictions
- status

## Supervision Object

Fields:
- review_id
- producer
- transaction
- product
- client
- issue
- evidence
- supervisor
- decision
- remediation
- status

## Required Workflows

- producer licensing
- appointment review
- CE monitoring
- product training
- advertising review
- annuity suitability review
- replacement review
- complaint review
- referral disclosure tracking
- claims complaint escalation

## KPIs

- licenses current
- appointments current
- CE completion
- product training completion
- suitability exceptions
- replacement exceptions
- complaint count
- advertising review time
- regulatory findings
- supervision backlog

## AI Opportunities

- license monitoring
- CE reminder
- suitability checklist
- replacement comparison
- complaint summary
- advertising review support
- disclosure evidence tracker
- producer supervision summary

## Dispatch Truth Statement

Insurance compliance is state-specific, product-specific, and producer-specific. Dispatch must track authority before activity.
