# Knowledge Packs & Playbooks

## Knowledge Packs

### Insurance Foundation Pack

- terminology
- participant taxonomy
- product taxonomy
- workflow maps
- KPI definitions

### Life & Annuity Pack

- life products
- annuities
- suitability
- beneficiary review
- retirement income
- replacement review

### P&C Pack

- personal lines
- commercial lines
- certificates
- renewals
- claims
- coverage gaps

### Claims Pack

- FNOL
- coverage review
- reserves
- investigation
- payment/denial
- subrogation

### Compliance Pack

- producer licensing
- appointments
- CE
- suitability
- advertising
- complaints
- state rules

### Credit Union / Bank Insurance Pack

- referral triggers
- debt protection
- GAP
- collateral protection
- wealth insurance
- business insurance
- consent/disclosure

## Playbooks

- Insurance Gap Review Playbook
- Quote-to-Bind Playbook
- Renewal Review Playbook
- Claim Intake Playbook
- Commission Reconciliation Playbook
- Producer Licensing Playbook
- Annuity Suitability Playbook
- Replacement Review Playbook
- Credit Union Insurance Buildout Playbook
- Business Insurance Referral Playbook

## Dispatch Truth Statement

Insurance knowledge packs turn protection expertise into repeatable relationship, service, and compliance execution.
