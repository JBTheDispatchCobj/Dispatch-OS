# Property, Casualty & Commercial Lines

## Purpose

This document defines P&C and commercial lines operations.

## Personal Lines Objects

- Homeowners Policy
- Auto Policy
- Umbrella
- Renters
- Condo
- Flood
- Personal Articles
- Vehicle
- Residence
- Driver
- Claim

## Commercial Lines Objects

- Commercial Property
- General Liability
- Business Owner Policy
- Workers Compensation
- Commercial Auto
- Professional Liability
- E&O
- D&O
- Cyber
- Crime
- Inland Marine
- Builder's Risk
- Surety Bond
- Certificate of Insurance
- Loss Runs

## Commercial Risk Discovery

Inputs:
- industry
- locations
- revenue
- payroll
- employees
- vehicles
- contracts
- property values
- cyber posture
- professional services
- subcontractors
- claims history
- lender requirements
- certificates needed

## Certificate Workflow

Request → Policy Verification → Holder Info → Coverage Review → Certificate Issue → Delivery → Archive

## Renewal Workflow

Expiration List → Loss Runs → Exposure Update → Market Submission → Quotes → Proposal → Binding → Policy Delivery

## KPIs

- policies
- premium
- retention
- quote-to-bind
- loss ratio
- claims frequency
- certificates issued
- renewal completion
- coverage gaps
- commercial account revenue

## AI Opportunities

- exposure checklist
- renewal proposal
- loss run summary
- certificate support
- coverage gap detection
- lender insurance requirement review
- commercial risk profile

## Dispatch Truth Statement

P&C and commercial lines protect assets, liability, operations, collateral, and business continuity.
