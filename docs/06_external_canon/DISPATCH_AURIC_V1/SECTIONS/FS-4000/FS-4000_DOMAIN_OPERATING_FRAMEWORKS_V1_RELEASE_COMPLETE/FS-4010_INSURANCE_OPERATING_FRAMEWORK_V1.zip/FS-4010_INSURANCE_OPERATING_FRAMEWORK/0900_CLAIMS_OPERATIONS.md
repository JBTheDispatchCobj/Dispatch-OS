# Claims Operations

## Purpose

This document defines claims intake, adjudication, reserves, payment, denial, subrogation, and recovery.

## Claim Object

Fields:
- claim_id
- policy
- claimant
- loss_date
- notice_date
- loss_type
- description
- coverage_status
- adjuster
- reserve
- paid_amount
- deductible
- status
- documents
- investigation
- fraud_flags
- subrogation
- recovery
- closure_date

## Claims Lifecycle

Loss Event → Notice → Coverage Review → Assignment → Investigation → Reserve → Documentation → Decision → Payment / Denial → Subrogation / Recovery → Closure → Reporting

## Claim Types

- death claim
- disability claim
- long-term care claim
- property loss
- auto accident
- liability claim
- workers compensation
- cyber incident
- theft
- business interruption
- credit protection claim
- GAP claim
- warranty claim

## Claim Evidence

- loss notice
- police report
- death certificate
- medical records
- repair estimate
- photos
- invoices
- proof of ownership
- adjuster notes
- legal correspondence
- beneficiary forms
- payment authorization

## Claims KPIs

- claims count
- claims severity
- claims frequency
- loss ratio
- time to contact
- time to close
- reserve accuracy
- denied claims
- reopened claims
- litigation rate
- fraud referrals
- subrogation recovery
- customer satisfaction

## AI Opportunities

- claim summary
- coverage check support
- evidence checklist
- adjuster notes summary
- reserve change explanation
- fraud indicator detection
- denial letter support
- subrogation opportunity detection
- claimant communication draft

## Dispatch Truth Statement

Claims are where the insurance promise is tested. Dispatch must connect policy language, evidence, investigation, coverage, payment, and customer experience.
