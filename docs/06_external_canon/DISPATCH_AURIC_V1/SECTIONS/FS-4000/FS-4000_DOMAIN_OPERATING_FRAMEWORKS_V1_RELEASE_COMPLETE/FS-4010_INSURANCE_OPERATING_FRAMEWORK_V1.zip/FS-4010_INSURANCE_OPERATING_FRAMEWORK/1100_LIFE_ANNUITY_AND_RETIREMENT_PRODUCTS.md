# Life, Annuity & Retirement Products

## Purpose

This document defines life insurance, annuities, retirement income, and related suitability operations.

## Life Policy Object

Fields:
- policy
- insured
- owner
- beneficiary
- face_amount
- premium
- cash_value
- surrender_value
- policy_type
- riders
- underwriting_class
- issue_date
- lapse_status
- review_date

## Annuity Object

Fields:
- annuity_id
- owner
- annuitant
- beneficiary
- product_type
- carrier
- premium
- account_value
- surrender_schedule
- income_benefit
- death_benefit
- riders
- fees
- suitability
- review_date

## Use Cases

- income replacement
- estate liquidity
- business succession
- key person
- buy-sell funding
- retirement income
- longevity protection
- tax deferral
- legacy planning
- long-term care funding

## Suitability Review

Inputs:
- age
- liquidity
- income
- net worth
- risk tolerance
- time horizon
- tax status
- surrender exposure
- fees
- replacement impact
- client objectives
- alternatives

## Review Workflow

Need → Product Review → Illustration → Suitability → Application → Underwriting → Issue → Delivery → Annual Review

## KPIs

- policies issued
- placed premium
- annuity assets
- persistency
- lapse rate
- replacements
- suitability exceptions
- beneficiary reviews
- income elections
- surrender activity

## AI Opportunities

- policy review
- annuity suitability checklist
- replacement summary
- beneficiary reminder
- illustration summary
- client-friendly explanation
- retirement income analysis support

## Dispatch Truth Statement

Life and annuity products are long-term promises that must be reviewed as household needs, beneficiaries, taxes, and retirement goals change.
