# Insurance Workflow Library

## Required Workflows

### Risk Discovery

Trigger → Discovery → Gap Identification → Product Match → Referral/Quote

### Quote to Bind

Quote Request → Carrier Appetite → Application → Underwriting → Proposal → Bind → Issue

### Policy Issuance

Approval → Premium → Documents → Delivery → Review → Archive

### Renewal Review

Expiration → Exposure Update → Market Review → Proposal → Bind Renewal → Archive

### Endorsement

Request → Coverage Review → Carrier Submission → Approval → Premium Change → Document Delivery

### Claim

Loss Notice → Coverage Review → Assignment → Investigation → Reserve → Payment/Denial → Closure

### Commission Reconciliation

Carrier Statement → Policy Match → Producer Split → Exception Review → Payment

### Producer Licensing

License Review → CE → Appointment → Product Training → Authorization

### Referral

Trigger → Consent → Producer Assignment → Outcome → Attribution

## Workflow KPIs

- cycle time
- quote-to-bind
- issue time
- renewal completion
- claim closure time
- commission exceptions
- license exceptions
- referral conversion
- compliance exceptions

## Dispatch Truth Statement

Insurance workflows convert risk identification into protection, service, claims outcomes, and relationship economics.
