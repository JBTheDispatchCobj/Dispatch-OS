# Insurance Operating Model

## Definition

Insurance is the institutional practice of assessing risk, pricing protection, issuing contracts, collecting premiums, paying valid claims, managing capital, and distributing protection products.

## Operating Layers

### 1. Risk Identification Layer

Identifies household, individual, business, collateral, income, liability, health, mortality, property, cyber, operational, and financial risks.

### 2. Product & Coverage Layer

Defines policy types, coverage limits, exclusions, riders, endorsements, deductibles, waiting periods, benefit triggers, and contractual obligations.

### 3. Distribution Layer

Includes captive agents, independent agents, brokers, bank/credit union referrals, wealth advisors, digital channels, employer channels, embedded insurance, and affinity groups.

### 4. Underwriting Layer

Evaluates applicant risk, eligibility, pricing, classifications, inspections, medical data, claims history, financials, and coverage suitability.

### 5. Policy Administration Layer

Issues policies, processes endorsements, renewals, cancellations, reinstatements, billing, premium collection, notices, servicing, and document retention.

### 6. Claims Layer

Receives loss notices, investigates, reserves, adjudicates, pays, denies, subrogates, recovers, and reports claims.

### 7. Finance & Risk Transfer Layer

Includes reserves, loss ratios, reinsurance, capital, profitability, commissions, actuarial analysis, and product economics.

### 8. Compliance Layer

Includes producer licensing, appointments, disclosures, suitability, claims handling, advertising, state insurance rules, privacy, records, and supervision.

## Insurance Functions

- Product Management
- Distribution
- Sales
- Agency Operations
- Underwriting
- Policy Administration
- Billing
- Claims
- Actuarial
- Reinsurance
- Compliance
- Licensing
- Producer Management
- Customer Service
- Technology
- Data & Analytics
- Fraud
- Risk Management

## Operating Cadence

Daily:
- quote activity
- applications
- underwriting queues
- policy service requests
- claims notices
- billing exceptions
- compliance alerts

Weekly:
- sales pipeline
- producer activity
- underwriting turn times
- claims backlog
- renewal pipeline
- referral status

Monthly:
- premium production
- commission statements
- loss ratios
- policy count
- persistency
- claims severity
- compliance exceptions

Quarterly:
- carrier performance
- product profitability
- referral partner review
- claims trend
- producer licensing review

Annual:
- renewals
- policyholder reviews
- product shelf review
- carrier appointment review
- compliance review
- strategic plan

## Dispatch Truth Statement

Insurance is the operating system of risk transfer. Dispatch must connect the risk, customer, coverage, carrier, producer, policy, premium, claim, and regulatory record.
