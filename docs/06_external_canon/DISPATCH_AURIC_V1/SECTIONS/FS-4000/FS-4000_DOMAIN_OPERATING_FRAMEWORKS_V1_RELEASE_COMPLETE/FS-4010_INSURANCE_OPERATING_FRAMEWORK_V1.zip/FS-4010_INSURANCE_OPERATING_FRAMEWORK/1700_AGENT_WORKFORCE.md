# Insurance Agent Workforce

## Sales & Distribution Agents

- Insurance Opportunity Agent
- Referral Routing Agent
- Producer Assistant
- Quote Prep Agent
- Coverage Gap Agent
- Renewal Outreach Agent

## Underwriting Agents

- Application Review Agent
- Risk Summary Agent
- Evidence Checklist Agent
- Carrier Appetite Agent
- Loss Run Summary Agent
- Underwriting Question Agent

## Policy Service Agents

- Policy Summary Agent
- Endorsement Agent
- Certificate Agent
- Renewal Review Agent
- Beneficiary Review Agent
- Cancellation Risk Agent

## Claims Agents

- Claim Intake Agent
- Coverage Summary Agent
- Evidence Checklist Agent
- Claim Status Agent
- Fraud Indicator Agent
- Subrogation Opportunity Agent

## Compliance Agents

- Licensing Monitor
- Appointment Monitor
- Suitability Review Agent
- Replacement Review Agent
- Advertising Review Agent
- Complaint Summary Agent
- Disclosure Tracker

## Finance Agents

- Commission Reconciliation Agent
- Billing Exception Agent
- Lapse Risk Agent
- Producer Statement Agent

## Governance

Human approval required for:
- coverage recommendations
- suitability decisions
- claim denial
- policy cancellation
- premium/commission adjustments
- regulatory responses
- producer disciplinary action
- external customer commitments

## Dispatch Truth Statement

Insurance agents assist across risk discovery, underwriting, policy service, claims, compliance, and revenue operations under governed authority.
