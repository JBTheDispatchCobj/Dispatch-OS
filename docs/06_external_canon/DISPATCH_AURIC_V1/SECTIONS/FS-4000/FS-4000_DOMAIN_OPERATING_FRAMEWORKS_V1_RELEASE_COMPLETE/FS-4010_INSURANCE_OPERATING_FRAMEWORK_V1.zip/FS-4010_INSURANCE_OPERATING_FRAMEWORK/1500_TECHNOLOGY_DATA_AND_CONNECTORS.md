# Technology, Data & Connectors

## Purpose

This document defines the insurance technology stack and connector priorities.

## Technology Categories

- Agency Management System
- Policy Administration System
- Carrier Portal
- Quoting Platform
- Comparative Rater
- CRM
- Document Management
- E-Signature
- Claims System
- Commission System
- Licensing System
- Compliance System
- Billing System
- Data Warehouse
- BI Dashboard
- AI Platform

## Common Data Objects

- policyholder
- insured
- policy
- coverage
- quote
- application
- premium
- commission
- claim
- producer
- license
- appointment
- referral
- service request
- renewal
- cancellation
- document

## Connector Priorities

Tier 1:
- CRM
- document storage
- email/calendar
- spreadsheet/CSV
- agency management exports
- AI provider

Tier 2:
- carrier portals
- policy admin
- commission statements
- claims system
- quoting platform
- e-signature

Tier 3:
- licensing systems
- comparative raters
- billing
- data warehouse
- compliance platform
- bank/credit union CRM/core triggers

## Data Quality Rules

- policyholder must link to policy
- policy must link to carrier
- producer must have license authority
- referral must preserve source and consent
- commission must link to premium and producer
- claim must link to policy
- renewal must link to policy expiration

## AI Opportunities

- policy extraction
- carrier statement reconciliation
- renewal queue generation
- claims summarization
- referral matching
- coverage gap detection
- license/appointment monitoring

## Dispatch Truth Statement

Insurance data is fragmented across carriers, agencies, producers, policy systems, claims systems, and referral partners. Dispatch turns it into protection intelligence.
