# Market Participants

## Purpose

This document defines the institutional participant map for insurance.

## Carrier

The entity that issues policies, assumes risk, collects premium, holds reserves, and pays claims.

Fields:
- carrier_id
- name
- lines
- ratings
- states
- products
- appointments
- claims_capability
- underwriting_appetite
- financial_strength
- commission_schedule
- service_model

## Agency

An entity distributing insurance products through producers.

Fields:
- agency_id
- name
- structure
- carriers
- producers
- licenses
- appointments
- revenue
- book_of_business
- retention
- compliance_status

## Broker

Represents clients and places coverage across carriers.

## MGA / MGU

A delegated underwriting authority managing specialized products or programs.

## Producer

Licensed individual selling, soliciting, or negotiating insurance.

Fields:
- producer_id
- name
- licenses
- states
- appointments
- product_authority
- book
- production
- compliance_status
- training_status

## Reinsurer

Assumes risk from carriers or other insurers.

## InsurTech

Technology provider improving distribution, underwriting, claims, embedded insurance, pricing, data, or compliance.

## Credit Union / Bank Partner

Institution that may refer, distribute, embed, or own insurance economics through partnership, agency, CUSO, or wealth platform.

## Relationship Types

- CARRIER_APPOINTS Producer
- AGENCY_CONTRACTS_WITH Carrier
- PRODUCER_SERVES Policyholder
- CARRIER_ISSUES Policy
- POLICYHOLDER_PAYS Premium
- CLAIM_ADJUSTER_HANDLES Claim
- REINSURER_ASSUMES Risk
- CREDIT_UNION_REFERS Member
- WEALTH_ADVISOR_IDENTIFIES Protection Gap
- BANK_CROSSELLS Insurance

## AI Opportunities

- participant profile
- carrier appetite matching
- producer licensing summary
- agency book analysis
- referral partner mapping
- insurtech category map
- carrier comparison

## Dispatch Truth Statement

Insurance is a multi-party operating network. Understanding who originates, underwrites, issues, services, reinsures, and regulates the policy is core intelligence.
