# Policyholder & Relationship Lifecycle

## Purpose

This document defines policyholder, insured, beneficiary, household, and business insurance relationship management.

## Policyholder Object

Fields:
- policyholder_id
- name
- type
- household_id
- business_id
- risk_profile
- policies
- coverages
- beneficiaries
- claims_history
- premium_history
- renewal_dates
- producer
- referrals
- banking_relationships
- wealth_relationships
- lending_relationships
- protection_gaps
- service_requests
- compliance_status

## Household Insurance Profile

Fields:
- household_id
- members
- income
- assets
- liabilities
- homes
- vehicles
- businesses
- dependents
- estate_plan
- life_coverage
- disability_coverage
- LTC_coverage
- P&C_coverage
- umbrella
- annuities
- protection_gaps

## Business Insurance Profile

Fields:
- business_id
- industry
- revenue
- employees
- locations
- vehicles
- property
- liability_exposure
- cyber_exposure
- workers_comp
- key_people
- contracts
- collateral
- policies
- claims
- certificates
- renewal_dates
- lender_requirements

## Relationship Lifecycle

Prospect → Risk Discovery → Quote → Application → Underwriting → Policy Issuance → Billing → Service → Annual Review → Renewal → Claim → Retention / Cross-Sell / Exit

## Life Events

- marriage
- divorce
- birth/adoption
- home purchase
- vehicle purchase
- business formation
- business sale
- new debt
- retirement
- inheritance
- death
- disability
- lawsuit
- property acquisition
- major contract
- employee growth
- cyber event

## Relationship KPIs

- policies per household
- coverage gap count
- premium
- commission
- retention
- renewal rate
- cross-sell
- claims frequency
- service response time
- referral conversion
- protection review completion

## AI Opportunities

- protection gap detection
- household risk profile
- business risk profile
- annual review prep
- life event trigger
- beneficiary review
- coverage summary
- cross-sell recommendation
- referral opportunity detection

## Dispatch Truth Statement

Insurance relationships are risk relationships. Dispatch must understand what can go wrong, who is exposed, what is protected, and where the gaps remain.
