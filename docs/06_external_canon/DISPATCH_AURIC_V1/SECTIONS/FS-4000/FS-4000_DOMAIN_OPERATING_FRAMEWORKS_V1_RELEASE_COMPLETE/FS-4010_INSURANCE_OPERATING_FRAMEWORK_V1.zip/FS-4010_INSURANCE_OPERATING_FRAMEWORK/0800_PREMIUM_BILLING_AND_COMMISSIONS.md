# Premium, Billing & Commissions

## Purpose

This document defines premium collection, billing, revenue, commission, and compensation operations.

## Premium Object

Fields:
- premium_id
- policy
- amount
- frequency
- due_date
- paid_date
- status
- payment_method
- billing_mode
- late_status
- refund
- earned_premium
- unearned_premium

## Billing Models

- Direct Bill
- Agency Bill
- Payroll Deduction
- ACH
- Credit Card
- Loan Payment Add-On
- Escrow
- Annual
- Semiannual
- Quarterly
- Monthly
- Single Premium

## Commission Object

Fields:
- commission_id
- policy
- producer
- agency
- carrier
- premium
- commission_rate
- commission_amount
- split
- override
- payment_date
- chargeback
- renewal_commission
- referral_attribution

## Commission Workflow

Policy Issued → Premium Paid → Carrier Statement → Commission Calculation → Split/Override → Payment → Reconciliation → Exception Review

## Billing Risks

- lapse
- nonpayment
- chargeback
- refund error
- commission mismatch
- referral attribution error
- premium financing issue
- escrow mismatch
- cancellation notice timing

## KPIs

- premium volume
- earned premium
- commission revenue
- renewal commission
- chargebacks
- billing exceptions
- lapse rate
- past due premium
- producer payout accuracy
- reconciliation breaks

## AI Opportunities

- commission reconciliation
- billing exception detection
- lapse risk alert
- premium summary
- chargeback explanation
- producer statement review
- referral attribution validation

## Dispatch Truth Statement

Premium and commission operations convert protection products into economic activity that must be reconciled, attributed, and governed.
