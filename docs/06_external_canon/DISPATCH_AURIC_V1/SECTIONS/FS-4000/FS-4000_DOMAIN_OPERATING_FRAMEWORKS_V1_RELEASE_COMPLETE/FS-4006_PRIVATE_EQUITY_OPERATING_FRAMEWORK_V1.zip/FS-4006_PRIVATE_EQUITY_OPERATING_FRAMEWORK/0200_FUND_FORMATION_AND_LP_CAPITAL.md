# Fund Formation & LP Capital

## Purpose

This document defines private equity fund formation, LP capital, governance, and reporting.

## Fund Object

Fields:

- fund_id
- fund_name
- strategy
- vintage
- legal_structure
- GP
- management_company
- LPs
- target_size
- hard_cap
- commitments
- called_capital
- uncalled_capital
- investment_period
- fund_term
- extensions
- management_fee
- carry
- preferred_return
- GP_commitment
- recycling
- concentration_limits
- key_person
- reporting_frequency
- advisory_committee
- auditor
- fund_admin
- custodian
- legal_counsel

## LP Object

Fields:

- lp_id
- investor_type
- commitment
- capital_called
- unfunded_commitment
- distributions
- NAV
- IRR
- MOIC
- side_letter
- restrictions
- reporting_requirements
- contacts
- KYC_status
- tax_forms
- portal_access

## Fund Lifecycle

Strategy → Formation → PPM → Fundraising → First Close → Subsequent Closes → Investment Period → Portfolio Management → Harvest → Wind Down → Liquidation → Archive

## Fund Documents

- PPM
- LPA
- Subscription Agreement
- Side Letter
- Management Agreement
- Advisory Committee Charter
- Capital Call Notice
- Distribution Notice
- LP Report
- Audited Financials
- Tax Documents
- Valuation Policy
- Compliance Manual

## Capital Call Workflow

Capital Need → Allocation → Notice Draft → Approval → LP Notice → Wire Receipt → Allocation → Accounting Entry → Investor Record Update → Archive

## Distribution Workflow

Cash Available → Waterfall Calculation → Reserve Review → Approval → Distribution Notice → Wire → Investor Statement → Accounting → Archive

## LP Reporting

Sections:
- fund performance
- portfolio summary
- capital account
- contributions
- distributions
- NAV
- IRR/MOIC
- commentary
- material events
- ESG/compliance where required
- pipeline where appropriate

## KPIs

- commitments
- capital called
- uncalled capital
- NAV
- DPI
- RVPI
- TVPI
- gross IRR
- net IRR
- MOIC
- management fees
- carry accrual
- LP reporting timeliness
- side letter compliance

## AI Opportunities

- LP report drafting
- capital call notice generation
- distribution notice generation
- side letter obligation tracking
- annual meeting prep
- investor Q&A briefing
- valuation commentary
- fund performance summary

## Dispatch Truth Statement

LP capital is not just funding. It is a governed relationship with obligations, restrictions, reporting expectations, trust, and long-term franchise value.
