# Deal Origination & Intermediary Network

## Purpose

This document defines private equity sourcing, origination, relationship intelligence, and pipeline management.

## Origination Sources

- Investment Bankers
- Business Brokers
- Lawyers
- CPAs
- Consultants
- Founders
- CEOs
- Operating Executives
- Independent Sponsors
- Family Offices
- Lenders
- Credit Unions
- Commercial Banks
- Wealth Advisors
- Search Funds
- Existing Portfolio Companies
- Board Members
- Industry Operators
- Conferences
- Proprietary Research
- Auric Intelligence Network

## Deal Object

Fields:
- deal_id
- target
- source
- source_contact
- sponsor_contact
- industry
- geography
- revenue
- EBITDA
- growth_rate
- asking_valuation
- process_type
- timing
- competitiveness
- mandate_fit
- thesis_fit
- status
- probability
- next_action
- NDA_status
- data_room_status
- relationship_context

## Intermediary Object

Fields:
- intermediary_id
- firm
- contact
- coverage_area
- industries
- deal_quality
- relationship_strength
- prior_deals
- close_rate
- process_style
- trust_score
- responsiveness
- current_pipeline
- last_contact
- next_touch

## Origination Lifecycle

Market Map → Target List → Relationship Development → Deal Intro → Teaser Review → NDA → CIM Review → Management Call → IOI/LOI → Exclusivity → Diligence → Close

## Deal Source Scoring

Inputs:
- relevance
- quality
- exclusivity
- valuation discipline
- relationship strength
- prior close history
- founder access
- information quality
- speed
- trust
- proprietary angle

## Origination KPIs

- targets mapped
- teasers received
- NDAs signed
- management calls
- IOIs
- LOIs
- deals under LOI
- closed deals
- source conversion
- proprietary deals
- average valuation
- source quality score
- time to screen

## AI Opportunities

- teaser summarization
- CIM summarization
- mandate fit scoring
- market map generation
- intermediary relationship tracking
- founder research
- proprietary sourcing list generation
- pipeline prioritization
- follow-up email drafting
- deal comparison

## Dispatch Truth Statement

Origination is relationship compounding. The highest-value firms do not merely see more deals; they understand the market graph better.
