# Value Creation & Operating Plans

## Purpose

This document defines value creation planning and portfolio operations.

## Value Creation Plan Object

Fields:
- plan_id
- portfolio_company
- owner
- thesis
- initiatives
- baseline_KPIs
- target_KPIs
- timeline
- responsible_executives
- investment_required
- expected_value
- risk
- status
- evidence
- outcomes

## Value Creation Levers

- revenue growth
- pricing optimization
- sales effectiveness
- customer retention
- product expansion
- margin expansion
- procurement savings
- labor productivity
- technology modernization
- AI adoption
- automation
- working capital optimization
- CapEx discipline
- add-on acquisitions
- management upgrade
- reporting improvement
- debt optimization
- exit preparation

## 100-Day Plan

Sections:
- leadership alignment
- financial reporting
- cash controls
- KPI baseline
- debt compliance
- quick wins
- customer risks
- employee risks
- technology risks
- vendor review
- value creation initiatives
- governance cadence

## Initiative Object

Fields:
- initiative_id
- name
- value_creation_category
- owner
- baseline
- target
- expected_value
- required_investment
- milestones
- dependencies
- risks
- status
- evidence
- KPI_impact

## Operating Review Workflow

KPI Pull → Management Commentary → Variance Analysis → Initiative Review → Risk Review → Action Items → Board Update → Knowledge Capture

## AI Opportunities

- 100-day plan generation
- initiative tracker
- pricing opportunity analysis
- procurement opportunity analysis
- working capital analysis
- KPI variance commentary
- operational bottleneck detection
- value bridge generation

## Dispatch Truth Statement

Value creation is not a slide in the investment memo. It is an executable operating system connected to KPIs, owners, initiatives, governance, and enterprise value.
