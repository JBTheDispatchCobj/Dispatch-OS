# Valuation, Modeling & Returns

## Purpose

This document defines valuation, financial modeling, return analysis, and scenario planning for private equity.

## Valuation Methods

- EBITDA Multiple
- Revenue Multiple
- Discounted Cash Flow
- Comparable Companies
- Precedent Transactions
- Sum of the Parts
- Replacement Cost
- Asset Value
- LBO Model
- Strategic Buyer Value
- Sponsor Buyer Value

## Valuation Object

Fields:
- valuation_id
- company
- date
- method
- revenue
- EBITDA
- multiple
- enterprise_value
- equity_value
- debt
- cash
- working_capital_adjustment
- sensitivity
- assumptions
- reviewer
- approval

## LBO Model Objects

- Entry Enterprise Value
- Entry Equity
- Debt Financing
- Management Rollover
- Seller Note
- Transaction Fees
- Revenue Forecast
- EBITDA Forecast
- CapEx
- Working Capital
- Debt Paydown
- Exit Multiple
- Exit Enterprise Value
- Exit Equity Value
- IRR
- MOIC

## Return Metrics

- Gross IRR
- Net IRR
- MOIC
- Cash-on-Cash
- DPI
- RVPI
- TVPI
- Payback
- Enterprise Value Creation
- Debt Paydown
- Multiple Expansion
- EBITDA Growth
- Revenue Growth
- Margin Expansion

## Scenario Types

- Base Case
- Downside Case
- Upside Case
- Recession Case
- No Multiple Expansion Case
- Delayed Exit Case
- Covenant Stress Case
- Add-On Case
- Pricing Improvement Case
- Margin Expansion Case

## Value Creation Bridge

Entry EBITDA  
+ Revenue Growth  
+ Margin Improvement  
+ Add-On EBITDA  
+ Cost Savings  
+ Pricing Improvement  
+ Multiple Expansion  
- Debt  
= Exit Equity Value

## AI Opportunities

- model review
- assumption testing
- scenario generation
- return bridge explanation
- comparable transaction summary
- valuation sensitivity summary
- IC return commentary
- red flag identification

## Dispatch Truth Statement

Valuation is not a number. It is a set of assumptions about future operating performance, capital structure, market appetite, and exit timing.
