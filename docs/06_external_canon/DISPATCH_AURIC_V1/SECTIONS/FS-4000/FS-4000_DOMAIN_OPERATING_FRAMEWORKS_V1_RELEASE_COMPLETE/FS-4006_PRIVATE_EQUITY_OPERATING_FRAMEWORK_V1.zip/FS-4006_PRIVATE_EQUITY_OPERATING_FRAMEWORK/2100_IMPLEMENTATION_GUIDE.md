# Private Equity Implementation Guide

## Phase 1 — Setup

- create PE firm
- create management company
- create fund
- create LPs
- configure strategy
- configure IC
- configure approval rights
- configure portfolio structure

## Phase 2 — Objects

- deals
- targets
- investment theses
- diligence items
- findings
- portfolio companies
- boards
- KPIs
- value creation plans
- LP reports

## Phase 3 — Workflows

Activate:
- fund formation
- deal origination
- diligence
- IC
- closing
- 100-day plan
- portfolio monitoring
- add-ons
- LP reporting
- exit readiness

## Phase 4 — Agents

Deploy:
- Deal Sourcing Agent
- CIM Summary Agent
- IC Memo Writer
- Valuation Analyst
- Diligence Coordinator
- Board Packet Writer
- Value Creation Tracker
- LP Reporting Agent
- Exit Readiness Agent

## Phase 5 — Dashboards

Configure:
- fund
- deal pipeline
- diligence
- IC
- portfolio
- value creation
- board
- LP reporting
- exit

## Demo Flow

1. Open fund dashboard.
2. Show deal pipeline.
3. Summarize CIM.
4. Generate investment thesis.
5. Build diligence request list.
6. Draft IC memo.
7. Open portfolio dashboard.
8. Show value creation plan.
9. Generate LP report.
10. Show exit readiness.

## Dispatch Truth Statement

Private equity implementation should begin with fund, deal, and portfolio truth; then layer workflows, agents, and reporting.
