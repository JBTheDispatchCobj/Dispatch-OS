# FS-4006 Private Equity Operating Framework

Version: 1.0  
Owner: Auric Works  
Library: Dispatch Institutional Intelligence Library  
Domain: Private Equity / Sponsor Finance / Portfolio Operations  
Status: Production Knowledge Volume

## Purpose

This volume defines the canonical Private Equity Operating Framework used by Dispatch OS and the Auric Institutional Intelligence Network.

Private equity is the operating discipline of raising capital, sourcing investments, underwriting businesses, structuring transactions, closing acquisitions, governing portfolio companies, creating enterprise value, reporting to investors, and exiting assets.

Dispatch operationalizes portfolio execution.  
Auric maps sponsors, LPs, executives, intermediaries, lenders, service providers, targets, portfolio companies, vendors, and market intelligence.

## Strategic Lens

Private equity is not simply buying companies.

It is an institutional operating system for converting capital, judgment, governance, leverage, operating improvement, management talent, technology, and market timing into enterprise value.

Every investment is a living operating object.

## Volume Contents

1. Private Equity Schema & Object Standard
2. Private Equity Operating Model
3. Fund Formation & LP Capital
4. Deal Origination & Intermediary Network
5. Target Screening & Investment Thesis
6. Due Diligence
7. Valuation, Modeling & Returns
8. Transaction Structuring & Financing
9. Investment Committee & Approvals
10. Closing & Transition
11. Portfolio Governance
12. Value Creation & Operating Plans
13. Portfolio Monitoring & Reporting
14. Add-Ons, Roll-Ups & M&A
15. Exit Planning
16. Risk, Compliance & Documentation
17. Technology, Data & Connectors
18. Workflow Library
19. Agent Workforce
20. KPI & Dashboard Registry
21. Knowledge Packs & Playbooks
22. Implementation Guide
23. Acceptance Tests & Roadmap

## Completion Standard

This volume is complete when Dispatch can represent a private equity firm, fund, deal, portfolio company, value creation plan, governance process, reporting cycle, and exit process as executable institutional objects.
