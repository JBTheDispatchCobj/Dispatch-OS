# Transaction Structuring & Financing

## Purpose

This document defines private equity transaction structures and financing models.

## Transaction Structures

- Stock Purchase
- Asset Purchase
- Merger
- Recapitalization
- Management Buyout
- Rollover Equity
- Majority Buyout
- Minority Growth Equity
- Carve-Out
- Add-On Acquisition
- Platform Acquisition
- Continuation Vehicle
- Secondary Buyout

## Capital Stack Objects

- Sponsor Equity
- LP Equity
- Management Rollover
- Seller Note
- Earnout
- Senior Debt
- Unitranche
- Mezzanine Debt
- Preferred Equity
- Revolver
- Delayed Draw Facility
- Bridge Loan

## Sources & Uses Object

Fields:
- purchase_price
- debt_refinance
- transaction_fees
- financing_fees
- working_capital
- cash_to_balance_sheet
- rollover_equity
- sponsor_equity
- debt
- seller_note
- earnout
- total_sources
- total_uses

## Financing Documents

- Debt Commitment Letter
- Fee Letter
- Credit Agreement
- Intercreditor Agreement
- Security Agreement
- Equity Commitment Letter
- Rollover Agreement
- Seller Note
- Purchase Agreement
- Disclosure Schedules
- Escrow Agreement

## Structuring Considerations

- tax treatment
- liability assumption
- working capital peg
- indemnity
- escrow
- reps and warranties
- rollover incentives
- earnout metrics
- leverage capacity
- covenant flexibility
- lender appetite
- closing certainty
- regulatory approvals

## AI Opportunities

- structure comparison
- sources and uses validation
- financing terms summary
- lender package preparation
- purchase agreement issue list
- earnout risk summary
- working capital peg analysis
- closing condition checklist

## Dispatch Truth Statement

Transaction structure is where investment thesis, risk allocation, tax, financing, control, management incentives, and exit optionality become legally enforceable.
