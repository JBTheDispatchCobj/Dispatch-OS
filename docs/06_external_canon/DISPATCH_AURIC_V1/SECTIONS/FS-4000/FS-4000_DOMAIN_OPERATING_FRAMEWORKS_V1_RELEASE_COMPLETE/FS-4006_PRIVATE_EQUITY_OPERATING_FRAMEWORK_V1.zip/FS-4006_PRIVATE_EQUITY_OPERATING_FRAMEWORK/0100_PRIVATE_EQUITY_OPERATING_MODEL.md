# Private Equity Operating Model

## Definition

Private equity is the institutional process of acquiring or investing in private companies, improving them through governance and operations, and realizing value through exit.

## Operating Layers

### 1. Fund & Capital Layer

Defines fund structure, LP commitments, management fees, carry, investment mandate, concentration limits, reporting, and capital call obligations.

### 2. Origination Layer

Captures relationships with intermediaries, founders, executives, lenders, advisors, brokers, banks, consultants, and proprietary sourcing channels.

### 3. Investment Judgment Layer

Defines thesis, market map, target criteria, diligence priorities, valuation, risk, downside protection, operating opportunity, and exit pathway.

### 4. Transaction Execution Layer

Includes NDA, LOI, exclusivity, diligence, financing, legal documentation, closing conditions, funds flow, and transition planning.

### 5. Governance Layer

Includes board, shareholder rights, reporting cadence, approval thresholds, management incentives, and strategic oversight.

### 6. Portfolio Operations Layer

Includes 100-day plan, value creation, revenue growth, margin expansion, pricing, procurement, technology, talent, working capital, add-ons, and exit readiness.

### 7. Reporting Layer

Includes monthly reporting, board packets, quarterly LP reporting, valuation, portfolio review, audit, tax, and investor communications.

### 8. Exit Layer

Includes strategic sale, sponsor sale, IPO, dividend recap, continuation vehicle, recapitalization, management buyout, or asset sale.

## Private Equity Operating Cadence

Daily:
- deal pipeline updates
- portfolio exceptions
- lender issues
- management communications
- urgent diligence items

Weekly:
- origination meetings
- deal review
- portfolio operating review
- add-on pipeline
- financing updates
- operating partner workstreams

Monthly:
- portfolio financial package
- KPI review
- debt compliance
- board prep
- value creation plan update
- cash/liquidity review

Quarterly:
- valuation
- LP reporting
- board meetings
- portfolio review
- fund performance
- risk review
- exit readiness review

Annual:
- fund audit
- tax reporting
- annual meeting
- strategy review
- management compensation
- budget approval
- exit planning
- portfolio value creation refresh

## Dispatch Truth Statement

Private equity is a governance and operating model for enterprise value creation. Dispatch must model the firm, fund, deal, company, board, initiatives, capital structure, and exit as one connected system.
