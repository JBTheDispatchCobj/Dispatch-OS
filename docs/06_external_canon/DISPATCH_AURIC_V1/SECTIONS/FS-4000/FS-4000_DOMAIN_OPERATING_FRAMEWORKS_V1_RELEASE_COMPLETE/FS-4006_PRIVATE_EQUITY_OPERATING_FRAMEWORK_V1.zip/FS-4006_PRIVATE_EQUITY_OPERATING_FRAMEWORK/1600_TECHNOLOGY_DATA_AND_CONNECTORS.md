# Technology, Data & Connectors

## Purpose

This document defines the private equity technology stack and connector priorities.

## Technology Categories

- CRM
- Deal Pipeline
- Data Room
- Document Management
- Fund Accounting
- Portfolio Monitoring
- Investor Portal
- Cap Table
- Board Portal
- BI Dashboard
- Financial Planning
- ERP
- HRIS
- Legal Document Management
- E-Signature
- Market Data
- AI Platform

## Data Objects

- LP
- fund
- commitment
- capital call
- distribution
- deal
- target
- diligence item
- finding
- investment
- portfolio company
- board packet
- KPI
- valuation
- initiative
- exit plan
- document
- relationship

## Connector Priorities

Tier 1:
- email/calendar
- document storage
- CRM/pipeline
- data room
- spreadsheets
- AI provider

Tier 2:
- fund accounting
- investor portal
- portfolio monitoring
- BI/data warehouse
- e-signature
- cap table
- board portal

Tier 3:
- market data
- legal document systems
- HRIS/ERP for portfolio companies
- banking data
- lender reporting
- valuation tools

## AI Opportunities

- data room indexing
- diligence summarization
- portfolio KPI extraction
- LP report generation
- relationship mapping
- deal pipeline deduplication
- document obligation extraction
- board packet generation

## Dispatch Truth Statement

Private equity data is scattered across emails, decks, data rooms, spreadsheets, legal documents, and portfolio systems. Dispatch converts it into institutional memory.
