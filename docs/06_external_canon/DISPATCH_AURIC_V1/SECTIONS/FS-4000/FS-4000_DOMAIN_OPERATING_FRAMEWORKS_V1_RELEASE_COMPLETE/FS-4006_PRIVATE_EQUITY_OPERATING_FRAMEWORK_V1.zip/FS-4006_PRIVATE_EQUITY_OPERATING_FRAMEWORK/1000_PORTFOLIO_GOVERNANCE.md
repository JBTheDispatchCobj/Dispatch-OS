# Portfolio Governance

## Purpose

This document defines private equity portfolio company governance.

## Portfolio Company Object

Fields:
- company_id
- legal_name
- fund
- ownership
- board
- management_team
- debt
- value_creation_plan
- budget
- KPIs
- strategic_plan
- reporting_cadence
- lender_reporting
- risk_profile
- exit_strategy
- technology_stack
- operating_plan

## Board Object

Fields:
- board_id
- directors
- observers
- committees
- meeting_cadence
- reserved_matters
- approvals
- minutes
- board_packages
- decisions
- follow_up_tasks

## Reserved Matters

- budget approval
- debt incurrence
- acquisitions
- asset sales
- hiring/firing CEO/CFO
- compensation
- equity issuance
- major contracts
- CapEx above threshold
- related-party transactions
- litigation settlement
- exit process

## Board Package

Sections:
- CEO update
- financials
- KPIs
- cash
- debt compliance
- sales pipeline
- operations
- people
- technology
- value creation
- risks
- decisions required
- add-ons
- exit readiness

## Governance Cadence

Weekly:
- management update
- cash/liquidity
- urgent issues

Monthly:
- financial package
- KPI dashboard
- operating review
- lender compliance

Quarterly:
- board meeting
- valuation update
- value creation review
- strategic initiatives

Annual:
- budget
- compensation
- strategy
- audit
- exit planning

## AI Opportunities

- board packet drafting
- meeting prep
- reserved matter tracking
- decision log
- follow-up task generation
- KPI commentary
- governance history search

## Dispatch Truth Statement

Portfolio governance is the operating bridge between ownership and management execution.
