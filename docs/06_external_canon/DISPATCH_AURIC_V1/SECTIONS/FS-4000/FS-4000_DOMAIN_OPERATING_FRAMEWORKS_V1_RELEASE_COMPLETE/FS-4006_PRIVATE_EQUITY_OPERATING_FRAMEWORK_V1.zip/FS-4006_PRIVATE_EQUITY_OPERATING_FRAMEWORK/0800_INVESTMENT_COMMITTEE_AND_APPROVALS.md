# Investment Committee & Approvals

## Purpose

This document defines investment committee process, authority, decisioning, and institutional memory.

## Investment Committee Object

Fields:
- committee_id
- members
- authority
- quorum
- voting_rules
- reserved_matters
- meeting_cadence
- approval_thresholds
- minutes
- conflicts
- decisions
- conditions
- follow_ups

## IC Memo Object

Fields:
- memo_id
- deal
- thesis
- recommendation
- valuation
- returns
- diligence
- risks
- mitigants
- financing
- structure
- value_creation_plan
- exit
- open_items
- approval_request
- attachments

## IC Process

Screening Memo → Preliminary IC → LOI Approval → Diligence Update → Final IC → Approval Conditions → Closing Authorization → Post-Close Review

## IC Decision Object

Fields:
- decision_id
- deal
- date
- requested_action
- approved
- rejected
- deferred
- conditions
- dissenting_views
- risk_notes
- follow_up
- expiration
- audit_history

## Common Approval Requests

- approve LOI
- approve exclusivity
- approve diligence spend
- approve final investment
- approve financing
- approve add-on acquisition
- approve management incentive plan
- approve budget
- approve exit process
- approve amendment

## IC KPIs

- deals reviewed
- approval rate
- time to decision
- diligence spend
- close rate after IC
- post-close variance
- thesis accuracy
- value creation achievement
- loss ratio
- decision quality

## AI Opportunities

- IC memo drafting
- pre-read summary
- question generation
- risk table
- dissenting view simulation
- decision log
- post-close variance analysis
- institutional memory search

## Dispatch Truth Statement

Investment Committee is the institutional judgment layer. Dispatch must preserve not only what was decided, but why it was decided and what evidence supported the decision.
