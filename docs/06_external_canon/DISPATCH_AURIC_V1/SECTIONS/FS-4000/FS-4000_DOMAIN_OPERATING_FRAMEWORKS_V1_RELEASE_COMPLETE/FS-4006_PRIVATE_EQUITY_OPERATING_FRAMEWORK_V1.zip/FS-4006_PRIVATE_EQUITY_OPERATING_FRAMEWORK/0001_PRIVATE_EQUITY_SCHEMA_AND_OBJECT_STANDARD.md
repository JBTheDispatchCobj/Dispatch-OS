# Private Equity Schema & Object Standard

## Purpose

This document defines canonical private equity objects used by Dispatch.

## Universal Private Equity Investment Object

Fields:

- investment_id
- fund_id
- platform_id
- portfolio_company_id
- sponsor_id
- deal_source
- investment_type
- transaction_type
- thesis
- entry_date
- entry_enterprise_value
- entry_equity_value
- ownership_percentage
- invested_equity
- debt_financing
- management_rollover
- seller_note
- earnout
- governance_rights
- board_seats
- value_creation_plan
- KPIs
- risk_rating
- operating_status
- exit_strategy
- current_valuation
- realized_proceeds
- unrealized_value
- documents
- approvals
- workflows
- audit_history

## Core Private Equity Objects

- Private Equity Firm
- Management Company
- General Partner
- Fund
- Parallel Fund
- Co-Investment Vehicle
- SPV
- Limited Partner
- Advisory Board
- Investment Committee
- Operating Partner
- Deal
- Target Company
- Platform Company
- Add-On Acquisition
- Portfolio Company
- Management Team
- Board
- Investment Thesis
- LOI
- Purchase Agreement
- Equity Commitment
- Debt Commitment
- Quality of Earnings
- Diligence Report
- Value Creation Plan
- 100-Day Plan
- Board Package
- Exit Memo
- LP Report

## Investment Types

- Control Buyout
- Minority Growth Equity
- Recapitalization
- Management Buyout
- Carve-Out
- Public-to-Private
- Founder Liquidity
- Add-On Acquisition
- Roll-Up
- Distressed Acquisition
- Special Situation
- Co-Investment
- Secondary Purchase
- Continuation Vehicle

## Dispatch Truth Statement

Private equity objects connect capital, ownership, governance, operating improvement, leverage, management, risk, reporting, and exit into one continuous institutional graph.
