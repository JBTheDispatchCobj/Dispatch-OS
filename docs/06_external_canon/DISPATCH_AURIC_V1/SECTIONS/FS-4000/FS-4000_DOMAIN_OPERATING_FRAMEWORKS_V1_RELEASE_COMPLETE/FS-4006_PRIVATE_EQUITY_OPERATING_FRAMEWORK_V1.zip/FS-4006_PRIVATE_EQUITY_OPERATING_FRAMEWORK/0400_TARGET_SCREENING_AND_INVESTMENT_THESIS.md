# Target Screening & Investment Thesis

## Purpose

This document defines investment thesis development and target screening.

## Investment Thesis Object

Fields:
- thesis_id
- title
- sector
- market_problem
- target_profile
- value_creation_hypothesis
- growth_drivers
- margin_opportunities
- technology_opportunities
- acquisition_opportunities
- risks
- mitigants
- exit_buyer_universe
- expected_return
- evidence
- owner
- status

## Target Screening Criteria

- industry fit
- revenue scale
- EBITDA scale
- margin profile
- growth rate
- recurring revenue
- customer concentration
- defensibility
- management quality
- technology maturity
- operational maturity
- add-on potential
- fragmentation
- exit universe
- valuation
- leverage capacity
- downside protection

## Screening Object

Fields:
- screening_id
- deal
- reviewer
- thesis_fit
- financial_fit
- market_fit
- management_fit
- risk_fit
- valuation_fit
- diligence_questions
- recommendation
- decision
- next_action

## Market Map

Objects:
- market
- subsegment
- target companies
- competitors
- buyers
- suppliers
- vendors
- regulators
- technology trends
- consolidation activity
- valuation benchmarks

## Investment Thesis Workflow

Market Observation → Research → Hypothesis → Target Criteria → Market Map → Target List → Outreach/Origination → Screening → Thesis Validation → Investment Memo

## AI Opportunities

- thesis drafting
- market map creation
- target list generation
- competitor analysis
- exit buyer mapping
- valuation benchmark research
- risk hypothesis generation
- screening memo drafting

## Dispatch Truth Statement

The investment thesis is the operating logic of a private equity investment. It must remain connected from origination through diligence, value creation, monitoring, and exit.
