# Closing & Transition

## Purpose

This document defines closing execution and post-close transition for private equity investments.

## Closing Object

Fields:
- closing_id
- deal
- buyer
- seller
- target
- closing_date
- legal_counsel
- financing
- purchase_agreement
- disclosure_schedules
- closing_conditions
- funds_flow
- approvals
- signatures
- wires
- post_closing_items
- transition_plan

## Closing Workflow

Final IC Approval → Conditions → Financing Docs → Purchase Agreement → Disclosure Schedules → Funds Flow → Signature Pages → Wire Approval → Closing → Post-Closing Checklist → Transition

## Closing Conditions

- financing availability
- equity funding
- legal opinions
- third-party consents
- regulatory approvals
- lien releases
- insurance
- employment agreements
- rollover agreements
- management incentive plan
- escrow
- working capital estimate

## Day 1 Transition

Objects:
- management meeting
- employee communication
- lender communication
- customer communication
- vendor communication
- bank accounts
- payroll
- insurance
- financial reporting
- governance calendar
- board setup
- 100-day plan

## Post-Closing Items

- final working capital
- true-up
- escrow
- final schedules
- assignments
- insurance endorsements
- board consents
- final closing binder
- debt onboarding
- portfolio monitoring setup

## Transition KPIs

- closing checklist completion
- post-closing items overdue
- Day 1 readiness
- management continuity
- reporting setup
- lender onboarding
- 100-day plan activation
- transition issue count

## AI Opportunities

- closing checklist
- funds flow review
- post-closing tracker
- Day 1 communication drafts
- transition plan generation
- working capital true-up tracker
- closing binder index

## Dispatch Truth Statement

Closing is not the end of the deal. It is the transfer point where underwriting becomes governance and value creation begins.
