# Add-Ons, Roll-Ups & M&A

## Purpose

This document defines add-on acquisition and roll-up operating models.

## Add-On Object

Fields:
- add_on_id
- platform
- target
- thesis
- revenue
- EBITDA
- purchase_price
- multiple
- synergies
- integration_complexity
- financing
- diligence
- approval
- closing_status
- integration_plan
- status

## Roll-Up Strategy

Components:
- platform company
- target universe
- market fragmentation
- acquisition criteria
- integration playbook
- synergy model
- financing strategy
- management bandwidth
- technology standardization
- reporting integration
- exit thesis

## Add-On Lifecycle

Market Map → Target List → Outreach → NDA → Diligence → Valuation → LOI → Financing → IC Approval → Closing → Integration → Synergy Tracking

## Integration Areas

- leadership
- finance
- accounting
- sales
- pricing
- operations
- systems
- HR
- payroll
- legal
- insurance
- vendor contracts
- brand
- customers
- facilities
- reporting

## Synergy Object

Fields:
- synergy_id
- category
- baseline
- target
- timing
- owner
- cost_to_achieve
- realized_value
- evidence
- status

## M&A KPIs

- targets identified
- outreach
- deals reviewed
- LOIs
- closed add-ons
- average multiple
- revenue acquired
- EBITDA acquired
- synergies identified
- synergies realized
- integration milestones
- return impact

## AI Opportunities

- target list generation
- add-on screening
- synergy estimate
- integration plan
- diligence checklist
- roll-up market map
- outreach drafting
- IC add-on memo
- integration tracker

## Dispatch Truth Statement

Add-ons are not simply smaller acquisitions. In a roll-up strategy, they are the operating mechanism by which market fragmentation becomes enterprise value.
