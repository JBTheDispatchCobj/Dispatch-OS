# KPI & Dashboard Registry

## Fund KPIs

- commitments
- called capital
- uncalled capital
- NAV
- DPI
- RVPI
- TVPI
- gross IRR
- net IRR
- MOIC
- management fees
- carry
- LP reporting timeliness

## Deal KPIs

- teasers reviewed
- NDAs signed
- IOIs
- LOIs
- deals under exclusivity
- deals closed
- close rate
- average valuation
- diligence cycle time
- transaction expenses

## Portfolio KPIs

- revenue growth
- EBITDA growth
- margin expansion
- cash flow
- leverage
- covenant compliance
- value creation initiative status
- add-on activity
- board package timeliness
- forecast accuracy

## Exit KPIs

- exit readiness score
- valuation range
- buyer universe
- LOIs received
- exit MOIC
- exit IRR
- proceeds
- DPI impact

## Dashboards

- Fund Dashboard
- LP Dashboard
- Deal Pipeline Dashboard
- Diligence Dashboard
- Investment Committee Dashboard
- Portfolio Dashboard
- Value Creation Dashboard
- Board Dashboard
- Add-On Dashboard
- Exit Dashboard

## Dispatch Truth Statement

Private equity KPIs must connect fund performance, deal quality, portfolio execution, and exit outcomes.
