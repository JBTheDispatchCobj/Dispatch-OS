# Portfolio Monitoring & Reporting

## Purpose

This document defines private equity portfolio monitoring and reporting.

## Monitoring Package

- monthly financials
- KPI dashboard
- budget variance
- cash flow
- debt compliance
- sales pipeline
- operational metrics
- value creation status
- risks
- management commentary
- lender compliance
- board materials

## Portfolio Monitoring Object

Fields:
- monitoring_id
- company
- period
- revenue
- EBITDA
- cash
- debt
- covenants
- KPIs
- forecast
- budget_variance
- initiative_status
- risk_alerts
- management_commentary
- board_actions

## Fund Portfolio Dashboard

- total companies
- invested equity
- current value
- realized value
- unrealized value
- EBITDA growth
- revenue growth
- leverage
- exits
- add-ons
- watchlist
- value creation progress
- fund IRR/MOIC

## LP Reporting

Sections:
- fund overview
- portfolio highlights
- valuation
- capital activity
- distributions
- performance metrics
- portfolio company commentary
- material events
- outlook

## Valuation Update Workflow

Financials → Performance Review → Market Comps → Multiple Review → DCF/Scenario → Valuation Committee → Approval → LP Reporting

## KPIs

- reporting timeliness
- forecast accuracy
- budget variance
- EBITDA growth
- revenue growth
- cash conversion
- leverage
- covenant compliance
- initiative completion
- valuation change
- LP report completion

## AI Opportunities

- portfolio commentary
- LP report drafting
- variance analysis
- valuation commentary
- KPI anomaly detection
- forecast risk detection
- board summary
- lender reporting package

## Dispatch Truth Statement

Portfolio monitoring is the continuous translation of operating performance into investor intelligence and enterprise value.
