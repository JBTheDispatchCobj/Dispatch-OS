# Exit Planning

## Purpose

This document defines private equity exit planning and execution.

## Exit Types

- Strategic Sale
- Sponsor-to-Sponsor Sale
- IPO
- Dividend Recapitalization
- Management Buyout
- Continuation Vehicle
- Minority Recap
- Merger
- Asset Sale
- Liquidation

## Exit Readiness Object

Fields:
- company
- expected_exit_window
- target_buyers
- financial_readiness
- reporting_quality
- management_depth
- legal_readiness
- tax_readiness
- QoE_readiness
- technology_readiness
- growth_story
- risks
- valuation_range
- preparation_plan

## Exit Preparation

- growth narrative
- financial cleanup
- QoE prep
- management presentation
- data room
- buyer universe
- market timing
- lender consent
- legal cleanup
- customer concentration mitigation
- technology cleanup
- KPI history
- add-on integration proof
- margin story
- exit model

## Buyer Universe

- strategic buyers
- private equity buyers
- family offices
- public companies
- competitors
- suppliers
- customers
- international buyers
- continuation vehicle investors

## Exit Workflow

Exit Readiness Review → Banker Selection → CIM → Buyer List → Outreach → IOIs → Management Meetings → LOIs → Diligence → Purchase Agreement → Closing → Distribution

## Exit KPIs

- valuation range
- expected MOIC
- expected IRR
- buyer universe size
- process timeline
- diligence readiness
- QoE adjustments
- LOIs received
- closing certainty
- proceeds
- DPI impact

## AI Opportunities

- exit readiness score
- buyer universe mapping
- CIM outline
- management presentation prep
- QoE readiness checklist
- valuation scenario
- buyer-specific positioning
- diligence risk forecast

## Dispatch Truth Statement

Exit planning begins at entry. Every operating initiative should be connected to the future buyer's willingness to pay.
