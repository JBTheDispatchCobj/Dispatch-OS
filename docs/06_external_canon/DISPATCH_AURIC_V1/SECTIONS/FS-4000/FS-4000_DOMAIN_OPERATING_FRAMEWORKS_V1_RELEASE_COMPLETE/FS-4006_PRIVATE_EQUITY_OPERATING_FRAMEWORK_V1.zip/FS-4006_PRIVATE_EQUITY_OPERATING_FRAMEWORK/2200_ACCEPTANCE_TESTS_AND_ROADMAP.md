# Acceptance Tests & Roadmap

## Object Tests

- Can create Private Equity Firm.
- Can create Fund.
- Can create LP.
- Can create Deal.
- Can create Target.
- Can create Investment Thesis.
- Can create Diligence Item.
- Can create IC Memo.
- Can create Portfolio Company.
- Can create Value Creation Plan.
- Can create Board Packet.
- Can create Exit Plan.

## Relationship Tests

- LP COMMITS_TO Fund.
- Fund INVESTS_IN Portfolio Company.
- Deal SOURCED_BY Intermediary.
- Thesis SUPPORTS Deal.
- Finding IMPACTS Valuation.
- Board GOVERNS Portfolio Company.
- Initiative IMPACTS KPI.
- Exit Plan TARGETS Buyer.

## Workflow Tests

- Deal origination workflow completes.
- Diligence workflow produces findings.
- IC workflow records decision.
- Closing workflow tracks conditions.
- 100-day workflow creates initiatives.
- Portfolio monitoring workflow creates board packet.
- LP reporting workflow creates report.
- Exit workflow creates buyer universe.

## Agent Tests

- CIM Summary Agent summarizes CIM.
- IC Memo Writer drafts memo.
- Value Creation Tracker updates initiatives.
- Board Packet Writer drafts board packet.
- LP Reporting Agent drafts quarterly report.
- Exit Readiness Agent scores readiness.

## Roadmap

Priority 1:
- machine-readable PE object registry
- fixture fund
- fixture deal
- fixture portfolio company
- fixture IC memo
- fixture value creation plan

Priority 2:
- workflow implementation
- agent implementation
- dashboard implementation
- data room intelligence

Priority 3:
- valuation engine
- LP reporting engine
- add-on engine
- exit readiness engine

## Dispatch Truth Statement

The Private Equity cartridge is accepted when Dispatch can connect fund capital, deal judgment, portfolio governance, operating initiatives, reporting, and exit outcomes into one institutional operating system.
