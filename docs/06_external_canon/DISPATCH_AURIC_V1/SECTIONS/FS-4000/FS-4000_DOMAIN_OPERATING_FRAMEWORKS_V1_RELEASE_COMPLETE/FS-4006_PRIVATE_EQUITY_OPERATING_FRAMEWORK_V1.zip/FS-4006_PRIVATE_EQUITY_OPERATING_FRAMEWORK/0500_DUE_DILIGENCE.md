# Due Diligence

## Purpose

This document defines private equity diligence categories, workflows, artifacts, and risk outputs.

## Diligence Categories

- Commercial
- Financial
- Quality of Earnings
- Tax
- Legal
- Operational
- Technology
- Cybersecurity
- Human Resources
- Insurance
- Environmental
- Regulatory
- Customer
- Vendor
- Market
- Management
- Real Estate
- Integration
- AI Readiness

## Diligence Request Object

Fields:
- request_id
- category
- requested_item
- owner
- source
- due_date
- status
- document_received
- reviewer
- finding
- risk_level
- follow_up

## Diligence Finding Object

Fields:
- finding_id
- category
- description
- evidence
- severity
- financial_impact
- operational_impact
- legal_impact
- mitigation
- owner
- status
- decision_impact

## Quality of Earnings Areas

- revenue recognition
- gross margin
- EBITDA adjustments
- non-recurring items
- owner expenses
- working capital
- debt-like items
- customer concentration
- backlog
- cash-to-accrual issues
- seasonality
- add-backs
- normalization

## Technology Diligence

- core systems
- ERP
- CRM
- cybersecurity
- cloud
- data quality
- technical debt
- vendor dependency
- AI readiness
- integration risks
- scalability
- software licenses
- product roadmap where applicable

## Management Diligence

- CEO quality
- CFO/controller quality
- sales leadership
- operations leadership
- bench strength
- succession
- incentives
- cultural fit
- reporting discipline
- change readiness

## Diligence Workflow

Request List → Data Room → Review → Findings → Follow-Up → Risk Assessment → Impact on Price/Structure → IC Update → Closing Conditions → Knowledge Archive

## AI Opportunities

- data room indexing
- document summarization
- request list generation
- finding extraction
- QofE summary
- risk matrix
- diligence question generation
- red flag detection
- IC diligence update

## Dispatch Truth Statement

Diligence is not document review. It is structured uncertainty reduction before capital is committed.
