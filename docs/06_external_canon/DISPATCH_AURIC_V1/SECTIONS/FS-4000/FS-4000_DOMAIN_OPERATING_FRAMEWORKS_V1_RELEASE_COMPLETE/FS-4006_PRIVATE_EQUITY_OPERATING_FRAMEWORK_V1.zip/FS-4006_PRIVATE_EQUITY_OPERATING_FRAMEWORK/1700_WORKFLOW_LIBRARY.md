# Private Equity Workflow Library

## Required Workflows

### Fund Formation

Strategy → Documents → Fundraising → Subscription → First Close → Investor Onboarding

### Deal Origination

Source → Teaser → NDA → CIM → Management Call → IOI/LOI

### Diligence

Request List → Data Room → Review → Findings → Risk Matrix → IC Update

### Investment Committee

Memo → Pre-Read → Meeting → Vote → Conditions → Approval

### Closing

Final Approval → Documents → Financing → Funds Flow → Signatures → Closing → Transition

### 100-Day Plan

Baseline → Initiatives → Owners → Milestones → KPIs → Weekly Review → Board Update

### Portfolio Monitoring

Financials → KPIs → Variance → Initiatives → Risk → Board Package → Archive

### Add-On Acquisition

Target → Diligence → Approval → Closing → Integration → Synergy Tracking

### Exit Process

Readiness → Banker → CIM → Buyer Outreach → IOIs → LOIs → Diligence → Closing

### LP Reporting

Portfolio Data → Valuation → Commentary → Review → Publish → Archive

## Workflow KPIs

- cycle time
- touch time
- approval time
- diligence completeness
- reporting timeliness
- initiative completion
- value creation impact
- exit readiness
- investor satisfaction

## Dispatch Truth Statement

Private equity workflows connect capital allocation decisions to operating execution and investor outcomes.
