# Knowledge Packs & Playbooks

## Knowledge Packs

### PE Foundation Pack
- terminology
- fund structures
- deal lifecycle
- portfolio lifecycle
- KPI definitions

### Fund Operations Pack
- capital calls
- distributions
- LP reporting
- fund accounting
- side letters

### Diligence Pack
- request lists
- findings
- QofE
- legal
- technology
- management
- risk matrix

### Value Creation Pack
- 100-day plan
- revenue growth
- margin expansion
- procurement
- technology
- working capital
- add-ons

### Exit Pack
- readiness
- buyer universe
- CIM
- management presentation
- process timeline
- closing

## Playbooks

- Fund Launch Playbook
- Deal Screening Playbook
- IC Memo Playbook
- Diligence Playbook
- Closing Playbook
- 100-Day Plan Playbook
- Board Governance Playbook
- Add-On Integration Playbook
- LP Reporting Playbook
- Exit Readiness Playbook

## Dispatch Truth Statement

Private equity knowledge packs turn investment and operating expertise into reusable systems for value creation.
