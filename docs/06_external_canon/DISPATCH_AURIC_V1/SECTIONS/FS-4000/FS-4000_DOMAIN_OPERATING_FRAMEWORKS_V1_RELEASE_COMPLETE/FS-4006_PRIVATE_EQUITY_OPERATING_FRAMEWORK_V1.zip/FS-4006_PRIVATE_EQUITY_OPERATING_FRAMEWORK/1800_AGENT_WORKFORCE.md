# Private Equity Agent Workforce

## Fund Agents

- LP Reporting Agent
- Capital Call Agent
- Distribution Notice Agent
- Fund Performance Analyst
- Side Letter Tracker
- Annual Meeting Prep Agent

## Origination Agents

- Deal Sourcing Agent
- Intermediary Relationship Agent
- Teaser Summary Agent
- CIM Summary Agent
- Target Research Agent
- Market Map Agent

## Diligence Agents

- Diligence Coordinator
- QoE Summary Agent
- Legal Diligence Tracker
- Technology Diligence Agent
- Customer Concentration Agent
- Management Assessment Agent
- Risk Matrix Agent

## Investment Agents

- IC Memo Writer
- Valuation Analyst
- LBO Model Reviewer
- Return Bridge Agent
- Financing Advisor
- Structure Comparison Agent

## Portfolio Agents

- Board Packet Writer
- Portfolio Monitoring Agent
- Value Creation Tracker
- KPI Analyst
- Working Capital Advisor
- Pricing Opportunity Agent
- Procurement Savings Agent
- Technology Modernization Agent

## Exit Agents

- Exit Readiness Agent
- Buyer Universe Agent
- CIM Outline Agent
- Management Presentation Prep Agent
- Diligence Readiness Agent
- Process Tracker

## Governance

Human approval required for:
- investment decisions
- valuation decisions
- capital calls
- distributions
- LP communications
- purchase agreements
- debt commitments
- board decisions
- exit decisions

## Dispatch Truth Statement

Private equity agents are digital operating professionals that assist across fund, deal, portfolio, governance, and exit workflows.
