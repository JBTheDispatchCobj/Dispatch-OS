# Follow-On, Reserves & Pro Rata

## Purpose

This document defines venture follow-on decisions, reserve planning, and pro rata management.

## Reserve Object

Fields:
- reserve_id
- fund
- company
- initial_investment
- ownership
- pro_rata_rights
- expected_next_round
- reserve_amount
- priority
- follow_on_status
- decision_history
- updated_value

## Follow-On Decision Framework

Inputs:
- company performance
- founder execution
- revenue growth
- customer traction
- runway
- next round lead
- valuation
- ownership
- strategic value
- fund reserves
- downside risk
- insider support
- market conditions
- pro rata value

## Follow-On Decision Types

- Exercise Full Pro Rata
- Exercise Partial Pro Rata
- Super Pro Rata
- Insider Bridge
- Decline
- Wait
- Secondary Sale
- Write Down
- Write Off

## Bridge Financing

Objects:
- bridge note
- insider round
- runway extension
- milestone
- conversion terms
- investor participation
- default risk
- next financing probability

## Pro Rata Workflow

Round Notice → Rights Review → Company Performance Review → Reserve Availability → Partner Recommendation → IC Decision → Legal Docs → Funding → Ownership Update

## KPIs

- reserve coverage
- pro rata exercised
- follow-on success
- graduation rate
- insider bridge outcomes
- ownership retained
- markups after follow-on
- losses after follow-on
- reserve efficiency

## AI Opportunities

- follow-on memo
- reserve forecast
- pro rata value analysis
- bridge risk analysis
- ownership dilution model
- company momentum score
- next round probability
- IC recommendation

## Dispatch Truth Statement

In venture, the first check creates optionality. Follow-on decisions determine whether the fund captures it.
