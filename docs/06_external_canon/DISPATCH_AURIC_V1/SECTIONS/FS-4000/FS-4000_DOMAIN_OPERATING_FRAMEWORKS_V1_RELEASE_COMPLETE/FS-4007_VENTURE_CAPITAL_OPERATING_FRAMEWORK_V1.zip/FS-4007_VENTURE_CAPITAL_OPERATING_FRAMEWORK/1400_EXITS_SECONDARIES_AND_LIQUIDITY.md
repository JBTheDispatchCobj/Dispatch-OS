# Exits, Secondaries & Liquidity

## Purpose

This document defines venture liquidity events.

## Exit Types

- Strategic Acquisition
- Financial Sponsor Acquisition
- IPO
- Direct Listing
- SPAC where applicable
- Secondary Sale
- Tender Offer
- Recapitalization
- Asset Sale
- Shutdown
- Acqui-hire
- Write-Off

## Exit Object

Fields:
- exit_id
- startup
- buyer
- transaction_type
- proceeds
- escrow
- holdback
- consideration_type
- closing_date
- MOIC
- IRR
- DPI_impact
- distribution_status
- lessons_learned

## Secondary Object

Fields:
- secondary_id
- seller
- buyer
- company
- shares
- price
- discount
- transfer_restrictions
- ROFR
- company_approval
- closing
- proceeds

## Exit Readiness Signals

- inbound acquisition interest
- strategic partnership
- revenue scale
- profitability
- category consolidation
- investor pressure
- founder fatigue
- next round difficulty
- secondary demand
- IPO market openness

## Liquidity Workflow

Opportunity → Valuation → Rights Review → Buyer Diligence → Approval → Documentation → Closing → Distribution → Archive

## KPIs

- realized proceeds
- MOIC
- IRR
- DPI
- escrow exposure
- time to liquidity
- secondary discount
- exit by category
- loss ratio
- write-off rate

## AI Opportunities

- buyer universe mapping
- exit scenario
- secondary price analysis
- acquisition signal detection
- distribution notice
- lessons learned summary
- liquidity forecast

## Dispatch Truth Statement

Venture liquidity is rare and nonlinear. Dispatch must preserve every signal, right, buyer, valuation, and outcome.
