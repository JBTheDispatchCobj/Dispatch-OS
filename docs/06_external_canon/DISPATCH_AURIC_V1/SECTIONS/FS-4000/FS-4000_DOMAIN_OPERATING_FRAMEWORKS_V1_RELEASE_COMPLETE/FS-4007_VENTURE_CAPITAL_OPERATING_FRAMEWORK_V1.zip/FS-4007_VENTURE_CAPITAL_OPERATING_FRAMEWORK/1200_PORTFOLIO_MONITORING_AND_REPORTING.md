# Portfolio Monitoring & Reporting

## Purpose

This document defines venture portfolio monitoring and reporting.

## Investor Update Object

Fields:
- update_id
- startup
- period
- revenue
- growth
- burn
- runway
- cash
- hiring
- product
- customers
- pipeline
- risks
- asks
- next_round
- valuation_signal
- founder_notes
- attachments

## Portfolio Monitoring Package

- company status
- stage
- ownership
- cost basis
- current value
- cash/runway
- revenue/traction
- customer growth
- product milestones
- team changes
- fundraising
- strategic partnerships
- risks
- support needs
- follow-on recommendation

## Portfolio Statuses

- Active
- Scaling
- Watch
- Runway Risk
- Follow-On Candidate
- Markup Candidate
- Markdown Candidate
- Strategic Exit Candidate
- Secondary Candidate
- Shut Down
- Exited

## Valuation Inputs

- priced round
- secondary price
- revenue multiple
- comparable companies
- traction
- runway
- investor quality
- market conditions
- strategic interest
- impairment indicators

## LP Reporting

Sections:
- fund summary
- new investments
- follow-ons
- portfolio company updates
- valuation changes
- exits
- markdowns
- strategic pilots
- market commentary
- fund metrics
- outlook

## KPIs

- active portfolio companies
- follow-on rate
- graduation rate
- markup rate
- markdown rate
- loss ratio
- runway risk
- revenue growth
- strategic pilots
- enterprise adoption
- LP report timeliness

## AI Opportunities

- investor update parsing
- portfolio summary
- runway risk alerts
- valuation commentary
- LP report drafting
- support need extraction
- follow-on readiness summary
- market signal enrichment

## Dispatch Truth Statement

Venture portfolio monitoring is the continuous tracking of uncertainty, momentum, capital needs, and strategic value.
