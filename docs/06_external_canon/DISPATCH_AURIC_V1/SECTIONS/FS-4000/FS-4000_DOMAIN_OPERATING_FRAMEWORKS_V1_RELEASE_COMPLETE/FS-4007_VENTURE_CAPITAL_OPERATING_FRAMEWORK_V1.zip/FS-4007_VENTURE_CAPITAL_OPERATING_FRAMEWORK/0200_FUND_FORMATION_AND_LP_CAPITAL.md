# Fund Formation & LP Capital

## Purpose

This document defines venture fund formation, LP capital, portfolio construction, and reporting.

## Venture Fund Object

Fields:

- fund_id
- fund_name
- strategy
- stage_focus
- sector_focus
- geography
- vintage
- target_size
- commitments
- called_capital
- uncalled_capital
- management_fee
- carry
- preferred_return_if_applicable
- GP_commit
- check_size
- ownership_target
- reserve_ratio
- portfolio_construction_model
- investment_period
- fund_term
- extensions
- LPs
- advisory_committee
- reporting_frequency
- side_letters
- eligible_investments
- restrictions

## LP Types

- Family Office
- Fund of Funds
- Endowment
- Foundation
- Pension
- Corporate Investor
- Strategic Investor
- Credit Union
- Corporate Credit Union
- CUSO
- Insurance Company
- RIA Platform
- High Net Worth Individual
- Government Program
- Economic Development Organization

## Portfolio Construction

Inputs:
- fund size
- initial check
- follow-on reserves
- target ownership
- stage
- loss ratio
- power law assumptions
- graduation rates
- sector allocation
- concentration limits
- liquidity expectations
- expected round cadence

## Fund Lifecycle

Strategy → Formation → Fundraising → First Close → Investment Period → Follow-On Period → Harvest → Wind Down → Liquidation

## LP Reporting

Sections:
- fund performance
- portfolio summary
- new investments
- follow-ons
- exits
- valuation
- capital account
- market commentary
- risk commentary
- strategic network activity
- major portfolio updates

## Venture Fund KPIs

- committed capital
- capital called
- capital deployed
- uncalled capital
- active companies
- follow-on reserve coverage
- ownership percentage
- markups
- markdowns
- DPI
- RVPI
- TVPI
- gross IRR
- net IRR
- loss ratio
- graduation rate
- follow-on rate
- strategic pilots created

## AI Opportunities

- LP update drafting
- reserve model support
- fund performance commentary
- side letter tracking
- annual meeting prep
- portfolio construction simulation
- capital call notices
- distribution notices

## Dispatch Truth Statement

Venture fund capital is not a pool of money. It is a long-duration mandate to take structured risk on innovation and compound access, knowledge, and outcomes.
