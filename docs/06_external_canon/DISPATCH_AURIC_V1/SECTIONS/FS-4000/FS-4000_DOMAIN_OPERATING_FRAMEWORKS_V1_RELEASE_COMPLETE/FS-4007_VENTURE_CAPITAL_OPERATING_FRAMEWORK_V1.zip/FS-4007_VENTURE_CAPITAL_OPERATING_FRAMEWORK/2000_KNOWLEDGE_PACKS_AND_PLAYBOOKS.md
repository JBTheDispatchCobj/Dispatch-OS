# Knowledge Packs & Playbooks

## Knowledge Packs

### Venture Foundation Pack
- terminology
- stages
- instruments
- fund economics
- workflow maps
- KPI definitions

### FinTech Venture Pack
- regulatory risk
- bank partnerships
- credit union adoption
- security reviews
- integration readiness
- compliance readiness

### Founder Diligence Pack
- founder assessment
- references
- founder-market fit
- resilience
- execution velocity

### Deal Terms Pack
- SAFE
- convertible note
- preferred equity
- pro rata
- liquidation preference
- board rights

### Portfolio Support Pack
- investor updates
- runway
- customer intros
- fundraising prep
- board prep
- hiring support

### Strategic Adoption Pack
- pilot design
- institution readiness
- vendor security
- compliance review
- ROI measurement
- expansion decision

## Playbooks

- Thesis Development Playbook
- Deal Sourcing Playbook
- Pitch Deck Review Playbook
- Founder Diligence Playbook
- FinTech Diligence Playbook
- IC Memo Playbook
- SAFE Review Playbook
- Pilot-to-Invest Playbook
- Portfolio Support Playbook
- Follow-On Decision Playbook
- LP Reporting Playbook
- Secondary Sale Playbook

## Dispatch Truth Statement

Venture knowledge packs turn pattern recognition into reusable institutional intelligence.
