# Screening & Diligence

## Purpose

This document defines venture screening and diligence.

## Screening Framework

- founder quality
- problem severity
- market size
- timing
- product clarity
- traction
- customer evidence
- go-to-market
- competition
- business model
- pricing
- margins
- technical feasibility
- security/compliance
- regulatory risk
- cap table
- valuation
- round dynamics
- strategic fit
- exit potential

## Diligence Request Object

Fields:
- request_id
- startup
- category
- requested_item
- owner
- due_date
- status
- document
- finding
- risk_level
- follow_up

## Diligence Categories

- Founder
- Market
- Customer
- Product
- Technology
- Security
- Compliance
- Regulatory
- Financial
- Legal
- Cap Table
- Fundraising
- Competition
- GTM
- References
- Strategic Adoption
- Integration Readiness

## Customer Diligence

Questions:
- Who is the buyer?
- Who is the user?
- What budget pays for it?
- What system does it replace?
- What workflow does it improve?
- How long is implementation?
- What proof exists?
- What churn risk exists?
- What procurement friction appears?
- What references exist?

## FinTech Diligence

Additional review:
- bank partnership model
- sponsor bank dependency
- regulatory posture
- BSA/AML implications
- data security
- SOC status
- API maturity
- core integrations
- compliance ownership
- implementation burden
- support requirements

## Investment Memo Sections

1. Executive Summary
2. Company Overview
3. Founder Assessment
4. Market Thesis
5. Product
6. Traction
7. Business Model
8. Customers
9. Competition
10. Financials
11. Round Terms
12. Cap Table
13. Strategic Fit
14. Risks
15. Mitigants
16. Recommendation

## AI Opportunities

- pitch deck summary
- diligence checklist
- founder brief
- customer reference summary
- cap table summary
- risk matrix
- investment memo draft
- regulatory risk detection
- product gap analysis

## Dispatch Truth Statement

Venture diligence does not eliminate uncertainty. It identifies which uncertainties are acceptable, which are fatal, and which can be reduced through network access.
