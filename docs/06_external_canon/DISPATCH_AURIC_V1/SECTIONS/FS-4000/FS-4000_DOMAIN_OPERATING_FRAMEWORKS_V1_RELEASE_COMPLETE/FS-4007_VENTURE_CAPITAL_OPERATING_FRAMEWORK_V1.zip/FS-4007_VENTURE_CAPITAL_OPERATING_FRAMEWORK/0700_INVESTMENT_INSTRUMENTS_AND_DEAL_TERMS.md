# Investment Instruments & Deal Terms

## Purpose

This document defines venture instruments, economics, rights, and deal terms.

## Instrument Types

- SAFE
- Post-Money SAFE
- Pre-Money SAFE
- Convertible Note
- Priced Preferred Equity
- Common Equity
- Warrant
- Secondary Purchase
- SPV Interest
- Co-Investment
- Venture Debt
- Revenue-Based Financing
- Strategic Investment Agreement

## SAFE Object

Fields:
- safe_id
- startup
- investor
- amount
- valuation_cap
- discount
- MFN
- pro_rata
- post_money_or_pre_money
- conversion_event
- side_letter
- closing_date

## Convertible Note Object

Fields:
- note_id
- principal
- interest_rate
- maturity
- valuation_cap
- discount
- conversion_terms
- qualified_financing
- default_terms
- investor
- startup

## Priced Round Object

Fields:
- round_id
- security
- pre_money_valuation
- post_money_valuation
- price_per_share
- liquidation_preference
- participation
- anti_dilution
- board_rights
- information_rights
- pro_rata
- ROFR
- drag_along
- protective_provisions

## Core Terms

- valuation cap
- discount
- liquidation preference
- participation
- conversion
- anti-dilution
- board seat
- observer right
- information rights
- pro rata rights
- MFN
- ROFR
- co-sale
- drag-along
- protective provisions
- option pool
- founder vesting
- side letter

## Term Review Workflow

Term Sheet → Economics Review → Rights Review → Cap Table Impact → Legal Review → IC Approval → Execution → Closing → Portfolio Setup

## AI Opportunities

- term sheet summary
- SAFE comparison
- cap table impact
- rights extraction
- side letter tracker
- valuation sensitivity
- dilution analysis
- closing checklist

## Dispatch Truth Statement

Venture terms are not just economics. They define ownership, governance, information access, downside protection, and future optionality.
