# Venture Capital Workflow Library

## Required Workflows

### Thesis Development

Signal → Market Research → Company Map → Customer Interviews → Hypothesis → Target List

### Deal Sourcing

Company Identified → Founder Contact → Intro → Materials → Screening → Partner Review

### Screening

Deck Review → Founder Assessment → Market Score → Traction Score → Strategic Fit → Decision

### Diligence

Request List → Founder Calls → Customer References → Product Review → Legal/Cap Table → Memo

### Investment Committee

Memo → Pre-Read → Discussion → Vote → Conditions → Commitment

### Closing

Legal Docs → Allocation → Wire → Signature → Portfolio Setup

### Pilot-to-Invest

Institution Problem → Startup Match → Pilot → Measurement → Strategic Decision → Investment Review

### Portfolio Support

Founder Ask → Network Search → Intro/Resource → Follow-Up → Outcome

### Follow-On

Round Notice → Performance Review → Reserve Review → IC → Funding

### Exit / Secondary

Liquidity Opportunity → Rights Review → Valuation → Approval → Closing → Distribution

## Workflow KPIs

- cycle time
- conversion rate
- founder response
- diligence completeness
- IC approval rate
- close time
- pilot conversion
- support request outcome
- follow-on accuracy

## Dispatch Truth Statement

Venture workflows must preserve both quantitative signals and relationship context.
