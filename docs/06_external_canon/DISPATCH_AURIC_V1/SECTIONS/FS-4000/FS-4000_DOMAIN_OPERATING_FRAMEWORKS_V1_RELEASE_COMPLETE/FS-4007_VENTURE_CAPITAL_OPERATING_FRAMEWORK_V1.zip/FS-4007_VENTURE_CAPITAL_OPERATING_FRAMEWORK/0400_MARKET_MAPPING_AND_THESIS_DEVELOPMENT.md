# Market Mapping & Thesis Development

## Purpose

This document defines venture thesis development, market mapping, and category intelligence.

## Thesis Object

Fields:
- thesis_id
- category
- market_problem
- customer
- pain
- timing
- enabling_technology
- regulatory_driver
- incumbent_gap
- startup_opportunity
- market_size
- adoption_path
- risks
- key_companies
- strategic_buyers
- investor_activity
- evidence
- status

## Venture Market Categories

- Payments
- Banking Infrastructure
- Credit Union Technology
- Core Banking
- Digital Banking
- Lending
- Mortgage
- Treasury
- Fraud
- Identity
- Cybersecurity
- RegTech
- Compliance
- Wealth
- Insurance
- Embedded Finance
- BaaS
- Open Banking
- Data Infrastructure
- AI Agents
- Workflow Automation
- Accounting
- Tax
- SMB Finance
- Capital Markets Infrastructure

## Market Map Object

Fields:
- market_id
- category
- subcategories
- companies
- investors
- customers
- incumbents
- strategic buyers
- regulators
- standards
- adoption barriers
- integration requirements
- pricing models
- funding activity
- exits
- white space

## Thesis Development Workflow

Signal → Problem Definition → Market Research → Company Mapping → Customer Interviews → Regulatory Review → Adoption Friction Analysis → Investment Hypothesis → Target List → Diligence Framework

## Credit Union Lens

For Auric, every fintech thesis should ask:

- What CU problem does this solve?
- Who inside the CU owns the problem?
- What system does it integrate with?
- What policy or regulatory issue appears?
- What evidence does a board need?
- What pilot would prove value?
- What CUSO or corporate CU channel could scale it?
- Could institutions invest or partner?
- Is this procurement, partnership, or investment?

## AI Opportunities

- thesis drafting
- market map creation
- company categorization
- competitor grid
- white space analysis
- strategic buyer universe
- regulatory map
- adoption barrier summary
- target list generation

## Dispatch Truth Statement

A venture thesis is not a sector preference. It is a structured hypothesis about why a market is changing, why now, who benefits, and which companies can capture the change.
