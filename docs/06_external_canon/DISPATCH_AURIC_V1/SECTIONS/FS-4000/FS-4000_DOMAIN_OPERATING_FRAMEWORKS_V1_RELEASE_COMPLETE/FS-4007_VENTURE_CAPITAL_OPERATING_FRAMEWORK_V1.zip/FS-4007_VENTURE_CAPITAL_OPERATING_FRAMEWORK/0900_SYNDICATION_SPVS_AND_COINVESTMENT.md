# Syndication, SPVs & Co-Investment

## Purpose

This document defines venture syndication, SPVs, co-investments, and network participation.

## Syndicate Object

Fields:
- syndicate_id
- startup
- lead_investor
- participating_investors
- allocation
- round_size
- valuation
- instrument
- closing_timeline
- information_rights
- lead_terms
- pro_rata
- strategic_value

## SPV Object

Fields:
- SPV_id
- manager
- startup
- round
- investors
- commitments
- capital_called
- fees
- carry
- legal_structure
- subscription_documents
- wire_status
- closing_status
- reporting

## Co-Investment Object

Fields:
- coinvestment_id
- fund
- LP
- startup
- allocation
- terms
- rights
- reporting
- closing
- side_letter
- conflicts_review

## Credit Union / CUSO Participation Lens

Auric may support:
- CUSO SPV participation
- institution-level strategic investment
- corporate CU-led innovation vehicles
- fintech pilot-to-invest pathways
- cooperative co-investment clubs
- non-fund strategic access models
- compliant marketplace participation

## Syndication Workflow

Allocation Opportunity → Investor Fit → Materials → Interest → Subscription → Capital Call → Close → Reporting → Follow-On

## KPIs

- syndicate participants
- allocation filled
- close time
- capital raised
- co-investment conversion
- strategic investors added
- investor update engagement
- follow-on participation

## AI Opportunities

- investor fit matching
- SPV document checklist
- subscription tracking
- allocation management
- co-investment memo
- investor communication drafts
- strategic participant discovery

## Dispatch Truth Statement

Syndication is relationship architecture. The right capital can be more valuable than the largest check.
