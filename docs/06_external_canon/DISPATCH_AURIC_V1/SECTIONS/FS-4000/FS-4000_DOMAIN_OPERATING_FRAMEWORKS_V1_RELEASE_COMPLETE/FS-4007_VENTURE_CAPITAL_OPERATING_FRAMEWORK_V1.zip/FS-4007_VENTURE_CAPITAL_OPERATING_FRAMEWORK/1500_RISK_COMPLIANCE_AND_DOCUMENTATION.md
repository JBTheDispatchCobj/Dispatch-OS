# Risk, Compliance & Documentation

## Purpose

This document defines venture risk, compliance, legal, and documentation.

## Risk Domains

- founder risk
- market risk
- product risk
- technology risk
- security risk
- regulatory risk
- funding risk
- valuation risk
- cap table risk
- customer concentration
- adoption risk
- platform risk
- competition
- legal/IP risk
- governance risk
- liquidity risk
- reputational risk

## Compliance Areas

- investment adviser compliance
- conflicts of interest
- allocation policy
- side letters
- valuation policy
- marketing rule
- custody rule where applicable
- AML/KYC
- sanctions
- privacy
- data security
- accredited investor / qualified purchaser
- securities exemptions
- finder/solicitation rules

## Venture Documents

- Pitch Deck
- Data Room
- SAFE
- Convertible Note
- Term Sheet
- Stock Purchase Agreement
- Investor Rights Agreement
- Voting Agreement
- ROFR/Co-Sale
- Side Letter
- Cap Table
- Board Consent
- Subscription Agreement
- SPV Documents
- Investor Update
- Pro Rata Notice
- Secondary Transfer Documents

## Documentation Workflow

Document Intake → Classification → Term Extraction → Legal Review → Approval → Signature → Storage → Relationship Linking → Obligation Tracking

## AI Opportunities

- term extraction
- side letter tracking
- cap table review
- risk matrix
- document checklist
- compliance review support
- conflict detection
- valuation policy support

## Dispatch Truth Statement

Venture documentation captures ownership, rights, obligations, and optionality. Dispatch must make those rights operationally visible.
