# Acceptance Tests & Roadmap

## Object Tests

- Can create Venture Fund.
- Can create LP.
- Can create Startup.
- Can create Founder.
- Can create Deal.
- Can create Round.
- Can create SAFE.
- Can create Convertible Note.
- Can create Investment Memo.
- Can create Pilot.
- Can create Portfolio Company.
- Can create Follow-On Decision.
- Can create Exit.

## Relationship Tests

- Founder FOUNDS Startup.
- Fund INVESTS_IN Startup.
- LP COMMITS_TO Fund.
- Investor PARTICIPATES_IN Round.
- SAFE CONVERTS_INTO Equity.
- Pilot VALIDATES Startup.
- Institution PILOTS Product.
- Follow-On Decision RESPONDS_TO Round.
- Exit REALIZES Investment.

## Workflow Tests

- Thesis workflow creates market map.
- Deal sourcing workflow creates pipeline.
- Screening workflow scores company.
- Diligence workflow creates memo.
- IC workflow records decision.
- Closing workflow creates investment record.
- Pilot-to-invest workflow measures adoption.
- Portfolio monitoring workflow parses update.
- Follow-on workflow produces recommendation.
- LP reporting workflow creates report.

## Agent Tests

- Pitch Deck Summarizer creates company brief.
- Founder Research Agent creates founder profile.
- Market Analyst creates category map.
- Investment Memo Writer drafts memo.
- Strategic Pilot Manager creates pilot plan.
- Investor Update Parser extracts KPIs.
- Follow-On Memo Agent drafts recommendation.
- LP Reporting Agent drafts quarterly update.

## Roadmap

Priority 1:
- machine-readable venture object registry
- fixture venture fund
- fixture startup
- fixture pitch deck summary
- fixture investment memo
- fixture pilot workflow

Priority 2:
- deal pipeline
- startup profiles
- founder profiles
- strategic adoption scoring
- IC workflow
- LP reporting

Priority 3:
- market map engine
- relationship graph
- follow-on reserve engine
- secondary/liquidity tracker
- credit union fintech adoption marketplace

## Dispatch Truth Statement

The Venture Capital cartridge is accepted when Dispatch can connect startup intelligence, fund capital, investment judgment, strategic adoption, portfolio support, and outcomes into one institutional knowledge system.
