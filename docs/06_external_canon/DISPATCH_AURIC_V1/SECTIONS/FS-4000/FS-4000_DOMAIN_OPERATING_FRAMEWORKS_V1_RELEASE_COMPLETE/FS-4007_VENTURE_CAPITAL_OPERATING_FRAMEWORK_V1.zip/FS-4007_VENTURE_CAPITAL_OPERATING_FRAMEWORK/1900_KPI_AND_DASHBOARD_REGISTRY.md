# KPI & Dashboard Registry

## Deal Flow KPIs

- companies sourced
- decks reviewed
- intro calls
- diligence starts
- IC reviews
- investments closed
- source quality
- proprietary percentage
- time to decision
- conversion rate

## Fund KPIs

- committed capital
- deployed capital
- uncalled capital
- reserves
- ownership
- active investments
- follow-on rate
- gross IRR
- net IRR
- TVPI
- DPI
- RVPI
- loss ratio

## Startup KPIs

- ARR
- MRR
- growth
- burn
- runway
- cash
- gross margin
- retention
- churn
- pipeline
- active users
- customers
- implementation time
- support burden

## Strategic Adoption KPIs

- pilots launched
- pilots completed
- pilot conversion
- institution adoption
- revenue influenced
- implementation time
- compliance issues
- strategic partnerships
- CUSO opportunities
- investment opportunities

## Dashboards

- Fund Dashboard
- Deal Flow Dashboard
- Thesis Dashboard
- Startup Dashboard
- Portfolio Dashboard
- Follow-On Dashboard
- Strategic Adoption Dashboard
- LP Reporting Dashboard
- Exit Dashboard
- Relationship Graph Dashboard

## Dispatch Truth Statement

Venture KPIs must track both financial performance and network value creation.
