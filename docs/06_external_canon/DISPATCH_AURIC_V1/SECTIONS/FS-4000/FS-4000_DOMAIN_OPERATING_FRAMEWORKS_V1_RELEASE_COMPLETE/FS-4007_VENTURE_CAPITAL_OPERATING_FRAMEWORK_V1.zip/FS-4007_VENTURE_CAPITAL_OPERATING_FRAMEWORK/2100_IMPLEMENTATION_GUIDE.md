# Venture Capital Implementation Guide

## Phase 1 — Setup

- create venture firm
- create fund
- configure strategy
- configure stages
- configure categories
- configure investment committee
- configure check sizes
- configure reserve policy
- configure LP reporting cadence

## Phase 2 — Objects

- startups
- founders
- investors
- deals
- rounds
- instruments
- cap tables
- memos
- pilots
- portfolio companies
- follow-on decisions
- exits

## Phase 3 — Workflows

Activate:
- thesis development
- deal sourcing
- screening
- diligence
- IC
- closing
- pilot-to-invest
- portfolio support
- follow-on
- LP reporting

## Phase 4 — Agents

Deploy:
- Deal Scout
- Pitch Deck Summarizer
- Founder Research Agent
- Market Analyst
- Investment Memo Writer
- Strategic Pilot Manager
- Investor Update Parser
- Follow-On Memo Agent
- LP Reporting Agent

## Phase 5 — Dashboards

Configure:
- fund dashboard
- deal flow
- thesis
- startup profile
- portfolio
- strategic adoption
- follow-on
- LP reporting
- relationship graph

## Demo Flow

1. Open thesis dashboard.
2. Show fintech market map.
3. Ingest pitch deck.
4. Generate startup profile.
5. Score credit union readiness.
6. Draft investment memo.
7. Create pilot-to-invest workflow.
8. Parse investor update.
9. Generate follow-on recommendation.
10. Produce LP report.

## Dispatch Truth Statement

Venture implementation should begin with startup and relationship truth, then layer diligence, pilots, portfolio support, and LP reporting.
