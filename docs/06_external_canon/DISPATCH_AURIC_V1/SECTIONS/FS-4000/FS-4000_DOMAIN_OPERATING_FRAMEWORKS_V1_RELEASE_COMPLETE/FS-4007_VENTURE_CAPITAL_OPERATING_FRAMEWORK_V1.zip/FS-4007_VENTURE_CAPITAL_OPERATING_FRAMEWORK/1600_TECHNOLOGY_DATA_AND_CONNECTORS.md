# Technology, Data & Connectors

## Purpose

This document defines the venture technology stack and connector priorities.

## Technology Categories

- CRM
- Deal Pipeline
- Data Room
- Cap Table
- Fund Accounting
- Investor Portal
- Portfolio Monitoring
- Market Intelligence
- Email/Calendar
- Document Management
- E-Signature
- BI/Data Warehouse
- Startup Databases
- Web Research
- AI Platform

## Data Objects

- startup
- founder
- investor
- fund
- LP
- deal
- round
- instrument
- cap table
- memo
- diligence item
- portfolio company
- investor update
- pilot
- strategic partner
- follow-on decision
- exit
- relationship

## Connector Priorities

Tier 1:
- email/calendar
- document storage
- CRM/pipeline
- spreadsheet/CSV
- data rooms
- AI provider
- web research

Tier 2:
- cap table platforms
- fund accounting
- investor portals
- e-signature
- portfolio monitoring
- market databases
- company databases

Tier 3:
- startup metrics platforms
- accounting systems
- product analytics
- CRM from portfolio companies
- data warehouses

## Data Quality Rules

- founder must link to startup
- round must link to instrument
- investment must link to fund
- pro rata must link to rights source
- pilot must link to institution
- strategic partner must link to company and use case
- all terms must preserve source document

## AI Opportunities

- deck ingestion
- data room indexing
- founder profile enrichment
- company categorization
- market map generation
- cap table normalization
- investor update extraction
- relationship graph enrichment

## Dispatch Truth Statement

Venture data is relationship-heavy and document-heavy. Dispatch makes it operational by linking founders, companies, investors, rounds, rights, pilots, and outcomes.
