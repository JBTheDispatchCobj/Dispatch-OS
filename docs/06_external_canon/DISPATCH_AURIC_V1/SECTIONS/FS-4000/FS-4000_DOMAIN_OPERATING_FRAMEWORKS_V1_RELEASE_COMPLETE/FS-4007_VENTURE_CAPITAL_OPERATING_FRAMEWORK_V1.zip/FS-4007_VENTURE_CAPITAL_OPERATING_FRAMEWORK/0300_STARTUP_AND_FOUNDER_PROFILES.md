# Startup & Founder Profiles

## Purpose

This document defines startup, founder, company, product, and team intelligence.

## Founder Object

Fields:
- founder_id
- name
- role
- background
- prior_companies
- education
- domain_expertise
- technical_expertise
- sales_expertise
- fundraising_history
- leadership_score
- references
- network
- founder_market_fit
- communication_quality
- resilience_score
- known_relationships

## Startup Profile Sections

- company overview
- problem
- solution
- product
- customer
- market
- business model
- traction
- revenue
- pipeline
- go-to-market
- competition
- technology
- security
- compliance
- regulatory posture
- team
- investors
- cap table
- funding history
- runway
- risks
- strategic fit
- institution readiness
- integration readiness

## Founder Assessment

Dispatch tracks:

- founder-market fit
- urgency of problem
- product vision
- hiring ability
- selling ability
- technical judgment
- customer empathy
- adaptability
- integrity
- coachability
- execution velocity
- communication
- fundraising capability
- ability to navigate regulation

## Startup Metrics

- ARR
- MRR
- revenue growth
- gross margin
- net revenue retention
- gross revenue retention
- churn
- CAC
- LTV
- payback
- pipeline
- conversion
- active users
- transaction volume
- API calls
- implementation time
- customer concentration
- burn
- runway

## FinTech-Specific Profile Additions

- target institution type
- core integrations
- digital banking integrations
- regulatory dependencies
- bank partnership dependencies
- sponsor bank dependencies
- compliance model
- security posture
- SOC status
- implementation model
- procurement friction
- pilot requirements
- data requirements
- pricing model
- support model

## AI Opportunities

- founder brief
- startup profile generation
- traction analysis
- market fit summary
- regulatory risk summary
- institution readiness score
- integration readiness score
- customer reference summary
- investor update summary

## Dispatch Truth Statement

A startup is not a pitch deck. It is a living operating system made of founders, product, market, traction, capital, customers, risk, and readiness for institutional adoption.
