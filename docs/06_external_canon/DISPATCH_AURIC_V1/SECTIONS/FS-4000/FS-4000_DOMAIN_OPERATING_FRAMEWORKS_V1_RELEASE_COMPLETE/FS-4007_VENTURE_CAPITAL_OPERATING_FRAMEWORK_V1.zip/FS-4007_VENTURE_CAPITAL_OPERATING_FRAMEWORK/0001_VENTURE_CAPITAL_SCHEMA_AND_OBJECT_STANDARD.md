# Venture Capital Schema & Object Standard

## Purpose

This document defines canonical venture capital objects used by Dispatch.

## Universal Startup Object

Fields:

- startup_id
- legal_name
- display_name
- sector
- category
- stage
- founding_date
- headquarters
- founders
- CEO
- product
- customers
- revenue_model
- ARR
- MRR
- GMV
- usage_metrics
- funding_history
- investors
- valuation
- cap_table
- runway
- burn_rate
- cash
- employees
- technology_stack
- regulatory_profile
- compliance_readiness
- integration_readiness
- institution_readiness
- strategic_fit
- risk_rating
- documents
- relationships
- workflows
- KPIs
- AI_context
- audit_history

## Core Venture Objects

- Venture Fund
- Management Company
- General Partner
- Limited Partner
- Startup
- Founder
- Executive
- Investor
- Angel
- Accelerator
- Incubator
- Studio
- Syndicate
- SPV
- SAFE
- Convertible Note
- Preferred Equity
- Warrant
- Option Pool
- Cap Table
- Board
- Observer
- Investment Memo
- Term Sheet
- Data Room
- Pilot
- Strategic Partner
- Customer Reference
- Follow-On Round
- Secondary Sale
- Exit
- Acquisition

## Startup Stages

- Idea
- Pre-Seed
- Seed
- Post-Seed
- Series A
- Series B
- Growth
- Late Stage
- Pre-IPO
- Distressed
- Acquired
- Public
- Shut Down

## Venture Investment Types

- SAFE
- Convertible Note
- Priced Equity
- Preferred Equity
- Common Equity
- Secondary Purchase
- SPV Participation
- Co-Investment
- Strategic Investment
- CUSO Investment
- Revenue-Based Financing
- Venture Debt
- Warrant
- Pilot-to-Investment

## Dispatch Truth Statement

Venture objects connect founders, markets, products, customers, capital, regulation, integration readiness, strategic adoption, and network relationships into one institutional intelligence graph.
