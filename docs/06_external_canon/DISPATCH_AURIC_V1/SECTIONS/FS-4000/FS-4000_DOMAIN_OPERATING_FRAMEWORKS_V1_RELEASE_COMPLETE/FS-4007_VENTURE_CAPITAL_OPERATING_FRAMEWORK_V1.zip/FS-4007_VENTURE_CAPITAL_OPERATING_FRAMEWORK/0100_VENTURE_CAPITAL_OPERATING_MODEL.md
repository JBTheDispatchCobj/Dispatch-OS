# Venture Capital Operating Model

## Definition

Venture capital is the institutional practice of investing in early and growth-stage companies where uncertainty is high, upside is asymmetric, and network access, adoption, capital, and judgment influence outcomes.

## Operating Layers

### 1. Fund & Mandate Layer

Defines strategy, stage, check size, reserve model, ownership targets, sector focus, LP obligations, reporting, and portfolio construction.

### 2. Market Thesis Layer

Defines sectors, customer problems, technology shifts, regulatory openings, infrastructure gaps, and categories where innovation can produce outlier outcomes.

### 3. Sourcing Layer

Captures inbound, outbound, founder networks, accelerators, angels, operators, strategic partners, fintech ecosystems, credit union networks, and proprietary intelligence.

### 4. Screening Layer

Evaluates founder quality, market size, problem severity, product, traction, business model, timing, valuation, competition, regulatory risk, and strategic relevance.

### 5. Diligence Layer

Tests product, market, customers, technology, security, legal, financials, cap table, references, pipeline, adoption friction, and path to next round.

### 6. Investment Layer

Determines instrument, valuation, ownership, allocation, rights, pro rata, governance, reserves, co-investment, and closing.

### 7. Portfolio Support Layer

Supports sales, hiring, partnerships, pilots, customer intros, fundraising, product feedback, compliance readiness, and strategic relationships.

### 8. Monitoring Layer

Tracks runway, burn, revenue, pipeline, product usage, customer adoption, investor updates, follow-on needs, risks, and valuation changes.

### 9. Liquidity Layer

Manages follow-ons, secondaries, acquisitions, write-offs, IPOs, recapitalizations, and distributions.

## Venture Operating Cadence

Daily:
- new deals
- founder updates
- portfolio alerts
- investor news
- customer intros
- market signals

Weekly:
- deal flow review
- partner meeting
- diligence updates
- portfolio support needs
- fundraising pipeline
- strategic adoption pipeline

Monthly:
- portfolio company updates
- runway review
- KPI review
- follow-on tracking
- LP update inputs
- market intelligence

Quarterly:
- valuation updates
- LP reporting
- reserve planning
- portfolio construction review
- fund performance
- strategic network review

Annual:
- fund audit
- tax
- annual meeting
- strategy refresh
- LP review
- portfolio support plan

## Dispatch Truth Statement

Venture capital is structured learning under uncertainty. Dispatch must preserve each assumption, signal, decision, relationship, and outcome so the fund becomes smarter with every investment.
