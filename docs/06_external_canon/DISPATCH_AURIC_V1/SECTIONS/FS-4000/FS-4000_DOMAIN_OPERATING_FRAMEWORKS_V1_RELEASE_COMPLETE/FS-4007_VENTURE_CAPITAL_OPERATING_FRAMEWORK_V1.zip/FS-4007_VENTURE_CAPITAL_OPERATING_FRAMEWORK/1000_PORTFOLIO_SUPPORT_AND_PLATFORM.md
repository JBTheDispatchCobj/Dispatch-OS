# Portfolio Support & Platform

## Purpose

This document defines post-investment support for startups.

## Portfolio Support Categories

- Fundraising
- Customer Introductions
- Strategic Partnerships
- Talent
- Hiring
- Pricing
- Go-to-Market
- Product Feedback
- Compliance Readiness
- Security Readiness
- Enterprise Sales
- Credit Union Adoption
- Bank Partnership
- Vendor Partnerships
- Board Prep
- Investor Updates
- Financial Planning
- Operations
- Exit Readiness

## Portfolio Company Object

Fields:
- company_id
- fund
- investment
- stage
- ownership
- cost_basis
- current_value
- founders
- board
- KPIs
- runway
- burn
- revenue
- customers
- strategic_needs
- support_requests
- introductions
- pilots
- risks
- follow_on_status
- exit_status

## Platform Request Object

Fields:
- request_id
- startup
- category
- description
- urgency
- owner
- related_relationships
- status
- outcome
- value_created
- knowledge_generated

## Support Workflow

Founder Need → Request → Network Search → Intro/Resource → Follow-Up → Outcome → Knowledge Capture

## Board / Advisor Support

Dispatch tracks:
- board meetings
- investor updates
- key metrics
- strategic issues
- hiring needs
- runway
- fundraising
- product launches
- customer pipeline
- founder asks
- action items

## Portfolio KPIs

- support requests
- introductions made
- customer intros
- pilots launched
- follow-on rounds
- hiring assists
- strategic partnerships
- revenue influenced
- runway risk
- founder satisfaction
- knowledge objects created

## AI Opportunities

- investor update summary
- founder request routing
- intro path discovery
- board prep
- fundraising narrative
- customer target list
- sales deck feedback
- pricing feedback
- strategic partner matching

## Dispatch Truth Statement

Venture platform is not a service menu. It is the operating network that converts capital into advantage.
