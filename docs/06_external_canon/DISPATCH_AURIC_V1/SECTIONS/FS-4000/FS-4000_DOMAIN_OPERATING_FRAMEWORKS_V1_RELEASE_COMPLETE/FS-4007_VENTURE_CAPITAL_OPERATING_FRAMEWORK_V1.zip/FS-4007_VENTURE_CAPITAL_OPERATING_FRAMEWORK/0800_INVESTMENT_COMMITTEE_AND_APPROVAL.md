# Investment Committee & Approval

## Purpose

This document defines venture investment approval.

## Investment Committee Object

Fields:
- committee_id
- members
- authority
- quorum
- voting_rules
- conflict_policy
- meeting_cadence
- approval_thresholds
- decisions
- minutes
- conditions
- follow_ups

## IC Decision Types

- Pass
- Watch
- Diligence Approved
- Soft Commit
- Invest
- Invest Subject to Conditions
- Follow-On Approved
- Secondary Approved
- Write-Off
- Reserve Allocation

## IC Memo Object

Fields:
- memo_id
- startup
- round
- amount
- instrument
- valuation
- thesis
- founder_assessment
- market
- product
- traction
- customers
- competition
- strategic_fit
- risks
- mitigants
- expected_return
- recommendation
- conditions

## Approval Workflow

Partner Sponsorship → Memo Draft → Pre-Read → IC Discussion → Vote → Conditions → Legal Review → Final Allocation → Closing → Portfolio Setup

## IC Questions

- Why now?
- Why this team?
- Why this market?
- Why this product?
- Why this valuation?
- Why can this be huge?
- What kills it?
- What proves it?
- Who buys it?
- What is our edge?
- What can Auric/Dispatch do to help?

## AI Opportunities

- IC memo draft
- dissenting view generation
- risk table
- founder questions
- strategic fit summary
- scenario analysis
- decision log
- post-investment assumptions tracker

## Dispatch Truth Statement

Venture IC is the institutional memory of risk-taking. Dispatch must preserve the assumptions behind every investment.
