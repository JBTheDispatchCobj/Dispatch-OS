# Sourcing & Deal Flow

## Purpose

This document defines venture deal sourcing, relationship mapping, and pipeline management.

## Deal Sources

- Founder Inbound
- Investor Referral
- Angel Network
- Accelerator
- Incubator
- University
- Operator Network
- Credit Union Executive
- Corporate Credit Union
- CUSO
- FinTech Vendor
- Bank Partner
- Conference
- Demo Day
- Product Hunt / Public Launch
- Customer Signal
- Regulatory Signal
- Market Research
- Portfolio Founder
- Strategic Partner
- Auric Intelligence Network

## Venture Deal Object

Fields:
- deal_id
- startup
- founders
- source
- source_contact
- category
- stage
- round
- amount_raising
- valuation
- lead_investor
- allocation_available
- traction
- customer_fit
- strategic_fit
- status
- probability
- next_action
- partner_owner
- diligence_status
- relationship_context

## Sourcing Lifecycle

Signal → Company Identified → Founder Contact → Intro Call → Materials → Screening → Partner Review → Diligence → IC → Commit → Close

## Deal Flow Statuses

- New
- Reviewed
- Declined
- Watching
- Intro Scheduled
- Diligence
- IC
- Soft Commit
- Committed
- Closed
- Passed
- Lost
- Portfolio
- Archived

## Source Scoring

Inputs:
- deal quality
- relevance
- conversion rate
- founder quality
- stage fit
- strategic fit
- proprietary nature
- timing
- trust
- prior outcomes

## Pipeline KPIs

- deals sourced
- qualified deals
- intro calls
- diligence starts
- IC reviews
- commitments
- closed investments
- conversion rate
- proprietary deal percentage
- source quality
- time to decision
- category coverage

## AI Opportunities

- inbound triage
- deal scoring
- founder background research
- warm intro path discovery
- pipeline prioritization
- follow-up drafting
- source performance analysis
- CRM cleanup
- duplicate company detection

## Dispatch Truth Statement

Venture sourcing is network intelligence. The best funds win because they see better companies earlier and understand why they matter.
