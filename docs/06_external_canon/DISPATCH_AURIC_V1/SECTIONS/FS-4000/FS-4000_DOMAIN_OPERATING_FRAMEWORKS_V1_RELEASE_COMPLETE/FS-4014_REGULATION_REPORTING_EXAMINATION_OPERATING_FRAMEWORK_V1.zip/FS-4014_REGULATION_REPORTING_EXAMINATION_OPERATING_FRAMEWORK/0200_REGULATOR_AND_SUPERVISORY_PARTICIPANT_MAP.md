# Regulator & Supervisory Participant Map

## Purpose

This document defines the regulatory and supervisory participant ecosystem.

## Regulator Object

Fields:
- regulator_id
- name
- jurisdiction
- entity_types_supervised
- authority
- examination_scope
- reporting_requirements
- enforcement_authority
- guidance_sources
- contacts
- portals
- cadence
- risk_focus_areas

## Core Federal / Supervisory Participants

- NCUA
- Federal Reserve
- FDIC
- OCC
- CFPB
- FinCEN
- SEC
- FINRA
- CFTC where applicable
- Treasury
- IRS
- FTC
- HUD
- FHA
- VA
- USDA
- SBA
- State Banking Regulators
- State Credit Union Regulators
- State Insurance Departments
- State Securities Regulators
- State Mortgage Regulators
- OFAC
- FFIEC
- Federal Home Loan Banks where applicable

## Industry Participant Objects

- Trade Association
- Corporate Credit Union
- CUSO
- Compliance Consultant
- Auditor
- Law Firm
- Examination Consultant
- Vendor Risk Platform
- Core Provider
- RegTech Vendor
- Training Provider
- Board Portal
- Document Management Provider

## Examiner Object

Fields:
- examiner_id
- regulator
- name
- exam_type
- focus_areas
- prior_requests
- known_preferences
- communications
- institutions_examined
- issue_patterns
- relationship_notes

## Supervisory Relationship Types

- REGULATES
- EXAMINES
- ISSUES_GUIDANCE
- RECEIVES_REPORT
- ENFORCES
- APPROVES
- LICENSES
- CHARTERS
- INSURES
- AUDITS
- TESTS
- CONSULTS
- REPORTS_TO

## AI Opportunities

- regulator profile
- examiner request pattern analysis
- supervisory theme summary
- regulator obligation map
- compliance contact map
- portal/checklist assistant
- peer finding trend map

## Dispatch Truth Statement

Regulatory intelligence begins with knowing who has authority, what they expect, where evidence goes, and how supervisory judgment has historically appeared.
