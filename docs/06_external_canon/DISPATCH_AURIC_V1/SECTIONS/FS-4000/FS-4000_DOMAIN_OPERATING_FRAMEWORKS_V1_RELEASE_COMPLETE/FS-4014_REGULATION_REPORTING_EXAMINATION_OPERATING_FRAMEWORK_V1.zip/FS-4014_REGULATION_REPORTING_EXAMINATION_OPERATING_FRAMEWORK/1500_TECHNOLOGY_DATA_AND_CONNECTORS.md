# Technology, Data & Connectors

## Purpose

This document defines the compliance/regulatory technology stack and connector priorities.

## Technology Categories

- GRC Platform
- Compliance Management System
- Policy Management
- Audit Management
- Exam Management
- Issue Management
- Vendor Risk Management
- BSA/AML System
- Complaint Management
- Regulatory Reporting
- Training/LMS
- Document Management
- Board Portal
- Data Warehouse
- Core Banking
- LOS
- CRM
- SIEM / Cyber Tools
- Ticketing System
- AI Platform

## Data Objects

- institution
- regulator
- rule
- obligation
- control
- policy
- procedure
- evidence
- report
- filing
- calendar
- exam request
- finding
- issue
- remediation
- vendor
- training
- complaint
- board report
- audit trail

## Connector Priorities

Tier 1:
- document storage
- email/calendar
- spreadsheet/CSV
- policy repository
- board portal exports
- AI provider

Tier 2:
- GRC/compliance system
- audit management
- issue management
- vendor management
- complaint system
- LMS/training
- BSA/AML
- regulatory reporting
- core/LOS reports

Tier 3:
- regulator portals
- cybersecurity systems
- SIEM
- ticketing
- data warehouse
- external legal/regulatory feeds
- vendor SOC/document portals

## Data Quality Rules

- obligations must map to rules
- controls must map to obligations
- evidence must map to controls or requests
- findings must map to source and remediation
- reports must map to calendar items
- policies must map to owners and approvals
- vendors must map to risk tier and review cadence
- regulatory changes must map to impact assessment

## AI Opportunities

- obligation extraction
- evidence retrieval
- policy mapping
- issue summarization
- regulatory change summary
- exam response drafting
- dashboard commentary
- connector health monitoring

## Dispatch Truth Statement

Regulatory technology should not create another filing cabinet. It should make obligations, evidence, issues, and governance executable.
