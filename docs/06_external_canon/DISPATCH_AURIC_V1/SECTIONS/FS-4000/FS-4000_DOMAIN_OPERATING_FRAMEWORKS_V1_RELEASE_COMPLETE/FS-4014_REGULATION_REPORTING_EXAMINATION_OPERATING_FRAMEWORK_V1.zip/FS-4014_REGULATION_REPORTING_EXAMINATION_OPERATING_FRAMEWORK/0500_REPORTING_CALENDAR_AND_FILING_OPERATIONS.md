# Reporting Calendar & Filing Operations

## Purpose

This document defines regulatory reporting, filing calendars, attestations, and submission workflows.

## Reporting Obligation Object

Fields:
- report_id
- report_name
- regulator
- institution
- frequency
- due_date
- period_covered
- owner
- preparer
- reviewer
- approver
- source_data
- portal
- submission_status
- confirmation
- exceptions
- evidence
- audit_history

## Common Filing / Reporting Categories

- Call Reports
- Credit Union 5300 Call Report
- Bank Call Report
- SAR
- CTR
- OFAC Reporting
- HMDA
- CRA
- Fair Lending Reports
- Mortgage Reports
- Privacy Notices
- Financial Statements
- Board Reports
- Audit Reports
- Vendor Reports
- Cyber Incident Reports
- Insurance Licensing Reports
- Securities Filings where applicable
- Form D where applicable
- ADV/CRS where applicable
- State License Renewals
- Tax Reporting
- SBA Reporting
- Investor Reporting where governed

## Reporting Calendar Object

Fields:
- calendar_id
- institution
- report
- frequency
- due_date
- reminder_schedule
- dependencies
- owners
- status
- evidence
- escalation

## Filing Workflow

Calendar Trigger → Data Collection → Preparation → Review → Approval → Submission → Confirmation → Archive → Exception Review

## Data Dependencies

- GL
- core banking
- loan system
- deposit system
- mortgage LOS
- BSA/AML system
- HMDA LAR
- HR/training
- vendor system
- complaint system
- cybersecurity logs
- board minutes
- audit system

## KPIs

- reports due
- reports filed on time
- late filings
- filing corrections
- data quality issues
- review cycle time
- evidence completeness
- owner SLA compliance

## AI Opportunities

- filing calendar generation
- reporting checklist
- data dependency map
- report drafting support
- variance explanation
- submission evidence tracker
- late-risk alert
- filing QA checklist

## Dispatch Truth Statement

Regulatory reporting is not a calendar reminder. It is a controlled data, review, approval, and evidence workflow.
