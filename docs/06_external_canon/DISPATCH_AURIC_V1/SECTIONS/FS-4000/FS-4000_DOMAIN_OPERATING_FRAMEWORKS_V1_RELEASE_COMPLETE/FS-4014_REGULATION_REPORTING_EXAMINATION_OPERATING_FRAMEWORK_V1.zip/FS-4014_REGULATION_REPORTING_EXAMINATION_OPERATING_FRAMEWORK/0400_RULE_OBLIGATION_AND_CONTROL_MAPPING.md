# Rule, Obligation & Control Mapping

## Purpose

This document defines how Dispatch maps legal/regulatory text into operational requirements.

## Rule Object

Fields:
- rule_id
- title
- source
- citation
- regulator
- effective_date
- status
- summary
- full_text_reference
- impacted_domains
- related_guidance
- change_history

## Obligation Object

Fields:
- obligation_id
- rule
- requirement
- applicability
- owner
- frequency
- trigger
- evidence_required
- control
- policy
- procedure
- testing
- reporting
- risk_level

## Control Object

Fields:
- control_id
- obligation
- control_type
- objective
- owner
- frequency
- system
- procedure
- evidence
- testing_method
- effectiveness
- exceptions
- reviewer

## Control Types

- preventive
- detective
- corrective
- manual
- automated
- system-based
- approval-based
- reconciliation
- review
- attestation
- training
- monitoring

## Mapping Workflow

Rule Intake → Applicability Review → Obligation Extraction → Owner Assignment → Policy Mapping → Procedure Mapping → Control Mapping → Evidence Definition → Testing Plan → Approval → Monitoring

## Evidence Examples

- report filing confirmation
- board minutes
- policy approval
- system screenshot
- transaction sample
- exception report
- training record
- complaint log
- vendor review
- audit workpaper
- control test result
- management attestation

## KPIs

- obligations mapped
- controls mapped
- unmapped rules
- evidence gaps
- controls tested
- exceptions
- overdue reviews
- policy gaps
- procedure gaps

## AI Opportunities

- obligation extraction
- control mapping suggestions
- policy gap analysis
- evidence checklist
- requirement summary
- control test plan
- applicability support
- citation-to-control graphing

## Dispatch Truth Statement

Compliance becomes executable when every rule is translated into owned obligations, controls, evidence, and testing.
