# KPI & Dashboard Registry

## Compliance KPIs

- obligations mapped
- controls mapped
- controls tested
- policy currency
- procedure currency
- training completion
- complaints
- compliance exceptions
- regulatory changes open
- control failures

## Reporting KPIs

- filings due
- filings on time
- filing corrections
- data quality issues
- review cycle time
- owner SLA
- evidence completeness
- submission confirmations

## Exam KPIs

- open exam requests
- overdue requests
- evidence completeness
- examiner follow-ups
- findings
- repeat findings
- management response timing
- remediation closure
- exam readiness score

## Audit / Testing KPIs

- audits scheduled
- audits completed
- exceptions
- high-risk findings
- retest completion
- validation failures
- overdue action items
- control effectiveness

## Vendor KPIs

- critical vendors
- reviews complete
- reviews overdue
- SOC reports current
- contracts expiring
- vendor incidents
- vendor risk ratings
- exit plans complete

## Governance KPIs

- board reports delivered
- policies approved
- action items overdue
- committee escalations
- high-risk issues
- risk appetite breaches
- AI/model risk exceptions

## Dashboards

- Regulatory Executive Dashboard
- Compliance Calendar Dashboard
- Obligation/Control Dashboard
- Filing Dashboard
- Exam Dashboard
- Audit Dashboard
- Issue Remediation Dashboard
- Vendor Risk Dashboard
- Regulatory Change Dashboard
- Board Governance Dashboard
- AI Governance Dashboard

## Dispatch Truth Statement

Regulatory KPIs must show whether the institution can prove control before an examiner asks.
