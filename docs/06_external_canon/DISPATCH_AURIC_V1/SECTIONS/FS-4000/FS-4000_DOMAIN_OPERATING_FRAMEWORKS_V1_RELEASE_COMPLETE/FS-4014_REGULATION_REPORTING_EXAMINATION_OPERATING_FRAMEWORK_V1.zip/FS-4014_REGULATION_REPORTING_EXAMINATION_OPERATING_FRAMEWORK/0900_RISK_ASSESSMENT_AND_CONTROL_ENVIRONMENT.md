# Risk Assessment & Control Environment

## Purpose

This document defines institutional risk assessments and control environment monitoring.

## Risk Assessment Object

Fields:
- assessment_id
- institution
- domain
- period
- inherent_risk
- controls
- residual_risk
- trend
- risk_appetite
- owner
- evidence
- action_items
- approval

## Risk Domains

- Credit Risk
- Liquidity Risk
- Interest Rate Risk
- Market Risk
- Operational Risk
- Compliance Risk
- BSA/AML Risk
- Fraud Risk
- Cybersecurity Risk
- Technology Risk
- Vendor Risk
- Model Risk
- AI Risk
- Strategic Risk
- Reputation Risk
- Legal Risk
- Capital Risk
- Consumer Compliance Risk
- Privacy Risk

## Control Environment Inputs

- policies
- procedures
- control inventory
- testing results
- exceptions
- losses
- complaints
- audit findings
- exam findings
- vendor issues
- cyber incidents
- training results
- staffing changes
- product changes
- regulatory change

## Risk Rating Scale

Example:
- Low
- Moderate
- Elevated
- High
- Critical

Risk dimensions:
- impact
- likelihood
- velocity
- control strength
- trend
- residual exposure

## Risk Assessment Workflow

Scope → Data Collection → Inherent Risk → Control Review → Residual Risk → Action Plan → Management Review → Board/Committee Approval → Monitoring

## KPIs

- risk assessments complete
- high residual risks
- control failures
- action items
- risk trend
- appetite breaches
- testing exceptions
- loss events
- unresolved issues

## AI Opportunities

- risk assessment draft
- control effectiveness summary
- risk heatmap
- appetite breach detection
- issue trend analysis
- board risk commentary
- AI risk assessment support

## Dispatch Truth Statement

Risk assessment is how an institution explains its exposure before losses, exams, or failures force the explanation.
