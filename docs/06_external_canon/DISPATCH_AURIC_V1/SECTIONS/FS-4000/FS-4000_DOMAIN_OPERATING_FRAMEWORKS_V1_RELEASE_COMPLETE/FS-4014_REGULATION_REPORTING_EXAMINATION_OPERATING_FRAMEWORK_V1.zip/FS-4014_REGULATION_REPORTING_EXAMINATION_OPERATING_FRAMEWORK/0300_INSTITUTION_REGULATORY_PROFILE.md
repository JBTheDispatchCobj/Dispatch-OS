# Institution Regulatory Profile

## Purpose

This document defines the regulatory profile of an institution or entity.

## Regulatory Profile Object

Fields:
- profile_id
- institution_id
- legal_name
- charter_type
- license_type
- regulators
- deposit_insurance_status
- jurisdictions
- entity_type
- asset_size
- member_customer_type
- products
- services
- subsidiaries
- CUSOs
- vendors
- risk_profile
- reporting_requirements
- examination_cadence
- enforcement_history
- open_findings
- compliance_owner
- board_committee
- last_review_date

## Profile Inputs

- charter
- bylaws
- licenses
- call reports
- annual reports
- product list
- vendor list
- policy inventory
- board committee structure
- risk assessment
- audit reports
- exam reports
- enforcement actions
- organizational chart
- strategic plan

## Applicability Rules

Dispatch determines applicability based on:

- charter type
- legal entity type
- asset size
- geography
- customer/member base
- product offerings
- lending activities
- mortgage activity
- payments activity
- investment activity
- insurance activity
- wealth activity
- fintech/vendor activity
- third-party relationships
- data and privacy footprint

## Regulatory Readiness Score

Inputs:
- policy currency
- control mapping
- evidence completeness
- findings open
- training completion
- reporting timeliness
- vendor reviews
- complaint trends
- audit issues
- regulatory change backlog
- board reporting quality

## AI Opportunities

- institution regulatory profile
- applicability matrix
- readiness score
- missing policy list
- reporting calendar generation
- exam readiness summary
- risk heatmap
- board compliance brief

## Dispatch Truth Statement

An institution's regulatory profile is the root object that determines what compliance means for that institution.
