# Data, Records & Retention

## Purpose

This document defines regulatory records, retention, data lineage, privacy, and retrieval.

## Record Object

Fields:
- record_id
- title
- record_type
- owner
- system_of_record
- retention_period
- retention_basis
- legal_hold_status
- confidentiality
- related_obligation
- related_workflow
- creation_date
- expiration_date
- archive_status
- deletion_status
- audit_history

## Record Types

- policies
- procedures
- board minutes
- committee minutes
- loan files
- member/customer records
- account records
- transaction records
- BSA records
- SAR/CTR evidence
- complaint records
- vendor records
- audit workpapers
- exam responses
- regulatory filings
- employee training
- marketing materials
- advisory records
- insurance records
- mortgage records
- cybersecurity logs
- AI decision logs

## Data Governance Objects

- Data Owner
- Data Steward
- System of Record
- Data Classification
- Data Lineage
- Retention Schedule
- Legal Hold
- Privacy Request
- Access Review
- Data Quality Issue

## Retention Workflow

Record Created → Classification → Retention Assignment → Storage → Access Control → Review → Legal Hold Check → Archive → Disposal Approval → Destruction Evidence

## Privacy / Access Considerations

- least privilege
- confidentiality
- encryption
- retention limit
- customer/member privacy
- vendor access
- AI access
- audit logs
- consent
- data minimization

## KPIs

- records classified
- retention schedules assigned
- expired records
- legal holds
- access reviews
- missing records
- retrieval time
- data quality issues
- unauthorized access events

## AI Opportunities

- record classification
- retention mapping
- data lineage summary
- missing record detection
- legal hold checklist
- privacy request support
- evidence retrieval assistant

## Dispatch Truth Statement

Records are institutional memory under legal obligation. They must be findable, controlled, retained, and defensibly destroyed.
