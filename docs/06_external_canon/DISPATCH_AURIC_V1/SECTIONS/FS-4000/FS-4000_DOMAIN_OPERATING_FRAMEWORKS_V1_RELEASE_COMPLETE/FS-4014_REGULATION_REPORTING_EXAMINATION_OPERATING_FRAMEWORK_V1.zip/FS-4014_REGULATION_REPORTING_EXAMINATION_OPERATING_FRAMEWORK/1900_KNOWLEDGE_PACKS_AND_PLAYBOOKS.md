# Knowledge Packs & Playbooks

## Knowledge Packs

### Regulation Foundation Pack

- regulator taxonomy
- obligation taxonomy
- control taxonomy
- evidence taxonomy
- workflow maps
- KPI definitions

### Credit Union Compliance Pack

- charter profile
- call reporting
- NCUA exam prep
- CUSO oversight
- vendor risk
- member-facing compliance

### Bank Compliance Pack

- bank profile
- call reporting
- FDIC/OCC/Fed supervision
- CRA/fair lending
- vendor risk
- board governance

### BSA/AML Pack

- risk assessment
- SAR/CTR
- OFAC
- CDD/KYC/KYB
- monitoring
- evidence

### Mortgage Compliance Pack

- TRID
- ECOA
- HMDA
- RESPA/TILA
- flood
- appraisal
- adverse action

### Vendor / Fintech Oversight Pack

- due diligence
- security review
- SOC review
- contract obligations
- pilot controls
- CUSO/fintech governance

### Exam Management Pack

- request list
- evidence room
- examiner Q&A
- findings
- management response
- remediation

### AI Governance Pack

- AI inventory
- model risk
- human approval
- audit logs
- evidence
- policy
- vendor AI review

## Playbooks

- Regulatory Profile Setup Playbook
- Obligation Mapping Playbook
- Filing Calendar Playbook
- Exam Readiness Playbook
- Exam Response Playbook
- Finding Remediation Playbook
- Policy Review Playbook
- Vendor Review Playbook
- Regulatory Change Playbook
- Board Compliance Reporting Playbook
- Fintech Pilot Compliance Playbook
- AI Governance Playbook

## Dispatch Truth Statement

Regulatory knowledge packs turn rules, guidance, and supervisory patterns into executable compliance systems.
