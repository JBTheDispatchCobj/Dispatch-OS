# Regulation Schema & Object Standard

## Purpose

This document defines canonical regulation, reporting, examination, and compliance objects used by Dispatch.

## Universal Regulatory Obligation Object

Fields:

- obligation_id
- obligation_name
- source_authority
- regulator_id
- citation
- jurisdiction
- applicable_entity_types
- business_domain
- requirement_summary
- owner
- frequency
- due_date
- trigger
- policy_links
- procedure_links
- control_links
- evidence_required
- reporting_required
- risk_level
- status
- last_review_date
- next_review_date
- exceptions
- audit_history
- AI_context

## Core Regulatory Objects

- Regulator
- Agency
- Examiner
- Examination
- Exam Request
- Supervisory Letter
- Rule
- Regulation
- Guidance
- Obligation
- Citation
- Policy
- Procedure
- Control
- Risk Assessment
- Compliance Test
- Evidence
- Filing
- Report
- Calendar Item
- Board Report
- Committee
- Finding
- Issue
- Matter Requiring Attention
- Corrective Action
- Remediation Plan
- Vendor Review
- Third-Party Risk Review
- Regulatory Change
- Approval
- Attestation
- Audit Trail
- Record
- Retention Schedule

## Institution Types Covered

- Credit Union
- Corporate Credit Union
- Bank
- Bank Holding Company
- CUSO
- Fintech
- Mortgage Lender
- Broker-Dealer where applicable
- RIA where applicable
- Insurance Agency where applicable
- Private Fund Manager where applicable
- Commercial Lender
- Payment Provider
- Wealth Program
- Loan Participation Platform
- Vendor / Third Party

## Dispatch Rule

Every rule must map to at least one obligation.  
Every obligation must map to an owner, control, evidence requirement, review cadence, and audit trail.

## Dispatch Truth Statement

Regulatory objects make compliance operational by converting text, guidance, deadlines, controls, and evidence into actionable institutional memory.
