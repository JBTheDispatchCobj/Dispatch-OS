# Issue, Finding & Remediation Management

## Purpose

This document defines findings, issues, corrective actions, remediation, validation, and closure.

## Issue Object

Fields:
- issue_id
- institution
- source
- domain
- description
- severity
- owner
- root_cause
- affected_obligations
- affected_controls
- remediation_plan
- due_date
- status
- evidence
- validation
- closure_date
- escalation

## Finding Sources

- regulatory exam
- internal audit
- external audit
- compliance testing
- control self-assessment
- vendor review
- incident
- complaint
- model validation
- cyber assessment
- board review
- management review

## Severity Levels

- Low
- Moderate
- High
- Critical
- MRA / MRIA equivalent where applicable
- Repeat Finding
- Enforcement Risk

## Remediation Plan Object

Fields:
- plan_id
- issue
- root_cause
- corrective_actions
- owner
- milestones
- target_date
- resources
- dependencies
- evidence_required
- validation_method
- status

## Remediation Workflow

Finding → Severity → Root Cause → Action Plan → Approval → Execution → Evidence → Validation → Closure → Sustainability Testing

## KPIs

- open issues
- overdue issues
- critical issues
- repeat findings
- remediation cycle time
- validation failures
- sustainability failures
- issue aging
- owner SLA
- examiner/audit closure

## AI Opportunities

- finding summary
- root cause suggestion
- remediation plan draft
- action item tracker
- evidence checklist
- management response draft
- validation plan
- repeat finding detection

## Dispatch Truth Statement

A finding is not closed when management says it is closed. It is closed when evidence proves the control environment changed.
