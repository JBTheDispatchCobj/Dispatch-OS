# Policy, Procedure & Governance

## Purpose

This document defines policy inventory, procedure management, approvals, governance, and board oversight.

## Policy Object

Fields:
- policy_id
- title
- owner
- approving_body
- effective_date
- review_frequency
- last_review_date
- next_review_date
- related_rules
- related_obligations
- related_controls
- procedures
- exceptions
- status
- version
- approval_history

## Procedure Object

Fields:
- procedure_id
- policy
- process
- owner
- steps
- systems
- evidence
- controls
- frequency
- role_responsibilities
- review_date
- version

## Governance Object

Fields:
- governance_id
- body
- charter
- members
- authority
- meeting_cadence
- reports
- decisions
- minutes
- action_items
- escalation_paths

## Governance Bodies

- Board of Directors
- Supervisory Committee
- Audit Committee
- Risk Committee
- Compliance Committee
- ALCO
- IT Steering Committee
- Vendor Management Committee
- Credit Committee
- Loan Committee
- Investment Committee
- Trust Committee
- BSA Committee
- Model Risk Committee
- AI Governance Committee

## Policy Lifecycle

Need → Draft → Legal/Compliance Review → Management Review → Committee Review → Board Approval → Publication → Training → Monitoring → Annual Review → Revision / Retirement

## Procedure Lifecycle

Process Change → Draft → Owner Review → Control Mapping → Training → Use → Testing → Update

## KPIs

- policies current
- policies overdue
- procedures current
- unmapped procedures
- board approvals
- training completion
- policy exceptions
- version control exceptions
- governance action items overdue

## AI Opportunities

- policy draft
- policy comparison
- procedure draft
- policy-to-obligation mapping
- version change summary
- board approval tracker
- training content generation
- governance minutes summary

## Dispatch Truth Statement

Policies are the institution's stated rules. Procedures and controls prove those rules are operational.
