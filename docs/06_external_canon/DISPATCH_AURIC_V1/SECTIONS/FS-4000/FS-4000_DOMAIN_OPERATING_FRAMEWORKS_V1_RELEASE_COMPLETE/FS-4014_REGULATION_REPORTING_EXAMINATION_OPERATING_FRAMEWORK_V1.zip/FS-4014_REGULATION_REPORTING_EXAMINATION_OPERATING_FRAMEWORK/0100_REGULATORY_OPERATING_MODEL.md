# Regulatory Operating Model

## Definition

The regulatory operating model is the system by which an institution identifies obligations, assigns ownership, creates controls, collects evidence, reports to boards and regulators, responds to exams, remediates findings, and adapts to regulatory change.

## Operating Layers

### 1. Authority Layer

Defines regulators, statutes, rules, guidance, supervision manuals, enforcement actions, consent orders, FAQs, and examiner expectations.

### 2. Applicability Layer

Determines which obligations apply based on charter, size, activities, products, geography, customer/member type, licenses, vendors, and risk profile.

### 3. Governance Layer

Defines board oversight, committees, executive ownership, compliance function, risk function, audit function, and escalation paths.

### 4. Control Layer

Maps obligations to policies, procedures, controls, testing, training, systems, approvals, and evidence.

### 5. Reporting Layer

Defines filings, call reports, HMDA, SAR/CTR, CRA, privacy notices, board reports, audit reports, vendor reviews, management reports, and regulatory submissions.

### 6. Examination Layer

Manages request lists, evidence, interviews, examiner questions, findings, responses, corrective actions, and closure.

### 7. Change Layer

Monitors regulatory change, assesses impact, updates policies, modifies procedures, trains teams, implements controls, and documents completion.

### 8. Intelligence Layer

Tracks regulatory trends, examiner patterns, peer findings, enforcement themes, product opportunities, risk heatmaps, and institutional readiness.

## Compliance Operating Cadence

Daily:
- alerts
- suspicious activity queues
- deadline monitoring
- issue escalation
- complaint intake
- vendor events
- policy exceptions

Weekly:
- compliance queue review
- issue tracking
- evidence collection
- regulatory change scan
- vendor risk items
- audit requests

Monthly:
- compliance dashboard
- board/committee reporting
- open finding status
- policy review calendar
- training completion
- report filing status

Quarterly:
- risk assessment update
- control testing
- regulatory change review
- vendor review
- board risk package
- audit committee

Annual:
- compliance plan
- risk assessment
- policy approval
- training plan
- vendor annual review
- audit plan
- exam readiness review

## Dispatch Truth Statement

A regulatory operating model is successful when the institution can prove what applies, who owns it, how it is controlled, what evidence exists, and what changed.
