# Vendor, Third Party & Fintech Oversight

## Purpose

This document defines vendor, third-party, fintech, CUSO, and partner risk oversight.

## Vendor Object

Fields:
- vendor_id
- name
- category
- product_service
- criticality
- business_owner
- contract
- renewal_date
- risk_rating
- data_access
- customer_member_impact
- compliance_review
- security_review
- financial_review
- SOC_reports
- insurance
- BCP
- subcontractors
- issues
- performance
- exit_plan

## Third-Party Relationship Types

- Core Provider
- Digital Banking
- Payment Processor
- Card Processor
- Lending Vendor
- Mortgage Vendor
- Wealth Partner
- Insurance Partner
- Fintech Partner
- CUSO
- Cloud Provider
- Data Provider
- AI Provider
- Compliance Vendor
- Marketing Vendor
- Collection Vendor
- Servicer
- Loan Participation Platform
- BaaS / Embedded Finance Partner

## Review Types

- due diligence
- contract review
- security review
- compliance review
- financial condition review
- SOC review
- insurance review
- BCP review
- performance review
- renewal review
- termination / exit review
- ongoing monitoring

## Vendor Review Workflow

Need → Vendor Intake → Risk Tier → Due Diligence → Security/Compliance Review → Contract → Approval → Implementation → Monitoring → Renewal / Exit

## Fintech Oversight Additions

- regulatory ownership
- data flows
- model/AI usage
- customer/member impact
- complaint handling
- servicing responsibility
- third-party dependencies
- integration risk
- implementation risk
- pilot controls
- strategic investment relationship

## KPIs

- vendors by tier
- critical vendors
- reviews complete
- reviews overdue
- contracts expiring
- SOC reports current
- security exceptions
- vendor issues
- service incidents
- exit plans complete
- fintech pilots approved

## AI Opportunities

- vendor risk summary
- SOC report summary
- contract obligation extraction
- renewal alert
- vendor comparison
- fintech readiness review
- security questionnaire summary
- exit plan draft

## Dispatch Truth Statement

Third-party oversight is institutional accountability for outsourced activity. A vendor can perform the task, but the institution retains the risk.
