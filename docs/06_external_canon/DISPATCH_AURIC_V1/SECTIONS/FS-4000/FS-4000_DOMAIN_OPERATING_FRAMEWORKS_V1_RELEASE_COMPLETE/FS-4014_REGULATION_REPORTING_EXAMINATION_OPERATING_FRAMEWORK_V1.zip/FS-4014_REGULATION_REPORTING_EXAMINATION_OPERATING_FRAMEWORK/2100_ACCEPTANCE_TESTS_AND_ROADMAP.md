# Acceptance Tests & Roadmap

## Object Tests

- Can create Regulator.
- Can create Institution Regulatory Profile.
- Can create Rule.
- Can create Obligation.
- Can create Policy.
- Can create Procedure.
- Can create Control.
- Can create Evidence.
- Can create Filing.
- Can create Examination.
- Can create Exam Request.
- Can create Finding.
- Can create Remediation Plan.
- Can create Vendor Review.
- Can create Regulatory Change.
- Can create Board Report.

## Relationship Tests

- Regulator SUPERVISES Institution.
- Rule CREATES Obligation.
- Obligation GOVERNED_BY Policy.
- Procedure IMPLEMENTS Policy.
- Control SATISFIES Obligation.
- Evidence PROVES Control.
- Filing SUBMITTED_TO Regulator.
- Exam Request REQUIRES Evidence.
- Finding CREATES Remediation Plan.
- Vendor Review EVALUATES Vendor.
- Regulatory Change IMPACTS Policy.
- Board Report SUMMARIZES Risk.

## Workflow Tests

- Regulatory profile setup creates applicability map.
- Obligation mapping links rule to control and evidence.
- Filing workflow captures approval and confirmation.
- Exam workflow tracks request to response.
- Audit workflow tests control.
- Policy review workflow captures approval.
- Remediation workflow validates closure.
- Vendor review workflow assigns risk tier.
- Regulatory change workflow creates implementation actions.
- Board reporting workflow creates governance package.

## Agent Tests

- Obligation Extractor creates candidate obligations.
- Evidence Collector finds matching evidence.
- Exam Request Parser converts request list into tasks.
- Filing Checklist Agent creates submission checklist.
- Vendor Risk Reviewer summarizes due diligence.
- Management Response Agent drafts response.
- Regulatory Change Monitor summarizes change.
- Board Compliance Report Writer drafts board report.

## Roadmap

Priority 1:
- machine-readable regulatory object registry
- fixture credit union profile
- fixture rule/obligation/control/evidence map
- fixture filing calendar
- fixture exam request list
- fixture remediation plan

Priority 2:
- compliance calendar engine
- evidence repository mapping
- exam management workflow
- policy/control mapper
- issue remediation dashboard
- vendor review workflow

Priority 3:
- regulatory change feed
- peer finding intelligence
- AI governance module
- CUSO/fintech oversight module
- board governance package generator

## Dispatch Truth Statement

The Regulation, Reporting & Examination cartridge is accepted when Dispatch can prove obligations, controls, evidence, filings, exams, findings, remediation, vendor oversight, and board governance in one institutional operating system.
