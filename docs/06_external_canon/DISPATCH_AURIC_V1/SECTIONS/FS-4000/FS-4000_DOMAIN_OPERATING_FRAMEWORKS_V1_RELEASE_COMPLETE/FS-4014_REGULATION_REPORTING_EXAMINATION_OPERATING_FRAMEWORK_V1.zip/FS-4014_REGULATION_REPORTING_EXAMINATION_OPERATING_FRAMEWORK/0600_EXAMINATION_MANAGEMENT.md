# Examination Management

## Purpose

This document defines examination planning, request management, response, tracking, and closure.

## Examination Object

Fields:
- examination_id
- institution
- regulator
- exam_type
- start_date
- scope
- examiners
- request_list
- evidence
- meetings
- questions
- findings
- management_responses
- status
- final_report
- remediation
- closure_date

## Exam Types

- Safety and Soundness
- Consumer Compliance
- BSA/AML
- IT / Cybersecurity
- Fair Lending
- Mortgage
- Credit Review
- Liquidity / ALM
- Vendor / Third-Party Risk
- Fiduciary / Trust
- Wealth / Brokerage
- Insurance
- Specialty Exam
- Follow-Up Exam

## Exam Request Object

Fields:
- request_id
- examination
- request_number
- description
- owner
- due_date
- status
- evidence_items
- response
- examiner_follow_up
- confidentiality
- approval
- audit_history

## Exam Workflow

Notice → Scope Review → Internal Kickoff → Request List → Evidence Collection → Response Review → Submission → Interviews → Follow-Up Questions → Exit Meeting → Report → Management Response → Remediation → Closure

## Exam Room Controls

- request tracking
- version control
- evidence approval
- response approval
- privilege/confidentiality review
- owner assignment
- deadline tracking
- examiner communication log
- follow-up tracker
- response history

## KPIs

- open exam requests
- overdue requests
- response cycle time
- evidence completeness
- examiner follow-up rate
- findings
- repeat findings
- management response timeliness
- remediation closure
- exam readiness score

## AI Opportunities

- request list parser
- evidence finder
- response draft
- examiner question tracker
- exam status summary
- finding theme analysis
- management response draft
- exam readiness briefing

## Dispatch Truth Statement

Exam management is controlled evidence production under supervisory scrutiny.
