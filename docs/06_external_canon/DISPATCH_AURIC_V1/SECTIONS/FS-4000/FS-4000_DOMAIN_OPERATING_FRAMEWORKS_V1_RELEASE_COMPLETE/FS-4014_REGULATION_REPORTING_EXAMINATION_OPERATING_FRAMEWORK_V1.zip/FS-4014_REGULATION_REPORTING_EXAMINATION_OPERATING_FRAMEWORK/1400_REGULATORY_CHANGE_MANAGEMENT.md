# Regulatory Change Management

## Purpose

This document defines regulatory change intake, impact assessment, implementation, and attestation.

## Regulatory Change Object

Fields:
- change_id
- source
- regulator
- title
- citation
- publication_date
- effective_date
- comment_deadline
- summary
- impacted_domains
- applicability
- risk_level
- owner
- required_actions
- policies_impacted
- procedures_impacted
- controls_impacted
- training_impacted
- systems_impacted
- implementation_status
- evidence
- board_reporting_required

## Change Sources

- final rules
- proposed rules
- guidance
- FAQs
- enforcement actions
- supervisory letters
- agency speeches
- examiner feedback
- industry alerts
- litigation
- state law updates
- market practices
- vendor notifications

## Change Workflow

Monitor → Intake → Triage → Applicability → Impact Assessment → Action Plan → Implementation → Training → Control Update → Evidence → Approval → Board/Committee Reporting → Closure

## Impact Assessment Areas

- products
- policies
- procedures
- controls
- systems
- vendors
- data
- disclosures
- training
- reporting
- customer/member communications
- contracts
- board oversight
- staffing

## KPIs

- changes identified
- changes applicable
- impact assessments complete
- open implementation tasks
- overdue changes
- policy updates
- training updates
- control updates
- board reports
- closure evidence

## AI Opportunities

- change summary
- applicability analysis support
- impact assessment draft
- action plan generation
- policy/procedure update suggestions
- training outline
- board memo
- implementation tracker

## Dispatch Truth Statement

Regulatory change management converts external rule movement into internal operating change.
