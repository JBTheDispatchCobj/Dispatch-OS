# Board & Committee Reporting

## Purpose

This document defines governance reporting for board and committees.

## Board Report Object

Fields:
- report_id
- institution
- board_or_committee
- period
- owner
- topics
- KPIs
- issues
- decisions_required
- approvals
- risks
- attachments
- meeting_date
- minutes_link
- action_items
- audit_history

## Required Reporting Areas

- enterprise risk
- compliance
- BSA/AML
- audit
- credit risk
- liquidity/ALM
- vendor risk
- cybersecurity
- complaints
- regulatory change
- exam status
- findings/remediation
- policy approvals
- training completion
- AI/model risk
- strategic initiatives

## Committee Reporting

- Audit Committee
- Supervisory Committee
- Risk Committee
- Compliance Committee
- ALCO
- Credit Committee
- IT Steering Committee
- Vendor Committee
- Investment Committee
- Trust Committee
- AI Governance Committee

## Board Package Workflow

Data Pull → KPI Update → Issue Review → Management Commentary → Decisions Required → Review → Distribution → Meeting → Minutes → Action Items → Archive

## Decision Object

Fields:
- decision_id
- body
- topic
- recommendation
- approval_status
- conditions
- vote
- rationale
- evidence
- follow_up

## KPIs

- reports delivered on time
- action items overdue
- policies approved
- decisions pending
- board package completeness
- repeat issues
- high-risk items
- committee escalation quality

## AI Opportunities

- board packet drafting
- committee report summary
- decision log
- action item tracker
- executive risk commentary
- findings/remediation summary
- policy approval brief

## Dispatch Truth Statement

Board reporting is not management theater. It is the evidence that governance saw, understood, challenged, and acted.
