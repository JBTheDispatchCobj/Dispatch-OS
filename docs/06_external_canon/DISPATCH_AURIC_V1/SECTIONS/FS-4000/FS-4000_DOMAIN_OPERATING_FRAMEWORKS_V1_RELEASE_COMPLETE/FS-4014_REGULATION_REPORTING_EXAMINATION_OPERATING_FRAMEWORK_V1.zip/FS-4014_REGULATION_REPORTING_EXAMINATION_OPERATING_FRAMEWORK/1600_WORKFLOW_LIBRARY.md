# Regulation, Reporting & Examination Workflow Library

## Required Workflows

### Regulatory Profile Setup

Institution → Charter/License → Activities → Regulators → Obligations → Calendar → Owners

### Obligation Mapping

Rule → Applicability → Obligation → Owner → Policy → Control → Evidence → Testing

### Filing Workflow

Calendar → Data Collection → Preparation → Review → Approval → Submission → Confirmation → Archive

### Exam Management

Notice → Request List → Evidence → Response → Follow-Up → Findings → Management Response → Remediation

### Audit / Testing

Plan → Population → Sample → Evidence → Testing → Exceptions → Report → Remediation → Retest

### Policy Review

Calendar → Owner Review → Rule Mapping → Revisions → Approval → Training → Archive

### Issue Remediation

Finding → Root Cause → Plan → Action → Evidence → Validation → Closure

### Vendor Review

Vendor Intake → Risk Tier → Due Diligence → Review → Approval → Monitoring → Renewal/Exit

### Regulatory Change

Monitor → Intake → Applicability → Impact → Action Plan → Implementation → Evidence → Closure

### Board Reporting

Data Pull → KPI → Issues → Decisions → Review → Meeting → Minutes → Action Items

## Workflow KPIs

- cycle time
- overdue tasks
- evidence completeness
- owner SLA
- exception rate
- findings closed
- repeat issues
- report timeliness
- board action closure

## Dispatch Truth Statement

Regulatory workflows convert supervision from reactive scramble into repeatable institutional control.
