# Audit, Testing & Evidence Management

## Purpose

This document defines audit, compliance testing, evidence, sampling, and workpaper management.

## Audit Object

Fields:
- audit_id
- institution
- audit_type
- scope
- auditor
- period
- request_list
- testing
- findings
- management_responses
- report
- status
- closure

## Compliance Test Object

Fields:
- test_id
- obligation
- control
- population
- sample
- method
- tester
- result
- exceptions
- evidence
- conclusion
- remediation

## Evidence Object

Fields:
- evidence_id
- title
- type
- source_system
- owner
- related_obligation
- related_control
- related_request
- period
- file_reference
- version
- confidentiality
- retention
- approval_status
- audit_history

## Evidence Types

- policy
- procedure
- report
- screenshot
- transaction sample
- board minutes
- committee minutes
- training record
- attestation
- exception report
- reconciliation
- system export
- email
- signed agreement
- vendor document
- audit workpaper

## Testing Workflow

Test Plan → Population Pull → Sample Selection → Evidence Request → Testing → Exceptions → Review → Report → Remediation → Retest

## Evidence Management Workflow

Requirement → Owner → Collection → Review → Approval → Linkage → Retention → Retrieval

## KPIs

- tests scheduled
- tests completed
- exceptions
- control failures
- evidence gaps
- audit requests
- audit findings
- retesting completion
- evidence retrieval time
- stale evidence

## AI Opportunities

- evidence classification
- evidence gap detection
- sample testing support
- workpaper summary
- exception theme analysis
- audit request response
- control test draft
- evidence mapping

## Dispatch Truth Statement

Evidence is the currency of compliance. If the institution cannot retrieve it, it cannot prove control.
