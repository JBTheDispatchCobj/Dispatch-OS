# KPI & Dashboard Registry

## Market KPIs

- issuance volume
- trading volume
- spreads
- yields
- liquidity
- volatility
- investor demand
- oversubscription
- bid/ask spread
- market depth

## Transaction KPIs

- capital raised
- deals closed
- conversion rate
- pricing variance
- settlement fails
- allocation quality
- closing time
- documentation exceptions

## Portfolio KPIs

- market value
- book value
- yield
- duration
- unrealized gain/loss
- realized gain/loss
- income
- rating distribution
- maturity ladder
- liquidity score
- concentration

## Compliance KPIs

- eligibility exceptions
- disclosure exceptions
- trade supervision exceptions
- valuation exceptions
- records complete
- policy exceptions
- audit findings

## Operations KPIs

- settlement time
- reconciliation breaks
- failed trades
- corporate action processing
- income accuracy
- custody statement timeliness

## Dashboards

- Capital Markets Executive Dashboard
- Offering Dashboard
- Investor Appetite Dashboard
- Trading Dashboard
- Portfolio Dashboard
- Valuation Dashboard
- Settlement Dashboard
- Compliance Dashboard
- Participation Marketplace Dashboard
- Structured Finance Dashboard

## Dispatch Truth Statement

Capital markets KPIs must show both market opportunity and operational control.
