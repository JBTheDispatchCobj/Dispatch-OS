# Capital Markets Operating Model

## Definition

Capital markets are the systems, institutions, products, rules, and workflows that allow capital to be raised, allocated, traded, financed, settled, and monitored.

## Operating Layers

### 1. Participant Layer

Defines issuers, borrowers, investors, intermediaries, advisors, service providers, custodians, clearing entities, exchanges, and regulators.

### 2. Instrument Layer

Defines the financial contract or security: bond, equity, loan, participation, derivative, structured product, fund interest, or private placement.

### 3. Primary Market Layer

Handles issuance, underwriting, placement, subscription, allocation, pricing, documentation, investor qualification, and closing.

### 4. Secondary Market Layer

Handles trading, liquidity, bids, offers, transfer restrictions, settlement, custody, marks, and reporting.

### 5. Structuring Layer

Defines tranche, priority, collateral, waterfall, credit enhancement, guarantee, insurance, leverage, covenants, and rating.

### 6. Investment Operations Layer

Includes trade capture, reconciliation, position keeping, performance, valuation, income, distributions, corporate actions, and reporting.

### 7. Risk & Compliance Layer

Includes suitability, accreditation, disclosures, securities law, market conduct, conflicts, best execution, insider information, sanctions, AML, and supervision.

### 8. Intelligence Layer

Maps market signals, capital flows, investor appetite, issuer needs, intermediary networks, spreads, valuations, performance, and strategic opportunities.

## Capital Markets Operating Cadence

Daily:
- trade activity
- market prices
- risk alerts
- settlement status
- liquidity
- portfolio marks
- issuer news
- counterparty events

Weekly:
- pipeline review
- investor appetite
- syndication status
- secondary liquidity
- position review
- market commentary

Monthly:
- portfolio reporting
- valuation
- income
- compliance exceptions
- investor statements
- risk reports

Quarterly:
- board/investment committee reporting
- portfolio performance
- regulatory reporting
- capital allocation review
- market outlook

Annual:
- audit
- policy review
- investor reporting
- compliance review
- strategy and allocation review

## Dispatch Truth Statement

Capital markets are the institutional coordination layer between capital supply and capital demand. Dispatch must model each transaction as both a financial instrument and an operational workflow.
