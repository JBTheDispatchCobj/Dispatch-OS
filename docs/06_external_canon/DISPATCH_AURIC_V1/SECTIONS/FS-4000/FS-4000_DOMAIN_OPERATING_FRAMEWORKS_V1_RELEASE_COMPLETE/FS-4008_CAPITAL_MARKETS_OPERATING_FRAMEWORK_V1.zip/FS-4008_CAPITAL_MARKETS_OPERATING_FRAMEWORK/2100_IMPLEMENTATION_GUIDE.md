# Capital Markets Implementation Guide

## Phase 1 — Setup

- define institution type
- configure participant taxonomy
- configure instrument taxonomy
- configure investment policy
- configure approval authority
- configure compliance requirements
- configure settlement/custody model

## Phase 2 — Objects

- participants
- issuers
- investors
- instruments
- offerings
- trades
- positions
- portfolios
- valuations
- settlements
- documents
- compliance evidence

## Phase 3 — Workflows

Activate:
- offering
- private placement
- secondary trade
- participation sale
- securitization
- investment decision
- valuation
- settlement
- compliance review

## Phase 4 — Agents

Deploy:
- Market Analyst
- Investor Matching Agent
- Offering Coordinator
- Investment Analyst
- Valuation Analyst
- Settlement Agent
- Compliance Review Agent
- Participation Package Agent

## Phase 5 — Dashboards

Configure:
- market intelligence
- offering
- investor appetite
- portfolio
- valuation
- settlement
- compliance
- participation marketplace

## Demo Flow

1. Open capital markets dashboard.
2. Show issuer profile.
3. Show investor appetite map.
4. Generate offering summary.
5. Match investors.
6. Review instrument terms.
7. Execute participation workflow.
8. Show valuation dashboard.
9. Resolve settlement exception.
10. Generate board investment report.

## Dispatch Truth Statement

Capital markets implementation begins with participant, instrument, and transaction truth.
