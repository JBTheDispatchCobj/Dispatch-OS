# Capital Markets Workflow Library

## Required Workflows

### Offering Workflow

Issuer Need → Structuring → Materials → Investor Targeting → Bookbuilding → Pricing → Allocation → Closing

### Private Placement Workflow

Mandate → Investor Eligibility → Materials → Subscription → Funding → Closing → Reporting

### Secondary Trade Workflow

Bid/Offer → Eligibility → Documentation → Trade Capture → Settlement → Position Update

### Participation Sale Workflow

Loan Package → Buyer Review → Agreement → Funding → Servicing → Reporting

### Securitization Workflow

Asset Pool → Eligibility → Structuring → Rating → Offering → Closing → Surveillance

### Investment Decision Workflow

Opportunity → Policy Check → Diligence → Approval → Trade/Subscription → Settlement → Monitoring

### Valuation Workflow

Data → Pricing Source → Model → Review → Approval → Reporting

### Settlement Workflow

Trade → Confirmation → Instructions → Cash/Security Movement → Reconciliation → Archive

### Compliance Review Workflow

Transaction → Rule Mapping → Eligibility → Disclosure → Approval → Evidence → Archive

## Workflow KPIs

- cycle time
- approval time
- settlement time
- exception rate
- automation percentage
- investor conversion
- pricing variance
- compliance exceptions
- reconciliation breaks

## Dispatch Truth Statement

Capital markets workflows convert market intent into governed, settled, reportable financial exposure.
