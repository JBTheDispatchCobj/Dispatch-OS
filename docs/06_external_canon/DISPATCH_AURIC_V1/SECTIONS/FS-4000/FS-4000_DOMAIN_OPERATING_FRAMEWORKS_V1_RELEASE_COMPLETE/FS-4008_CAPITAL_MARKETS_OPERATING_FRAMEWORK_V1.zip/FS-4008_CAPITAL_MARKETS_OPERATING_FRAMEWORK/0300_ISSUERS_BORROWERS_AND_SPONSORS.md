# Issuers, Borrowers & Sponsors

## Purpose

This document defines entities seeking capital or issuing instruments.

## Issuer Object

Fields:
- issuer_id
- legal_name
- entity_type
- sector
- jurisdiction
- financials
- rating
- capital_need
- instrument_history
- outstanding_securities
- debt_schedule
- investor_base
- disclosures
- covenants
- reporting_history
- default_history
- sponsor
- advisors
- regulatory_profile

## Borrower Object

Fields:
- borrower_id
- legal_name
- industry
- revenue
- EBITDA
- cash_flow
- leverage
- liquidity
- collateral
- management
- sponsor
- credit_rating
- existing_debt
- requested_capital
- use_of_proceeds
- repayment_source
- reporting_quality
- risk_profile

## Sponsor Object

Fields:
- sponsor_id
- type
- AUM
- funds
- portfolio
- track_record
- capital_support
- reputation
- relationships
- prior_transactions
- support_history
- governance_role

## Use of Proceeds

- acquisition
- refinancing
- growth
- working capital
- recapitalization
- shareholder liquidity
- capital expenditure
- construction
- warehouse funding
- portfolio financing
- regulatory capital
- liquidity
- general corporate purposes

## Issuer Readiness

Dispatch evaluates:
- financial reporting quality
- audit status
- governance
- legal structure
- collateral
- ratings
- investor materials
- regulatory constraints
- covenant capacity
- market timing
- investor appetite

## AI Opportunities

- issuer profile
- borrower credit brief
- sponsor profile
- use-of-proceeds analysis
- investor material checklist
- readiness score
- capital structure recommendation

## Dispatch Truth Statement

Issuers and borrowers are not capital requests. They are operating entities whose governance, financials, relationships, documents, and market credibility determine access to capital.
