# Capital Markets Schema & Object Standard

## Purpose

This document defines canonical capital markets objects used by Dispatch.

## Universal Capital Markets Transaction Object

Fields:

- transaction_id
- transaction_type
- issuer_id
- borrower_id
- sponsor_id
- investor_ids
- intermediary_ids
- instrument_type
- amount
- currency
- pricing
- yield
- coupon
- spread
- maturity
- duration
- rating
- collateral
- structure
- offering_status
- settlement_status
- compliance_status
- documents
- approvals
- workflows
- KPIs
- audit_history
- AI_context

## Market Participant Objects

- Issuer
- Borrower
- Sponsor
- Investor
- Underwriter
- Placement Agent
- Broker Dealer
- Investment Bank
- RIA
- Asset Manager
- Fund
- Custodian
- Trustee
- Servicer
- Rating Agency
- Transfer Agent
- Administrator
- Exchange
- ATS
- Clearinghouse
- Depository
- Regulator
- Legal Counsel
- Auditor
- Data Provider
- Market Maker

## Instrument Objects

- Bond
- Note
- Loan
- Participation
- Syndicated Loan
- Preferred Equity
- Common Equity
- SAFE
- Convertible Note
- Warrant
- Fund Interest
- LP Interest
- SPV Interest
- Asset-Backed Security
- Mortgage-Backed Security
- CLO
- CDO
- Warehouse Facility
- Repo
- Derivative
- Swap
- Option
- Forward
- Treasury Security
- Municipal Bond
- Corporate Bond
- Agency Security
- Certificate of Deposit
- Structured Note

## Transaction Objects

- Offering
- Private Placement
- Public Offering
- Syndication
- Participation Sale
- Secondary Trade
- Tender Offer
- Exchange Offer
- Capital Call
- Distribution
- Subscription
- Redemption
- Securitization
- Warehouse Financing
- Refinancing
- Recapitalization
- Settlement
- Trade Allocation
- Custody Transfer

## Dispatch Rule

No instrument is isolated. Every capital markets object must connect to issuer, investor, intermediary, pricing, documentation, regulation, settlement, risk, and reporting.

## Dispatch Truth Statement

Capital markets objects are the grammar of institutional finance. They allow Dispatch to represent how capital is created, transferred, priced, held, monitored, and exited.
