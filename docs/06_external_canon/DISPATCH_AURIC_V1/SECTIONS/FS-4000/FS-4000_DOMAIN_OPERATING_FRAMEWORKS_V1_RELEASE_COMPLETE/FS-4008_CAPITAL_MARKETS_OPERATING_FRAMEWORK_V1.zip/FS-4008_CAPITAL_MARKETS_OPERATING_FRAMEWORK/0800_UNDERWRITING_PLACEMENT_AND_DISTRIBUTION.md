# Underwriting, Placement & Distribution

## Purpose

This document defines the intermediary operating model for raising and distributing capital.

## Intermediary Roles

- Lead Underwriter
- Co-Manager
- Placement Agent
- Broker Dealer
- Syndication Agent
- Arranger
- Administrative Agent
- Selling Group Member
- Financial Advisor
- Capital Advisor
- Marketplace Operator

## Mandate Object

Fields:
- mandate_id
- issuer
- intermediary
- transaction_type
- scope
- exclusivity
- fee
- retainer
- success_fee
- expenses
- term
- target_investors
- responsibilities
- compliance_requirements

## Distribution Workflow

Mandate → Investor Targeting → Materials → Outreach → Indications → Due Diligence → Commitments → Allocation → Closing → Post-Close Follow-Up

## Investor Targeting Inputs

- mandate fit
- prior activity
- sector appetite
- check size
- geography
- risk appetite
- liquidity
- regulatory eligibility
- relationship strength
- decision speed

## Fees

- underwriting fee
- placement fee
- success fee
- retainer
- structuring fee
- arranger fee
- management fee
- selling concession
- expense reimbursement

## KPIs

- investors contacted
- indications
- commitments
- conversion rate
- capital raised
- fee revenue
- closing probability
- outreach efficiency
- investor quality
- repeat investor rate

## AI Opportunities

- investor list generation
- outreach drafting
- materials summary
- indication tracking
- allocation recommendation
- compliance checklist
- fee analysis

## Dispatch Truth Statement

Distribution is not email outreach. It is the governed matching of capital appetite to issuer need through trusted intermediaries and compliant workflows.
