# Investors & Allocators

## Purpose

This document defines investor types, mandates, suitability, allocation behavior, and capital appetite.

## Investor Object

Fields:
- investor_id
- investor_type
- AUM
- mandate
- eligible_instruments
- risk_tolerance
- target_return
- liquidity_needs
- duration_target
- rating_requirements
- concentration_limits
- regulatory_constraints
- tax_constraints
- geography
- sector_preferences
- check_size
- decision_process
- committee
- contacts
- prior_transactions
- appetite_status

## Investor Mandate Types

- Investment Grade Fixed Income
- High Yield
- Private Credit
- Venture Capital
- Private Equity
- Real Estate
- Infrastructure
- Municipal Bonds
- Agency Securities
- Mortgage-Backed Securities
- Loan Participations
- CUSO Investments
- Strategic Innovation Investments
- Cash Management
- Liquidity Portfolio
- ALM Portfolio

## Suitability / Eligibility Inputs

- accredited investor
- qualified purchaser
- institutional status
- investment policy
- charter authority
- board approval
- risk appetite
- liquidity requirements
- regulatory permission
- concentration limits
- fiduciary duty
- client profile

## Investor Decision Workflow

Opportunity → Mandate Fit → Diligence → Risk Review → Investment Committee → Allocation → Subscription/Trade → Settlement → Monitoring

## Investor KPIs

- allocation size
- yield
- duration
- risk rating
- performance
- liquidity
- concentration
- commitment pace
- drawdown pace
- distributions
- unrealized gain/loss
- policy exceptions
- committee approvals

## AI Opportunities

- investor profile
- mandate fit scoring
- policy eligibility review
- investment committee memo
- opportunity matching
- portfolio fit analysis
- allocation recommendation
- investor update generation

## Dispatch Truth Statement

Investors are not simply sources of money. They are governed capital allocators with constraints, appetites, policies, relationships, and decision systems.
