# Technology, Data & Connectors

## Purpose

This document defines the technology stack and data model for capital markets.

## Technology Categories

- Order Management System
- Execution Management System
- Portfolio Management System
- Risk System
- Data Warehouse
- Market Data
- Pricing Engine
- Valuation Platform
- Custody Platform
- Fund Accounting
- Investor Portal
- Loan Servicing
- Participation Marketplace
- Document Management
- CRM
- Compliance System
- Trade Surveillance
- BI
- AI Platform

## Data Objects

- participant
- instrument
- offering
- trade
- position
- portfolio
- price
- valuation
- settlement
- custody account
- investor
- issuer
- compliance record
- document
- corporate action
- cash flow
- KPI

## Connector Priorities

Tier 1:
- document storage
- email/calendar
- CRM
- spreadsheets/CSV
- accounting/GL
- AI provider
- web/market research

Tier 2:
- portfolio management
- custody
- fund accounting
- investor portal
- market data
- loan servicing
- BI/data warehouse

Tier 3:
- OMS/EMS
- pricing providers
- securities master
- clearing systems
- transfer agent
- compliance surveillance
- regulatory filing systems

## Data Quality Rules

- every trade must resolve to an instrument
- every instrument must resolve to issuer
- every position must resolve to owner
- every settlement must resolve to trade
- every valuation must preserve source and method
- every offering must link to documents
- every investor must carry eligibility fields

## AI Opportunities

- securities master enrichment
- document extraction
- trade blotter summary
- valuation support
- market signal ingestion
- investor matching
- portfolio commentary
- compliance evidence mapping

## Dispatch Truth Statement

Capital markets data is only useful when transactions, instruments, positions, prices, documents, and counterparties resolve to the same canonical graph.
