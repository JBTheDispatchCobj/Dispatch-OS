# Structured Finance & Securitization

## Purpose

This document defines structured finance, securitization, tranching, collateral pools, and waterfalls.

## Structured Finance Objects

- Asset Pool
- Issuer SPV
- Depositor
- Sponsor
- Servicer
- Trustee
- Rating Agency
- Noteholder
- Tranche
- Waterfall
- Credit Enhancement
- Reserve Account
- Overcollateralization
- Excess Spread
- Trigger
- Collateral Report

## Asset Pool Types

- mortgages
- auto loans
- credit cards
- consumer loans
- equipment leases
- commercial loans
- receivables
- student loans
- small business loans
- solar loans
- leases

## Tranche Object

Fields:
- tranche_id
- securitization
- seniority
- principal
- coupon
- rating
- expected_maturity
- legal_final
- credit_enhancement
- loss_allocation
- payment_priority
- current_balance

## Waterfall Object

Fields:
- waterfall_id
- payment_date
- collections
- fees
- interest
- principal
- reserves
- triggers
- excess_spread
- losses
- distributions
- residual

## Securitization Workflow

Asset Selection → Eligibility → Pool Tape → Structuring → Rating → Documentation → Marketing → Pricing → Closing → Monthly Reporting → Surveillance

## KPIs

- pool balance
- delinquency
- defaults
- losses
- prepayments
- excess spread
- trigger status
- tranche performance
- rating migration
- collateral quality
- servicer performance

## AI Opportunities

- pool tape review
- eligibility testing
- waterfall explanation
- trigger monitoring
- collateral performance summary
- rating agency Q&A prep
- investor report drafting

## Dispatch Truth Statement

Structured finance turns pools of assets into engineered cash flow systems. Dispatch must model collateral, rules, waterfalls, triggers, servicers, investors, and performance continuously.
