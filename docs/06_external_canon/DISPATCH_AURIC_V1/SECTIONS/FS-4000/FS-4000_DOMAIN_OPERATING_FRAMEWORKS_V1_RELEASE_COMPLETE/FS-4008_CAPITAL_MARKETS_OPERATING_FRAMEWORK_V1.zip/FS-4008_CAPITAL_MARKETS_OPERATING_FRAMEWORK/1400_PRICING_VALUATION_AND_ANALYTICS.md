# Pricing, Valuation & Analytics

## Purpose

This document defines pricing, valuation, yield, return, and risk analytics.

## Pricing Inputs

- instrument type
- issuer credit
- collateral
- seniority
- maturity
- duration
- coupon
- spread
- benchmark rate
- liquidity
- rating
- covenants
- market comps
- supply/demand
- volatility
- optionality
- tax status

## Valuation Methods

- market price
- broker quote
- matrix pricing
- discounted cash flow
- comparable trades
- NAV
- appraisal
- model valuation
- amortized cost
- fair value hierarchy
- internal mark
- third-party valuation

## Analytics Objects

- Yield
- Yield to Maturity
- Yield to Call
- Duration
- Modified Duration
- Convexity
- Spread
- OAS
- WAL
- IRR
- MOIC
- TVPI
- DPI
- Value at Risk
- Stress Loss
- Expected Loss
- Recovery Rate

## Valuation Workflow

Position Data → Market Data → Model Inputs → Calculation → Review → Approval → Reporting → Archive

## Pricing Governance

Every valuation should record:
- source
- method
- assumptions
- confidence
- reviewer
- approval
- variance
- prior mark
- policy basis

## KPIs

- valuation confidence
- stale marks
- price variance
- yield variance
- spread movement
- duration change
- unrealized gain/loss
- impairment triggers
- policy exceptions

## AI Opportunities

- valuation commentary
- price variance explanation
- comparable trade summary
- yield analysis
- stress scenario generation
- fair value memo draft
- portfolio analytics summary

## Dispatch Truth Statement

Pricing is market judgment expressed numerically. Dispatch must preserve the method, evidence, assumption, reviewer, and consequence of every mark.
