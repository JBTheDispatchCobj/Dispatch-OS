# Secondary Markets & Trading

## Purpose

This document defines secondary market trading, liquidity, transfer, and execution.

## Secondary Transactions

- Security Trade
- Loan Trade
- Participation Transfer
- Fund Interest Secondary
- Tender Offer
- Block Trade
- Private Secondary
- Marketplace Trade
- Assignment
- Novation
- Redemption
- Repurchase

## Trade Object

Fields:
- trade_id
- instrument
- buyer
- seller
- broker
- quantity
- price
- yield
- trade_date
- settlement_date
- status
- transfer_restrictions
- approvals
- counterparty
- fees
- custody
- settlement_instructions

## Secondary Market Workflow

Interest → Bid/Offer → Negotiation → Eligibility Review → Documentation → Trade Capture → Confirmation → Settlement → Position Update → Reporting

## Liquidity Object

Fields:
- instrument
- bid
- ask
- spread
- market_depth
- trading_frequency
- last_trade
- valuation_confidence
- transfer_restrictions
- liquidity_score

## Transfer Restrictions

- issuer consent
- ROFR
- minimum transfer size
- qualified purchaser requirement
- accredited investor requirement
- board approval
- regulatory approval
- lock-up
- transfer agent requirements

## KPIs

- trade volume
- bid/ask spread
- settlement failures
- trade cycle time
- liquidity score
- realized gain/loss
- valuation variance
- counterparty exposure
- approval delay

## AI Opportunities

- trade summary
- transfer restriction review
- buyer/seller match
- liquidity assessment
- settlement checklist
- valuation comparison
- secondary opportunity detection

## Dispatch Truth Statement

Secondary markets transform held instruments into liquid or semi-liquid institutional relationships governed by transfer rules, pricing, settlement, and trust.
