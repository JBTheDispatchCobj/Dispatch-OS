# Acceptance Tests & Roadmap

## Object Tests

- Can create Issuer.
- Can create Investor.
- Can create Intermediary.
- Can create Instrument.
- Can create Offering.
- Can create Trade.
- Can create Position.
- Can create Portfolio.
- Can create Valuation.
- Can create Settlement.
- Can create Participation.
- Can create Securitization.
- Can create Compliance Record.

## Relationship Tests

- Issuer ISSUES Instrument.
- Investor INVESTS_IN Instrument.
- Intermediary PLACES Offering.
- Trade TRANSFERS Instrument.
- Position HELD_BY Investor.
- Custodian CUSTODIES Position.
- Valuation PRICES Instrument.
- Settlement SETTLES Trade.
- Participation TRANSFERS Loan Interest.
- Regulation GOVERNS Transaction.

## Workflow Tests

- Offering workflow reaches closing.
- Secondary trade workflow settles.
- Participation sale workflow creates package and buyer review.
- Securitization workflow creates pool and tranches.
- Investment decision workflow records approval.
- Valuation workflow preserves method and approval.
- Settlement workflow detects exception.
- Compliance workflow produces evidence.

## Agent Tests

- Market Analyst summarizes market.
- Investor Matching Agent recommends investors.
- Offering Coordinator creates checklist.
- Investment Analyst drafts memo.
- Valuation Analyst explains mark.
- Settlement Agent classifies exception.
- Compliance Review Agent maps requirements.
- Participation Package Agent summarizes loan package.

## Roadmap

Priority 1:
- machine-readable instrument registry
- participant registry
- fixture offering
- fixture participation
- fixture investment portfolio
- fixture valuation

Priority 2:
- workflows
- agents
- dashboards
- settlement and valuation modules

Priority 3:
- structured finance engine
- participation marketplace
- investor appetite intelligence
- secondary market intelligence
- regulatory evidence engine

## Dispatch Truth Statement

The Capital Markets cartridge is accepted when Dispatch can connect capital demand, capital supply, instruments, intermediaries, pricing, settlement, compliance, and reporting into one executable market operating system.
