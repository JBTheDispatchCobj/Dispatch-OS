# Loan Participations & Syndications

## Purpose

This document defines loan participations, syndications, and cooperative secondary credit markets.

## Participation Object

Fields:
- participation_id
- lead_lender
- participant
- borrower
- loan
- participation_percentage
- funded_amount
- purchase_price
- servicing_fee
- payment_distribution
- reporting_requirements
- consent_rights
- transfer_rights
- risk_rating
- documents
- settlement_status

## Syndicated Loan Object

Fields:
- syndication_id
- borrower
- arranger
- administrative_agent
- lenders
- commitments
- funded_amounts
- facility_types
- pricing
- covenants
- collateral
- voting_rights
- assignments
- agent_reports

## Participation Lifecycle

Loan Identified → Offering Package → Participant Review → Approval → Participation Agreement → Funding → Servicing → Reporting → Payments → Transfer/Exit

## Offering Package

- borrower summary
- credit memo
- financials
- loan terms
- collateral
- risk rating
- covenants
- payment history
- appraisal
- legal documents
- servicing arrangement
- participation agreement

## Cooperative Finance Lens

For credit unions and corporate credit unions, participations may create:

- diversification
- liquidity
- yield
- relationship sharing
- balance sheet management
- secondary market capacity
- cooperative capital formation
- network intelligence

## KPIs

- participation volume
- outstanding balance
- yield
- credit quality
- delinquencies
- payment remittance timeliness
- participant count
- concentration
- transfer activity
- servicing exceptions

## AI Opportunities

- participation package summary
- buyer/investor matching
- credit memo extraction
- risk comparison
- servicing report summary
- payment distribution reconciliation
- secondary market pricing support

## Dispatch Truth Statement

Loan participations are cooperative capital markets. Dispatch must model them as tradable, reportable, monitored credit interests with shared risk and shared intelligence.
