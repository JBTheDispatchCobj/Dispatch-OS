# Treasury, ALM & Investment Portfolio

## Purpose

This document defines how capital markets connect to treasury, ALM, liquidity, and institutional investment portfolios.

## ALM Connections

Capital markets instruments impact:

- liquidity
- interest rate risk
- duration
- net interest margin
- earnings at risk
- economic value of equity
- capital
- unrealized losses
- available-for-sale portfolio
- held-to-maturity portfolio
- regulatory reporting
- board reporting

## Investment Portfolio Categories

- Cash
- Overnight Funds
- Treasuries
- Agencies
- Municipals
- Corporate Bonds
- Mortgage-Backed Securities
- Asset-Backed Securities
- CDs
- Loan Participations
- CUSO Investments
- Funds
- Private Placements
- Alternative Investments where permitted

## ALM Scenario Object

Fields:
- scenario_id
- rate_shock
- balance_sheet_assumptions
- deposit_beta
- prepayment_speed
- reinvestment_rate
- NIM_impact
- EVE_impact
- liquidity_impact
- capital_impact
- recommended_actions

## Investment Decision Workflow

Need → Policy Check → Market Review → Instrument Selection → Risk Review → Approval → Trade → Settlement → Position Monitoring

## KPIs

- portfolio yield
- cost of funds
- duration
- convexity
- liquidity coverage
- unrealized losses
- rating distribution
- maturity ladder
- ALM sensitivity
- policy compliance
- investment income

## AI Opportunities

- ALM commentary
- investment recommendation support
- rate scenario summary
- portfolio risk summary
- unrealized loss analysis
- maturity strategy
- board report drafting

## Dispatch Truth Statement

Capital markets are not separate from balance sheet management. They are how institutions express liquidity, risk, yield, and strategic positioning.
