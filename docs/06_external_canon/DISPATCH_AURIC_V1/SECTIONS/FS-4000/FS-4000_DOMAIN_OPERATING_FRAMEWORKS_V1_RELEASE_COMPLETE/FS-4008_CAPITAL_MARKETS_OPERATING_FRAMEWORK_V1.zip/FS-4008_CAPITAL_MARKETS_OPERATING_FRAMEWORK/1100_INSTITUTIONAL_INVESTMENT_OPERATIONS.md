# Institutional Investment Operations

## Purpose

This document defines investment operations for institutions holding securities, funds, participations, and structured products.

## Investment Position Object

Fields:
- position_id
- investor
- instrument
- quantity
- cost_basis
- market_value
- unrealized_gain_loss
- income
- yield
- duration
- rating
- maturity
- liquidity
- custodian
- restrictions
- policy_status
- risk_classification

## Investment Operations Functions

- trade capture
- position keeping
- reconciliation
- income accrual
- corporate actions
- capital calls
- distributions
- valuation
- impairment review
- compliance monitoring
- portfolio reporting
- board reporting
- regulatory reporting

## Portfolio Object

Fields:
- portfolio_id
- owner
- strategy
- positions
- market_value
- book_value
- yield
- duration
- liquidity
- realized_gain_loss
- unrealized_gain_loss
- income
- risk
- policy_compliance

## Reconciliation Workflow

Custodian Data → Internal Positions → Trade Activity → Income → Exceptions → Resolution → Signoff → Archive

## Investment Policy Monitoring

Dispatch monitors:

- permitted instruments
- credit ratings
- maturity limits
- duration limits
- issuer concentration
- sector concentration
- liquidity
- mark-to-market
- unrealized losses
- board approvals
- exceptions

## KPIs

- portfolio yield
- market value
- book value
- duration
- WAL
- income
- unrealized gain/loss
- rating distribution
- maturity ladder
- liquidity
- policy exceptions
- reconciliation breaks

## AI Opportunities

- investment portfolio summary
- policy exception detection
- maturity ladder commentary
- income forecast
- reconciliation break analysis
- board investment report
- impairment review support

## Dispatch Truth Statement

Investment operations preserve the integrity of institutional capital after allocation.
