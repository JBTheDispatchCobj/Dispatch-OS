# Primary Markets

## Purpose

This document defines new issuance, capital raising, and primary market workflows.

## Primary Market Transactions

- IPO
- Follow-On Offering
- Private Placement
- Bond Offering
- Municipal Offering
- Loan Syndication
- Participation Sale
- Fundraising
- SPV Offering
- Securitization Issuance
- Preferred Equity Offering
- Strategic Investment
- CUSO Investment Offering

## Offering Object

Fields:
- offering_id
- issuer
- instrument
- amount
- price
- yield
- valuation
- underwriters
- placement_agents
- investors
- documents
- subscription_status
- allocation
- closing_date
- settlement_date
- compliance_status
- use_of_proceeds

## Offering Lifecycle

Mandate → Structuring → Documentation → Marketing → Bookbuilding → Pricing → Allocation → Closing → Settlement → Reporting

## Offering Documents

- offering memorandum
- PPM
- prospectus
- subscription agreement
- purchase agreement
- indenture
- credit agreement
- investor presentation
- roadshow deck
- term sheet
- legal opinions
- closing binder

## Bookbuilding Object

Fields:
- book_id
- offering
- investor_indications
- demand
- pricing_feedback
- allocation_requests
- final_allocation
- oversubscription
- investor_quality
- order_book_notes

## KPIs

- capital raised
- demand coverage
- oversubscription
- pricing spread
- allocation quality
- closing time
- investor count
- repeat investors
- distribution cost
- documentation defects

## AI Opportunities

- offering memo summary
- investor target list
- bookbuilding summary
- allocation recommendation
- use-of-proceeds review
- closing checklist
- investor Q&A prep

## Dispatch Truth Statement

Primary markets are the workflow by which capital formation becomes executable.
