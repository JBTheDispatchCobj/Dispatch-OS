# Risk, Compliance & Market Regulation

## Purpose

This document defines capital markets risk, compliance, supervision, and market regulation.

## Risk Domains

- market risk
- credit risk
- liquidity risk
- counterparty risk
- settlement risk
- valuation risk
- model risk
- concentration risk
- legal risk
- disclosure risk
- suitability risk
- conflicts risk
- operational risk
- conduct risk
- regulatory risk

## Compliance Areas

- Securities Act
- Exchange Act
- Investment Advisers Act
- Investment Company Act
- FINRA rules where applicable
- MSRB rules where applicable
- Reg D
- Reg S
- Blue Sky
- AML/KYC
- OFAC
- accredited investor
- qualified purchaser
- suitability
- best execution
- advertising/marketing
- custody
- insider trading
- MNPI
- conflicts of interest
- recordkeeping

## Compliance Object

Fields:
- compliance_id
- rule
- transaction
- participant
- requirement
- evidence
- status
- owner
- exception
- remediation
- approval

## Market Conduct Controls

- restricted list
- watch list
- insider trading policy
- MNPI wall
- allocation policy
- personal trading
- conflicts review
- gifts and entertainment
- communications review
- supervision
- books and records

## Regulatory Reporting

- trade reports
- regulatory filings
- investor disclosures
- audited financials
- Form D
- ADV where applicable
- CRS where applicable
- call report connections where applicable
- board reporting

## AI Opportunities

- compliance checklist
- offering exemption review
- investor eligibility review
- conflicts detection
- disclosure summary
- marketing review support
- MNPI risk alert
- records retention tracking

## Dispatch Truth Statement

Capital markets compliance protects market integrity, investor trust, transaction validity, and institutional license to operate.
