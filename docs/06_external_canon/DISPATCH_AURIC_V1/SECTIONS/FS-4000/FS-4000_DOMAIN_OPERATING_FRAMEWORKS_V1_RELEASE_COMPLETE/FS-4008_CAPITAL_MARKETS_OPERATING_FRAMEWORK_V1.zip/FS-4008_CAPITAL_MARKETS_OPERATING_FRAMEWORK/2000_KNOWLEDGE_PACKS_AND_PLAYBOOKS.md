# Knowledge Packs & Playbooks

## Knowledge Packs

### Capital Markets Foundation Pack

- participant taxonomy
- instrument taxonomy
- transaction lifecycle
- KPI definitions
- workflow maps

### Primary Markets Pack

- offerings
- private placements
- underwriting
- placement
- bookbuilding
- allocation

### Secondary Markets Pack

- trading
- transfer restrictions
- settlement
- liquidity
- secondary pricing

### Structured Finance Pack

- collateral pools
- tranches
- waterfalls
- triggers
- surveillance

### Loan Participation Pack

- participation packages
- buyer review
- servicing
- reporting
- secondary transfer

### Institutional Investment Pack

- positions
- portfolio
- custody
- valuation
- policy compliance
- ALM connections

### Market Regulation Pack

- securities exemptions
- suitability
- AML/KYC
- conflicts
- records
- investor eligibility

## Playbooks

- Offering Playbook
- Private Placement Playbook
- Participation Sale Playbook
- Secondary Trade Playbook
- Securitization Playbook
- Investment Committee Playbook
- Valuation Review Playbook
- Settlement Exception Playbook
- Investor Matching Playbook
- Board Investment Reporting Playbook

## Dispatch Truth Statement

Capital markets knowledge packs convert specialized financial market expertise into reusable institutional operating intelligence.
