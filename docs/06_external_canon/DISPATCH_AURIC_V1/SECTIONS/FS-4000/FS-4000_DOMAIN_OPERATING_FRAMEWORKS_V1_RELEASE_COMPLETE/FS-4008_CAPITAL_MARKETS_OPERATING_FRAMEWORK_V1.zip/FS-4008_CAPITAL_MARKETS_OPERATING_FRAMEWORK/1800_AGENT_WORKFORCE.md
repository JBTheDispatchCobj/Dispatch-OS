# Capital Markets Agent Workforce

## Market Intelligence Agents

- Market Analyst
- Investor Appetite Agent
- Issuer Research Agent
- Intermediary Relationship Agent
- Pricing Signal Agent
- Regulatory Signal Agent

## Transaction Agents

- Offering Coordinator
- Placement Agent Assistant
- Bookbuilding Analyst
- Allocation Advisor
- Closing Checklist Agent
- Settlement Agent
- Participation Package Agent
- Syndication Coordinator

## Investment Agents

- Investment Analyst
- Policy Eligibility Agent
- Portfolio Fit Agent
- Valuation Analyst
- Yield Analyst
- Risk Analyst
- Investment Committee Memo Writer

## Operations Agents

- Trade Capture Agent
- Reconciliation Agent
- Custody Statement Agent
- Corporate Action Agent
- Income Posting Agent
- Position Monitor

## Compliance Agents

- Investor Eligibility Agent
- Offering Exemption Agent
- Conflicts Review Agent
- Suitability Review Agent
- MNPI Monitor
- Records Retention Agent

## Agent Governance

Human approval required for:
- investment decisions
- trade execution
- offering commitments
- investor eligibility determinations
- valuation marks
- compliance exceptions
- regulatory filings
- external investor communications

## Dispatch Truth Statement

Capital markets agents operate at the intersection of market data, documents, rules, transactions, and institutional approval.
