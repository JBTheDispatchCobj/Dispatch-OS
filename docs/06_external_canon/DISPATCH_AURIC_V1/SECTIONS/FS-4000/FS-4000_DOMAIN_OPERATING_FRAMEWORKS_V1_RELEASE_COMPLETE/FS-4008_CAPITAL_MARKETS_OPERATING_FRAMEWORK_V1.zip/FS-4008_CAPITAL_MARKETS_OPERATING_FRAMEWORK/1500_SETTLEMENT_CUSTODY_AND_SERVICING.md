# Settlement, Custody & Servicing

## Purpose

This document defines post-trade settlement, custody, asset servicing, and operations.

## Settlement Object

Fields:
- settlement_id
- trade
- instrument
- buyer
- seller
- custodian
- clearinghouse
- settlement_date
- delivery_method
- cash_amount
- status
- fail_reason
- instructions
- confirmation
- reconciliation

## Custody Object

Fields:
- custody_id
- custodian
- account
- investor
- positions
- cash
- transactions
- income
- corporate_actions
- statements
- reconciliation_status

## Asset Servicing Events

- coupon payment
- principal payment
- dividend
- capital call
- distribution
- redemption
- maturity
- call
- tender
- exchange
- split
- merger
- default
- amendment
- waiver
- consent

## Settlement Workflow

Trade Capture → Confirmation → Allocation → Settlement Instructions → Cash/Security Movement → Reconciliation → Exception Resolution → Archive

## Reconciliation Types

- trade reconciliation
- cash reconciliation
- position reconciliation
- income reconciliation
- custodian statement reconciliation
- investor allocation reconciliation

## KPIs

- settlement fails
- reconciliation breaks
- aging exceptions
- income posting accuracy
- corporate action processing time
- custody statement timeliness
- trade confirmation timeliness
- operational loss

## AI Opportunities

- settlement exception summary
- reconciliation break analysis
- corporate action summary
- cash movement review
- custody statement comparison
- fail reason classification

## Dispatch Truth Statement

Settlement and custody are the operational proof that capital markets transactions actually happened.
