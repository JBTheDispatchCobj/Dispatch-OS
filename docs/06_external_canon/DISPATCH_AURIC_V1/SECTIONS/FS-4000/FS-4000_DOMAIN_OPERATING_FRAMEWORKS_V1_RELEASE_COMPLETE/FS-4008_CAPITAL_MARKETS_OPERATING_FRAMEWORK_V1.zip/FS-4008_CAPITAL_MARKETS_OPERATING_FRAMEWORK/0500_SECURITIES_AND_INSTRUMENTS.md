# Securities & Instruments

## Purpose

This document defines core capital markets instruments.

## Fixed Income

- Treasury Security
- Agency Bond
- Corporate Bond
- Municipal Bond
- Certificate of Deposit
- Commercial Paper
- Medium-Term Note
- Senior Note
- Subordinated Note
- Convertible Note
- Structured Note

## Equity

- Common Stock
- Preferred Stock
- Restricted Stock
- Warrant
- Option
- Convertible Preferred
- Membership Interest
- LP Interest
- SPV Interest

## Loans

- Term Loan
- Revolver
- Delayed Draw Term Loan
- Bridge Loan
- Syndicated Loan
- Participation
- Warehouse Facility
- NAV Facility
- Subscription Facility
- Asset-Based Loan

## Structured Products

- Asset-Backed Security
- Mortgage-Backed Security
- CLO
- CDO
- CMBS
- RMBS
- Equipment ABS
- Auto ABS
- Credit Card ABS
- Consumer Loan ABS

## Derivatives

- Interest Rate Swap
- Cap
- Floor
- Forward
- Futures
- Option
- Credit Default Swap
- Total Return Swap

## Instrument Object

Fields:
- instrument_id
- type
- issuer
- principal
- currency
- coupon
- yield
- spread
- maturity
- duration
- rating
- seniority
- collateral
- covenants
- call_features
- put_features
- conversion_features
- liquidity
- market_price
- valuation
- documents
- settlement_convention

## AI Opportunities

- instrument summary
- risk factor extraction
- term comparison
- yield analysis
- covenant extraction
- liquidity assessment
- portfolio fit commentary

## Dispatch Truth Statement

A financial instrument is a contract, a risk object, a cash flow object, a compliance object, and a market object at the same time.
