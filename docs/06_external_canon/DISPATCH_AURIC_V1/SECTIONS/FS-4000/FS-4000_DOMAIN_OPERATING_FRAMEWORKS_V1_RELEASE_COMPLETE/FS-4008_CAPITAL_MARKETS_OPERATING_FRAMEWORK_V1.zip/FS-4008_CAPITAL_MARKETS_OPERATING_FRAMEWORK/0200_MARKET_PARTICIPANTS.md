# Market Participants

## Purpose

This document defines the canonical participant taxonomy for capital markets.

## Issuer

An entity that creates securities or obligations to raise capital.

Types:
- corporation
- bank
- credit union
- CUSO
- SPV
- fund
- municipality
- government agency
- real estate entity
- operating company
- trust
- securitization vehicle

## Investor

An entity that allocates capital into instruments.

Types:
- credit union
- corporate credit union
- bank
- insurance company
- asset manager
- pension
- endowment
- foundation
- family office
- RIA client
- fund
- private credit vehicle
- hedge fund
- sovereign wealth fund
- strategic investor
- qualified purchaser
- accredited investor

## Intermediary

An entity that connects issuers and investors.

Types:
- investment bank
- broker dealer
- placement agent
- loan broker
- syndication desk
- participation marketplace
- wealth platform
- RIA platform
- corporate credit union
- CUSO
- advisor
- consultant

## Service Providers

- custodian
- fund administrator
- trustee
- servicer
- paying agent
- transfer agent
- registrar
- rating agency
- auditor
- legal counsel
- tax advisor
- valuation agent
- data provider

## Participant Object

Fields:
- participant_id
- name
- type
- regulatory_status
- licenses
- jurisdiction
- capabilities
- products
- relationships
- transactions
- risk_rating
- compliance_status
- documents
- contacts
- trust_score
- market_role

## Relationship Types

- ISSUES
- INVESTS_IN
- UNDERWRITES
- PLACES
- DISTRIBUTES
- CUSTODIES
- CLEARS
- SETTLES
- RATES
- SERVICES
- ADMINISTERS
- ADVISES
- MAKES_MARKET
- PARTICIPATES_IN
- SYNDICATES
- TRANSFERS
- REPORTS_TO
- REGULATED_BY

## AI Opportunities

- participant profile generation
- relationship mapping
- licensing summary
- investor fit matching
- issuer needs analysis
- intermediary quality scoring
- service provider comparison

## Dispatch Truth Statement

Capital markets are relationship markets. Understanding who plays which role, with whom, under what authority, and with what history is core institutional intelligence.
