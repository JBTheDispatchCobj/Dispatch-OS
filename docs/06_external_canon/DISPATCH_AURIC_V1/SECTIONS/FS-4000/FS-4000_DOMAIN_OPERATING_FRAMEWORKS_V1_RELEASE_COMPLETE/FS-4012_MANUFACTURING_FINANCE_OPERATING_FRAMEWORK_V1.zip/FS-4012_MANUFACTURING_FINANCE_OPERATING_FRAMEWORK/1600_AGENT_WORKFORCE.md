# Manufacturing Finance Agent Workforce

## Relationship Agents

- Manufacturer Relationship Agent
- Owner Meeting Prep Agent
- Treasury Opportunity Agent
- Equipment Finance Opportunity Agent
- Owner Wealth Trigger Agent

## Credit Agents

- Manufacturing Credit Analyst
- Working Capital Analyst
- Borrowing Base Analyst
- Inventory Analyst
- AR Aging Analyst
- Customer Concentration Agent
- Supplier Risk Agent
- Credit Memo Writer
- Covenant Monitor

## Operations Agents

- Production KPI Agent
- Backlog Review Agent
- Margin Variance Agent
- Equipment Collateral Agent
- CapEx ROI Agent
- ERP Data Quality Agent

## Treasury Agents

- Payment Flow Agent
- Fraud Controls Agent
- Account Structure Agent
- Cash Forecast Agent
- Supplier Payment Optimization Agent

## Risk Agents

- Early Warning Agent
- Liquidity Stress Agent
- Inventory Obsolescence Agent
- Equipment Downtime Agent
- Succession Risk Agent
- Workout Strategy Agent

## Governance

Human approval required for:
- credit approval
- borrowing base adjustments
- covenant waivers
- collateral releases
- charge-offs
- workout strategy
- customer-facing commitments
- treasury implementation requiring contracts

## Dispatch Truth Statement

Manufacturing finance agents translate factory, ERP, working capital, treasury, and credit data into lender-ready intelligence.
