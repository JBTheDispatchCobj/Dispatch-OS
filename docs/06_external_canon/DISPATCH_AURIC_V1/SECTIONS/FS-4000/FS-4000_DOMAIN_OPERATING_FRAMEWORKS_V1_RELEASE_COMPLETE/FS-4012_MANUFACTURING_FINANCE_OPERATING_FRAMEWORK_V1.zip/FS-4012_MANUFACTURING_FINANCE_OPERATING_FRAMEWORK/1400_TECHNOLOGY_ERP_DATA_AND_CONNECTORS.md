# Technology, ERP, Data & Connectors

## Purpose

This document defines manufacturing systems and connector priorities.

## Technology Categories

- ERP
- Accounting System
- MRP
- MES
- WMS
- CRM
- EDI
- Payroll
- Time Tracking
- Job Costing
- Inventory Management
- Maintenance Management
- Quality Management
- Procurement
- AP/AR
- Treasury Platform
- Bank Core
- LOS
- Document Management
- BI/Data Warehouse
- AI Platform

## Common Systems

Examples:
- NetSuite
- SAP
- Oracle
- Microsoft Dynamics
- Sage
- QuickBooks
- Epicor
- Infor
- Plex
- JobBOSS
- Fishbowl
- Odoo
- Acumatica
- Katana
- MRPeasy
- Salesforce
- HubSpot

## Data Objects

- customer
- supplier
- SKU
- BOM
- inventory
- WIP
- sales order
- purchase order
- invoice
- receivable
- payable
- equipment
- job
- production order
- shipment
- payment
- GL
- payroll
- KPI

## Connector Priorities

Tier 1:
- accounting/GL
- AR/AP aging exports
- inventory exports
- document storage
- email/calendar
- spreadsheet/CSV
- CRM
- AI provider

Tier 2:
- ERP
- MRP
- MES
- bank core
- LOS
- treasury platform
- payroll
- BI/data warehouse

Tier 3:
- EDI
- WMS
- maintenance system
- quality system
- procurement
- equipment valuation
- insurance tracking

## Data Quality Rules

- inventory must map to SKU/category
- receivables must map to customer
- payables must map to supplier
- equipment must map to collateral
- borrowing base must map to eligible AR/inventory
- sales orders must map to backlog
- financials must reconcile to GL

## AI Opportunities

- ERP data normalization
- borrowing base automation
- inventory aging extraction
- AR/AP risk detection
- KPI dashboard creation
- production/finance reconciliation
- connector exception summary

## Dispatch Truth Statement

Manufacturing intelligence depends on connecting ERP reality to lender risk models.
