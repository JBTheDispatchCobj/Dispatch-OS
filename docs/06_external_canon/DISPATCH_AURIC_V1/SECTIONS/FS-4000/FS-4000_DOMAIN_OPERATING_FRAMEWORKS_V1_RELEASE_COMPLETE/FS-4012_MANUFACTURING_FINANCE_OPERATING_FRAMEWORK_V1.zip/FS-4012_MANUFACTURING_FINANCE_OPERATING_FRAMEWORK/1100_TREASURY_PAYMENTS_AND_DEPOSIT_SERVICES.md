# Treasury, Payments & Deposit Services

## Purpose

This document defines treasury services and deposit strategy for manufacturers.

## Treasury Products

- Business Checking
- Operating Account
- Payroll Account
- Tax Account
- Lockbox
- Remote Deposit Capture
- ACH Origination
- Wire Transfers
- Positive Pay
- ACH Positive Pay
- Commercial Card
- Purchasing Card
- Merchant Services
- Account Analysis
- Sweep Account
- Zero Balance Account
- Cash Forecasting
- FX / International Payments
- Integrated Payables
- Integrated Receivables

## Payment Flow Object

Fields:
- payment_flow_id
- manufacturer
- payer
- payee
- rail
- frequency
- average_amount
- risk
- fraud_controls
- treasury_service
- automation_status

## Manufacturer Treasury Needs

- payroll
- supplier payments
- tax payments
- customer collections
- international payments
- fraud controls
- account structure
- working capital visibility
- line sweep
- payment approval controls
- ERP integration
- receivables automation

## Treasury Assessment Workflow

Discovery → Payment Flow Map → Fraud Risk → Account Structure → Product Recommendation → Pricing → Implementation → Monitoring

## KPIs

- deposit balances
- treasury revenue
- ACH volume
- wire volume
- lockbox volume
- positive pay adoption
- commercial card spend
- payment exceptions
- fraud prevented
- account analysis revenue

## AI Opportunities

- treasury needs assessment
- payment flow map
- fraud control recommendation
- account structure design
- supplier payment optimization
- collections automation recommendation
- treasury proposal draft

## Dispatch Truth Statement

Treasury services embed the institution inside the manufacturer's operating cash cycle.
