# Knowledge Packs & Playbooks

## Knowledge Packs

### Manufacturing Finance Foundation Pack

- terminology
- participant taxonomy
- product taxonomy
- working capital model
- KPI definitions
- workflow maps

### Working Capital Pack

- AR
- AP
- inventory
- cash conversion
- borrowing base
- liquidity risk

### Inventory & WIP Pack

- raw materials
- WIP
- finished goods
- job costing
- obsolescence
- collateral eligibility

### Equipment Finance Pack

- equipment types
- valuation
- useful life
- collateral
- CapEx ROI
- maintenance

### Treasury Pack

- payment flows
- supplier payments
- customer collections
- fraud controls
- account structures

### Credit Underwriting Pack

- credit memo
- facility structures
- covenants
- customer/supplier risk
- repayment source

### Distress Pack

- early warnings
- liquidity stress
- inventory liquidation
- equipment sale
- customer loss
- workout

## Playbooks

- Manufacturer Discovery Playbook
- Manufacturing Credit Memo Playbook
- Borrowing Base Review Playbook
- Inventory Aging Playbook
- Equipment Finance Playbook
- Treasury Assessment Playbook
- Customer Concentration Playbook
- Supplier Risk Playbook
- CapEx Finance Playbook
- Annual Review Playbook
- Distressed Manufacturer Playbook
- Owner Succession/Wealth Referral Playbook

## Dispatch Truth Statement

Manufacturing knowledge packs turn industrial operating knowledge into credit, treasury, and relationship execution.
