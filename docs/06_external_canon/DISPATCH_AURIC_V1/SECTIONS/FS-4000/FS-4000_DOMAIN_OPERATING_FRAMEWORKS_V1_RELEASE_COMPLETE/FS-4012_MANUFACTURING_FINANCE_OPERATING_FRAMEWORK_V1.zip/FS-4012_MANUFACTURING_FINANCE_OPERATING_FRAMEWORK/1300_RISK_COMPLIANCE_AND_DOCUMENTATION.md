# Risk, Compliance & Documentation

## Purpose

This document defines manufacturing finance risk, compliance, and documentation.

## Risk Domains

- credit risk
- working capital risk
- inventory risk
- receivables risk
- customer concentration
- supplier concentration
- margin risk
- equipment risk
- labor risk
- quality risk
- product liability
- environmental risk
- regulatory risk
- cyber risk
- technology risk
- liquidity risk
- succession risk
- fraud risk

## Compliance Areas

- BSA/KYB
- beneficial ownership
- environmental diligence
- UCC/lien perfection
- appraisal/equipment valuation
- insurance
- OSHA-related operational awareness
- export controls where applicable
- defense contracting rules where applicable
- food/medical/device regulatory certifications where applicable
- loan policy
- appraisal policy
- records retention
- adverse action where applicable

## Required Documents

- financial statements
- tax returns
- AR aging
- AP aging
- inventory report
- borrowing base certificate
- debt schedule
- customer list
- supplier list
- backlog
- equipment list
- insurance certificates
- UCC search
- equipment appraisal
- environmental report where needed
- purchase orders
- contracts
- quality certifications
- credit memo
- loan agreement
- security agreement
- guarantees
- compliance certificates

## Control Object

Fields:
- control_id
- manufacturer
- risk
- requirement
- evidence
- frequency
- owner
- status
- exception
- remediation

## AI Opportunities

- document checklist
- AR/AP/inventory evidence review
- UCC/lien checklist
- insurance review
- environmental summary
- compliance certificate review
- credit file completeness

## Dispatch Truth Statement

Manufacturing finance documentation must prove not only repayment capacity, but collateral validity, operating reality, and control over working capital.
