# Manufacturing Finance Implementation Guide

## Phase 1 — Setup

- create manufacturing finance domain
- configure manufacturer object
- configure product taxonomy
- configure credit products
- configure borrowing base rules
- configure equipment collateral fields
- configure treasury product map
- configure risk rating model
- configure industry segments

## Phase 2 — Objects

- manufacturers
- owners
- facilities/plants
- products/SKUs
- customers
- suppliers
- inventory
- receivables
- payables
- equipment
- loans
- borrowing bases
- covenants
- treasury services
- KPIs

## Phase 3 — Connectors

- accounting/GL
- ERP exports
- AR/AP aging
- inventory report
- CRM
- document storage
- email/calendar
- LOS
- core system
- treasury platform
- AI provider

## Phase 4 — Workflows

Activate:
- manufacturer onboarding
- credit underwriting
- borrowing base
- equipment finance
- treasury assessment
- annual review
- covenant monitoring
- customer concentration
- supplier risk
- distressed manufacturer review

## Phase 5 — Agents

Deploy:
- Manufacturer Relationship Agent
- Working Capital Analyst
- Borrowing Base Analyst
- Inventory Analyst
- AR Aging Analyst
- Customer Concentration Agent
- Supplier Risk Agent
- Credit Memo Writer
- Treasury Opportunity Agent

## Phase 6 — Dashboards

Configure:
- executive
- relationship
- working capital
- borrowing base
- inventory
- AR/AP
- equipment
- production KPIs
- customer/supplier concentration
- risk

## Demo Flow

1. Open manufacturer profile.
2. Show products, customers, suppliers.
3. Review AR/AP/inventory.
4. Generate working capital summary.
5. Calculate borrowing base.
6. Identify equipment finance need.
7. Recommend treasury services.
8. Draft credit memo section.
9. Show early warning dashboard.
10. Generate annual review.

## Dispatch Truth Statement

Manufacturing finance implementation begins with working capital truth, then production intelligence, then credit structure, then relationship expansion.
