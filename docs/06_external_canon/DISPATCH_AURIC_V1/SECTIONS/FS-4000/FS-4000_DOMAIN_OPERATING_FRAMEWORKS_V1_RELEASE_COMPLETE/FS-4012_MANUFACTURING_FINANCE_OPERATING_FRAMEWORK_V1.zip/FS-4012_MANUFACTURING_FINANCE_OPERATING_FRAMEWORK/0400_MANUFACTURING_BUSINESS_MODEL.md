# Manufacturing Business Model

## Purpose

This document defines the operating economics of manufacturers.

## Revenue Models

- Build-to-Order
- Build-to-Stock
- Contract Manufacturing
- OEM Supply
- Tier Supplier
- Distributor-Supported Sales
- Direct Sales
- Recurring Consumables
- Project-Based Production
- Long-Term Supply Agreement
- Defense/Government Contract
- Private Label
- Custom Fabrication

## Cost Structure

- raw materials
- direct labor
- overhead
- utilities
- rent/occupancy
- equipment depreciation
- maintenance
- freight
- quality
- scrap/rework
- tooling
- engineering
- SG&A
- insurance
- financing costs

## Margin Drivers

- pricing
- material costs
- labor efficiency
- utilization
- scrap rate
- rework
- product mix
- automation
- purchasing terms
- freight
- customer concentration
- warranty/quality claims

## Operating Metrics

- capacity
- utilization
- throughput
- cycle time
- setup time
- downtime
- OEE
- defect rate
- scrap rate
- yield
- backlog
- on-time delivery
- inventory turns
- labor productivity

## Business Model Risk

- low gross margin
- volatile materials
- customer concentration
- supplier concentration
- labor shortage
- equipment downtime
- outdated equipment
- poor job costing
- weak pricing
- inventory obsolescence
- long cash conversion cycle
- warranty claims
- quality failures

## AI Opportunities

- business model summary
- margin driver analysis
- backlog review
- customer/supplier concentration
- production bottleneck summary
- pricing pressure detection
- operating risk memo
- credit memo business section

## Dispatch Truth Statement

Manufacturing financial performance is produced on the shop floor before it appears in the income statement.
