# Operations, KPIs & Production Intelligence

## Purpose

This document defines manufacturing operating KPIs and how they relate to financial performance and credit risk.

## Production KPI Objects

- Capacity
- Utilization
- Throughput
- Cycle Time
- Setup Time
- Downtime
- Overall Equipment Effectiveness
- Scrap
- Rework
- Yield
- On-Time Delivery
- Backlog
- Labor Productivity
- Overtime
- Warranty Claims
- Quality Defects

## Production Line Object

Fields:
- line_id
- facility
- products
- capacity
- utilization
- equipment
- labor
- throughput
- downtime
- bottlenecks
- quality
- maintenance
- margin_contribution

## Backlog Object

Fields:
- backlog_id
- customer
- product
- order_value
- margin
- delivery_date
- production_status
- material_status
- risk
- expected_revenue_date

## Operating Review Workflow

ERP Data → Production KPIs → Financial KPIs → Variance → Bottlenecks → Risk Alerts → Recommendations → Relationship / Credit Update

## Credit-Relevant Operating Signals

- declining utilization
- backlog drop
- excessive overtime
- margin compression
- scrap spike
- warranty claims
- missed deliveries
- machine downtime
- labor turnover
- customer cancellations
- supplier delays

## KPIs

- capacity utilization
- OEE
- throughput
- backlog
- on-time delivery
- defect rate
- scrap
- rework
- labor productivity
- gross margin
- EBITDA margin
- cash conversion cycle

## AI Opportunities

- production dashboard commentary
- credit early warning detection
- backlog risk summary
- margin leakage analysis
- operational bottleneck detection
- customer delivery risk alert
- lender monthly monitoring summary

## Dispatch Truth Statement

Manufacturing operating KPIs are early-warning credit indicators because production creates revenue, margin, and cash flow.
