# KPI & Dashboard Registry

## Relationship KPIs

- manufacturer relationships
- deposit balances
- treasury revenue
- loan exposure
- equipment finance volume
- relationship profitability
- cross-sell ratio
- annual review completion

## Financial KPIs

- revenue
- gross margin
- EBITDA
- EBITDA margin
- cash
- leverage
- DSCR
- fixed charge coverage
- working capital
- liquidity
- forecast variance

## Working Capital KPIs

- DSO
- DIO
- DPO
- cash conversion cycle
- AR aging
- AP aging
- inventory turns
- line utilization
- excess availability
- borrowing base exceptions

## Production KPIs

- backlog
- capacity utilization
- throughput
- OEE
- downtime
- scrap
- rework
- on-time delivery
- labor productivity
- warranty claims

## Risk KPIs

- customer concentration
- supplier concentration
- inventory obsolescence
- margin compression
- covenant breaches
- risk rating migration
- delinquency
- charge-offs
- insurance exceptions
- collateral exceptions

## Dashboards

- Manufacturing Finance Executive Dashboard
- Manufacturer Relationship Dashboard
- Working Capital Dashboard
- Borrowing Base Dashboard
- Inventory Dashboard
- AR/AP Dashboard
- Equipment Dashboard
- Production KPI Dashboard
- Customer/Supplier Concentration Dashboard
- Portfolio Risk Dashboard

## Dispatch Truth Statement

Manufacturing finance KPIs must show financial performance, working capital, production health, collateral, and relationship economics.
