# Manufacturing Credit Products

## Purpose

This document defines credit products used to finance manufacturers.

## Credit Products

- Working Capital Line
- Revolving Line of Credit
- Asset-Based Loan
- Borrowing Base Facility
- Equipment Loan
- Equipment Lease
- CapEx Term Loan
- Owner-Occupied CRE Loan
- SBA 7(a)
- SBA 504
- USDA B&I
- Inventory Finance
- Purchase Order Finance
- Receivables Finance
- Trade Finance
- Export Finance
- Floor Plan Finance
- Acquisition Loan
- Management Buyout Loan
- Bridge Loan
- Letter of Credit

## Manufacturing Loan Object

Fields:
- loan_id
- manufacturer
- product_type
- amount
- purpose
- repayment_source
- collateral
- guarantees
- pricing
- maturity
- covenants
- borrowing_base
- availability
- risk_rating
- documents
- approval
- monitoring_requirements

## Structure Inputs

- working capital need
- cash conversion cycle
- customer concentration
- supplier risk
- inventory quality
- equipment value
- EBITDA
- leverage
- liquidity
- backlog
- management quality
- collateral
- guarantor support
- industry cyclicality
- government program eligibility

## Common Covenants

- DSCR
- fixed charge coverage
- leverage
- minimum liquidity
- borrowing base
- reporting
- inventory reporting
- AR aging
- customer concentration limits
- CapEx limits
- debt restrictions
- owner distributions

## KPIs

- loan exposure
- availability
- utilization
- yield
- risk rating
- covenant breaches
- borrowing base exceptions
- delinquency
- charge-off
- collateral coverage
- relationship profitability

## AI Opportunities

- facility recommendation
- credit memo draft
- covenant package suggestion
- borrowing base setup
- SBA eligibility checklist
- equipment finance structure
- repayment source analysis

## Dispatch Truth Statement

Manufacturing credit products should match the asset being financed: receivables, inventory, equipment, real estate, CapEx, acquisition, or permanent working capital.
