# Manufacturing Finance Operating Model

## Definition

Manufacturing finance is the institutional process of funding and monitoring manufacturers whose repayment capacity depends on production execution, working capital conversion, customer demand, supplier reliability, labor productivity, equipment uptime, and margin discipline.

## Operating Layers

### 1. Relationship Layer

Defines owner, management, facility, relationship manager, banking relationship, treasury services, credit exposure, owner wealth opportunities, and succession needs.

### 2. Production Layer

Defines product lines, SKUs, production processes, capacity, throughput, utilization, labor, downtime, quality, scrap, maintenance, and bottlenecks.

### 3. Working Capital Layer

Defines raw materials, WIP, finished goods, receivables, payables, purchase orders, sales orders, inventory aging, customer payments, and cash conversion.

### 4. Equipment & CapEx Layer

Defines machinery, tooling, maintenance, useful life, replacement needs, financing, appraisals, collateral, insurance, and productivity.

### 5. Credit Layer

Defines loan structure, borrowing base, advance rates, covenants, collateral, risk rating, guarantors, financial performance, and repayment source.

### 6. Treasury Layer

Defines deposits, ACH, wires, positive pay, payroll, vendor payments, customer collections, merchant/card where applicable, FX where applicable, and cash forecasting.

### 7. Risk & Monitoring Layer

Defines customer concentration, supplier concentration, margin compression, inventory obsolescence, equipment failure, labor shortage, quality events, compliance, and liquidity stress.

### 8. Strategic Layer

Defines reshoring, automation, capacity expansion, acquisition, succession, government incentives, tax credits, defense/regulated markets, and exit planning.

## Manufacturing Finance Functions

- Relationship Management
- Commercial Lending
- Credit Administration
- ABL / Borrowing Base
- Equipment Finance
- Treasury Management
- Deposit Services
- SBA / Government Program Lending
- Portfolio Management
- Vendor / Supplier Finance
- Insurance Referral
- Owner Wealth Referral
- Risk Management
- Compliance
- Data & Analytics

## Operating Cadence

Daily:
- cash position
- receivables collections
- payables pressure
- borrowing base availability
- production exceptions
- equipment outages
- customer delays
- supplier disruptions

Weekly:
- sales orders
- production backlog
- inventory status
- AR/AP aging
- treasury activity
- line utilization
- covenant early warnings

Monthly:
- financial statements
- borrowing base certificate
- inventory aging
- receivables aging
- margin analysis
- production KPIs
- liquidity review
- loan monitoring

Quarterly:
- portfolio review
- covenant testing
- customer concentration
- supplier concentration
- CapEx plan
- risk rating update
- board/commercial package

Annual:
- annual review
- tax returns
- insurance renewal
- equipment appraisal refresh
- succession review
- strategy review
- policy review

## Dispatch Truth Statement

Manufacturing finance succeeds when the institution understands both the financial statements and the factory operating system that produces them.
