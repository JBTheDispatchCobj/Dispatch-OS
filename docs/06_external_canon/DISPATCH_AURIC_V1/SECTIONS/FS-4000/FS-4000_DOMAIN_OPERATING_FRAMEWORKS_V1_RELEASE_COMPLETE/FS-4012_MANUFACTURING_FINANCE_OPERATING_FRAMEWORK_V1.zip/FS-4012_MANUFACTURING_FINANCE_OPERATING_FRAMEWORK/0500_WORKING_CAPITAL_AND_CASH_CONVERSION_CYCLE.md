# Working Capital & Cash Conversion Cycle

## Purpose

This document defines manufacturing working capital, cash conversion, liquidity, and borrowing needs.

## Working Capital Object

Fields:
- working_capital_id
- manufacturer
- cash
- receivables
- inventory
- WIP
- payables
- accrued_expenses
- customer_deposits
- supplier_terms
- borrowing_base
- availability
- liquidity
- cash_conversion_cycle
- status

## Cash Conversion Cycle

Raw Materials Purchased → Production → WIP → Finished Goods → Shipment → Invoice → Receivable → Collection → Cash

## Key Metrics

- Days Sales Outstanding
- Days Inventory Outstanding
- Days Payable Outstanding
- Cash Conversion Cycle
- Inventory Turns
- AR Aging
- AP Aging
- Working Capital Requirement
- Borrowing Base Availability
- Line Utilization

## Liquidity Risks

- slow collections
- large customer dispute
- inventory build
- raw material price spike
- supplier tightening terms
- payroll pressure
- tax obligations
- equipment repair
- customer delay
- backlog timing mismatch
- over-advance
- covenant breach

## Borrowing Base Object

Fields:
- borrowing_base_id
- facility
- receivables
- eligible_receivables
- ineligible_receivables
- inventory
- eligible_inventory
- advance_rates
- reserves
- availability
- outstanding
- excess_availability
- test_date
- exceptions

## Working Capital Workflow

Data Pull → AR Aging → Inventory Report → AP Aging → Eligibility → Advance Rate → Availability → Exception Review → Recommendation

## KPIs

- DSO
- DIO
- DPO
- cash conversion cycle
- availability
- line utilization
- excess availability
- AR over 90
- inventory turns
- liquidity days
- working capital gap

## AI Opportunities

- working capital summary
- borrowing base review
- AR aging risk
- inventory buildup alert
- liquidity forecast
- customer payment risk
- supplier pressure alert
- cash conversion improvement recommendations

## Dispatch Truth Statement

Manufacturing credit risk often shows up first in working capital before it shows up in earnings.
