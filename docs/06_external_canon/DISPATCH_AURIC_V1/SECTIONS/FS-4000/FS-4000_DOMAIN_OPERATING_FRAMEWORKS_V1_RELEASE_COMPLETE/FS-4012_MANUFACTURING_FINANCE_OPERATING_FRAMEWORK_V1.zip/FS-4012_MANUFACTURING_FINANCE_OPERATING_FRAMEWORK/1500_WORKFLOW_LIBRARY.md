# Manufacturing Finance Workflow Library

## Required Workflows

### Manufacturer Onboarding

Prospect → Discovery → Financials → Products → Facility → Customers/Suppliers → Treasury/Credit Needs → Relationship Plan

### Credit Underwriting

Request → Financials → Working Capital Analysis → Collateral → Customer/Supplier Risk → Structure → Memo → Approval

### Borrowing Base

AR/Inventory Pull → Eligibility → Advance Rate → Reserves → Availability → Exception → Approval

### Equipment Finance

Need → Quote → Equipment Review → Valuation → Credit → Documentation → Funding → Monitoring

### Treasury Assessment

Payment Flows → Fraud Controls → Account Structure → Product Recommendation → Implementation

### Annual Review

Financials → AR/AP/Inventory → Covenants → Risk Rating → Relationship Plan → Approval

### Covenant Monitoring

Reporting Due → Evidence → Calculation → Pass/Fail → Exception → Escalation

### Customer Concentration Review

Revenue Pull → Top Customers → AR Exposure → Contract Review → Risk Score → Recommendation

### Supplier Risk Review

Spend Pull → Top Suppliers → Lead Times → Alternatives → Risk Score → Mitigation

### Distressed Manufacturer Review

Early Warning → Liquidity → Collateral → Customer/Supplier → Workout Strategy → Recovery

## Workflow KPIs

- cycle time
- data completeness
- exception rate
- approval time
- monitoring timeliness
- covenant compliance
- borrowing base accuracy
- relationship profitability

## Dispatch Truth Statement

Manufacturing finance workflows must connect operating data to credit decisions.
