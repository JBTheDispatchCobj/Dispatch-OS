# Equipment, Tooling & CapEx Finance

## Purpose

This document defines equipment, tooling, machinery, maintenance, and capital expenditure finance.

## Equipment Asset Object

Fields:
- equipment_id
- manufacturer
- facility
- production_line
- asset_type
- make
- model
- serial_number
- year
- purchase_price
- current_value
- appraised_value
- useful_life
- condition
- maintenance_status
- utilization
- lien_status
- loan_balance
- insurance
- replacement_need

## Equipment Categories

- CNC machines
- presses
- lasers
- robotics
- conveyors
- forklifts
- packaging equipment
- injection molding
- machining centers
- welding equipment
- HVAC/plant systems
- compressors
- generators
- tooling
- molds
- dies
- test equipment
- lab equipment
- fleet vehicles

## CapEx Project Object

Fields:
- capex_id
- manufacturer
- project_name
- purpose
- equipment
- cost
- financing
- expected_productivity
- expected_margin_impact
- implementation_timeline
- vendor
- installation
- training
- risk
- status

## Financing Products

- equipment loan
- equipment lease
- sale-leaseback
- vendor finance
- SBA 504
- CapEx term loan
- line draw
- equipment refinance
- robotics/automation financing
- tooling finance

## Underwriting Factors

- equipment value
- useful life
- productivity impact
- customer contracts
- resale market
- maintenance history
- installation risk
- operator training
- technology obsolescence
- insurance
- collateral perfection

## KPIs

- equipment exposure
- utilization
- downtime
- maintenance cost
- OEE impact
- LTV
- depreciation
- CapEx ROI
- collateral exceptions
- replacement backlog

## AI Opportunities

- equipment finance memo
- CapEx ROI analysis
- maintenance risk alert
- collateral summary
- replacement need forecast
- automation opportunity assessment
- vendor quote comparison

## Dispatch Truth Statement

Manufacturing equipment is both production capacity and collateral. Financing decisions must understand both.
