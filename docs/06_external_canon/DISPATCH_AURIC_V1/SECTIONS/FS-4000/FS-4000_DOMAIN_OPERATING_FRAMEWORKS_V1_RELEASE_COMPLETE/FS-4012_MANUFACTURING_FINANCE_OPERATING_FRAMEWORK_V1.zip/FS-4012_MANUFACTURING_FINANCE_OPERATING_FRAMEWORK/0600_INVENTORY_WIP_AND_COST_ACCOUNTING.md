# Inventory, WIP & Cost Accounting

## Purpose

This document defines inventory, work-in-process, costing, and margin intelligence.

## Inventory Object

Fields:
- inventory_id
- manufacturer
- category
- SKU
- description
- quantity
- cost
- carrying_value
- location
- aging
- turnover
- obsolescence_risk
- eligibility_status
- collateral_value
- insurance_status

## Inventory Categories

- Raw Materials
- Work-in-Process
- Finished Goods
- MRO Supplies
- Spare Parts
- Tooling
- Consigned Inventory
- Customer-Owned Inventory
- Obsolete Inventory
- Slow-Moving Inventory

## WIP Object

Fields:
- WIP_id
- job
- product
- customer
- stage
- costs_to_date
- estimated_completion
- margin_estimate
- percent_complete
- issues
- delivery_date
- billing_status

## Cost Accounting Objects

- Standard Cost
- Actual Cost
- Job Cost
- Labor Cost
- Material Cost
- Overhead Allocation
- Variance
- Scrap
- Rework
- Yield
- Gross Margin
- Contribution Margin

## Inventory Risks

- obsolete stock
- slow-moving inventory
- inaccurate counts
- poor costing
- margin leakage
- theft/shrinkage
- customer-owned inventory confusion
- raw material volatility
- supply disruption
- overstated collateral
- insurance gap

## Inventory Monitoring Workflow

ERP Pull → Inventory Categorization → Aging → Eligibility → Valuation → Variance Review → Borrowing Base Update → Risk Alert

## KPIs

- inventory turns
- DIO
- obsolete inventory
- slow-moving percentage
- WIP aging
- gross margin variance
- scrap rate
- rework rate
- standard vs actual variance
- eligible inventory value

## AI Opportunities

- inventory aging summary
- WIP risk detection
- costing variance analysis
- obsolete inventory alert
- borrowing base eligibility
- margin leakage analysis
- production finance memo

## Dispatch Truth Statement

Inventory is both operating input and collateral. Dispatch must know whether it is usable, saleable, properly valued, insured, and convertible to cash.
