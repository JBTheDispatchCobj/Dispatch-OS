# Market Participants

## Purpose

This document defines the manufacturing finance ecosystem.

## Participant Types

- Manufacturer
- Owner / Sponsor
- Management Team
- Plant Manager
- Controller / CFO
- Production Manager
- Customer
- Supplier
- Distributor
- Logistics Provider
- Equipment Dealer
- Equipment Lessor
- Maintenance Provider
- ERP Vendor
- Quality Auditor
- Certification Body
- Insurance Agent
- Surety / Bond Provider
- Commercial Lender
- Credit Union
- Bank
- Corporate Credit Union
- SBA Lender
- Economic Development Agency
- State Incentive Agency
- Export Finance Provider
- Freight Forwarder
- Customs Broker
- CPA
- Attorney
- Appraiser

## Manufacturer Object

Fields:
- manufacturer_id
- name
- industry
- NAICS
- products
- facilities
- revenue
- EBITDA
- gross_margin
- backlog
- customers
- suppliers
- equipment
- employees
- shifts
- utilization
- certifications
- ERP
- banking_relationships
- credit_facilities
- risk_rating

## Customer Object

Fields:
- customer_id
- manufacturer
- customer_name
- industry
- revenue_contribution
- receivables
- payment_terms
- contract_status
- concentration_percentage
- credit_quality
- renewal_status

## Supplier Object

Fields:
- supplier_id
- manufacturer
- supplier_name
- materials
- spend
- payment_terms
- lead_time
- dependency_level
- alternate_suppliers
- disruption_risk
- geography

## Relationship Types

- MANUFACTURER_PRODUCES Product
- PRODUCT_USES Raw Material
- SUPPLIER_PROVIDES Material
- CUSTOMER_PURCHASES Product
- EQUIPMENT_SUPPORTS Production Line
- LENDER_FINANCES Manufacturer
- TREASURY_SERVICE_SUPPORTS Payments
- ERP_TRACKS Inventory
- RECEIVABLE_SUPPORTS Borrowing Base
- INVENTORY_SUPPORTS Borrowing Base

## AI Opportunities

- manufacturer profile
- customer concentration analysis
- supplier dependency map
- equipment vendor map
- market participant graph
- relationship intelligence
- referral opportunity detection

## Dispatch Truth Statement

Manufacturing finance is ecosystem finance. The manufacturer's repayment capacity depends on customers, suppliers, equipment, labor, logistics, systems, and lenders.
