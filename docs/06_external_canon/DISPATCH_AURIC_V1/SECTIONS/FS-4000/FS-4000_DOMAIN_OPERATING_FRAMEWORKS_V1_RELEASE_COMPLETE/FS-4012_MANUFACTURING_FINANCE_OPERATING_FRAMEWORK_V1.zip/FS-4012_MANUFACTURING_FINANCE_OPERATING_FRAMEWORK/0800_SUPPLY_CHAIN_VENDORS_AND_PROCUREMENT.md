# Supply Chain, Vendors & Procurement

## Purpose

This document defines supplier, procurement, materials, logistics, and supply chain risk.

## Supplier Object

Fields:
- supplier_id
- manufacturer
- supplier_name
- material_or_service
- spend
- payment_terms
- lead_time
- geography
- dependency_level
- alternate_supplier
- quality_score
- delivery_score
- price_volatility
- disruption_risk
- relationship_status

## Purchase Order Object

Fields:
- PO_id
- supplier
- manufacturer
- materials
- amount
- order_date
- expected_delivery
- status
- payment_terms
- related_job
- related_inventory
- financing_need

## Supply Chain Risks

- single-source supplier
- long lead times
- price volatility
- overseas shipping disruption
- tariffs
- quality failure
- supplier financial distress
- minimum order quantity
- inventory shortage
- logistics delay
- currency exposure
- geopolitical exposure

## Procurement Finance Opportunities

- supply chain finance
- purchase order finance
- vendor payments
- commercial card
- ACH/wire
- early pay discounts
- inventory finance
- supplier deposits
- trade finance
- FX support

## Supplier Monitoring Workflow

Spend Pull → Supplier Ranking → Dependency Review → Terms Review → Delivery Performance → Risk Score → Mitigation Plan

## KPIs

- top supplier concentration
- supplier on-time delivery
- material price variance
- lead time
- supplier payment terms
- procurement spend
- early pay discounts
- supply disruptions
- alternate supplier coverage

## AI Opportunities

- supplier risk map
- procurement spend analysis
- price variance summary
- alternate supplier checklist
- supply disruption alert
- payment terms optimization
- purchase order finance recommendation

## Dispatch Truth Statement

Supply chain risk is credit risk. A manufacturer cannot repay if it cannot procure, produce, ship, and collect.
