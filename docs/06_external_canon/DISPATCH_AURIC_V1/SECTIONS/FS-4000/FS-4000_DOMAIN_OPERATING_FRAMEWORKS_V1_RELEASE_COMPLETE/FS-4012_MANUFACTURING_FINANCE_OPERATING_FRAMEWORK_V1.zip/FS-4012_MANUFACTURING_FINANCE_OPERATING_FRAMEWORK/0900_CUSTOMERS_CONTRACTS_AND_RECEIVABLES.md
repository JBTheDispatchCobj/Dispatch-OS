# Customers, Contracts & Receivables

## Purpose

This document defines customer contracts, sales orders, receivables, collections, and concentration risk.

## Customer Object

Fields:
- customer_id
- manufacturer
- name
- industry
- revenue_share
- contract_status
- credit_quality
- payment_terms
- receivables
- aging
- dispute_history
- renewal_risk
- concentration
- relationship_status

## Customer Contract Object

Fields:
- contract_id
- customer
- manufacturer
- products
- term
- pricing
- volume_commitment
- renewal
- termination_rights
- payment_terms
- penalties
- quality_requirements
- delivery_requirements
- margin
- status

## Receivable Object

Fields:
- receivable_id
- customer
- invoice
- amount
- invoice_date
- due_date
- age
- status
- dispute
- eligibility
- advance_rate
- collection_probability
- related_PO
- related_shipment

## Receivables Risks

- customer concentration
- slow payment
- dispute
- chargeback
- bankruptcy
- contract termination
- quality rejection
- volume decline
- price concession
- foreign receivable
- affiliate receivable
- aged receivable
- ineligible receivable

## Customer Monitoring Workflow

Revenue Pull → Customer Ranking → AR Aging → Contract Review → Payment Trend → Concentration Risk → Borrowing Base Eligibility → Alert

## KPIs

- top customer concentration
- DSO
- AR over 60/90
- disputed receivables
- ineligible AR
- customer churn
- contract renewal
- sales order backlog
- on-time delivery
- margin by customer

## AI Opportunities

- customer concentration memo
- AR aging analysis
- contract summary
- payment delay alert
- dispute summary
- borrowing base AR eligibility
- customer renewal risk
- revenue quality assessment

## Dispatch Truth Statement

Receivables are repayment evidence only if the customer is real, solvent, satisfied, obligated, and likely to pay.
