# Acceptance Tests & Roadmap

## Object Tests

- Can create Manufacturer.
- Can create Plant.
- Can create Production Line.
- Can create Product/SKU.
- Can create Customer.
- Can create Supplier.
- Can create Inventory.
- Can create WIP.
- Can create Receivable.
- Can create Payable.
- Can create Equipment Asset.
- Can create Borrowing Base.
- Can create Working Capital Line.
- Can create Treasury Service.
- Can create Covenant.

## Relationship Tests

- Manufacturer PRODUCES Product.
- Product USES Raw Material.
- Supplier PROVIDES Material.
- Customer PURCHASES Product.
- Receivable OWED_BY Customer.
- Inventory SUPPORTS Borrowing Base.
- Equipment SUPPORTS Production Line.
- Loan FINANCES Manufacturer.
- Treasury Service SUPPORTS Payment Flow.
- Covenant GOVERNS Facility.

## Workflow Tests

- Manufacturer onboarding creates relationship plan.
- Credit underwriting creates credit memo.
- Borrowing base workflow calculates availability.
- Equipment finance workflow validates collateral.
- Treasury assessment recommends services.
- Annual review updates risk rating.
- Covenant workflow detects breach.
- Customer concentration workflow scores risk.
- Supplier risk workflow creates mitigation plan.

## Agent Tests

- Working Capital Analyst summarizes cash cycle.
- Borrowing Base Analyst calculates availability.
- Inventory Analyst identifies obsolescence.
- AR Aging Analyst flags slow collections.
- Customer Concentration Agent identifies risk.
- Supplier Risk Agent maps dependency.
- Credit Memo Writer drafts memo.
- Treasury Opportunity Agent recommends products.

## Roadmap

Priority 1:
- machine-readable manufacturing object registry
- fixture manufacturer
- fixture AR/AP/inventory data
- fixture borrowing base
- fixture equipment list
- fixture credit memo

Priority 2:
- borrowing base engine
- working capital dashboard
- equipment collateral module
- customer/supplier concentration module
- treasury assessment workflow

Priority 3:
- ERP connector library
- production KPI ingestion
- supply chain risk intelligence
- owner wealth/succession extension
- manufacturing market intelligence

## Dispatch Truth Statement

The Manufacturing Finance cartridge is accepted when Dispatch can connect manufacturer operating data to credit, collateral, treasury, relationship, and risk decisions.
