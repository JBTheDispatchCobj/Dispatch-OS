# Manufacturing Finance Schema & Object Standard

## Purpose

This document defines canonical manufacturing finance objects used by Dispatch.

## Universal Manufacturer Object

Fields:

- manufacturer_id
- legal_name
- DBA
- entity_type
- industry
- NAICS
- ownership
- management_team
- locations
- facilities
- plants
- production_lines
- products
- customers
- suppliers
- revenue
- gross_margin
- EBITDA
- backlog
- inventory
- WIP
- receivables
- payables
- equipment
- CapEx_plan
- debt
- treasury_services
- risk_rating
- compliance_status
- technology_stack
- documents
- workflows
- KPIs
- AI_context
- audit_history

## Core Manufacturing Finance Objects

- Manufacturer
- Plant
- Facility
- Production Line
- Product
- SKU
- Bill of Materials
- Raw Material
- Work-in-Process
- Finished Goods
- Inventory
- Purchase Order
- Sales Order
- Customer Contract
- Supplier
- Distributor
- Equipment Asset
- Tooling
- Maintenance Plan
- CapEx Project
- Receivable
- Payable
- Borrowing Base
- Covenant
- Working Capital Line
- Equipment Loan
- Term Loan
- SBA Loan
- ABL Facility
- Treasury Service
- Insurance Policy
- Quality System
- Certification
- ERP System

## Product / Production Types

- Discrete Manufacturing
- Process Manufacturing
- Job Shop
- Contract Manufacturing
- OEM
- Tier Supplier
- Food Manufacturing
- Medical Device Manufacturing
- Aerospace / Defense Manufacturing
- Automotive Supplier
- Metal Fabrication
- Plastics
- Packaging
- Electronics
- Industrial Equipment
- Chemical Manufacturing
- Textile / Apparel
- Consumer Goods
- Custom Fabrication

## Dispatch Rule

Manufacturing credit exposure must connect to production capacity, working capital, inventory quality, customer concentration, supplier dependency, equipment condition, margin, backlog, and cash conversion cycle.

## Dispatch Truth Statement

Manufacturing finance objects connect physical production, inventory, receivables, equipment, suppliers, customers, labor, cash flow, and credit into one operating graph.
