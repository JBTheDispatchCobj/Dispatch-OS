# Manufacturer Relationship Lifecycle

## Purpose

This document defines how institutions originate, manage, and deepen manufacturer relationships.

## Relationship Lifecycle

Prospect → Discovery → Qualification → Deposit/Treasury Onboarding → Credit Assessment → Facility Structure → Monitoring → Expansion → Strategic Relationship → Succession / Exit / Workout

## Manufacturer Discovery Framework

Dispatch captures:

- ownership
- management
- products
- markets served
- facilities
- production capacity
- shifts
- customers
- suppliers
- backlog
- revenue mix
- gross margin
- EBITDA
- inventory
- AR/AP
- working capital cycle
- equipment
- CapEx needs
- quality certifications
- ERP/accounting system
- treasury needs
- credit needs
- insurance needs
- owner wealth needs
- succession issues

## Relationship Plan Object

Fields:
- plan_id
- manufacturer
- relationship_manager
- current_products
- deposit_balances
- treasury_services
- credit_facilities
- equipment_needs
- owner_wealth_opportunities
- insurance_opportunities
- supplier/customer risks
- profitability
- next_actions
- review_date

## Relationship Opportunities

- operating accounts
- payroll account
- tax account
- ACH
- wire
- remote deposit
- positive pay
- merchant/card where applicable
- working capital line
- ABL facility
- equipment loan
- real estate loan
- SBA loan
- CapEx financing
- owner wealth management
- succession planning
- insurance referral
- FX/trade finance where applicable

## Relationship KPIs

- manufacturer relationships
- deposits
- loan exposure
- treasury revenue
- equipment finance volume
- relationship profitability
- cross-sell
- risk rating migration
- annual review completion
- covenant compliance
- customer retention

## AI Opportunities

- manufacturer relationship brief
- owner meeting prep
- next best product
- working capital need detection
- equipment finance opportunity
- treasury recommendation
- owner wealth trigger
- succession risk alert

## Dispatch Truth Statement

A manufacturer relationship is not a single credit product. It is a balance sheet, operating, treasury, equipment, owner, and market relationship.
