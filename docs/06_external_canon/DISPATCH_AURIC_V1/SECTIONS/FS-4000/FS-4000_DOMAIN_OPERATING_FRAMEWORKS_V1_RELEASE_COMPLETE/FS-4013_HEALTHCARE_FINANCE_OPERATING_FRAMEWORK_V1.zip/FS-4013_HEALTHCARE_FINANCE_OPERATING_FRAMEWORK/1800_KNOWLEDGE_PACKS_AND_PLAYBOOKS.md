# Knowledge Packs & Playbooks

## Knowledge Packs

### Healthcare Finance Foundation Pack

- terminology
- participant taxonomy
- product taxonomy
- healthcare business model
- KPI definitions
- workflow maps

### Revenue Cycle Pack

- claims
- denials
- AR aging
- payer mix
- collections
- net collection rate
- RCM vendor review

### Practice Acquisition Pack

- valuation
- diligence
- purchase agreement
- transition
- seller note
- patient retention
- provider continuity

### Equipment Finance Pack

- medical equipment
- revenue impact
- reimbursement
- collateral
- utilization
- replacement

### Treasury Pack

- patient payments
- payer deposits
- payroll
- merchant services
- account structure
- fraud controls

### Compliance Pack

- licensure
- malpractice
- HIPAA awareness
- credentialing
- payer participation
- documentation

### Distress Pack

- AR deterioration
- provider loss
- payer issue
- staffing shortage
- liquidity stress
- workout

## Playbooks

- Healthcare Discovery Playbook
- Practice Credit Memo Playbook
- Revenue Cycle Review Playbook
- Payer Mix Risk Playbook
- Practice Acquisition Playbook
- Partner Buy-In Playbook
- Equipment Finance Playbook
- Treasury Assessment Playbook
- Annual Review Playbook
- License/Insurance Monitoring Playbook
- Distressed Practice Playbook
- Owner Succession/Wealth Referral Playbook

## Dispatch Truth Statement

Healthcare knowledge packs turn specialized reimbursement and practice operating knowledge into credit, treasury, and relationship execution.
