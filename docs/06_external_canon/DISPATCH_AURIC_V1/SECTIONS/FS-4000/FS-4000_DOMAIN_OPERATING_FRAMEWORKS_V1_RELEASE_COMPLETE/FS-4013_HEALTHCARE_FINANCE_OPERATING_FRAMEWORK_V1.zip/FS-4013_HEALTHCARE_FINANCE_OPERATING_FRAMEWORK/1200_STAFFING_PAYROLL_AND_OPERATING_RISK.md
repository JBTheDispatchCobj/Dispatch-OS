# Staffing, Payroll & Operating Risk

## Purpose

This document defines healthcare staffing, payroll, productivity, and operating risk.

## Staffing Object

Fields:
- staffing_id
- practice
- providers
- clinical_staff
- admin_staff
- open_positions
- payroll
- benefits
- overtime
- turnover
- productivity
- staffing_ratio
- risk

## Key Roles

- Physician
- Dentist
- Nurse Practitioner
- Physician Assistant
- Hygienist
- Therapist
- Technician
- Nurse
- Medical Assistant
- Billing Specialist
- Scheduler
- Practice Manager
- Administrator
- CFO/Controller
- Caregiver
- Pharmacist

## Staffing Risks

- provider departure
- owner illness
- hygienist shortage
- nurse shortage
- caregiver turnover
- overtime spike
- credentialing delay
- compensation pressure
- union/labor issue
- burnout
- weak billing staff
- weak practice manager

## Productivity Metrics

- revenue per provider
- visits per provider
- procedures per provider
- provider days
- appointment utilization
- no-show rate
- staff-to-provider ratio
- payroll-to-revenue
- overtime
- turnover

## Payroll / Liquidity Risk

Payroll is often the largest recurring cash need. Dispatch tracks:
- payroll schedule
- payroll amount
- cash coverage
- LOC availability
- payer collections timing
- staffing changes
- overtime trend

## KPIs

- revenue per provider
- payroll-to-revenue
- provider utilization
- staff turnover
- open positions
- overtime
- no-show rate
- appointment utilization
- productivity variance

## AI Opportunities

- staffing risk alert
- provider productivity summary
- payroll pressure forecast
- no-show impact analysis
- practice manager brief
- turnover risk memo
- lender monitoring summary

## Dispatch Truth Statement

Healthcare repayment capacity depends heavily on licensed people showing up and producing care consistently.
