# Healthcare Finance Implementation Guide

## Phase 1 — Setup

- create healthcare finance domain
- configure provider/practice objects
- configure healthcare segments
- configure credit products
- configure revenue cycle KPIs
- configure payer mix fields
- configure license/insurance requirements
- configure risk rating model

## Phase 2 — Objects

- practices
- provider owners
- locations
- payers
- claims
- AR
- denials
- equipment
- facilities
- loans
- treasury services
- licenses
- insurance
- practice acquisition/buy-in objects
- KPIs

## Phase 3 — Connectors

- accounting/GL
- AR aging exports
- RCM reports
- document storage
- email/calendar
- merchant deposits
- EHR/practice management exports
- payroll
- bank core
- LOS
- treasury platform
- AI provider

## Phase 4 — Workflows

Activate:
- provider onboarding
- credit underwriting
- practice acquisition
- partner buy-in
- equipment finance
- revenue cycle monitoring
- treasury assessment
- annual review
- license/insurance monitoring
- distressed practice review

## Phase 5 — Agents

Deploy:
- Healthcare Relationship Agent
- Revenue Cycle Analyst
- Payer Mix Analyst
- Provider Productivity Analyst
- Practice Valuation Agent
- Credit Memo Writer
- Treasury Opportunity Agent
- License Monitor
- Early Warning Agent

## Phase 6 — Dashboards

Configure:
- executive
- relationship
- revenue cycle
- payer mix
- provider productivity
- equipment
- treasury
- acquisition/buy-in
- compliance
- risk

## Demo Flow

1. Open practice profile.
2. Show providers, locations, payer mix.
3. Review AR/denials.
4. Generate revenue cycle summary.
5. Identify treasury needs.
6. Analyze equipment finance opportunity.
7. Draft credit memo section.
8. Review license/insurance status.
9. Show early warning dashboard.
10. Generate annual review.

## Dispatch Truth Statement

Healthcare finance implementation begins with reimbursement truth, then provider productivity, then credit structure, then relationship expansion.
