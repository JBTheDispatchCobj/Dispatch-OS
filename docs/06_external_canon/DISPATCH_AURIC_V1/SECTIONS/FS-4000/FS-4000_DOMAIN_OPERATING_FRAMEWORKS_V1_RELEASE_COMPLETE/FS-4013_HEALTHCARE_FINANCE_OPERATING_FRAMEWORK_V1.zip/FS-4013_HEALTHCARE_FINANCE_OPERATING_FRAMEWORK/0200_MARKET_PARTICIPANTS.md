# Market Participants

## Purpose

This document defines the healthcare finance participant ecosystem.

## Participant Types

- Physician
- Dentist
- Provider Owner
- Practice Manager
- CFO / Controller
- Medical Practice
- Dental Practice
- Specialty Clinic
- Hospital
- Health System
- ASC
- Senior Care Operator
- Home Health Agency
- Pharmacy
- MSO
- DSO
- Private Equity Sponsor
- Payer
- Medicare
- Medicaid
- Commercial Insurer
- Patient
- Employer Plan
- Revenue Cycle Vendor
- Billing Company
- EHR Vendor
- Clearinghouse
- Credentialing Vendor
- Equipment Vendor
- Landlord
- Real Estate Developer
- Credit Union
- Bank
- SBA Lender
- Insurance Agent
- CPA
- Attorney
- Valuation Firm
- Regulator

## Provider Owner Object

Fields:
- provider_id
- name
- specialty
- license
- board_certification
- ownership_percentage
- productivity
- compensation
- patients
- referral_relationships
- malpractice_coverage
- succession_status
- wealth_relationship
- risk_flags

## Payer Object

Fields:
- payer_id
- payer_name
- type
- contract_terms
- reimbursement_rates
- claims_volume
- denial_rate
- days_to_pay
- concentration_percentage
- audit_risk
- relationship_status

## Vendor Object

Fields:
- vendor_id
- name
- category
- service
- contract
- performance
- integration
- risk
- renewal
- owner

## Relationship Types

- PROVIDER_TREATS Patient
- PRACTICE_BILLS Payer
- PAYER_REIMBURSES Practice
- EHR_TRACKS Encounter
- RCM_VENDOR_PROCESSES Claim
- LENDER_FINANCES Practice
- EQUIPMENT_VENDOR_SELLS Equipment
- OWNER_GUARANTEES Loan
- MSO_SUPPORTS Practice
- INSURER_COVERS Liability
- REGULATOR_LICENSES Provider

## AI Opportunities

- participant profile
- payer concentration map
- provider productivity summary
- vendor performance review
- MSO/DSO relationship map
- lender opportunity detection

## Dispatch Truth Statement

Healthcare finance is a participant network where providers deliver care, payers control reimbursement, vendors control systems, and lenders finance the operating cycle.
