# Medical Equipment & CapEx Finance

## Purpose

This document defines healthcare equipment, technology, buildout, and CapEx finance.

## Equipment Asset Object

Fields:
- equipment_id
- practice
- equipment_type
- make
- model
- serial_number
- vendor
- purchase_price
- current_value
- useful_life
- utilization
- revenue_supported
- maintenance
- warranty
- insurance
- lien_status
- loan_balance
- replacement_need

## Equipment Categories

- dental chairs
- dental imaging
- CBCT
- ophthalmology equipment
- lasers
- diagnostic imaging
- ultrasound
- MRI
- CT
- lab equipment
- sterilization
- surgical equipment
- physical therapy equipment
- exam room equipment
- pharmacy equipment
- EHR hardware
- IT infrastructure
- vehicles for home health

## CapEx Uses

- new equipment
- replacement equipment
- practice buildout
- leasehold improvements
- de novo location
- technology upgrade
- EHR conversion
- imaging expansion
- surgical suite
- accessibility/compliance upgrades

## Financing Products

- equipment loan
- equipment lease
- SBA 504
- SBA 7(a)
- CapEx term loan
- vendor finance
- sale-leaseback
- buildout loan
- working capital support

## Underwriting Factors

- equipment revenue impact
- utilization
- reimbursement support
- useful life
- resale market
- vendor
- maintenance
- installation
- training
- payer approval
- collateral value
- practice cash flow

## KPIs

- equipment exposure
- utilization
- equipment ROI
- revenue per equipment asset
- downtime
- maintenance cost
- LTV
- collateral exceptions
- insurance exceptions
- replacement backlog

## AI Opportunities

- equipment finance memo
- ROI analysis
- vendor quote comparison
- reimbursement impact
- replacement need forecast
- utilization analysis
- CapEx plan summary

## Dispatch Truth Statement

Medical equipment is clinical capacity, revenue engine, technology risk, and collateral at the same time.
