# Acceptance Tests & Roadmap

## Object Tests

- Can create Healthcare Provider Business.
- Can create Practice.
- Can create Provider Owner.
- Can create Payer.
- Can create Payer Contract.
- Can create Claim.
- Can create Denial.
- Can create AR Aging.
- Can create Revenue Cycle Object.
- Can create Equipment Asset.
- Can create Facility.
- Can create Practice Acquisition.
- Can create Partner Buy-In.
- Can create Healthcare Loan.
- Can create Treasury Service.
- Can create License and Insurance objects.

## Relationship Tests

- Provider WORKS_AT Practice.
- Practice BILLS Payer.
- Payer REIMBURSES Claim.
- Claim CREATES Receivable.
- Denial IMPACTS Revenue Cycle.
- Equipment SUPPORTS Procedure.
- Loan FINANCES Practice.
- Treasury Service SUPPORTS Payment Flow.
- License AUTHORIZES Provider.
- Insurance COVERS Malpractice Risk.

## Workflow Tests

- Provider onboarding creates relationship plan.
- Credit underwriting creates healthcare credit memo.
- Practice acquisition workflow creates valuation and diligence checklist.
- Equipment finance workflow validates revenue impact.
- Revenue cycle monitoring detects AR deterioration.
- Treasury assessment recommends services.
- Annual review updates risk rating.
- License monitoring detects expiration.
- Distressed practice workflow creates workout plan.

## Agent Tests

- Revenue Cycle Analyst summarizes AR/denials.
- Payer Mix Analyst identifies concentration risk.
- Provider Productivity Analyst summarizes production.
- Practice Valuation Agent prepares valuation summary.
- Credit Memo Writer drafts memo.
- Treasury Opportunity Agent recommends products.
- License Monitor flags missing evidence.
- Early Warning Agent identifies risk events.

## Roadmap

Priority 1:
- machine-readable healthcare object registry
- fixture practice
- fixture payer mix/AR/denials
- fixture equipment list
- fixture practice acquisition
- fixture credit memo

Priority 2:
- revenue cycle dashboard
- payer mix risk engine
- provider productivity dashboard
- treasury assessment workflow
- license/insurance monitoring

Priority 3:
- EHR/RCM connector library
- practice valuation engine
- partner buy-in module
- senior care specialization
- healthcare market intelligence

## Dispatch Truth Statement

The Healthcare Finance cartridge is accepted when Dispatch can connect practice operating data, reimbursement, provider productivity, compliance, treasury, equipment, and credit into one institutional operating system.
