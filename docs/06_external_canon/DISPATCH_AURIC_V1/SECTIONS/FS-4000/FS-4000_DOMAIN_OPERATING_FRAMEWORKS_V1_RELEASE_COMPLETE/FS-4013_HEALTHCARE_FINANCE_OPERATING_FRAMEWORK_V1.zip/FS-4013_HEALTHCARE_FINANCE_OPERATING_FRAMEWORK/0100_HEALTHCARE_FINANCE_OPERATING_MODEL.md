# Healthcare Finance Operating Model

## Definition

Healthcare finance is the institutional process of funding and monitoring healthcare providers whose financial performance depends on patient demand, provider productivity, reimbursement, claims quality, payer contracts, staffing, compliance, facilities, and equipment.

## Operating Layers

### 1. Relationship Layer

Defines owners, providers, management, referral sources, banking relationship, treasury services, lending relationship, owner wealth, insurance needs, and succession needs.

### 2. Care Delivery Layer

Defines patient visits, procedures, provider productivity, appointment capacity, facilities, equipment, staff, quality, and service lines.

### 3. Reimbursement Layer

Defines payer mix, contracts, claims, denials, collections, coding, billing, AR aging, net collection rate, and revenue cycle performance.

### 4. Credit Layer

Defines repayment source, practice cash flow, guarantor support, collateral, facility structure, covenants, DSCR, leverage, working capital need, acquisition value, and owner distributions.

### 5. Treasury Layer

Defines deposits, patient payments, merchant services, ACH, payroll, vendor payments, lockbox, sweeps, positive pay, operating accounts, tax accounts, and cash forecasting.

### 6. Equipment & Real Estate Layer

Defines medical equipment, imaging equipment, dental chairs, surgical equipment, leases, buildouts, facilities, owner-occupied CRE, expansion, and CapEx.

### 7. Risk & Compliance Layer

Defines licensure, accreditation, HIPAA, billing compliance, fraud/waste/abuse awareness, payer audit risk, provider credentialing, malpractice coverage, staffing, and regulatory change.

### 8. Strategic Layer

Defines acquisition, partner buy-in, succession, de novo expansion, roll-up, service line expansion, MSO relationships, private equity sponsor interest, and exit planning.

## Healthcare Finance Functions

- Relationship Management
- Professional Practice Banking
- Commercial Lending
- SBA Lending
- Equipment Finance
- Owner-Occupied CRE Lending
- Treasury Management
- Deposit Services
- Revenue Cycle Analysis
- Credit Administration
- Portfolio Monitoring
- Compliance Review
- Insurance Referral
- Wealth Referral
- Practice Succession Advisory
- Risk Management

## Operating Cadence

Daily:
- deposits
- patient payments
- payroll pressure
- claims activity
- denial spikes
- overdrafts
- urgent working capital needs

Weekly:
- patient volume
- collections
- AR aging
- payer issues
- staffing issues
- equipment issues
- loan pipeline

Monthly:
- financials
- revenue cycle KPIs
- claims/denials
- payer mix
- provider productivity
- treasury review
- covenant monitoring

Quarterly:
- annual review inputs
- credit risk update
- license/certification status
- insurance status
- payer concentration
- portfolio monitoring
- owner succession/wealth review

Annual:
- tax returns
- annual review
- license renewals
- insurance renewals
- compensation review
- practice valuation review
- succession review
- policy review

## Dispatch Truth Statement

Healthcare finance succeeds when the institution understands both the financial statements and the care/reimbursement system that creates them.
