# Practice Acquisition, Buy-In & Succession

## Purpose

This document defines healthcare practice acquisition, partner buy-ins, buyouts, and succession finance.

## Practice Transaction Types

- Practice Acquisition
- Partner Buy-In
- Partner Buyout
- Associate Dentist Buy-In
- Physician Practice Acquisition
- DSO/MSO Acquisition
- Roll-Up Add-On
- De Novo Startup
- Satellite Location
- Equipment-Driven Expansion
- Owner Retirement Transition
- Internal Succession
- Management Buyout

## Practice Valuation Object

Fields:
- valuation_id
- practice
- revenue
- EBITDA
- SDE
- collections
- provider_count
- patient_base
- payer_mix
- equipment_value
- goodwill
- real_estate
- multiple
- purchase_price
- working_capital
- adjustments
- valuation_method

## Partner Buy-In Object

Fields:
- buyin_id
- practice
- incoming_partner
- selling_partner
- ownership_percentage
- purchase_price
- financing
- note
- repayment_source
- compensation_adjustment
- governance_rights
- documents
- status

## Acquisition Underwriting

Inputs:
- historical financials
- tax returns
- production by provider
- payer mix
- collections
- patient retention
- referral sources
- equipment
- lease/real estate
- employment agreements
- noncompete/non-solicit
- transition plan
- seller note
- management continuity
- purchase agreement

## Succession Risks

- aging owner
- no associate pipeline
- provider dependence
- patient attrition
- referral loss
- valuation mismatch
- financing gap
- buyer readiness
- transition risk
- compensation conflict

## KPIs

- acquisition loans
- buy-in loans
- purchase price multiple
- DSCR
- seller note exposure
- transition success
- patient retention
- provider retention
- succession opportunities
- owner wealth capture

## AI Opportunities

- valuation summary
- buy-in structure
- acquisition credit memo
- succession risk alert
- transition plan
- seller note review
- practice continuity memo
- owner wealth opportunity

## Dispatch Truth Statement

Healthcare succession is both credit event and relationship opportunity.
