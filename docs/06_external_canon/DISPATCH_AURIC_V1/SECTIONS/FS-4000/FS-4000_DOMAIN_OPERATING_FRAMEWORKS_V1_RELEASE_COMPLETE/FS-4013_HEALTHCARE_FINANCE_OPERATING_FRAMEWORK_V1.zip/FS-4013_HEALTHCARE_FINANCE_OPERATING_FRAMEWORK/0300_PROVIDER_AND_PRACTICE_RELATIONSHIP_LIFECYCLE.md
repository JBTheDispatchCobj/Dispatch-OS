# Provider & Practice Relationship Lifecycle

## Purpose

This document defines healthcare provider and practice relationship management.

## Relationship Lifecycle

Prospect → Discovery → Qualification → Deposit/Treasury Onboarding → Credit Assessment → Facility / Equipment / Acquisition Financing → Monitoring → Expansion → Succession / Partner Buy-In → Strategic Relationship → Exit / Workout

## Practice Discovery Framework

Dispatch captures:

- specialty
- locations
- owners/providers
- provider productivity
- patient volume
- payer mix
- reimbursement profile
- procedure mix
- referral sources
- staffing
- EHR/RCM systems
- billing company
- AR aging
- denial rate
- collections
- equipment
- lease/real estate
- compliance status
- licenses/certifications
- malpractice insurance
- debt
- treasury needs
- owner wealth needs
- succession plans

## Relationship Plan Object

Fields:
- plan_id
- practice
- relationship_manager
- current_products
- deposit_balances
- treasury_services
- credit_facilities
- equipment_needs
- acquisition_or_buyin_needs
- owner_wealth_opportunities
- insurance_opportunities
- risk_profile
- profitability
- next_actions
- review_date

## Relationship Opportunities

- operating account
- payroll account
- tax account
- merchant services
- ACH
- wire
- positive pay
- lockbox
- working capital line
- equipment financing
- acquisition loan
- partner buy-in loan
- owner-occupied CRE
- SBA loan
- buildout financing
- insurance referral
- owner wealth management
- succession planning
- retirement plan
- treasury automation

## Relationship KPIs

- healthcare relationships
- deposit balances
- treasury revenue
- loan exposure
- equipment finance volume
- relationship profitability
- cross-sell
- retention
- risk rating migration
- annual review completion
- provider succession opportunities

## AI Opportunities

- practice relationship brief
- owner/provider meeting prep
- equipment finance opportunity
- treasury recommendation
- owner wealth trigger
- succession risk alert
- acquisition/buy-in opportunity detection
- practice risk summary

## Dispatch Truth Statement

Healthcare practice banking is both business banking and owner-life-cycle banking.
