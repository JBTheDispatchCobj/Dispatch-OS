# Treasury, Payments & Deposits

## Purpose

This document defines treasury and deposit services for healthcare providers.

## Treasury Products

- Operating Account
- Payroll Account
- Tax Account
- Patient Payment Account
- Merchant Services
- ACH
- Wire
- Remote Deposit
- Lockbox
- Positive Pay
- ACH Positive Pay
- Commercial Card
- Purchasing Card
- Sweep Account
- Zero Balance Account
- Online Treasury Portal
- Cash Forecasting

## Healthcare Payment Flows

- payer reimbursements
- patient payments
- copays
- deductibles
- subscriptions/memberships
- payroll
- provider distributions
- vendor payments
- equipment payments
- rent
- taxes
- insurance
- debt service

## Payment Flow Object

Fields:
- payment_flow_id
- practice
- payer_or_payee
- rail
- frequency
- average_amount
- source_system
- risk
- treasury_service
- automation_status

## Treasury Assessment Workflow

Discovery → Payment Flow Map → Patient Payment Review → Payer Deposit Review → Payroll/Vendor Review → Fraud Controls → Account Structure → Recommendation → Implementation

## KPIs

- deposit balances
- patient payment volume
- merchant volume
- ACH volume
- payroll volume
- treasury fee income
- payment exceptions
- fraud controls adopted
- account analysis revenue
- operating cash

## AI Opportunities

- treasury needs assessment
- patient payment optimization
- account structure recommendation
- fraud control recommendation
- cash forecast
- deposit opportunity detection
- lockbox/receivables recommendation

## Dispatch Truth Statement

Healthcare treasury services connect the institution to the provider's patient, payer, payroll, and vendor cash flows.
