# Real Estate, Facilities & Expansion

## Purpose

This document defines healthcare real estate, lease, facility, and expansion finance.

## Facility Object

Fields:
- facility_id
- practice
- address
- ownership_status
- lease
- square_feet
- exam_rooms
- operatories
- treatment_rooms
- licenses
- occupancy
- buildout
- accessibility
- compliance
- equipment
- landlord
- rent
- expansion_capacity

## Real Estate Products

- Owner-Occupied CRE Loan
- Practice Buildout Loan
- Tenant Improvement Financing
- SBA 504
- Construction-to-Perm
- Acquisition Loan
- Expansion Loan
- Leasehold Improvement Loan
- Sale-Leaseback

## Expansion Types

- additional operatories/exam rooms
- new location
- relocation
- de novo startup
- acquisition of facility
- equipment-driven expansion
- service line expansion
- ASC buildout
- imaging suite
- senior care beds
- pharmacy expansion

## Facility Underwriting Inputs

- location
- demographics
- referral market
- lease terms
- rent burden
- buildout cost
- zoning/use
- permits
- certificate of occupancy
- accessibility requirements
- environmental
- appraisal
- equipment needs
- staffing plan
- ramp-up forecast

## Expansion Risks

- patient volume ramp
- construction delay
- permit issue
- provider hiring
- payer credentialing delay
- equipment installation delay
- rent burden
- working capital shortfall
- marketing gap

## KPIs

- facility count
- revenue per location
- occupancy/utilization
- rent-to-revenue
- buildout budget variance
- ramp-up performance
- patient volume per location
- provider productivity
- DSCR
- expansion ROI

## AI Opportunities

- expansion memo
- demographic summary
- facility risk review
- lease summary
- buildout budget review
- ramp-up forecast
- location performance analysis

## Dispatch Truth Statement

Healthcare real estate finance must underwrite both the physical facility and the patient/reimbursement ramp that makes it profitable.
