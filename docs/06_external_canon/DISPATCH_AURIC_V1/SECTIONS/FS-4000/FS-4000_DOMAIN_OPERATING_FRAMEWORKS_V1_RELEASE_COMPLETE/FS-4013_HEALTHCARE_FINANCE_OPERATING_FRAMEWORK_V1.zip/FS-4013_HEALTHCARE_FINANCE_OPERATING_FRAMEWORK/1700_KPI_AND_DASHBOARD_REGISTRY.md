# KPI & Dashboard Registry

## Relationship KPIs

- healthcare relationships
- deposit balances
- treasury revenue
- loan exposure
- equipment finance volume
- acquisition/buy-in loans
- relationship profitability
- cross-sell ratio
- retention

## Financial KPIs

- revenue
- EBITDA
- EBITDA margin
- gross charges
- net collections
- collection rate
- DSCR
- leverage
- liquidity
- payroll-to-revenue
- rent-to-revenue

## Revenue Cycle KPIs

- AR days
- AR over 90
- denial rate
- clean claim rate
- net collection rate
- days to bill
- days to pay
- write-offs
- patient collections
- payer concentration

## Operating KPIs

- patient visits
- procedures
- new patients
- provider productivity
- schedule utilization
- no-show rate
- revenue per provider
- staffing ratio
- provider turnover
- appointment backlog

## Risk KPIs

- payer concentration
- provider concentration
- license exceptions
- malpractice insurance exceptions
- denial spike
- patient volume decline
- AR deterioration
- staffing shortages
- compliance exceptions
- risk rating migration

## Dashboards

- Healthcare Finance Executive Dashboard
- Practice Relationship Dashboard
- Revenue Cycle Dashboard
- Payer Mix Dashboard
- Provider Productivity Dashboard
- Equipment Dashboard
- Treasury Dashboard
- Acquisition/Buy-In Dashboard
- Compliance Dashboard
- Portfolio Risk Dashboard

## Dispatch Truth Statement

Healthcare finance KPIs must show care volume, reimbursement quality, operating stability, compliance, liquidity, and relationship economics.
