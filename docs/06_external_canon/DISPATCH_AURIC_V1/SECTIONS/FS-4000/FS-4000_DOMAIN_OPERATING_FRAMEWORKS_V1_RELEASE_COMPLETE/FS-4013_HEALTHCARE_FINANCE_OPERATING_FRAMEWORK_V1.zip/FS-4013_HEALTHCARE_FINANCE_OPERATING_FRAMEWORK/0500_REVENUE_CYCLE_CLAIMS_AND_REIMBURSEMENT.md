# Revenue Cycle, Claims & Reimbursement

## Purpose

This document defines revenue cycle management, claims, collections, and reimbursement intelligence.

## Revenue Cycle Object

Fields:
- revenue_cycle_id
- practice
- period
- gross_charges
- net_collections
- contractual_adjustments
- denials
- write_offs
- AR
- AR_days
- payer_mix
- collection_rate
- denial_rate
- clean_claim_rate
- days_to_bill
- days_to_pay
- status

## Claim Object

Fields:
- claim_id
- practice
- patient_reference
- provider
- payer
- service_date
- billed_amount
- allowed_amount
- paid_amount
- denial_status
- denial_reason
- appeal_status
- aging
- status

## Revenue Cycle Stages

Patient Scheduling → Eligibility Verification → Visit/Procedure → Coding → Charge Entry → Claim Submission → Payer Adjudication → Payment Posting → Denial Management → Patient Balance → Collections → Write-Off

## Key Metrics

- gross collection rate
- net collection rate
- clean claim rate
- denial rate
- AR days
- AR over 90
- charge lag
- claim lag
- days to pay
- patient collections
- contractual adjustment rate
- write-off rate

## Denial Categories

- eligibility
- authorization
- coding
- documentation
- medical necessity
- timely filing
- duplicate claim
- coordination of benefits
- credentialing
- payer policy
- missing information

## RCM Workflow

Encounter Data → Coding → Claim Submission → Clearinghouse → Payer Response → Payment/Denial → Appeal → Collections → Reporting

## KPIs

- net collection rate
- denial rate
- AR days
- AR over 90
- clean claim rate
- charge lag
- days to pay
- write-offs
- patient balance collections
- RCM vendor performance

## AI Opportunities

- RCM summary
- denial pattern analysis
- AR aging memo
- payer payment trend
- claims bottleneck detection
- cash forecast
- credit early warning
- RCM vendor review

## Dispatch Truth Statement

In healthcare, accounts receivable quality depends on coding, payer rules, authorization, documentation, and collection discipline.
