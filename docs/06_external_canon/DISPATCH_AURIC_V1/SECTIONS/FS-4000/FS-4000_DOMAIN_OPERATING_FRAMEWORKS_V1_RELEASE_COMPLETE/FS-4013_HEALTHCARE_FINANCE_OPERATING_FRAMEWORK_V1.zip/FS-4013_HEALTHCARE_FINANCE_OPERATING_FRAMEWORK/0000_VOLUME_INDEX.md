# FS-4013 Healthcare Finance Operating Framework

Version: 1.0  
Owner: Auric Works  
Library: Dispatch Institutional Intelligence Library  
Domain: Healthcare Finance / Medical Practice Banking / Provider Operations  
Status: Production Knowledge Volume

## Purpose

This volume defines the canonical Healthcare Finance Operating Framework used by Dispatch OS and the Auric Institutional Intelligence Network.

Healthcare finance is the operating discipline of underwriting, banking, funding, monitoring, and supporting healthcare providers whose repayment capacity depends on patient volume, payer mix, reimbursement, revenue cycle performance, staffing, licensure, compliance, equipment, facilities, claims, referrals, and regulatory stability.

Dispatch operationalizes healthcare finance workflows.  
Auric maps providers, practices, clinics, hospitals, payers, revenue cycle vendors, lenders, credit unions, banks, equipment vendors, EHR systems, owners, physicians, dentists, senior care operators, behavioral health operators, regulators, and market intelligence.

## Strategic Lens

Healthcare finance is not simply lending to doctors or medical businesses.

It is specialized relationship finance where patient care, reimbursement, claims, compliance, staffing, licensing, payer concentration, billing quality, equipment, and facility operations determine financial performance.

For credit unions and community financial institutions, healthcare touches professional practice banking, commercial lending, SBA lending, equipment finance, owner wealth, deposits, treasury, merchant/card payments, payroll, insurance, acquisition finance, partner buy-ins, succession planning, and local healthcare access.

## Volume Contents

1. Healthcare Finance Schema & Object Standard
2. Healthcare Finance Operating Model
3. Market Participants
4. Provider & Practice Relationship Lifecycle
5. Healthcare Business Model
6. Revenue Cycle, Claims & Reimbursement
7. Payers, Contracts & Patient Volume
8. Practice Acquisition, Buy-In & Succession
9. Medical Equipment & CapEx Finance
10. Real Estate, Facilities & Expansion
11. Healthcare Credit Products
12. Treasury, Payments & Deposits
13. Staffing, Payroll & Operating Risk
14. Risk, Compliance & Documentation
15. Technology, EHR, RCM, Data & Connectors
16. Workflow Library
17. Agent Workforce
18. KPI & Dashboard Registry
19. Knowledge Packs & Playbooks
20. Implementation Guide
21. Acceptance Tests & Roadmap

## Completion Standard

This volume is complete when Dispatch can represent a healthcare provider, practice, facility, provider owner, patient volume, payer mix, claim, receivable, revenue cycle, license, equipment asset, practice acquisition, partner buy-in, treasury need, and credit facility as executable institutional objects.
