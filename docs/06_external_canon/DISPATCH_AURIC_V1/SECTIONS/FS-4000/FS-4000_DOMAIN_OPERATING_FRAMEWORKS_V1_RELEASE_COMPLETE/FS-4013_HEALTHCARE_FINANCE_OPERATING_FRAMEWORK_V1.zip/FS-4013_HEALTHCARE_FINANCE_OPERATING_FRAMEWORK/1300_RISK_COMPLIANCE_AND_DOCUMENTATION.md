# Risk, Compliance & Documentation

## Purpose

This document defines healthcare finance risk, compliance, controls, and documentation.

## Risk Domains

- reimbursement risk
- payer concentration
- provider departure
- license risk
- credentialing risk
- revenue cycle risk
- denial risk
- patient volume risk
- staffing risk
- malpractice risk
- compliance risk
- fraud/waste/abuse risk
- equipment risk
- facility risk
- regulatory risk
- cyber/HIPAA risk
- owner succession risk
- goodwill valuation risk

## Compliance Areas

- BSA/KYB
- beneficial ownership
- HIPAA awareness
- licensure
- credentialing
- accreditation
- Medicare/Medicaid participation
- billing compliance
- Stark/Anti-Kickback awareness where relevant
- OSHA awareness
- malpractice insurance
- controlled substances registration where applicable
- privacy and data security
- loan policy
- SBA eligibility where applicable
- records retention
- adverse action where applicable

## Required Documents

- financial statements
- tax returns
- production reports
- payer mix
- AR aging
- denial reports
- provider licenses
- malpractice insurance
- lease
- equipment list
- purchase agreement
- practice valuation
- EHR/RCM reports
- debt schedule
- ownership documents
- credentialing evidence
- compliance certifications where applicable
- insurance certificates
- credit memo
- loan agreement
- security agreement
- guarantees

## Control Object

Fields:
- control_id
- practice
- risk
- requirement
- evidence
- frequency
- owner
- status
- exception
- remediation

## AI Opportunities

- healthcare documentation checklist
- license/insurance tracking
- AR/denial evidence review
- payer mix risk alert
- HIPAA/cyber questionnaire summary
- credit file completeness
- compliance exception memo

## Dispatch Truth Statement

Healthcare finance documentation must prove not just cash flow, but legal authority to deliver care and collect reimbursement.
