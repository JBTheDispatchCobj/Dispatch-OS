# Payers, Contracts & Patient Volume

## Purpose

This document defines payer mix, payer contracts, patient volume, and demand drivers.

## Payer Mix Object

Fields:
- payer_mix_id
- practice
- period
- commercial_percentage
- Medicare_percentage
- Medicaid_percentage
- cash_pay_percentage
- self_pay_percentage
- workers_comp_percentage
- other_percentage
- concentration
- reimbursement_risk

## Payer Contract Object

Fields:
- contract_id
- practice
- payer
- effective_date
- expiration_date
- rates
- covered_services
- authorization_rules
- payment_terms
- denial_rules
- termination_rights
- renewal_status
- profitability
- risk

## Patient Volume Object

Fields:
- volume_id
- practice
- period
- visits
- procedures
- new_patients
- active_patients
- no_shows
- cancellations
- referrals
- provider_days
- capacity
- utilization
- revenue_per_visit
- revenue_per_provider

## Demand Drivers

- population growth
- demographics
- employer base
- referral network
- insurance coverage
- provider reputation
- location
- wait times
- online reviews
- specialist supply
- payer network status
- marketing
- hospital affiliation

## Payer Risk

- reimbursement cut
- contract termination
- authorization burden
- denial increase
- delayed payment
- audit
- payer concentration
- coding dispute
- value-based penalty

## KPIs

- payer concentration
- patient volume
- new patients
- no-show rate
- provider utilization
- revenue per visit
- revenue per provider
- reimbursement rate
- days to pay
- referral volume
- contract renewals

## AI Opportunities

- payer mix risk memo
- patient volume trend
- contract summary
- reimbursement sensitivity
- referral source analysis
- no-show impact
- provider capacity analysis
- payer contract renewal alert

## Dispatch Truth Statement

Patient demand creates activity, but payer contracts convert activity into cash.
