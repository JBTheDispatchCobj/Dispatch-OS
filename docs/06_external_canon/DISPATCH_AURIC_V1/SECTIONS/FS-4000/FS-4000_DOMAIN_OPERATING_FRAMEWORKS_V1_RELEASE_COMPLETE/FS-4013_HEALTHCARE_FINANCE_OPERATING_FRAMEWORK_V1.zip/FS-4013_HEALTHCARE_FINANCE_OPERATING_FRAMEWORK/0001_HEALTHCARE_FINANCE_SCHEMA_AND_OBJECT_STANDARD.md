# Healthcare Finance Schema & Object Standard

## Purpose

This document defines canonical healthcare finance objects used by Dispatch.

## Universal Healthcare Provider Object

Fields:

- provider_business_id
- legal_name
- DBA
- entity_type
- healthcare_segment
- specialty
- ownership
- licensed_providers
- locations
- facilities
- patient_volume
- payer_mix
- revenue
- EBITDA
- gross_collections
- net_collections
- accounts_receivable
- claim_denials
- reimbursement_profile
- staffing
- equipment
- real_estate
- licenses
- certifications
- compliance_status
- technology_stack
- treasury_services
- debt
- risk_rating
- documents
- workflows
- KPIs
- AI_context
- audit_history

## Core Healthcare Finance Objects

- Healthcare Provider Business
- Medical Practice
- Dental Practice
- Behavioral Health Practice
- Physical Therapy Practice
- Veterinary Practice where included by lender policy
- Specialty Clinic
- Ambulatory Surgery Center
- Imaging Center
- Dialysis Center
- Senior Care Operator
- Skilled Nursing Facility
- Assisted Living Facility
- Home Health Agency
- Hospice
- Pharmacy
- Physician Owner
- Dentist Owner
- Provider
- Patient Volume
- Payer
- Payer Contract
- Claim
- Denial
- Accounts Receivable
- Revenue Cycle
- EHR System
- RCM Vendor
- Equipment Asset
- Facility
- License
- Certification
- Practice Acquisition
- Partner Buy-In
- Succession Plan
- Working Capital Line
- Equipment Loan
- SBA Loan
- Owner-Occupied CRE Loan
- Treasury Service

## Healthcare Segments

- Primary Care
- Dental
- Orthodontics
- Oral Surgery
- Dermatology
- Ophthalmology
- Optometry
- Physical Therapy
- Behavioral Health
- Pediatrics
- Women's Health
- Urgent Care
- Imaging
- Surgery Center
- Veterinary
- Pharmacy
- Home Health
- Hospice
- Senior Care
- Skilled Nursing
- Assisted Living
- Specialty Physician Group

## Dispatch Rule

Healthcare finance must connect clinical/provider operations, reimbursement, payer mix, patient volume, revenue cycle, staffing, licensure, compliance, equipment, facilities, owner economics, and credit structure.

## Dispatch Truth Statement

Healthcare finance objects connect care delivery, reimbursement, regulation, staffing, equipment, facilities, and cash flow into one operating graph.
