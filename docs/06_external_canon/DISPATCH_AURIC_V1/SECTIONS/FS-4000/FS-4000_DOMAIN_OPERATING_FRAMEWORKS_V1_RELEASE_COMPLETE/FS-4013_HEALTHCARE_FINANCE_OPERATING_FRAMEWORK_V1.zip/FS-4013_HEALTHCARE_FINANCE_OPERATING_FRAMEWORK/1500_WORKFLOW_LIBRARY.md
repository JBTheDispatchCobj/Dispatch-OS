# Healthcare Finance Workflow Library

## Required Workflows

### Provider Relationship Onboarding

Prospect → Discovery → Practice Profile → Payer/RCM Review → Treasury/Credit Needs → Relationship Plan

### Credit Underwriting

Request → Financials → RCM Analysis → Provider Productivity → Payer Mix → Structure → Memo → Approval

### Practice Acquisition

Target → Valuation → Diligence → Financing → Approval → Closing → Transition Monitoring

### Partner Buy-In

Ownership Terms → Valuation → Provider Review → Financing → Documents → Funding → Monitoring

### Equipment Finance

Need → Vendor Quote → Reimbursement/Revenue Impact → Credit → Documentation → Funding

### Revenue Cycle Monitoring

AR/Claims Data → Denials → Collections → Payer Mix → Risk Alerts → Credit Update

### Treasury Assessment

Payment Flows → Patient/Payer Deposits → Payroll/Vendors → Fraud Controls → Recommendation

### Annual Review

Financials → RCM → Payer Mix → Provider Productivity → Covenants → Risk Rating → Approval

### License / Insurance Monitoring

Requirements → Evidence → Expiration Tracking → Exception → Remediation

### Distressed Practice Review

Early Warning → Liquidity → RCM → Provider/Payer Risk → Workout Strategy → Recovery

## Workflow KPIs

- cycle time
- data completeness
- approval time
- RCM reporting timeliness
- covenant compliance
- license/insurance exceptions
- treasury conversion
- relationship profitability

## Dispatch Truth Statement

Healthcare finance workflows must connect reimbursement, provider productivity, compliance, and credit decisions.
