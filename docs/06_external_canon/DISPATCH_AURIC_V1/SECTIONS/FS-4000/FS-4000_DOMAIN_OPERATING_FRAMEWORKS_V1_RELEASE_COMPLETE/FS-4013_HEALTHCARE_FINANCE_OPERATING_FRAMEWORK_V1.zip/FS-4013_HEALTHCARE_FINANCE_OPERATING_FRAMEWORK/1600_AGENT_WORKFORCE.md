# Healthcare Finance Agent Workforce

## Relationship Agents

- Healthcare Relationship Agent
- Provider Meeting Prep Agent
- Treasury Opportunity Agent
- Equipment Finance Opportunity Agent
- Owner Wealth Trigger Agent
- Succession Opportunity Agent

## Credit Agents

- Healthcare Credit Analyst
- Revenue Cycle Analyst
- Payer Mix Analyst
- Provider Productivity Analyst
- Practice Valuation Agent
- Credit Memo Writer
- Covenant Monitor
- SBA Eligibility Agent

## Operations Agents

- AR Aging Analyst
- Denial Pattern Agent
- RCM Vendor Review Agent
- License Monitor
- Malpractice Insurance Monitor
- Equipment Collateral Agent
- Facility Expansion Analyst

## Treasury Agents

- Payment Flow Agent
- Patient Payment Optimization Agent
- Merchant Services Agent
- Payroll Pressure Agent
- Fraud Controls Agent

## Risk Agents

- Early Warning Agent
- Provider Departure Risk Agent
- Payer Concentration Agent
- Staffing Risk Agent
- Compliance Exception Agent
- Workout Strategy Agent

## Governance

Human approval required for:
- credit approval
- lending recommendations
- covenant waivers
- collateral releases
- practice valuation conclusions
- workout strategy
- compliance determinations
- customer-facing commitments

## Dispatch Truth Statement

Healthcare finance agents translate practice, payer, revenue cycle, provider, treasury, and credit data into lender-ready intelligence.
