# Healthcare Credit Products

## Purpose

This document defines credit products used to finance healthcare providers.

## Credit Products

- Practice Acquisition Loan
- Partner Buy-In Loan
- Equipment Loan
- Equipment Lease
- Working Capital Line
- Revenue Cycle Line
- Owner-Occupied CRE Loan
- SBA 7(a)
- SBA 504
- Buildout Loan
- De Novo Practice Loan
- Expansion Loan
- Practice Refinance
- Goodwill Loan
- Merchant Cash Advance Refinance
- Term Loan
- Line of Credit
- Bridge Loan
- Senior Care Facility Loan
- ASC Financing
- Pharmacy Financing

## Healthcare Loan Object

Fields:
- loan_id
- practice
- provider_owner
- product_type
- amount
- purpose
- repayment_source
- collateral
- guarantees
- pricing
- maturity
- covenants
- payer_mix
- revenue_cycle_requirements
- equipment
- approval
- monitoring

## Structure Inputs

- specialty
- provider productivity
- payer mix
- revenue cycle
- collections
- AR quality
- patient volume
- owner experience
- license/certification
- equipment value
- goodwill
- practice valuation
- guarantor support
- referral sources
- staffing
- compliance status

## Common Covenants

- DSCR
- leverage
- minimum liquidity
- provider employment
- license maintenance
- malpractice insurance
- reporting
- AR aging
- payer concentration
- distributions
- debt restrictions
- change of ownership

## KPIs

- healthcare loan exposure
- funded volume
- portfolio yield
- DSCR
- risk rating
- covenant breaches
- delinquency
- charge-off
- equipment exposure
- acquisition loans
- buy-in loans
- relationship profitability

## AI Opportunities

- credit product recommendation
- acquisition loan memo
- equipment finance memo
- revenue cycle requirement setup
- covenant package
- SBA eligibility checklist
- repayment source summary

## Dispatch Truth Statement

Healthcare credit products must be structured around reimbursement, provider productivity, equipment, goodwill, and practice continuity.
