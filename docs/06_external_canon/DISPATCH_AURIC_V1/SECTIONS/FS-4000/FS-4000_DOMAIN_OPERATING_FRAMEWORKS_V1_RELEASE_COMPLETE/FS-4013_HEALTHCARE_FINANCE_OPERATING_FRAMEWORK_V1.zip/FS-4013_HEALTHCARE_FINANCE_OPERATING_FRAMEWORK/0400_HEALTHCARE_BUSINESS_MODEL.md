# Healthcare Business Model

## Purpose

This document defines healthcare provider operating economics.

## Revenue Models

- Fee-for-Service
- Insurance Reimbursement
- Medicare Reimbursement
- Medicaid Reimbursement
- Cash Pay
- Membership / Subscription
- Concierge
- Capitation
- Value-Based Care
- Procedure-Based Revenue
- Ancillary Services
- Retail Product Sales
- Facility Fees
- Room/Bed Revenue
- Pharmacy Revenue

## Cost Structure

- provider compensation
- clinical staff
- administrative staff
- rent
- equipment
- medical supplies
- lab costs
- malpractice insurance
- billing/RCM
- EHR/software
- marketing
- payroll taxes/benefits
- utilities
- depreciation
- debt service
- compliance/legal
- training

## Margin Drivers

- payer mix
- procedure mix
- provider productivity
- appointment utilization
- collection rate
- denial rate
- staffing ratio
- supply cost
- equipment utilization
- reimbursement rates
- patient no-shows
- coding accuracy
- referral volume

## Operating Metrics

- visits
- procedures
- provider days
- revenue per visit
- revenue per provider
- patients
- new patients
- retention
- schedule utilization
- no-show rate
- gross charges
- net collections
- AR days
- denial rate
- staffing ratio
- EBITDA margin

## Business Model Risks

- payer concentration
- reimbursement cuts
- provider departure
- staffing shortage
- compliance issue
- billing errors
- denials
- malpractice event
- license issue
- referral source loss
- equipment outage
- lease/facility issue
- owner retirement

## AI Opportunities

- business model summary
- payer mix analysis
- procedure mix insight
- revenue per provider analysis
- no-show impact
- reimbursement risk memo
- owner/operator risk profile
- credit memo business section

## Dispatch Truth Statement

Healthcare financial performance is created through a care delivery and reimbursement machine, not through invoices alone.
