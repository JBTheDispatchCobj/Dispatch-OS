# Technology, EHR, RCM, Data & Connectors

## Purpose

This document defines healthcare technology and connector priorities.

## Technology Categories

- EHR
- Practice Management System
- Revenue Cycle Management
- Billing System
- Clearinghouse
- Patient Scheduling
- Patient Portal
- Payment Processor
- Merchant Services
- Accounting System
- Payroll
- CRM
- Document Management
- Credentialing System
- Telehealth Platform
- Equipment Systems
- BI/Data Warehouse
- AI Platform

## Common Systems

Examples:
- Epic
- Cerner / Oracle Health
- Athenahealth
- eClinicalWorks
- NextGen
- Dentrix
- Eaglesoft
- Open Dental
- Curve
- Kareo / Tebra
- AdvancedMD
- DrChrono
- SimplePractice
- TherapyNotes
- ChiroTouch
- QuickBooks
- NetSuite
- Stripe
- Square

## Data Objects

- patient volume
- encounter
- claim
- denial
- payment
- adjustment
- AR aging
- payer
- provider
- schedule
- no-show
- procedure
- equipment
- GL
- payroll
- merchant deposit
- loan
- KPI

## Connector Priorities

Tier 1:
- accounting/GL
- AR aging exports
- RCM reports
- document storage
- email/calendar
- spreadsheet/CSV
- merchant deposits
- AI provider

Tier 2:
- EHR/practice management
- billing system
- clearinghouse
- payroll
- bank core
- LOS
- treasury platform

Tier 3:
- credentialing
- patient scheduling
- patient portal
- BI/data warehouse
- equipment systems
- compliance systems

## Data Quality Rules

- payer must resolve to payer object
- claim must link to payer and service period
- AR must age by payer/patient
- provider productivity must link to provider
- revenue cycle KPIs must reconcile to financials
- equipment must link to collateral
- deposits should reconcile to collections

## AI Opportunities

- RCM report ingestion
- payer mix dashboard
- AR aging analysis
- claim denial categorization
- provider productivity summary
- merchant deposit reconciliation
- connector exception summary

## Dispatch Truth Statement

Healthcare data is operationally valuable only when clinical activity, billing, reimbursement, deposits, and financial statements reconcile.
