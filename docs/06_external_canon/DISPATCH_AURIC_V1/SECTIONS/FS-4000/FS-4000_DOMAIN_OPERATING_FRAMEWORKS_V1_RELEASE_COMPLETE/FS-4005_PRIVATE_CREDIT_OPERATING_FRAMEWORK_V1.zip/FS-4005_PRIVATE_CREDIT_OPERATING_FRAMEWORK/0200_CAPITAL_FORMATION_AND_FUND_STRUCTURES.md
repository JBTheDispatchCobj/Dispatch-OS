# Capital Formation & Fund Structures

## Purpose

This document defines the capital side of private credit.

## Capital Provider Objects

- Limited Partner
- General Partner
- Anchor Investor
- Strategic Investor
- Insurance Company
- Pension
- Endowment
- Foundation
- Family Office
- Credit Union
- Corporate Credit Union
- Bank
- Fund of Funds
- Wealth Platform
- RIA
- High Net Worth Investor
- Sovereign Wealth Fund

## Fund Structures

- Closed-End Fund
- Evergreen Fund
- Interval Fund
- BDC
- SMA
- Co-Investment Vehicle
- SPV
- Sidecar
- Opportunity Fund
- Credit Opportunity Fund
- Direct Lending Fund
- Asset-Based Lending Fund
- Real Estate Credit Fund
- Venture Debt Fund
- Specialty Finance Fund

## Fund Object

Fields:
- fund_id
- fund_name
- strategy
- vintage
- target_size
- committed_capital
- called_capital
- uncalled_capital
- NAV
- leverage
- LPs
- GP
- investment_period
- harvest_period
- management_fee
- carry
- hurdle
- waterfall
- reporting_frequency
- restrictions
- concentration_limits
- permitted_investments

## Capital Call Object

Fields:
- call_id
- fund_id
- LPs
- amount
- purpose
- due_date
- notice_date
- wire_instructions
- funded_status
- allocation
- investment_reference

## Distribution Object

Fields:
- distribution_id
- fund_id
- LPs
- amount
- source
- return_of_capital
- income
- gain
- recallable_status
- waterfall_treatment
- payment_date

## Fund Finance

Objects:
- subscription line
- NAV facility
- warehouse line
- leverage facility
- borrowing base
- covenant
- lender
- collateral pool
- draw
- repayment
- compliance certificate

## LP Reporting

Reports include:
- NAV
- capital account
- contributions
- distributions
- unfunded commitment
- portfolio summary
- risk summary
- realized/unrealized gains
- income
- fees
- expenses
- ESG/impact where applicable
- compliance certifications

## AI Opportunities

- LP report generation
- capital call notice drafting
- fund metrics calculation
- waterfall explanation
- NAV variance commentary
- investor Q&A support
- restriction/compliance monitoring
- concentration alerting

## Dispatch Truth Statement

Private credit begins before the first loan. The capital structure, LP obligations, fund restrictions, leverage, and reporting requirements determine what the platform can originate and how it must operate.
