# Risk, Compliance & Operating Controls

## Purpose

This document defines risk management, compliance, controls, and governance for private credit.

## Risk Domains

- credit risk
- concentration risk
- liquidity risk
- valuation risk
- leverage risk
- counterparty risk
- documentation risk
- collateral risk
- operational risk
- model risk
- regulatory risk
- investor reporting risk
- cyber risk
- vendor risk
- AI risk

## Compliance Domains

- investment restrictions
- fund documents
- side letters
- AML/KYC
- sanctions
- SEC adviser compliance where applicable
- private fund rules where applicable
- valuation policy
- allocation policy
- conflicts policy
- MNPI policy
- code of ethics
- marketing rules
- investor suitability
- custody requirements
- records retention

## Control Object

Fields:
- control_id
- domain
- purpose
- owner
- frequency
- evidence
- test
- exception
- remediation
- related_policy
- related_regulation
- related_workflow

## Key Controls

- investment eligibility
- allocation review
- valuation review
- side letter compliance
- covenant monitoring
- wire approvals
- closing checklist
- KYC/KYB
- sanctions screening
- conflict review
- concentration limits
- leverage limits
- reporting review

## Risk KPIs

- concentration exposures
- covenant breaches
- defaults
- nonaccrual
- valuation exceptions
- side letter exceptions
- late reports
- control failures
- audit findings
- compliance exceptions
- operational losses
- cyber incidents

## AI Opportunities

- side letter obligation extraction
- control evidence collection
- compliance checklist
- conflict detection support
- concentration monitoring
- valuation exception alerts
- policy mapping
- risk dashboard commentary

## Dispatch Truth Statement

Private credit governance requires continuous alignment between fund documents, investor promises, credit decisions, risk limits, reporting, and evidence.
