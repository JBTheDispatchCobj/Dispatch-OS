# Documentation, Closing & Funding

## Purpose

This document defines legal documentation, closing, and funding operations.

## Primary Documents

- Term Sheet
- Commitment Letter
- Credit Agreement
- Loan Agreement
- Promissory Note
- Security Agreement
- Pledge Agreement
- Guaranty
- Intercreditor Agreement
- Subordination Agreement
- Collateral Assignment
- Control Agreement
- UCC Filing
- Mortgage/Deed of Trust
- Legal Opinion
- Officer Certificate
- Board Consent
- Closing Checklist
- Funding Notice
- Wire Instructions
- Closing Binder

## Closing Checklist Object

Fields:
- checklist_id
- deal
- required_items
- owner
- status
- condition_precedent
- responsible_party
- evidence
- legal_signoff
- funding_signoff
- exceptions
- closing_date

## Conditions Precedent

- executed documents
- lien perfection
- insurance
- legal opinions
- KYC/KYB
- authority documents
- organizational documents
- collateral evidence
- payoff letters
- third-party consents
- equity contribution
- financial statements
- compliance certificates
- borrowing base certificate

## Funding Workflow

Final Approval → Closing Checklist → Legal Sign-Off → Operations Review → Wire Verification → Funding Authorization → Wire Release → Confirmation → Boarding → Post-Close Audit

## Funding Risk

- wire fraud
- missing CP
- incorrect amount
- lien not perfected
- intercreditor issue
- authority defect
- KYC/KYB gap
- collateral exception
- insurance gap
- document execution error

## AI Opportunities

- closing checklist management
- document comparison
- missing CP detection
- wire verification checklist
- closing binder index
- post-close exception summary
- legal issue tracker
- funding memo drafting

## Dispatch Truth Statement

Closing is a controlled risk event. Dispatch must connect legal documents, approvals, collateral, funding, authority, and evidence before capital moves.
