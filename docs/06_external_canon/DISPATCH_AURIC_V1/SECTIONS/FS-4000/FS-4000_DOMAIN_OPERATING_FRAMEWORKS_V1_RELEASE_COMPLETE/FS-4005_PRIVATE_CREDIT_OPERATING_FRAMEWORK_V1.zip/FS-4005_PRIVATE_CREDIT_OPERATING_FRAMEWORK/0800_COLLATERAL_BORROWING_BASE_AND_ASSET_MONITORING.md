# Collateral, Borrowing Base & Asset Monitoring

## Purpose

This document defines collateral monitoring and borrowing base operations.

## Collateral Types

- Accounts Receivable
- Inventory
- Equipment
- Real Estate
- Cash
- Securities
- Intellectual Property
- Contracts
- Licenses
- Vehicles
- Aircraft
- Marine Assets
- Consumer Loans
- Commercial Loans
- Mortgage Loans
- Receivables Pool
- Future Cash Flows
- Equity Interests
- Personal Guarantees
- Corporate Guarantees

## Collateral Object

Fields:
- collateral_id
- type
- owner
- borrower
- facility
- valuation
- valuation_date
- advance_rate
- eligible_amount
- ineligible_amount
- lien_status
- perfection
- monitoring_frequency
- audit_status
- insurance
- concentration
- aging
- exception_status

## Borrowing Base Object

Fields:
- borrowing_base_id
- facility
- report_date
- gross_collateral
- ineligibles
- eligible_collateral
- advance_rate
- availability
- outstanding_balance
- excess_availability
- reserves
- covenant_status
- certification

## Ineligible Criteria

- aged receivables
- cross-aged accounts
- affiliate receivables
- foreign receivables
- disputed receivables
- contra accounts
- slow-moving inventory
- obsolete inventory
- uninsured collateral
- unperfected collateral
- concentration over limit

## Monitoring Workflow

Report Request → Borrower Submission → Data Validation → Ineligibles → Advance Calculation → Availability → Exception Review → Approval → Update Dashboard

## Collateral KPIs

- eligible collateral
- excess availability
- utilization
- ineligible percentage
- concentration
- aging trend
- audit exceptions
- field exam findings
- collateral value change
- borrowing base errors

## AI Opportunities

- borrowing base review
- ineligible detection
- AR aging summary
- inventory trend analysis
- collateral exception alert
- field exam summary
- concentration monitoring
- availability forecast

## Dispatch Truth Statement

Collateral is not a static security interest. It is a dynamic source of repayment requiring continuous monitoring, eligibility testing, valuation, and evidence.
