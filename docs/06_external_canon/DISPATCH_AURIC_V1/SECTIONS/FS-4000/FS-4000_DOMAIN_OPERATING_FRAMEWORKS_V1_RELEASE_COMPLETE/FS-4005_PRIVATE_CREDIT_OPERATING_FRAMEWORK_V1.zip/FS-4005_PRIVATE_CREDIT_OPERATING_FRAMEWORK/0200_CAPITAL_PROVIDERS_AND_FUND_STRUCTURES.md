# Capital Providers & Fund Structures

## Purpose

This document defines private credit capital providers, vehicles, structures, and investor obligations.

## Capital Provider Types

- Credit Fund
- Private Credit Fund
- Business Development Company
- Family Office
- Insurance Company
- Pension
- Endowment
- Foundation
- Credit Union
- Corporate Credit Union
- Bank
- RIA Platform
- Wealth Platform
- Institutional Investor
- Sovereign Wealth Fund
- Fund of Funds
- Managed Account
- Strategic Investor
- High Net Worth Investor

## Fund Structure Objects

- Fund
- Master Fund
- Feeder Fund
- Parallel Fund
- SPV
- Series LLC
- Managed Account
- Co-Investment Vehicle
- BDC
- Interval Fund
- Evergreen Fund
- Closed-End Fund
- Open-End Fund
- Holding Company
- Management Company
- General Partner
- Investment Adviser
- Administrator
- Custodian
- Auditor
- Tax Advisor
- Legal Counsel

## Fund Object Fields

- fund_id
- name
- strategy
- vintage
- legal_structure
- manager
- GP
- LPs
- commitments
- called_capital
- uncalled_capital
- NAV
- leverage
- target_return
- preferred_return
- management_fee
- incentive_fee
- carry
- investment_period
- harvest_period
- reporting_frequency
- restrictions
- eligible_assets
- concentration_limits
- leverage_limits
- liquidity_terms

## Investor Object Fields

- investor_id
- investor_type
- commitment
- capital_called
- capital_remaining
- distributions
- NAV
- IRR
- MOIC
- side_letter
- reporting_needs
- restrictions
- accreditation
- qualified_purchaser_status
- AML/KYC_status
- contacts
- portal_access

## Fund Lifecycle

Strategy → Formation → Fundraising → First Close → Investment Period → Portfolio Construction → Monitoring → Harvest → Wind Down → Liquidation → Archive

## Capital Call Workflow

Need → Allocation → Notice → LP Review → Wire → Receipt → Allocation → GL Posting → Investor Reporting → Archive

## Distribution Workflow

Cash Available → Waterfall Calculation → Approval → Notice → Wire → GL Posting → Investor Statement → Archive

## Fund KPIs

- commitments
- capital called
- uncalled capital
- NAV
- portfolio yield
- gross IRR
- net IRR
- MOIC
- DPI
- RVPI
- TVPI
- leverage
- default rate
- nonaccrual rate
- investor reporting timeliness
- concentration limits

## AI Opportunities

- LP reporting drafts
- capital call notices
- distribution summaries
- side letter compliance
- fund performance commentary
- investor Q&A prep
- concentration monitoring
- fund liquidity forecast

## Dispatch Truth Statement

Private credit capital is not anonymous funding. It carries mandates, obligations, reporting requirements, liquidity expectations, restrictions, and relationship context.
