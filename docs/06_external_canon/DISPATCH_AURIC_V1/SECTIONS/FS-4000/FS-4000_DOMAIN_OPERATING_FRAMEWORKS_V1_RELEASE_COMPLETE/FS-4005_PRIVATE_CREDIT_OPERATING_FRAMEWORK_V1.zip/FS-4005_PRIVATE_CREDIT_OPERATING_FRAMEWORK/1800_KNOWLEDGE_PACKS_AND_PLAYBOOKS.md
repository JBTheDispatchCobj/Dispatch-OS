# Knowledge Packs & Playbooks

## Required Knowledge Packs

### Private Credit Foundation Pack

- terminology
- strategies
- facility types
- lifecycle
- roles
- fund structures
- documents
- KPIs

### Direct Lending Pack

- cash flow lending
- sponsor lending
- unitranche
- first lien
- second lien
- mezzanine
- underwriting

### Asset-Based Lending Pack

- borrowing base
- eligible collateral
- field exams
- inventory
- AR
- reserves
- advance rates

### Fund Finance Pack

- subscription lines
- NAV facilities
- warehouse
- borrowing bases
- LP restrictions

### Portfolio Monitoring Pack

- reporting
- covenants
- risk ratings
- valuation
- watchlist
- LP reporting

### Workout Pack

- amendments
- waivers
- forbearance
- restructuring
- liquidation
- recovery

## Playbooks

- Deal Screening Playbook
- Sponsor Relationship Playbook
- Diligence Request Playbook
- IC Memo Playbook
- Term Sheet Playbook
- Closing Checklist Playbook
- Covenant Monitoring Playbook
- Portfolio Review Playbook
- Valuation Review Playbook
- Workout Strategy Playbook
- LP Reporting Playbook
- Warehouse Monitoring Playbook

## Dispatch Truth Statement

Private credit knowledge packs convert institutional credit experience into repeatable, auditable execution.
