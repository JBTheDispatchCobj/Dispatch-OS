# Acceptance Tests & Roadmap

## Object Tests

- Can create Private Credit Fund.
- Can create LP and GP.
- Can create Sponsor.
- Can create Borrower.
- Can create Deal.
- Can create Facility.
- Can create Term Sheet.
- Can create IC Memo.
- Can create Covenant.
- Can create Collateral.
- Can create Borrowing Base.
- Can create Valuation.
- Can create LP Report.
- Can create Workout Plan.

## Relationship Tests

- LP COMMITS_TO Fund.
- GP MANAGES Fund.
- Fund INVESTS_IN Facility.
- Sponsor OWNS Borrower.
- Facility LENDS_TO Borrower.
- Collateral SECURES Facility.
- Covenant GOVERNS Facility.
- IC APPROVES Deal.
- Report SUPPORTS Valuation.
- Workout Plan RESPONDS_TO Default.

## Workflow Tests

- Origination workflow produces screened opportunity.
- Underwriting workflow produces diligence tracker and IC memo.
- IC workflow records approval conditions.
- Closing workflow validates CP checklist.
- Covenant workflow detects breach.
- Portfolio workflow updates risk rating.
- Valuation workflow generates mark support.
- LP reporting workflow creates report package.
- Workout workflow creates action plan.

## Agent Tests

- Opportunity Screener scores deal.
- IC Memo Writer drafts memo.
- Financial Spreading Agent extracts metrics.
- Covenant Monitor tests covenant.
- Portfolio Monitor flags deterioration.
- Valuation Agent drafts support.
- LP Reporting Agent drafts commentary.
- Workout Agent proposes options.

## Roadmap

Priority 1:
- object registry
- fixture fund
- fixture borrower
- fixture deal
- IC memo template
- covenant testing engine

Priority 2:
- LP reporting package
- valuation workflow
- portfolio dashboard
- watchlist dashboard
- data room ingestion

Priority 3:
- warehouse module
- ABL borrowing base engine
- fund finance module
- secondary sale module
- restructuring module

## Dispatch Truth Statement

The Private Credit cartridge is accepted when Dispatch can manage capital, deals, diligence, documents, risk, monitoring, valuation, reporting, and workout as one governed investment operating system.
