# Underwriting & Due Diligence

## Purpose

This document defines private credit underwriting and diligence.

## Underwriting Domains

- Business
- Financial
- Credit
- Collateral
- Sponsor
- Management
- Industry
- Legal
- Tax
- Insurance
- Technology
- Cybersecurity
- Operations
- Environmental
- Regulatory
- Exit
- Downside Case

## Borrower Object

Fields:
- borrower_id
- legal_name
- ownership
- sponsor
- industry
- business_model
- products
- customers
- suppliers
- management
- revenue
- EBITDA
- cash_flow
- working_capital
- debt
- liquidity
- assets
- technology_stack
- legal_entities
- risk_rating

## Diligence Request List

Categories:
- corporate documents
- financial statements
- tax returns
- debt schedule
- customer concentration
- supplier concentration
- contracts
- insurance
- litigation
- compliance
- collateral documents
- management bios
- quality of earnings
- budget/forecast
- technology systems
- cyber/security
- environmental
- real estate
- permits/licenses

## Financial Analysis

Dispatch should capture:
- revenue trends
- margin trends
- EBITDA
- adjustments
- working capital
- cash conversion
- capex
- free cash flow
- debt service
- liquidity
- leverage
- fixed charge coverage
- covenant cushion
- seasonality
- forecast assumptions

## Due Diligence Finding Object

Fields:
- finding_id
- category
- description
- severity
- owner
- evidence
- risk
- mitigant
- open_question
- resolution
- impact_on_terms
- investment_committee_visibility

## Underwriting Outputs

- investment committee memo
- credit model
- diligence tracker
- risk matrix
- term recommendation
- downside analysis
- collateral summary
- covenant package
- conditions precedent
- monitoring plan

## AI Opportunities

- data room summarization
- diligence request generation
- financial statement spreading
- QoE summary
- risk matrix drafting
- open item tracking
- management meeting prep
- downside case narrative
- investment memo drafting

## Dispatch Truth Statement

Private credit underwriting is evidence assembly plus judgment. Dispatch must preserve every source, assumption, risk, mitigant, and decision path.
