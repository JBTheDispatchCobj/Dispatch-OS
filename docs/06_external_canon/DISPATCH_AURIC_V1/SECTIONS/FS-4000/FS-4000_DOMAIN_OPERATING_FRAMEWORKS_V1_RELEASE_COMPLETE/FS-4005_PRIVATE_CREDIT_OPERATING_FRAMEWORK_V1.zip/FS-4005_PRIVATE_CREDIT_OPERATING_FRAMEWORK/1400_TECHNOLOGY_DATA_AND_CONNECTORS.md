# Technology, Data & Connectors

## Purpose

This document defines private credit technology and data infrastructure.

## Systems

- CRM
- Deal Pipeline
- Data Room
- Document Management
- Portfolio Monitoring
- Loan Servicing
- Fund Accounting
- Investor Portal
- Fund Administration
- Valuation Platform
- Credit Spreading
- Data Warehouse
- BI
- Workflow Platform
- Email/Calendar
- E-Signature
- Compliance Platform
- AI Platform

## Data Objects

- deal
- sponsor
- borrower
- financial statements
- credit model
- diligence findings
- term sheet
- IC memo
- credit agreement
- facility
- collateral
- covenant
- monthly report
- valuation
- LP report
- capital call
- distribution
- compliance certificate

## Connector Priorities

Tier 1:
- email/calendar
- document storage
- Excel/CSV
- data room
- CRM
- AI provider

Tier 2:
- portfolio monitoring
- fund accounting
- investor portal
- e-signature
- loan servicing
- BI/data warehouse

Tier 3:
- valuation provider
- compliance platform
- KYC provider
- sanctions screening
- collateral data feeds
- market data

## Data Quality Rules

- borrower identity must be canonical
- sponsor relationships must be linked
- facility terms must match documents
- covenants must link to evidence
- reports must preserve source lineage
- valuation marks must preserve assumptions
- capital calls must link to LPs and investments

## AI Opportunities

- data room indexing
- credit model extraction
- borrower profile generation
- sponsor graph enrichment
- report ingestion
- covenant calculation
- portfolio dashboard commentary
- LP Q&A support

## Dispatch Truth Statement

Private credit data is typically trapped in email, Excel, PDFs, data rooms, and fund systems. Dispatch converts it into a governed credit operating graph.
