# FS-4005 Private Credit Operating Framework

Version: 1.0  
Owner: Auric Works  
Library: Dispatch Institutional Intelligence Library  
Domain: Private Credit / Direct Lending / Structured Credit  
Status: Production Knowledge Volume

## Purpose

This volume defines the canonical Private Credit Operating Framework used by Dispatch OS and the Auric Institutional Intelligence Network.

Private credit is not simply lending outside banks. It is an institutional operating model for originating, underwriting, structuring, funding, monitoring, managing, restructuring, and exiting credit exposure in privately negotiated markets.

Dispatch operationalizes private credit execution.  
Auric maps the institutional, sponsor, borrower, lender, investor, and market intelligence around it.

## Scope

This volume covers:

- private credit operating model
- fund and lender structures
- capital sources
- origination
- sponsor relationships
- borrower analysis
- underwriting
- deal structuring
- documentation
- collateral
- covenants
- portfolio monitoring
- special situations
- workouts
- warehouse facilities
- NAV facilities
- asset-backed lending
- direct lending
- lender finance
- private credit technology stack
- risk and compliance
- KPIs
- AI agents
- workflows
- playbooks
- connectors
- implementation guide
- acceptance tests

## Strategic Lens

Private credit is institutional ownership of credit outcomes.

The lender is not only betting on repayment. The lender is monitoring operations, collateral, liquidity, sponsor behavior, capital structure, and exit optionality over time.

## Completion Standard

This volume is complete when Dispatch can represent a private credit platform from LP commitments through deal origination, underwriting, investment committee, funding, portfolio monitoring, covenant compliance, workout, refinancing, sale, and reporting.
