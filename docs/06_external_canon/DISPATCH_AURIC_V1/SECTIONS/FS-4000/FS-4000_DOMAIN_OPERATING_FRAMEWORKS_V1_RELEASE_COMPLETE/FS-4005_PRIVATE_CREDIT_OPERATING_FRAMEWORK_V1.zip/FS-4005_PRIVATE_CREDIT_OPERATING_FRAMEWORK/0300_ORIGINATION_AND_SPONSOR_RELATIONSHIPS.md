# Origination & Sponsor Relationships

## Purpose

This document defines private credit origination and relationship intelligence.

## Origination Sources

- Private Equity Sponsors
- Independent Sponsors
- Family Offices
- Investment Banks
- Business Brokers
- Commercial Banks
- Credit Unions
- Corporate Credit Unions
- Advisors
- Lawyers
- Accountants
- Real Estate Sponsors
- Developers
- FinTech Platforms
- Specialty Finance Platforms
- Direct Borrowers
- Existing Portfolio Companies
- LP Referrals
- Executive Network
- Market Intelligence Signals

## Sponsor Object

Fields:
- sponsor_id
- sponsor_name
- type
- funds
- AUM
- strategy
- sectors
- geography
- track_record
- realized_exits
- current_portfolio
- historical_borrowings
- default_history
- relationship_owner
- reputation_score
- execution_score
- reporting_quality
- responsiveness
- alignment_score
- relationship_strength

## Opportunity Object

Fields:
- opportunity_id
- source
- sponsor
- borrower
- industry
- transaction_type
- requested_amount
- use_of_proceeds
- target_return
- collateral
- initial_structure
- deadline
- competitive_process
- probability
- fit_score
- status
- next_action

## Origination Lifecycle

Relationship Mapping → Market Coverage → Opportunity Discovery → Initial Conversation → NDA → Teaser Review → Screening → Management Call → Term Sheet Decision → Underwriting

## Deal Screening Criteria

- strategy fit
- borrower quality
- sponsor quality
- size
- return
- collateral
- downside protection
- sector
- leverage
- cash flow
- execution timing
- competitive intensity
- documentation complexity
- monitoring burden
- exit clarity

## Relationship KPIs

- opportunities by source
- conversion rate
- sponsor repeat activity
- average response time
- term sheets issued
- win rate
- deals closed
- realized performance by source
- default rate by sponsor
- relationship profitability
- relationship strength

## AI Opportunities

- sponsor profile generation
- market mapping
- opportunity scoring
- teaser summary
- deal fit assessment
- relationship history briefing
- sponsor reputation analysis
- referral path discovery
- outreach drafting
- competitive process summary

## Dispatch Truth Statement

Origination is not lead generation. It is relationship intelligence applied to capital deployment.
