# KPI & Dashboard Registry

## Fund KPIs

- committed capital
- called capital
- uncalled capital
- NAV
- distributions
- DPI
- RVPI
- TVPI
- IRR
- MOIC
- management fees
- expenses
- leverage
- liquidity

## Origination KPIs

- opportunities sourced
- source conversion
- term sheets issued
- win rate
- deals closed
- average spread
- average size
- sponsor repeat rate
- declined reasons

## Credit KPIs

- portfolio yield
- weighted average spread
- weighted average risk rating
- LTV
- leverage
- DSCR
- covenant cushion
- default rate
- nonaccrual
- watchlist
- realized losses
- recovery rate

## Monitoring KPIs

- reporting timeliness
- covenant breach rate
- waiver count
- risk migration
- valuation changes
- collateral coverage
- liquidity
- borrower EBITDA trend
- portfolio concentration

## Operations KPIs

- underwriting cycle time
- IC approval time
- closing time
- reporting cycle time
- capital call timeliness
- LP report timeliness
- data completeness
- agent utilization

## Dashboards

- GP Executive Dashboard
- Origination Dashboard
- Underwriting Dashboard
- IC Dashboard
- Portfolio Dashboard
- Risk Dashboard
- Watchlist Dashboard
- Valuation Dashboard
- LP Reporting Dashboard
- Warehouse Dashboard

## Dispatch Truth Statement

Private credit KPIs must connect capital formation, origination, credit risk, portfolio performance, operations, and investor reporting.
