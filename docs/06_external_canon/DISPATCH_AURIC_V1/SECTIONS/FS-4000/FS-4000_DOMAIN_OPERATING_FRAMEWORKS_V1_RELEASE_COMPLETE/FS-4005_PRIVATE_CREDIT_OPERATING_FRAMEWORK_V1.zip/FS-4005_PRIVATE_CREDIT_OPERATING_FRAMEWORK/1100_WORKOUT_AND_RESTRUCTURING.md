# Workout & Restructuring

## Purpose

This document defines workout, restructuring, forbearance, recovery, and exit operations.

## Workout Lifecycle

Early Warning → Watchlist → Default → Reservation of Rights → Forbearance → Restructuring → Recovery Plan → Execution → Exit → Lessons Learned

## Workout Object

Fields:
- workout_id
- borrower
- facility
- default_type
- trigger
- collateral
- sponsor_support
- liquidity
- recovery_estimate
- strategy
- action_plan
- legal_counsel
- milestones
- approvals
- status
- outcome

## Default Types

- payment default
- covenant default
- reporting default
- bankruptcy
- insolvency
- cross-default
- collateral impairment
- change of control
- fraud
- judgment/lien
- material adverse change
- management abandonment

## Restructuring Tools

- waiver
- amendment
- maturity extension
- amortization relief
- payment deferral
- PIK interest
- additional collateral
- additional guaranty
- equity cure
- sponsor support
- new money
- collateral sale
- asset sale
- refinancing
- recapitalization
- bankruptcy sale
- liquidation

## Recovery Analysis

Inputs:
- collateral value
- liquidation timeline
- senior liens
- legal costs
- operating losses
- sponsor support
- borrower cooperation
- market value
- buyer universe
- bankruptcy risk
- enforcement rights

## Workout KPIs

- watchlist count
- default count
- recovery rate
- time in workout
- amendment count
- waiver count
- liquidation value
- legal spend
- charge-off
- realized loss
- sponsor support obtained
- successful refinance

## AI Opportunities

- default summary
- forbearance checklist
- recovery scenario
- collateral liquidation analysis
- legal timeline tracker
- borrower communication draft
- workout committee memo
- lessons learned extraction

## Dispatch Truth Statement

Workout is not failure management. It is the disciplined execution of downside protection, recovery strategy, institutional learning, and capital preservation.
