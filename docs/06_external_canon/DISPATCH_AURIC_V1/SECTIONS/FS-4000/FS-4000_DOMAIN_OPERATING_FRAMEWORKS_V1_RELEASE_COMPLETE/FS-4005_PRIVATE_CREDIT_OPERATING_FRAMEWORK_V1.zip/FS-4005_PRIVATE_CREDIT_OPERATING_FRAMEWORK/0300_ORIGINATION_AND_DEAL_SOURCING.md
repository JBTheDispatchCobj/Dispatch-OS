# Origination & Deal Sourcing

## Purpose

This document defines how private credit opportunities are discovered, qualified, tracked, and converted into underwritten transactions.

## Origination Sources

- Private Equity Sponsors
- Independent Sponsors
- Borrowers
- Investment Banks
- Business Brokers
- Commercial Banks
- Credit Unions
- Corporate Credit Unions
- Family Offices
- Attorneys
- CPAs
- Consultants
- Real Estate Brokers
- Developers
- Turnaround Advisors
- Marketplaces
- Vendor Ecosystems
- Existing Portfolio Companies
- Relationship Referrals
- Auric Intelligence Network

## Deal Object

Fields:

- deal_id
- source
- source_contact
- borrower
- sponsor
- industry
- geography
- requested_amount
- facility_type
- use_of_proceeds
- EBITDA
- revenue
- collateral
- leverage
- timing
- competitive_process
- mandate_fit
- screening_status
- underwriting_status
- probability
- next_action
- relationship_context

## Origination Lifecycle

Source Identified → Intro → NDA → Teaser Review → Screening → Initial Call → Data Request → Term Sheet → Diligence → Credit Committee → Closing

## Screening Framework

- borrower size
- industry fit
- EBITDA
- revenue quality
- sponsor quality
- leverage
- collateral
- cash flow
- use of proceeds
- transaction timing
- pricing expectations
- covenant expectations
- exit source
- mandate eligibility
- relationship value

## Deal Source Scoring

Inputs:
- historic close rate
- referral quality
- sponsor reputation
- fit with mandate
- speed to close
- repeat relationship
- information quality
- pricing discipline
- deal exclusivity
- strategic value

## Origination KPIs

- deals sourced
- qualified deals
- NDAs signed
- IOIs/term sheets issued
- term sheets accepted
- deals closed
- conversion rate
- source quality
- average spread
- average leverage
- time to close
- relationship source ROI

## AI Opportunities

- deal teaser summary
- mandate fit scoring
- source relationship mapping
- comparable deal search
- preliminary risk screen
- initial questions list
- term sheet draft
- follow-up email drafting
- pipeline prioritization
- source performance analysis

## Dispatch Truth Statement

Origination is not lead generation. It is relationship intelligence applied to capital deployment.
