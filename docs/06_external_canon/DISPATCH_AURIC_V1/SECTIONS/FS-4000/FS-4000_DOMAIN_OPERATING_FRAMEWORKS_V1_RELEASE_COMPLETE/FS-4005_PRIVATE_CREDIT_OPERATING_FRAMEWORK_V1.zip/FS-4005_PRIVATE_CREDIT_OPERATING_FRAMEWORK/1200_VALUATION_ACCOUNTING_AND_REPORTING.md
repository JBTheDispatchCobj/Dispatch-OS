# Valuation, Accounting & Reporting

## Purpose

This document defines private credit valuation, accounting, and reporting operations.

## Valuation Object

Fields:
- valuation_id
- investment
- valuation_date
- method
- fair_value
- cost
- unrealized_gain_loss
- risk_rating
- market_spread
- borrower_performance
- comparable_data
- discount_rate
- committee_approval
- audit_support

## Valuation Methods

- cost
- fair value
- discounted cash flow
- yield analysis
- market comparables
- recovery analysis
- collateral value
- broker quote
- third-party valuation
- internal mark

## Accounting Objects

- investment
- accrual
- interest income
- fee income
- PIK interest
- OID amortization
- unrealized gain/loss
- realized gain/loss
- impairment
- nonaccrual
- charge-off
- recovery
- distribution
- expense
- management fee
- carry

## Reporting Packages

- LP report
- fund financials
- portfolio summary
- valuation package
- capital account statement
- compliance certificate
- lender report
- board report
- investment committee update
- audit package

## Reporting KPIs

- NAV
- yield
- income
- fair value change
- risk rating distribution
- nonaccrual
- defaults
- realized losses
- unrealized gains/losses
- distributions
- coverage ratios
- fund expenses
- management fees

## AI Opportunities

- valuation memo drafting
- portfolio commentary
- variance explanation
- LP report generation
- audit support package
- nonaccrual analysis
- fair value change explanation
- fund metric calculation

## Dispatch Truth Statement

Private credit reporting is the institutional translation of borrower performance into investor trust.
