# Borrower & Sponsor Analysis

## Purpose

This document defines borrower, sponsor, management, business model, and operating diligence.

## Borrower Object

Fields:

- borrower_id
- legal_name
- entity_type
- industry
- NAICS
- revenue
- EBITDA
- gross_margin
- customers
- suppliers
- employees
- locations
- ownership
- management_team
- debt_schedule
- liquidity
- working_capital
- collateral
- technology_stack
- vendor_stack
- litigation
- insurance
- tax_status
- risk_rating
- operational_maturity
- AI_readiness

## Sponsor Object

Fields:

- sponsor_id
- sponsor_type
- AUM
- funds
- portfolio_companies
- track_record
- realized_returns
- unrealized_returns
- operating_partners
- reputation
- liquidity
- equity_commitment
- relationship_history
- prior_defaults
- support_history
- governance_rights
- board_seats

## Management Assessment

Dispatch tracks:

- CEO capability
- CFO capability
- controller maturity
- sales leadership
- operations leadership
- industry experience
- turnover
- succession risk
- reporting discipline
- lender communication quality
- sponsor alignment
- execution score

## Business Model Analysis

- revenue streams
- recurring revenue
- customer concentration
- supplier concentration
- gross margin
- fixed/variable cost structure
- working capital cycle
- CapEx needs
- seasonality
- cyclicality
- pricing power
- competitive position
- barriers to entry
- operational bottlenecks
- technology dependency

## Sponsor Support Analysis

- equity contribution
- unfunded support capacity
- track record in distress
- reporting responsiveness
- operating resources
- governance discipline
- reputation with lenders
- exit history
- willingness to support portfolio company

## AI Opportunities

- borrower summary
- sponsor track record summary
- management strengths/weaknesses
- customer concentration analysis
- supplier risk summary
- business model risk detection
- diligence question generation
- lender meeting prep
- sponsor relationship mapping

## Dispatch Truth Statement

A borrower is not a credit statistic. It is an operating company whose people, processes, customers, suppliers, systems, capital, and sponsor behavior determine repayment.
