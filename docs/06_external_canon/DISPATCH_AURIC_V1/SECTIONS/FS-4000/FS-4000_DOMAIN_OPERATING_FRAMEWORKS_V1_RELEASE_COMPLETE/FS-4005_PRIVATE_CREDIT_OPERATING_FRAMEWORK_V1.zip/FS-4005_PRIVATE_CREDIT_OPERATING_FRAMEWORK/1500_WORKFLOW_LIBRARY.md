# Private Credit Workflow Library

## Required Workflows

### Origination Workflow

Relationship → Opportunity → Teaser → Screening → NDA → Management Call → Term Sheet Decision

### Screening Workflow

Opportunity Intake → Strategy Fit → Risk Review → Return Estimate → Sponsor Review → Go/No-Go

### Underwriting Workflow

Diligence Request → Data Room Review → Financial Analysis → Risk Matrix → Structure → IC Memo

### Investment Committee Workflow

Memo → Pre-Read → Meeting → Questions → Vote → Conditions → Approval Archive

### Closing Workflow

Final Terms → Legal Documentation → CP Checklist → Wire Verification → Funding → Closing Binder

### Borrowing Base Workflow

Asset Tape → Eligibility → Haircuts → Availability → Draw → Reporting

### Covenant Monitoring Workflow

Report Due → Evidence Received → Calculation → Pass/Fail → Waiver/Escalation → Dashboard

### Portfolio Review Workflow

Monthly Reports → Spreading → Risk Rating → Valuation → Watchlist → Investor Reporting

### Workout Workflow

Early Warning → Default → Options Memo → Forbearance/Amendment → Recovery Plan → Exit

### LP Reporting Workflow

Portfolio Data → Valuation → Metrics → Commentary → Review → Distribution → Archive

## Workflow KPIs

- cycle time
- approval time
- diligence completion
- closing delay
- reporting timeliness
- covenant exceptions
- valuation completion
- investor report delivery
- workflow automation percentage

## Dispatch Truth Statement

Private credit workflows coordinate capital, diligence, documentation, monitoring, and investor trust.
