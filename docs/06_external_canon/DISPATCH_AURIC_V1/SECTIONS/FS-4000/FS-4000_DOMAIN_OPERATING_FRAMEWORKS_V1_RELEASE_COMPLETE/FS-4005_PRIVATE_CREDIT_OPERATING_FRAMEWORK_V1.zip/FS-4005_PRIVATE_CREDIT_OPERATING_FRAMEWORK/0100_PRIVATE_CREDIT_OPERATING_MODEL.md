# Private Credit Operating Model

## Definition

Private credit is privately negotiated credit capital provided to borrowers, sponsors, funds, or asset pools outside traditional broadly syndicated or public credit channels.

## Operating Layers

### 1. Capital Formation

LP commitments, fund structures, separately managed accounts, warehouse lines, leverage facilities, and co-investment vehicles create capital availability.

### 2. Origination

Relationships with sponsors, intermediaries, banks, brokers, borrowers, advisors, and platforms produce investment opportunities.

### 3. Screening

Initial review tests strategy fit, borrower quality, sponsor quality, structure, collateral, return, risk, and execution probability.

### 4. Underwriting

Deep diligence evaluates business model, financials, cash flow, collateral, management, industry, legal structure, technology, operations, and exit.

### 5. Structuring

Terms allocate risk through seniority, collateral, covenants, pricing, amortization, fees, guarantees, reporting, reserves, controls, and intercreditor rights.

### 6. Investment Committee

Governed approval process reviews recommendation, risks, mitigants, returns, downside cases, documentation, conditions, and authority.

### 7. Closing & Funding

Legal documentation, collateral perfection, conditions precedent, funding mechanics, escrow, wires, and closing binders complete execution.

### 8. Portfolio Monitoring

Monthly/quarterly reporting, covenant testing, financial analysis, collateral tracking, risk rating, valuation, and board/investor reporting.

### 9. Workout / Special Situations

When deterioration occurs, actions include waiver, amendment, forbearance, restructuring, collateral sale, sponsor support, recapitalization, refinancing, or enforcement.

### 10. Exit

Loan payoff, refinancing, sale, securitization, participation, secondary sale, restructuring exit, maturity, or liquidation.

## Private Credit Departments

- Origination
- Underwriting
- Portfolio Management
- Investment Committee
- Credit Risk
- Legal
- Operations
- Fund Finance
- Investor Relations
- Valuation
- Compliance
- Accounting
- Loan Servicing
- Special Assets
- Treasury
- Data & Analytics
- Technology
- AI Operations

## Operating Cadence

Daily:
- pipeline
- deal status
- funding requests
- liquidity
- watchlist alerts
- covenant exceptions
- borrower updates

Weekly:
- origination meeting
- underwriting committee
- portfolio review
- legal/documentation status
- funding calendar
- risk exceptions

Monthly:
- borrower reporting
- financial spreading
- covenant testing
- risk rating
- valuation updates
- investor reporting
- liquidity and leverage review

Quarterly:
- fund reporting
- LP reporting
- fair value marks
- portfolio review
- audit support
- concentration review
- stress testing

Annual:
- strategy review
- fund planning
- LP meeting
- policy review
- valuation policy review
- operating budget
- technology roadmap

## Dispatch Truth Statement

Private credit is an operating business, not a passive asset class. Dispatch must model the full lifecycle of capital, deals, borrowers, sponsors, risk, monitoring, and exit.
