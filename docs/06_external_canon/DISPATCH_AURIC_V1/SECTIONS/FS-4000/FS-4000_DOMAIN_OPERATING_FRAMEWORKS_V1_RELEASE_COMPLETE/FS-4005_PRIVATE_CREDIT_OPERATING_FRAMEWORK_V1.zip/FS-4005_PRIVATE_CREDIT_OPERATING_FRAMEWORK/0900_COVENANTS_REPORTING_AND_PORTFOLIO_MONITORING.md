# Covenants, Reporting & Portfolio Monitoring

## Purpose

This document defines covenant testing, borrower reporting, and portfolio monitoring.

## Covenant Object

Fields:
- covenant_id
- facility
- borrower
- covenant_type
- threshold
- test_period
- frequency
- actual_value
- status
- cushion
- breach_date
- cure_period
- waiver_status
- evidence
- owner

## Reporting Requirements

- monthly financials
- quarterly financials
- annual audited statements
- compliance certificate
- borrowing base certificate
- KPI package
- budget
- variance report
- covenant calculations
- collateral reports
- insurance certificates
- tax compliance
- management updates

## Monitoring Lifecycle

Report Due → Request → Receive → Validate → Spread → Covenant Test → Risk Update → Portfolio Dashboard → Escalate if Needed → Archive

## Risk Rating Migration

Inputs:
- financial performance
- covenant cushion
- liquidity
- collateral
- sponsor support
- industry trends
- management quality
- reporting timeliness
- payment history
- external events

## Portfolio Review Package

Sections:
- portfolio summary
- exposure
- yield
- risk rating distribution
- covenant status
- watchlist
- delinquencies
- valuation
- concentration
- funding obligations
- exits
- income
- forecast
- recommended actions

## KPIs

- reporting timeliness
- covenant breach rate
- waiver count
- risk rating migration
- watchlist exposure
- default rate
- nonaccrual rate
- portfolio yield
- fair value marks
- realized losses
- recovery rate

## AI Opportunities

- covenant testing
- reporting summary
- risk rating recommendation
- covenant breach alert
- portfolio review drafting
- borrower performance commentary
- trend detection
- watchlist recommendation

## Dispatch Truth Statement

Portfolio monitoring is the operating discipline that turns origination into realized performance.
