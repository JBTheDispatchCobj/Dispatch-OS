# Private Credit Schema & Object Standard

## Purpose

This document defines the canonical objects used in the Private Credit cartridge.

## Universal Private Credit Investment Object

Fields:

- investment_id
- facility_id
- borrower_id
- sponsor_id
- lender_id
- fund_id
- strategy
- facility_type
- commitment_amount
- funded_amount
- unfunded_amount
- current_balance
- interest_rate
- rate_index
- spread
- floor
- fees
- maturity_date
- amortization
- collateral
- covenants
- guarantees
- risk_rating
- investment_status
- monitoring_status
- workout_status
- exit_strategy
- documents
- approvals
- reporting_requirements
- valuation
- fair_value
- audit_history
- AI_context

## Institution Objects

- Private Credit Fund
- Direct Lender
- Business Development Company
- Credit Opportunity Fund
- Specialty Finance Company
- Family Office
- Insurance Company
- Credit Union Investor
- Corporate Credit Union
- Bank Lender
- Warehouse Lender
- Agent Bank
- Administrative Agent
- Collateral Agent
- Servicer
- Backup Servicer
- Fund Administrator
- Trustee
- Custodian

## Deal Objects

- Deal
- Opportunity
- Borrower
- Sponsor
- Guarantor
- Operating Company
- Holding Company
- SPV
- Facility
- Tranche
- Term Sheet
- Investment Committee Memo
- Diligence Request List
- Due Diligence Finding
- Credit Agreement
- Security Agreement
- Intercreditor Agreement
- Covenant
- Borrowing Base
- Collateral Package
- Funding Notice
- Amendment
- Waiver
- Workout Plan
- Exit

## Facility Types

- Senior Secured
- First Lien
- Second Lien
- Unitranche
- Stretch Senior
- Mezzanine
- Subordinated Debt
- Preferred Equity
- Bridge Loan
- Acquisition Loan
- Growth Debt
- Venture Debt
- Asset-Based Loan
- Equipment Finance
- Receivables Finance
- Inventory Finance
- Real Estate Bridge
- Construction Loan
- NAV Facility
- Subscription Line
- Warehouse Facility
- Lender Finance Facility
- Litigation Finance
- Revenue-Based Finance
- Special Situations Credit
- Distressed Credit

## Dispatch Truth Statement

Private credit objects must connect capital, borrower, sponsor, collateral, covenants, documents, monitoring, valuation, risk, and exit strategy into one continuous lifecycle.
