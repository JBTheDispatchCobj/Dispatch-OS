# Risk, Compliance & Documentation

## Purpose

This document defines private credit risk, compliance, governance, and documentation requirements.

## Risk Domains

- credit risk
- sponsor risk
- borrower risk
- liquidity risk
- collateral risk
- covenant risk
- documentation risk
- legal risk
- bankruptcy risk
- concentration risk
- valuation risk
- fraud risk
- operational risk
- servicing risk
- fund liquidity risk
- investor reporting risk
- regulatory risk

## Compliance Areas

- AML/KYC/KYB
- sanctions
- accredited investor / qualified purchaser where relevant
- investment adviser compliance
- conflicts of interest
- valuation policy
- side letters
- fund governing documents
- lending licensing where applicable
- usury
- privacy
- data security
- records retention

## Core Documents

- NDA
- term sheet
- commitment letter
- credit memo
- investment committee minutes
- loan agreement
- promissory note
- security agreement
- guaranty
- pledge agreement
- intercreditor agreement
- UCC filings
- control agreements
- legal opinions
- compliance certificate
- borrowing base certificate
- amendment
- waiver
- forbearance agreement
- payoff letter
- closing binder

## Documentation Exception Object

Fields:
- exception_id
- facility
- document
- requirement
- status
- risk_level
- owner
- due_date
- waiver
- remediation
- evidence

## AI Opportunities

- document checklist
- legal issue summary
- covenant extraction
- obligation extraction
- document comparison
- closing binder index
- compliance exception summary
- side letter obligation tracker

## Dispatch Truth Statement

Private credit documentation is the enforceability layer. Dispatch must preserve every covenant, obligation, right, remedy, and evidence item as operational knowledge.
