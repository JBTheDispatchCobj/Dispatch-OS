# Funding, Closing & Servicing

## Purpose

This document defines closing, funding, settlement, servicing, and administration.

## Closing Object

Fields:
- closing_id
- deal
- borrower
- facility
- closing_date
- conditions_precedent
- legal_counsel
- documents
- wire_instructions
- approvals
- collateral_status
- insurance_status
- UCC_status
- funding_authorization
- post_closing_items

## Closing Workflow

Approval → Conditions → Legal Docs → Diligence Completion → Collateral Perfection → Funds Flow → Signatures → Funding Authorization → Wire → Boarding → Post-Closing

## Conditions Precedent

- executed loan documents
- authority documents
- legal opinions
- collateral perfection
- insurance
- lien searches
- payoffs
- equity contribution
- KYC/KYB
- tax forms
- financial statements
- funds flow
- board/manager approvals

## Servicing Functions

- payment collection
- interest calculation
- fee calculation
- amortization tracking
- notices
- covenant calendar
- reporting requests
- borrower communications
- principal paydowns
- draws
- revolver availability
- default interest
- payoff
- investor reporting

## Payment Object

Fields:
- payment_id
- borrower
- facility
- due_date
- amount_due
- principal
- interest
- fees
- received_date
- status
- shortfall
- default_interest
- allocation
- investor_distribution

## Post-Closing Items

- original documents
- UCC confirmations
- control agreements
- insurance endorsements
- mortgages recorded
- legal opinions
- final schedules
- board approvals
- closing binders

## Servicing KPIs

- payment timeliness
- missed payments
- servicing exceptions
- reporting timeliness
- post-closing items overdue
- draw request cycle time
- interest calculation accuracy
- fee collection
- payoff completion

## AI Opportunities

- closing checklist
- funds flow review
- conditions tracking
- servicing notice drafting
- payment variance detection
- post-closing exception tracker
- payoff letter support
- draw request review

## Dispatch Truth Statement

Closing and servicing convert an approved credit into a controlled operating relationship with legal enforceability, cash flow, monitoring, and evidence.
