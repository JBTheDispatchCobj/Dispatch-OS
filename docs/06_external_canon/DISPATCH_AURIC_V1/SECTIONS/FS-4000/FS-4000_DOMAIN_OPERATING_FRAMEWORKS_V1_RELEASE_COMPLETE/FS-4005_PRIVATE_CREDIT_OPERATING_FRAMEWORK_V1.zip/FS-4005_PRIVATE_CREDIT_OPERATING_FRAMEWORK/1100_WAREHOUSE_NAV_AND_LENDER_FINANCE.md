# Warehouse, NAV & Lender Finance

## Purpose

This document defines leverage facilities used by private credit platforms and specialty finance companies.

## Facility Types

- Warehouse Line
- Lender Finance Facility
- NAV Facility
- Subscription Line
- Repo Facility
- Asset-Backed Facility
- Loan-on-Loan Financing
- Forward Flow Facility
- Securitization Warehouse

## Warehouse Facility Object

Fields:
- facility_id
- lender
- borrower
- commitment
- advance_rate
- eligible_assets
- concentration_limits
- borrowing_base
- outstanding
- availability
- margin
- covenants
- reporting
- collateral_custodian
- servicer
- maturity
- renewal_status

## Lender Finance Borrower

Fields:
- platform_name
- origination_strategy
- servicing_capability
- underwriting_policy
- portfolio_performance
- funding_sources
- equity
- leverage
- technology_stack
- compliance
- risk_management
- historical_losses

## Borrowing Base Workflow

Asset Tape → Eligibility Rules → Haircuts → Concentration Limits → Advance Rate → Availability → Draw Request → Approval → Funding → Reporting

## NAV Facility

Collateral:
- fund interests
- portfolio investments
- NAV
- distributions
- unfunded commitments
- borrowing base based on asset value

## KPIs

- utilization
- availability
- advance rate
- collateral performance
- eligibility exceptions
- concentration
- delinquency in collateral pool
- margin calls
- covenant breaches
- renewal risk
- cost of leverage

## AI Opportunities

- asset tape review
- eligibility testing
- borrowing base calculation
- collateral trend detection
- covenant monitoring
- lender reporting package
- renewal risk summary
- margin call alerting

## Dispatch Truth Statement

Leverage facilities are operating systems inside the private credit operating system. Dispatch must monitor both borrower credit and lender finance structure continuously.
