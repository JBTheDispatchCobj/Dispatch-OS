# Underwriting & Credit Memo

## Purpose

This document defines private credit underwriting and credit memo standards.

## Underwriting Categories

- Borrower Overview
- Sponsor Analysis
- Transaction Overview
- Use of Proceeds
- Industry Analysis
- Financial Analysis
- Quality of Earnings
- Cash Flow Analysis
- Collateral Analysis
- Management Assessment
- Customer/Supplier Analysis
- Legal/Tax Review
- Insurance Review
- Technology Review
- ESG/Regulatory where relevant
- Downside Case
- Recovery Analysis
- Exit Analysis
- Recommendation

## Financial Analysis

Metrics:
- revenue
- gross profit
- EBITDA
- adjusted EBITDA
- recurring revenue
- free cash flow
- working capital
- CapEx
- leverage
- fixed charge coverage
- DSCR
- liquidity
- backlog
- ARR where applicable
- churn where applicable
- customer concentration

## Credit Memo Object

Fields:

- memo_id
- deal
- borrower
- sponsor
- request
- recommendation
- facility_structure
- pricing
- sources_and_uses
- strengths
- weaknesses
- mitigants
- financial_analysis
- collateral_analysis
- risk_rating
- covenants
- conditions
- committee_decision
- approval_history

## Credit Memo Sections

1. Executive Summary
2. Transaction Overview
3. Borrower Overview
4. Sponsor Overview
5. Industry Overview
6. Financial Performance
7. Cash Flow & Repayment
8. Collateral
9. Structure & Pricing
10. Covenants
11. Risk Rating
12. Downside Case
13. Recovery Analysis
14. Key Risks
15. Mitigants
16. Conditions
17. Recommendation
18. Appendices

## Committee Decision Object

Fields:
- committee_id
- meeting_date
- members
- vote
- approval_status
- conditions
- dissent
- comments
- follow_up
- expiration
- authority

## AI Opportunities

- credit memo drafting
- financial trend analysis
- QofE summary
- diligence checklist
- downside scenario
- risk/mitigant table
- committee briefing
- IC Q&A prep
- covenant proposal
- approval condition extraction

## Dispatch Truth Statement

A credit memo is not a document. It is the institutional reasoning artifact that connects evidence, judgment, approval, and future monitoring.
