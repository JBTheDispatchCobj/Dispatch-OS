# Private Credit Implementation Guide

## Phase 1 — Setup

- create fund object
- create GP/manager
- configure strategy
- configure LPs
- configure investment committee
- configure approval authority
- configure facility types
- configure risk rating scale
- configure document library
- configure reporting cadence

## Phase 2 — Objects

- sponsors
- borrowers
- deals
- facilities
- collateral
- covenants
- IC memos
- documents
- reports
- valuations
- LPs
- capital calls
- distributions

## Phase 3 — Workflows

Activate:
- origination
- screening
- underwriting
- IC
- closing
- covenant monitoring
- portfolio review
- valuation
- LP reporting
- workout

## Phase 4 — Agents

Deploy:
- Opportunity Screener
- IC Memo Writer
- Financial Spreading Agent
- Covenant Monitor
- Portfolio Monitor
- Valuation Support Agent
- LP Reporting Agent
- Workout Strategy Agent

## Phase 5 — Dashboards

Configure:
- GP dashboard
- origination dashboard
- underwriting dashboard
- portfolio dashboard
- risk dashboard
- watchlist dashboard
- LP reporting dashboard

## Demo Flow

1. Open fund dashboard.
2. Show pipeline.
3. Screen opportunity.
4. Generate diligence request.
5. Draft IC memo.
6. Show term sheet and covenants.
7. Show portfolio monitoring.
8. Trigger covenant breach alert.
9. Generate LP report summary.
10. Show audit trail.

## Dispatch Truth Statement

Private credit implementation begins with capital, strategy, and workflow discipline—not generic CRM.
