# Covenants & Monitoring

## Purpose

This document defines covenant design, testing, reporting, and monitoring.

## Covenant Types

### Financial Covenants

- Minimum EBITDA
- Maximum Leverage
- Minimum Fixed Charge Coverage
- Minimum DSCR
- Minimum Liquidity
- Minimum Net Worth
- Current Ratio
- Borrowing Base
- Debt Yield
- Minimum Cash
- Interest Coverage

### Reporting Covenants

- Monthly Financials
- Quarterly Financials
- Annual Audited Financials
- Compliance Certificate
- Borrowing Base Certificate
- Budget
- Board Materials
- KPI Reports
- Tax Returns
- Insurance Certificates

### Negative Covenants

- Additional Debt
- Liens
- Restricted Payments
- Asset Sales
- Acquisitions
- Investments
- Affiliate Transactions
- Change of Control
- CapEx Limits
- Management Fees

### Affirmative Covenants

- Maintain Insurance
- Pay Taxes
- Maintain Collateral
- Provide Reporting
- Maintain Existence
- Permit Inspections
- Notify of Defaults
- Maintain Books and Records

## Covenant Object

Fields:
- covenant_id
- facility
- borrower
- covenant_type
- threshold
- calculation
- test_frequency
- due_date
- received_date
- tested_value
- status
- breach
- waiver
- cure_period
- evidence
- owner
- escalation

## Monitoring Package

- monthly financials
- compliance certificate
- covenant calculations
- borrowing base
- variance analysis
- liquidity
- sales
- EBITDA
- debt schedule
- collateral update
- management commentary
- risk rating update

## Monitoring Workflow

Report Due → Request → Receive → Validate → Calculate → Test → Pass/Fail → Update Risk → Escalate if Needed → Archive Evidence

## Early Warning Indicators

- missed reporting
- covenant cushion decline
- liquidity decline
- revenue decline
- margin compression
- customer loss
- management departure
- delayed audit
- borrowing base ineligibles
- supplier issues
- sponsor silence
- legal events

## AI Opportunities

- covenant testing
- compliance certificate review
- reporting gap alerts
- early warning detection
- monitoring package summary
- risk rating recommendation
- waiver memo draft
- covenant cushion forecast

## Dispatch Truth Statement

Covenants are not legal boilerplate. They are operating sensors that detect credit deterioration before payment default.
