# Collateral & Security

## Purpose

This document defines private credit collateral, lien, perfection, valuation, and monitoring operations.

## Collateral Types

- Accounts Receivable
- Inventory
- Equipment
- Machinery
- Real Estate
- Cash
- Securities
- Deposit Accounts
- Intellectual Property
- Contracts
- Equity Interests
- Vehicles
- Aircraft
- Marine Assets
- Franchise Rights
- Licenses
- Insurance Proceeds
- Personal Guarantees
- Corporate Guarantees

## Collateral Object

Fields:
- collateral_id
- borrower
- facility
- collateral_type
- owner
- value
- valuation_method
- valuation_date
- advance_rate
- lien_position
- perfection_method
- UCC_status
- control_agreement
- insurance
- monitoring_frequency
- liquidation_value
- recovery_estimate
- exceptions

## Security Documents

- Security Agreement
- Pledge Agreement
- Mortgage / Deed of Trust
- Assignment of Rents
- UCC Financing Statement
- Control Agreement
- Deposit Account Control Agreement
- Intercreditor Agreement
- Subordination Agreement
- Guaranty
- Collateral Assignment
- Insurance Assignment

## Perfection Workflow

Collateral Identification → Legal Review → Filing/Search → Control Agreements → Insurance → Confirmation → Exception Tracking → Monitoring → Release

## Valuation Methods

- Appraisal
- Desktop Valuation
- Broker Opinion
- Orderly Liquidation Value
- Forced Liquidation Value
- Net Book Value
- Market Comparables
- Discounted Cash Flow
- Borrowing Base Advance
- Inventory Appraisal
- Receivables Aging

## Collateral KPIs

- collateral coverage
- LTV
- advance rate
- borrowing base availability
- valuation currency
- lien exceptions
- insurance exceptions
- concentration
- liquidation recovery
- collateral deterioration
- inspection exceptions

## AI Opportunities

- collateral checklist
- lien exception detection
- borrowing base review
- valuation summary
- insurance review
- liquidation scenario
- UCC filing checklist
- collateral release analysis

## Dispatch Truth Statement

Collateral is not a static support item. It is a monitored recovery system that changes with borrower operations, markets, documentation, and legal perfection.
