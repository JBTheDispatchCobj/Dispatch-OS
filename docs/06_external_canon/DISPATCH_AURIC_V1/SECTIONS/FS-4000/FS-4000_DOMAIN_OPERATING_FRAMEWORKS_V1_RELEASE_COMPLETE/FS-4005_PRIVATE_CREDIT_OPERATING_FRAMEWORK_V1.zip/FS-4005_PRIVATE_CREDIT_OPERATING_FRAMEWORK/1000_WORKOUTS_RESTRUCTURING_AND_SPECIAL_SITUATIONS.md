# Workouts, Restructuring & Special Situations

## Purpose

This document defines workout and special situations operations for private credit.

## Distress Signals

- missed payment
- covenant breach
- liquidity decline
- EBITDA decline
- customer loss
- sponsor dispute
- delayed reporting
- collateral deterioration
- adverse litigation
- management turnover
- fraud concern
- refinancing failure
- maturity wall
- borrowing base deficiency

## Workout Object

Fields:
- workout_id
- borrower
- facility
- trigger
- status
- action_plan
- owner
- counsel
- collateral_status
- liquidity_status
- sponsor_support
- options
- recovery_estimate
- timeline
- approvals
- documents
- knowledge_captured

## Workout Lifecycle

Early Warning → Watchlist → Default → Reservation of Rights → Forbearance → Amendment → Restructuring → Enforcement → Sale/Refinance → Recovery → Archive

## Restructuring Tools

- waiver
- amendment
- maturity extension
- rate increase
- fee
- additional collateral
- sponsor equity injection
- cash sweep
- amortization change
- payment deferral
- PIK interest
- collateral sale
- refinancing
- debt-for-equity
- liquidation

## Special Situations

- distressed acquisition financing
- rescue financing
- debtor-in-possession financing
- bridge-to-sale financing
- litigation-driven credit
- turnaround credit
- asset liquidation financing
- recapitalization financing

## Workout KPIs

- watchlist exposure
- default rate
- cure rate
- recovery rate
- time in workout
- collateral recovery
- amendment count
- waiver count
- realized loss
- legal cost
- recovery versus estimate

## AI Opportunities

- early warning detection
- workout options memo
- recovery analysis
- borrower liquidity summary
- collateral liquidation summary
- amendment term comparison
- legal timeline tracker
- board/investor update drafting

## Dispatch Truth Statement

Workouts are where private credit proves its discipline. Dispatch must preserve every trigger, negotiation, concession, control right, and recovery path.
