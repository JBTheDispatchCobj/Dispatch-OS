# Portfolio Management

## Purpose

This document defines portfolio monitoring, reporting, valuation, risk migration, and investor communication.

## Portfolio Object

Fields:
- portfolio_id
- manager
- strategy
- facilities
- borrowers
- sponsors
- industries
- geographies
- total_commitment
- funded_balance
- unfunded_commitment
- weighted_spread
- weighted_yield
- weighted_risk_rating
- leverage
- nonaccrual
- defaults
- watchlist
- concentrations
- liquidity
- NAV
- investor_reporting

## Portfolio Management Functions

- exposure monitoring
- risk rating
- covenant review
- financial reporting
- valuation
- concentration monitoring
- watchlist
- sponsor updates
- liquidity
- capital allocation
- investor reporting
- performance attribution
- stress testing

## Portfolio Review Package

Sections:
- executive summary
- portfolio composition
- performance
- yield
- risk rating migration
- watchlist
- covenant breaches
- defaults
- industry trends
- concentration
- valuation
- liquidity
- recommendations

## Valuation

Inputs:
- borrower performance
- market spread
- risk rating
- collateral value
- covenant compliance
- liquidity
- comparable transactions
- recovery outlook
- exit strategy

## Portfolio KPIs

- portfolio yield
- weighted spread
- risk rating migration
- nonaccrual rate
- default rate
- recovery rate
- watchlist exposure
- covenant breach rate
- reporting timeliness
- concentration
- NAV
- IRR
- MOIC
- cash yield
- realized losses
- unrealized marks

## AI Opportunities

- portfolio summary
- risk migration detection
- concentration dashboard
- quarterly LP report
- valuation commentary
- watchlist recommendation
- borrower update digest
- market comparison
- stress scenario summary

## Dispatch Truth Statement

Portfolio management is the continuous intelligence layer between individual credit exposures and institutional capital outcomes.
