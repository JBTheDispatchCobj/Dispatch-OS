# Warehouse, NAV & Subscription Facilities

## Purpose

This document defines fund-level and asset-level credit facilities used in private credit ecosystems.

## Warehouse Facility

A line used to aggregate or finance eligible assets before sale, securitization, takeout, or permanent financing.

Objects:
- warehouse lender
- borrower
- eligible collateral
- advance rate
- borrowing base
- availability
- margin
- collateral pool
- reporting
- audit
- takeout
- maturity

## NAV Facility

A facility secured by the net asset value of a fund or portfolio.

Objects:
- fund
- portfolio assets
- NAV
- advance rate
- concentration limits
- collateral package
- borrowing availability
- lender
- covenants
- valuation

## Subscription Facility

A facility secured by uncalled LP capital commitments.

Objects:
- LP commitments
- eligible investors
- borrowing base
- capital call rights
- concentration limits
- notices
- facility lender
- maturity
- covenants

## Borrowing Base Object

Fields:
- borrowing_base_id
- facility
- collateral_pool
- gross_collateral
- ineligible_collateral
- net_eligible
- advance_rate
- availability
- outstanding
- excess_availability
- test_date
- exceptions

## Facility Monitoring

- eligibility
- concentration
- valuation
- reporting
- audits
- margin calls
- borrowing requests
- repayments
- investor changes
- collateral substitutions

## KPIs

- availability
- utilization
- advance rate
- excess availability
- ineligible collateral
- margin calls
- borrowing base exceptions
- audit findings
- maturity risk
- takeout progress

## AI Opportunities

- borrowing base review
- availability forecast
- margin call alert
- collateral eligibility detection
- subscription line report
- NAV facility monitoring
- warehouse aging report
- lender reporting package

## Dispatch Truth Statement

Fund-level credit facilities are operating leverage. Dispatch must continuously monitor collateral, eligibility, availability, covenants, reporting, and liquidity.
