# Investment Committee & Approvals

## Purpose

This document defines private credit governance and approval processes.

## Investment Committee Object

Fields:
- committee_id
- fund
- members
- voting_rights
- authority
- quorum
- meeting_cadence
- policies
- conflicts
- approval_thresholds
- minutes
- decisions
- conditions
- audit_history

## Investment Committee Memo Sections

- executive summary
- transaction overview
- borrower overview
- sponsor overview
- use of proceeds
- investment thesis
- capital structure
- financial analysis
- collateral analysis
- industry analysis
- management assessment
- diligence summary
- structure and pricing
- covenants
- risks
- mitigants
- downside case
- exit strategy
- recommendation
- conditions
- appendices

## Approval Lifecycle

Screening Approval → Term Sheet Approval → Diligence Review → Final IC Approval → Conditions → Legal Sign-Off → Funding Authorization → Post-Close Review

## Decision Object

Fields:
- decision_id
- committee
- deal
- recommendation
- vote
- conditions
- dissent
- conflicts
- approval_date
- expiration
- required_follow_up
- knowledge_captured

## Approval Risks

- incomplete diligence
- conflicts
- missing legal review
- insufficient downside analysis
- valuation uncertainty
- covenant weakness
- sponsor concentration
- fund restriction issue
- documentation gap
- authority breach

## AI Opportunities

- IC memo drafting
- risk/mitigant extraction
- open question list
- committee briefing
- voting record summary
- condition tracker
- decision archive
- prior similar deal comparison

## Dispatch Truth Statement

Investment Committee is where capital authority becomes institutional memory. Dispatch must preserve not only the decision, but the reasoning and conditions behind it.
