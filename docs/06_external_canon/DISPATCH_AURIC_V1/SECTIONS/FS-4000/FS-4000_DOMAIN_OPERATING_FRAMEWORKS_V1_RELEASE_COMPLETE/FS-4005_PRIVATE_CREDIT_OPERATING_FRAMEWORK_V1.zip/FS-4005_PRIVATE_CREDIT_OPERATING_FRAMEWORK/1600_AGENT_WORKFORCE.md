# Private Credit Agent Workforce

## Origination Agents

- Sponsor Relationship Analyst
- Market Mapping Agent
- Opportunity Screener
- Teaser Summary Agent
- Deal Fit Agent
- Outreach Agent

## Underwriting Agents

- Credit Analyst
- Financial Spreading Agent
- Cash Flow Analyst
- Collateral Analyst
- Diligence Coordinator
- Risk Matrix Agent
- IC Memo Writer
- Downside Case Analyst

## Structuring Agents

- Term Sheet Drafting Agent
- Covenant Design Agent
- Pricing Advisor
- Intercreditor Review Agent
- Return Model Agent

## Portfolio Agents

- Portfolio Monitor
- Covenant Monitor
- Borrower Reporting Agent
- Risk Rating Agent
- Watchlist Agent
- Valuation Support Agent
- Investor Reporting Agent

## Workout Agents

- Early Warning Agent
- Workout Strategy Agent
- Recovery Analyst
- Amendment/Waiver Agent
- Collateral Liquidation Agent

## Operations Agents

- Closing Checklist Agent
- Funding Agent
- Document Indexer
- Compliance Evidence Agent
- LP Reporting Agent
- Capital Call Agent

## Governance

Human approval required for:
- investment decisions
- term sheets
- waivers
- amendments
- workouts
- valuations
- capital calls
- distributions
- investor communications
- regulatory/compliance matters

## Dispatch Truth Statement

Private credit agents act as credit, diligence, monitoring, reporting, and operations staff under strict human authority.
