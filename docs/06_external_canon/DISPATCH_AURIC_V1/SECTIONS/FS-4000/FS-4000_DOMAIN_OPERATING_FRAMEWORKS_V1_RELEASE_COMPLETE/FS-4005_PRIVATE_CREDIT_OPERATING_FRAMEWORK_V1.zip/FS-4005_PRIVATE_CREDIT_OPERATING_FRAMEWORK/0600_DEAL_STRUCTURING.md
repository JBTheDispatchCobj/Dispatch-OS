# Deal Structuring

## Purpose

This document defines private credit structure design.

## Structure Components

- facility type
- commitment amount
- funded amount
- delayed draw
- revolver
- term loan
- tenor
- amortization
- interest rate
- spread
- floor
- default rate
- original issue discount
- upfront fee
- unused fee
- exit fee
- prepayment premium
- call protection
- collateral
- lien position
- guarantees
- covenants
- reporting
- control rights
- intercreditor terms

## Facility Types

### First Lien

Senior secured debt with first priority claim on collateral.

### Second Lien

Secured debt subordinate to first lien lenders.

### Unitranche

Single debt facility blending senior and subordinated risk/return.

### Mezzanine

Subordinated debt often with warrants or equity-like return.

### Bridge

Short-term facility supporting acquisition, refinancing, liquidity, or transition.

### ABL

Asset-based facility secured by receivables, inventory, or other borrowing-base collateral.

### NAV Facility

Facility secured by portfolio value or fund assets.

### Subscription Facility

Facility secured by LP capital commitments.

## Sources & Uses Object

Fields:
- source_id
- use_id
- debt
- equity
- seller_note
- rollover
- fees
- expenses
- purchase_price
- refinance_amount
- working_capital
- cash_to_balance_sheet
- reserves

## Pricing Framework

Inputs:
- borrower risk
- leverage
- collateral
- sponsor
- industry
- competition
- liquidity
- facility size
- documentation strength
- covenant package
- exit risk
- relationship value
- market spread

## Structure Rules

- risk should be compensated by pricing and controls
- weak collateral requires stronger covenants or pricing
- weak sponsor requires lower leverage or more control
- high cyclicality requires liquidity cushion
- high growth may require delayed draw
- turnaround requires monitoring intensity
- weak reporting requires additional controls

## AI Opportunities

- structure recommendation
- pricing comparison
- covenant package suggestion
- intercreditor risk summary
- sources and uses validation
- term sheet drafting
- control rights analysis
- scenario comparison

## Dispatch Truth Statement

Deal structure is how risk judgment becomes contract architecture.
