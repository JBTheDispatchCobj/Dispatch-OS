# Structuring, Pricing & Terms

## Purpose

This document defines private credit deal structuring.

## Structure Components

- Seniority
- Collateral
- Term
- Amortization
- Interest Rate
- Spread
- Floor
- Original Issue Discount
- Commitment Fee
- Unused Fee
- Exit Fee
- Prepayment Premium
- Call Protection
- Warrants
- Equity Co-Invest
- Covenants
- Reporting Requirements
- Guaranties
- Reserves
- Cash Dominion
- Control Agreements
- Intercreditor Rights

## Term Sheet Object

Fields:
- term_sheet_id
- borrower
- sponsor
- facility_type
- commitment
- use_of_proceeds
- maturity
- pricing
- fees
- collateral
- covenants
- reporting
- conditions
- exclusivity
- expenses
- confidentiality
- approval_status
- expiration

## Pricing Inputs

- risk rating
- leverage
- collateral quality
- borrower size
- sponsor quality
- sector
- competition
- market spreads
- documentation complexity
- monitoring intensity
- downside protection
- fund return target
- leverage facility cost
- relationship value

## Covenant Types

- leverage
- fixed charge coverage
- minimum EBITDA
- liquidity
- minimum revenue
- borrowing base
- capex limits
- debt incurrence
- restricted payments
- acquisitions
- affiliate transactions
- reporting
- audit rights
- collateral monitoring

## Control Features

- lockbox
- cash dominion
- blocked accounts
- reserves
- reporting triggers
- borrowing base certificates
- field exams
- collateral audits
- mandatory prepayments
- springing covenants

## Structuring Workflow

Risk Assessment → Return Requirement → Collateral Package → Covenant Design → Reporting Requirements → Intercreditor Review → Term Sheet → Negotiation → Investment Committee → Final Documentation

## AI Opportunities

- covenant package recommendation
- pricing comparison
- structure sensitivity
- term sheet drafting
- downside protection analysis
- market term comparison
- negotiation prep
- return calculation
- risk-adjusted pricing recommendation

## Dispatch Truth Statement

Structure is how private credit converts risk into enforceable protection and return.
