# Knowledge Packs & Playbooks

## Purpose

This document defines reusable banking knowledge assets.

## Required Knowledge Packs

### Banking Foundation Pack

Includes:
- banking terminology
- institution types
- products
- departments
- core operating model
- risk domains
- regulatory overview
- workflow templates

### Deposit Operations Pack

Includes:
- deposit products
- account opening
- pricing
- retention
- runoff
- dormant accounts
- escheatment
- deposit analytics

### Lending Pack

Includes:
- underwriting
- credit memo
- approval matrices
- collateral
- covenants
- portfolio monitoring
- workout
- recovery

### Payments Pack

Includes:
- ACH
- wires
- cards
- RTP/FedNow
- settlement
- returns
- exceptions
- fraud

### Treasury & ALM Pack

Includes:
- liquidity
- funding
- investments
- ALCO
- interest rate risk
- stress testing
- capital planning

### Compliance Pack

Includes:
- BSA/AML
- OFAC
- KYC/KYB
- fair lending
- privacy
- complaint management
- regulatory exams
- evidence collection

### Technology & Vendor Pack

Includes:
- core systems
- digital banking
- security reviews
- vendor risk
- contract reviews
- connector deployment
- technology roadmap

### AI Governance Pack

Includes:
- agent permissions
- model governance
- human approval thresholds
- evidence
- citations
- hallucination controls
- audit logs

## Playbooks

- Board Packet Playbook
- ALCO Package Playbook
- Commercial Credit Playbook
- Deposit Growth Playbook
- Vendor Due Diligence Playbook
- Exam Readiness Playbook
- Core Conversion Playbook
- AI Adoption Playbook
- Payments Exception Playbook
- Incident Response Playbook
- Strategic Planning Playbook

## Playbook Schema

- playbook_id
- name
- objective
- trigger
- prerequisites
- steps
- owners
- agents
- documents
- KPIs
- workflows
- acceptance criteria
- outputs

## Dispatch Truth Statement

Knowledge Packs and Playbooks are how Dispatch turns banking expertise into repeatable institutional execution.
