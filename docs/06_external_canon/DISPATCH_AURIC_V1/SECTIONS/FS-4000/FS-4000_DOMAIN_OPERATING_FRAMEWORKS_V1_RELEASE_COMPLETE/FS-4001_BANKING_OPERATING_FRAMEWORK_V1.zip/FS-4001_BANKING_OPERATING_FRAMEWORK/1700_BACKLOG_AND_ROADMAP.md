# Backlog & Roadmap

## Priority 1 — Registry Build

- implement institution objects
- implement customer/account objects
- implement product taxonomy
- implement lending objects
- implement payment objects
- implement risk/control/evidence objects
- implement technology/vendor objects
- implement KPI registry

## Priority 2 — Workflows

- account opening
- customer onboarding
- commercial loan origination
- ALCO package
- deposit pricing
- vendor review
- board packet
- exam preparation
- payment exception
- complaint management

## Priority 3 — Agents

- Executive Briefing Agent
- Board Packet Writer
- ALCO Analyst
- Credit Memo Writer
- Vendor Risk Reviewer
- Compliance Monitor
- Deposit Growth Agent
- Payments Exception Agent
- Data Quality Agent

## Priority 4 — Dashboards

- board
- CEO
- CFO
- lending
- deposits
- treasury
- risk
- compliance
- technology
- vendor
- AI operations

## Priority 5 — Connectors

- email/calendar
- document storage
- CSV/Excel
- GL/accounting
- CRM
- core system
- LOS
- digital banking
- payments
- data warehouse
- AI provider

## Priority 6 — Knowledge

- Banking Foundation Pack
- Lending Pack
- Deposit Pack
- Payments Pack
- Treasury Pack
- Compliance Pack
- Vendor Pack
- AI Governance Pack

## Priority 7 — Market Intelligence

- bank profile format
- executive profile format
- vendor profile format
- technology stack intelligence
- peer benchmarking
- market signals
- regulatory signals
- opportunity discovery

## Production Sprint

1. Load volume into repo.
2. Convert objects into machine-readable registry.
3. Create fixture bank.
4. Create sample customers/accounts/loans/payments.
5. Create sample board packet.
6. Create sample ALCO package.
7. Wire first agents.
8. Run acceptance tests.

## Dispatch Truth Statement

The roadmap should convert this volume from written knowledge into executable product assets.
