# Banking Institution Types

## Purpose

This document defines the canonical banking institution taxonomy used by Dispatch.

## Commercial Bank

A depository institution serving consumers, businesses, and communities through deposits, loans, payments, treasury, and financial products.

Objects:

- Bank
- Charter
- Branch
- Customer
- Account
- Loan
- Payment
- Treasury Service
- Regulator
- Board
- Executive

## Community Bank

A locally or regionally focused banking institution with relationship-oriented lending and deposits.

Key attributes:

- local market concentration
- relationship banking
- community deposits
- small business lending
- CRE exposure
- branch-based operations
- local board knowledge
- market-specific credit judgment

## Regional Bank

A multi-market institution with broader product capabilities, treasury services, commercial banking, capital markets exposure, and more complex risk management.

Key attributes:

- multi-state operations
- larger commercial portfolios
- treasury platforms
- institutional deposits
- syndicated credit exposure
- more complex vendor stack
- higher regulatory scrutiny

## Money Center Bank

A large national or global bank with institutional markets, capital markets, payments, custody, investment banking, wealth, and global treasury capabilities.

Key attributes:

- global settlement
- capital markets
- trading
- custody
- correspondent banking
- institutional clients
- advanced risk systems
- systemically important operations

## Savings Bank / Thrift

Historically mortgage and savings oriented.

Objects:

- Mortgage Portfolio
- Savings Deposits
- Real Estate Loan
- Residential Lending
- Community Market
- Liquidity Portfolio

## Trust Company

Provides fiduciary, custody, trust administration, wealth, estate, and institutional asset services.

Objects:

- Trust
- Beneficiary
- Fiduciary Account
- Custody Account
- Investment Policy
- Trustee
- Estate
- Distribution

## Industrial Bank

A state-chartered institution often associated with specialized lending, fintech sponsorship, commercial parent relationships, or niche banking services.

Objects:

- Parent Company
- Industrial Charter
- Banking Product
- Sponsor Relationship
- Compliance Program
- Regulatory Profile

## Private Bank

Serves high-net-worth individuals, families, executives, and business owners.

Objects:

- Wealth Client
- Relationship Manager
- Credit Facility
- Investment Account
- Trust
- Estate
- Family Office Relationship

## Digital Bank / Neobank

A digital-first institution or fintech bank interface operating with or through banking infrastructure.

Objects:

- Digital Account
- Partner Bank
- BaaS Provider
- Ledger
- Mobile App
- Identity Verification
- Card Program
- API
- Compliance Owner

## Bank Holding Company

Owns one or more banks and may own non-bank subsidiaries.

Objects:

- Holding Company
- Subsidiary
- Board
- Capital Plan
- Regulatory Filing
- Intercompany Agreement
- Corporate Treasury
- M&A Pipeline

## Correspondent Bank

Provides services to other financial institutions.

Functions:

- settlement
- cash letter
- liquidity
- wires
- international payments
- safekeeping
- treasury
- participations
- back-office services

## Dispatch Truth Statement

Institution type determines permissible activities, operating complexity, regulatory expectations, technology needs, customer segments, and strategic opportunities.
