# Deposit & Liability Operations

## Purpose

This document defines deposit products, liability management, funding strategy, account operations, and deposit intelligence.

## Deposit Product Types

- Demand Deposit Account
- Interest Checking
- Savings
- Money Market
- Certificate of Deposit
- Brokered Deposit
- Reciprocal Deposit
- Sweep Account
- Escrow Account
- Trust Account
- Custodial Account
- Business Checking
- Commercial DDA
- Public Funds Deposit
- Institutional Deposit
- Health Savings Account
- IRA
- Zero Balance Account

## Deposit Object

Fields:

- deposit_id
- account_id
- customer_id
- product_type
- balance
- average_balance
- interest_rate
- rate_tier
- maturity_date
- term
- early_withdrawal_penalty
- fees
- restrictions
- source
- branch
- channel
- cost_of_funds
- profitability
- deposit_beta
- attrition_risk
- insured_uninsured_status
- concentration_flag

## Deposit Lifecycle

Product Design → Pricing → Account Opening → Funding → Servicing → Rate Review → Retention → Maturity/Renewal → Closure → Archive

## Liability Management

The bank manages deposits as funding sources. Dispatch links deposits to:

- liquidity
- cost of funds
- loan growth capacity
- interest rate risk
- customer relationships
- treasury products
- concentration risk
- profitability

## Deposit Pricing Workflow

Market Rate Scan → Current Portfolio Review → Funding Need → Competitor Pricing → Deposit Beta Analysis → Margin Impact → ALCO Review → Pricing Decision → System Update → Campaign → Monitoring

## Deposit Risk Domains

- runoff risk
- concentration risk
- uninsured deposit risk
- rate sensitivity
- brokered deposit dependency
- public funds risk
- operational restrictions
- fraud risk
- compliance risk
- escheatment

## Deposit KPIs

- total deposits
- deposit growth
- DDA growth
- commercial deposit growth
- average balance
- cost of deposits
- deposit beta
- retention
- churn
- maturity runoff
- uninsured deposit percentage
- top depositor concentration
- public funds concentration
- branch/channel source mix

## AI Opportunities

- deposit runoff prediction
- pricing recommendation
- customer retention offers
- maturity renewal strategy
- relationship-based pricing
- concentration alerting
- uninsured exposure analysis
- ALCO deposit briefing
- deposit campaign targeting

## Dispatch Truth Statement

Deposits are not passive liabilities. They are relationship-driven funding instruments that determine liquidity, profitability, loan capacity, customer depth, and strategic flexibility.
