# Acceptance Tests

## Object Tests

- Can create Bank object.
- Can create Community Bank, Regional Bank, Trust Company, Digital Bank, Holding Company.
- Can create Customer, Household, Business Customer, Borrower, Guarantor.
- Can create Account, Deposit, Loan, Payment, Transaction, Vendor, Policy, Control.
- Every object inherits universal fields.
- Every object supports relationships, documents, telemetry, and audit history.

## Relationship Tests

- Bank REGULATED_BY Regulator.
- Bank INSURED_BY Deposit Insurer.
- Bank OWNS Subsidiary.
- Customer HOLDS Account.
- Customer BORROWS Loan.
- Business Customer USES Treasury Service.
- Vendor PROVIDES Product.
- Product SUPPORTS Workflow.
- Policy GOVERNS Workflow.
- Control SATISFIES Regulation.

## Workflow Tests

- Account opening workflow completes.
- Commercial loan workflow produces credit memo.
- ALCO package workflow produces liquidity/rate summary.
- Vendor review workflow produces risk output.
- Board packet workflow produces executive summary.
- Exam prep workflow produces evidence inventory.
- Payment exception workflow routes to correct owner.

## Agent Tests

- Executive Briefing Agent summarizes institution.
- Board Packet Writer creates packet.
- ALCO Analyst explains liquidity and rate risk.
- Credit Memo Writer drafts memo.
- Vendor Risk Reviewer identifies missing evidence.
- Compliance Agent maps policy to controls.
- Data Quality Agent detects mapping issues.

## KPI Tests

- Calculates deposit growth.
- Calculates loan growth.
- Calculates NIM.
- Calculates efficiency ratio.
- Calculates delinquency.
- Calculates charge-off rate.
- Calculates liquidity ratio.
- Calculates vendor review completion.

## Connector Tests

- Connector maps source records to canonical objects.
- Connector preserves source lineage.
- Connector supports audit trail.
- Connector emits telemetry.
- Connector handles failure and retry.
- Connector respects permissions.

## Demo Acceptance

A demo is acceptable when it shows:

- complete bank profile
- customer/account object graph
- product map
- technology stack
- board dashboard
- executive briefing
- lending workflow
- ALCO workflow
- vendor review
- compliance evidence
- AI agent output
- audit trail

## Dispatch Truth Statement

The Banking cartridge is accepted when it can represent, explain, execute, monitor, and improve the operational reality of a bank.
