# Banking Workflow Library

## Purpose

This document defines reusable banking workflows for Dispatch.

## Universal Workflow Schema

- workflow_id
- workflow_name
- business_domain
- owner
- trigger
- required_objects
- required_documents
- agents
- human_participants
- decision_points
- approvals
- rules
- policies
- controls
- KPIs
- output
- evidence
- audit_history

## Executive Workflows

- Strategic Planning
- Annual Budget
- Board Packet
- Executive Committee
- M&A Review
- Capital Planning
- Technology Roadmap
- Risk Appetite Review
- Policy Approval

## Customer Workflows

- Customer Onboarding
- Account Opening
- KYC Review
- Business Account Opening
- Beneficial Ownership Review
- Complaint Management
- Service Recovery
- Customer Offboarding

## Deposit Workflows

- Deposit Product Launch
- Deposit Pricing Review
- Certificate Maturity Review
- Deposit Retention Campaign
- Dormant Account Review
- Escheatment

## Lending Workflows

- Consumer Loan Origination
- Mortgage Origination
- Commercial Loan Origination
- Credit Approval
- Loan Closing
- Portfolio Monitoring
- Annual Review
- Collections
- Workout
- Charge-Off
- Recovery

## Payments Workflows

- Wire Approval
- ACH Exception
- Fraud Alert
- Card Dispute
- Positive Pay Exception
- Reconciliation Break
- Settlement Review

## Treasury Workflows

- Daily Liquidity Review
- ALCO Package
- Deposit Pricing
- Investment Purchase
- Borrowing Request
- Contingency Funding

## Compliance Workflows

- Policy Review
- Control Testing
- Audit Response
- Exam Preparation
- SAR Review
- OFAC Alert
- Complaint Investigation
- Vendor Review

## Technology Workflows

- Vendor Selection
- Security Review
- Change Management
- Incident Response
- Connector Deployment
- Core Conversion
- AI Agent Deployment

## Dispatch Truth Statement

Workflows convert institutional knowledge into repeatable execution. Every banking activity that occurs more than once should eventually become a Dispatch workflow.
