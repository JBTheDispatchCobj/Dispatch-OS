# Banking Cartridge Implementation Guide

## Purpose

This guide defines how to implement the Banking Operating Framework in Dispatch.

## Phase 1 — Institution Setup

- create Bank object
- identify charter
- identify regulators
- define organizational structure
- add executives
- add board and committees
- map departments
- set security and permissions
- set reporting cadence

## Phase 2 — Product & Customer Setup

- define customer segments
- define products
- define accounts
- define loan types
- define treasury services
- define payment channels
- load sample or production objects

## Phase 3 — Technology Setup

- map core banking system
- map digital banking
- map LOS
- map CRM
- map GL
- map payments
- map document systems
- configure connectors
- configure AI access

## Phase 4 — Knowledge Packs

Install:

- Banking Foundation
- Deposit Operations
- Lending
- Payments
- Treasury & ALM
- Risk & Compliance
- Technology & Vendor
- AI Governance

## Phase 5 — Agent Deployment

Start with:

- Executive Briefing Agent
- Board Packet Writer
- ALCO Analyst
- Credit Memo Writer
- Vendor Risk Reviewer
- Compliance Monitor
- Liquidity Monitor
- Data Quality Agent

## Phase 6 — Workflow Activation

Activate:

- board packet
- ALCO package
- account opening
- commercial loan origination
- vendor review
- exam preparation
- payments exception
- policy review

## Phase 7 — Dashboards

Configure:

- board dashboard
- CEO dashboard
- CFO dashboard
- lending dashboard
- treasury dashboard
- compliance dashboard
- technology dashboard
- vendor dashboard
- AI operations dashboard

## Demo Script

1. Open bank profile.
2. Show organizational map.
3. Show customer/product map.
4. Show technology stack.
5. Show board dashboard.
6. Generate executive briefing.
7. Generate ALCO summary.
8. Generate vendor risk summary.
9. Run credit memo workflow.
10. Show audit trail.

## Dispatch Truth Statement

Implementation begins by representing the institution accurately. Software configuration is secondary to operational truth.
