# Banking Agent Workforce

## Purpose

This file defines the canonical AI agent workforce for banking operations.

## Universal Agent Schema

- agent_id
- agent_name
- business_function
- department
- authority_level
- human_owner
- supported_workflows
- object_access
- connector_access
- knowledge_packs
- policies
- rules
- KPIs
- escalation_rules
- memory_scope
- audit_requirements

## Executive Agents

- CEO Strategic Advisor
- CFO Financial Analyst
- COO Operations Advisor
- CRO Risk Advisor
- CCO Compliance Advisor
- CIO Technology Advisor
- Board Packet Writer
- Executive Briefing Agent
- Strategic Planning Agent

## Customer & Growth Agents

- Customer Onboarding Agent
- Relationship Manager Prep Agent
- Deposit Growth Agent
- Product Recommendation Agent
- Complaint Resolution Agent
- Customer Retention Agent
- Campaign Analyst

## Lending Agents

- Consumer Underwriter
- Mortgage Underwriter
- Commercial Underwriter
- Credit Analyst
- Credit Memo Writer
- Collateral Analyst
- Covenant Monitor
- Portfolio Review Agent
- Collections Agent
- Workout Advisor

## Treasury Agents

- Liquidity Monitor
- ALCO Analyst
- Deposit Pricing Advisor
- Investment Portfolio Analyst
- Funding Advisor
- Payments Exception Agent
- Wire Review Agent

## Risk & Compliance Agents

- BSA Analyst
- AML Monitor
- OFAC Alert Agent
- Fair Lending Analyst
- Complaint Investigator
- Vendor Risk Reviewer
- Exam Prep Agent
- Evidence Collector
- Policy Writer
- Control Tester
- Cyber Risk Analyst

## Technology Agents

- Vendor Analyst
- Core System Analyst
- Connector Manager
- Security Review Agent
- Incident Response Agent
- Data Quality Agent
- AI Governance Agent

## Agent Governance

Agents may recommend, draft, summarize, monitor, classify, route, and prepare materials.

Agents require human approval for:

- credit decisions
- adverse action
- regulatory filings
- policy changes
- wire/payment approvals above threshold
- customer-facing commitments
- board materials
- vendor contracts
- investment decisions

## Dispatch Truth Statement

Banking agents are governed digital operators, not generic assistants. They act within roles, workflows, permissions, policies, controls, and audit requirements.
