# Lending & Credit Operations

## Purpose

This document defines the universal banking lending and credit operating model.

## Lending Product Types

- Consumer Loan
- Auto Loan
- Credit Card
- Personal Loan
- Home Equity
- Mortgage
- Commercial Real Estate
- Commercial & Industrial
- Equipment Finance
- Construction Loan
- SBA Loan
- Agriculture Loan
- Line of Credit
- Asset-Based Loan
- Warehouse Facility
- Syndicated Loan
- Participation Loan
- Letter of Credit
- Bridge Loan
- Working Capital Facility

## Universal Loan Object

Fields:

- loan_id
- borrower_id
- co_borrowers
- guarantors
- product_type
- purpose
- original_amount
- current_balance
- availability
- maturity
- amortization
- rate_index
- spread
- current_rate
- fees
- collateral
- LTV
- DSCR
- DTI
- risk_grade
- credit_score
- covenants
- approval_authority
- conditions
- servicing_status
- delinquency_status
- workout_status
- documents
- policies
- exceptions

## Credit Lifecycle

Lead → Application → Data Collection → Underwriting → Risk Rating → Pricing → Approval → Documentation → Closing → Funding → Boarding → Servicing → Monitoring → Renewal → Workout → Payoff/Charge-Off → Archive

## Underwriting Categories

- borrower capacity
- cash flow
- collateral
- credit history
- capital
- conditions
- character
- industry
- management
- market
- repayment source
- secondary repayment source
- guarantor support
- policy fit
- risk-adjusted return

## Credit Approval Model

Approval authority may depend on:

- loan size
- borrower exposure
- risk grade
- exception count
- collateral type
- product type
- industry concentration
- regulatory classification
- officer authority
- committee authority
- board authority

## Credit Documents

- application
- credit memo
- financial statements
- tax returns
- borrowing base
- collateral schedule
- appraisal
- title
- environmental
- guarantee
- loan agreement
- promissory note
- security agreement
- UCC
- covenants
- closing checklist
- funding authorization

## Portfolio Management

Dispatch monitors:

- delinquency
- renewals
- annual reviews
- covenant compliance
- collateral value
- borrowing base
- risk grade migration
- concentration
- watch list
- criticized/classified assets
- nonaccrual
- charge-off
- recovery

## Credit KPIs

- applications
- approvals
- funded volume
- average loan size
- portfolio yield
- weighted average risk grade
- approval time
- funding time
- exception rate
- delinquency
- nonperforming loans
- charge-offs
- recoveries
- covenant breaches
- annual review completion
- concentration limits

## AI Opportunities

- credit memo generation
- spreading financial statements
- covenant monitoring
- collateral review
- risk rating support
- annual review drafting
- watchlist detection
- portfolio trend analysis
- borrower meeting prep
- loan policy exception detection
- concentration monitoring

## Dispatch Truth Statement

Credit is not a decision point. It is a lifecycle of evidence, judgment, structure, monitoring, and repayment intelligence.
