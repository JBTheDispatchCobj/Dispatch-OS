# Banking Schema & Object Standard

## Purpose

This document defines the canonical banking objects and inherited schema used by all banking-related cartridges.

## Universal Banking Object

Every banking object inherits:

- object_id
- object_type
- institution_id
- business_unit_id
- department_id
- canonical_name
- display_name
- description
- owner
- custodian
- lifecycle_state
- status
- version
- created_at
- modified_at
- effective_date
- review_date
- relationships
- documents
- policies
- controls
- workflows
- tasks
- evidence
- telemetry
- audit_history
- source_system
- connector_references
- security_classification
- permissions
- AI_context
- knowledge_links

## Banking Institution Objects

- Bank
- Community Bank
- Regional Bank
- Money Center Bank
- National Bank
- State Bank
- Savings Bank
- Industrial Bank
- Trust Company
- Private Bank
- Digital Bank
- Neobank
- Bank Holding Company
- Financial Holding Company
- Subsidiary Bank
- Branch
- Operations Center
- Call Center
- Treasury Center
- Lending Office

## Regulatory Identity Fields

- charter_type
- charter_number
- primary_regulator
- secondary_regulator
- deposit_insurer
- state_jurisdiction
- holding_company
- legal_entity_identifier
- FDIC_certificate_number
- RSSD_ID
- routing_number
- tax_id
- call_report_filer
- report_cycle
- enforcement_status

## Customer Objects

- Customer
- Household
- Business Customer
- Commercial Borrower
- Depositor
- Guarantor
- Authorized Signer
- Beneficial Owner
- Trustee
- Fiduciary
- Investor
- Wealth Client
- Prospect
- Lead
- Relationship
- Account Party

## Product Objects

- Account
- Deposit Account
- Checking
- Savings
- Money Market
- Certificate
- Loan
- Mortgage
- Commercial Loan
- Line of Credit
- Credit Card
- Debit Card
- Treasury Service
- Merchant Service
- Investment Product
- Trust Service
- Insurance Referral
- Digital Wallet

## Operational Objects

- Workflow
- Case
- Task
- Queue
- Approval
- Exception
- Escalation
- Policy
- Procedure
- Control
- Evidence
- Incident
- Service Request
- Complaint
- Fraud Alert
- Risk Assessment
- Board Packet
- Regulatory Filing
- Audit Finding
- Corrective Action

## Technology Objects

- Core Banking System
- Digital Banking Platform
- LOS
- CRM
- GL
- Payment Processor
- Card Processor
- Data Warehouse
- BI Platform
- Identity Provider
- Fraud Platform
- AML Platform
- Document System
- AI Agent
- Connector
- API
- Webhook
- Data Feed

## Object Mapping Rule

A banking object should never be modeled as a vendor-specific record first. It must be modeled as a canonical banking object with vendor/system identifiers attached as external references.

## Dispatch Truth Statement

The Banking Object Standard ensures that a customer, account, transaction, branch, loan, payment, policy, vendor, and AI agent all operate in the same institutional language.
