# FS-4001 Banking Operating Framework

Version: 1.0  
Owner: Auric Works  
Library: Dispatch Institutional Intelligence Library  
Domain: Banking / Financial Institutions  
Status: Production Knowledge Volume

## Purpose

This volume defines the canonical Banking Operating Framework used by Dispatch OS and the Auric Institutional Intelligence Network.

It is the broad banking reference layer that sits underneath more specialized cartridges such as Credit Unions, Commercial Banking, Mortgage, Private Credit, Wealth Management, Insurance, Capital Markets, and Regulation & Reporting.

## Scope

This volume covers:

- banking institution types
- operating model
- departments
- governance
- customers
- accounts
- deposits
- lending
- payments
- treasury
- finance
- risk
- compliance
- technology
- vendors
- workflows
- KPIs
- AI agents
- data sources
- connectors
- implementation guidance

## Strategic Lens

A bank is not merely a chartered institution with accounts and loans.

A bank is a regulated operating system for trust, capital, payments, liquidity, credit, risk, compliance, financial products, customer relationships, and institutional knowledge.

Dispatch models banks as living operational systems.  
Auric maps the market around them.

## Relationship to Other Volumes

This volume provides shared banking primitives for:

- FS-4002 Credit Unions
- FS-4003 Commercial Banking
- FS-4004 Mortgage
- FS-4005 Private Credit
- FS-4008 Capital Markets
- FS-4009 Wealth Management
- FS-4014 Regulation, Reporting & Examination

## Completion Standard

This volume is complete when a banking institution can be represented inside Dispatch through:

- canonical objects
- inherited attributes
- relationships
- operating workflows
- departments
- products
- documents
- KPIs
- policies
- risk domains
- compliance requirements
- connector priorities
- AI agents
- dashboards
- implementation paths
- acceptance tests
