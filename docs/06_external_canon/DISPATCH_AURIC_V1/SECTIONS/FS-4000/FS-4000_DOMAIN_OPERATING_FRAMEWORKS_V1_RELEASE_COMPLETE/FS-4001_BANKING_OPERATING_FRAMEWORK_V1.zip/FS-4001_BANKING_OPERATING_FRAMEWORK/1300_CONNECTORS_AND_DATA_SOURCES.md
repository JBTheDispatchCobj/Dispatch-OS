# Connectors & Data Sources

## Purpose

This document defines banking connector priorities and data source categories.

## Tier 1 Connectors

- Microsoft 365
- Google Workspace
- SharePoint
- OneDrive
- Google Drive
- Email
- Calendar
- CSV Import
- Excel Import
- SQL Database
- Data Warehouse
- AI Provider
- Web/Research Source
- Document Management
- CRM
- GL / Accounting

## Tier 2 Connectors

- Core Banking System
- Digital Banking Platform
- LOS
- Mortgage LOS
- Card Processor
- Payment Processor
- Fraud Platform
- AML Platform
- BI Platform
- Contact Center
- Vendor Management Platform

## Tier 3 Connectors

- Fed payment systems
- SWIFT
- ACH operator files
- check processing
- merchant acquiring
- treasury systems
- trust/custody systems
- wealth platforms
- HRIS
- LMS
- board portal
- audit management

## Data Source Types

- API
- webhook
- flat file
- CSV
- Excel
- PDF
- email
- SFTP
- database
- data warehouse
- screen export
- manual upload
- public web
- regulatory filing

## Connector Requirements

Every connector must:

- authenticate securely
- preserve lineage
- map to canonical objects
- support incremental sync where possible
- emit telemetry
- expose errors
- support retry
- enforce permissions
- log audit history
- avoid storing business logic

## Priority Objects to Sync

- customers
- accounts
- transactions
- loans
- deposits
- payments
- vendors
- policies
- documents
- GL
- KPIs
- incidents
- cases
- tasks
- meetings
- emails
- reports
- board packets
- regulatory filings

## Dispatch Truth Statement

Connectors make external systems legible to Dispatch. The goal is not data ingestion for its own sake; the goal is institutional understanding.
