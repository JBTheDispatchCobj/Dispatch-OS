# Banking Operating Model

## Definition

A banking institution is a regulated financial intermediary that accepts deposits, extends credit, facilitates payments, manages liquidity, safeguards funds, and supports economic activity through trusted financial infrastructure.

Dispatch models banking institutions across ten operating layers.

## Operating Layers

### 1. Charter & Regulatory Layer

Defines legal authority, permissible activities, regulatory obligations, supervisory regime, reporting cadence, and governance expectations.

### 2. Governance Layer

Includes board, committees, executive leadership, internal audit, risk appetite, policy authority, and strategic oversight.

### 3. Customer Relationship Layer

Captures consumer, household, commercial, wealth, fiduciary, treasury, and institutional relationships.

### 4. Product & Balance Sheet Layer

Includes deposits, loans, investments, securities, treasury products, credit facilities, and fee-based services.

### 5. Payments & Transaction Layer

Includes ACH, wires, card rails, RTP, FedNow, checks, ATM, POS, merchant acquiring, settlement, returns, disputes, and fraud operations.

### 6. Credit & Lending Layer

Includes origination, underwriting, approval, funding, servicing, portfolio management, collections, workout, charge-off, and recovery.

### 7. Treasury & ALM Layer

Includes liquidity, funding, cost of funds, capital, investment portfolio, interest rate risk, stress testing, ALCO, and balance sheet strategy.

### 8. Risk & Compliance Layer

Includes enterprise risk, operational risk, credit risk, vendor risk, BSA/AML, consumer compliance, cybersecurity, model risk, regulatory reporting, and exams.

### 9. Technology & Vendor Layer

Includes core systems, digital channels, data, APIs, identity, infrastructure, cybersecurity, vendor contracts, and integration architecture.

### 10. Intelligence & Execution Layer

Includes dashboards, KPIs, AI agents, knowledge packs, workflow automation, evidence, audit history, recommendations, and institutional memory.

## Canonical Banking Departments

- Board & Governance
- Executive Office
- Finance
- Accounting
- Treasury
- ALM
- Retail Banking
- Branch Operations
- Contact Center
- Digital Banking
- Commercial Banking
- Business Banking
- Mortgage
- Consumer Lending
- Credit Administration
- Loan Operations
- Loan Servicing
- Collections
- Special Assets
- Wealth
- Trust
- Risk Management
- Compliance
- BSA/AML
- Internal Audit
- Technology
- Cybersecurity
- Data & Analytics
- Vendor Management
- Human Resources
- Marketing
- Operations
- Facilities
- Legal

## Strategic Banking Themes

Dispatch tracks each theme as an object:

- balance sheet growth
- deposit strategy
- loan growth
- credit quality
- margin management
- liquidity resilience
- cost reduction
- branch optimization
- digital transformation
- commercial expansion
- treasury services growth
- mortgage strategy
- payments modernization
- fraud prevention
- vendor consolidation
- core modernization
- AI adoption
- regulatory readiness
- customer experience
- merger and acquisition readiness

## Dispatch Truth Statement

A bank is not a set of accounts. It is an institutional system for converting trust, capital, liquidity, risk, technology, and governance into financial services.
