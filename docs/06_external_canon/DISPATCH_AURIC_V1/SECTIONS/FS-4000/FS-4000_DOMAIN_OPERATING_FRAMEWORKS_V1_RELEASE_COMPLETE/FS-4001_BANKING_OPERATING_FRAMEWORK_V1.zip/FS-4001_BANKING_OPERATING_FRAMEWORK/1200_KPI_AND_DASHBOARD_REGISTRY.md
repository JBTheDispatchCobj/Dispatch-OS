# KPI & Dashboard Registry

## Purpose

This document defines canonical banking KPIs and dashboard layers.

## Board KPIs

- asset growth
- deposit growth
- loan growth
- ROA
- ROE
- net interest margin
- efficiency ratio
- capital ratio
- liquidity
- credit quality
- compliance findings
- audit findings
- technology risk
- strategic initiative progress

## Executive KPIs

- revenue growth
- expense growth
- forecast accuracy
- budget variance
- operating efficiency
- customer growth
- product adoption
- risk trend
- vendor performance
- innovation velocity
- AI utilization

## Financial KPIs

- total assets
- total liabilities
- equity/capital
- net income
- pre-tax pre-provision income
- NIM
- non-interest income
- non-interest expense
- provision
- allowance
- cost of funds

## Deposit KPIs

- deposit growth
- DDA growth
- commercial deposits
- average balance
- cost of deposits
- deposit beta
- retention
- uninsured exposure
- concentration
- maturity runoff

## Lending KPIs

- originations
- funded volume
- approval rate
- portfolio yield
- delinquency
- charge-offs
- recoveries
- NPLs
- criticized/classified loans
- exceptions
- annual reviews

## Treasury KPIs

- liquidity ratio
- borrowing capacity
- cash position
- investment yield
- duration
- rate sensitivity
- ALM exposure
- stress test result

## Payments KPIs

- transaction volume
- transaction value
- exception rate
- return rate
- fraud loss
- dispute volume
- settlement failures
- interchange revenue

## Risk & Compliance KPIs

- open findings
- overdue remediation
- control effectiveness
- policy currency
- training completion
- SAR timeliness
- OFAC alerts
- complaint trend
- vendor reviews complete

## Technology KPIs

- uptime
- incidents
- MTTR
- connector health
- data quality
- API latency
- cyber incidents
- patch compliance
- AI utilization
- automation percentage

## Dashboard Layers

- Board Dashboard
- CEO Dashboard
- CFO Dashboard
- Treasury Dashboard
- Lending Dashboard
- Risk Dashboard
- Compliance Dashboard
- Technology Dashboard
- Customer Dashboard
- AI Operations Dashboard
- Vendor Dashboard

## Dispatch Truth Statement

KPIs are operational signals, not report decorations. Every KPI must connect to objects, workflows, owners, evidence, and recommended actions.
