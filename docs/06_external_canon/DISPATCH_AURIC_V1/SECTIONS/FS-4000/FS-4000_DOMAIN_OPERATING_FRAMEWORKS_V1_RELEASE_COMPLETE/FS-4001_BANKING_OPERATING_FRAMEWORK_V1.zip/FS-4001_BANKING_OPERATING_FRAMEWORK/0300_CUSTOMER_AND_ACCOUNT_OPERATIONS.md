# Customer & Account Operations

## Purpose

This document defines customer, household, business, account, and servicing operations for banking institutions.

## Customer Object

Fields:

- customer_id
- legal_name
- preferred_name
- customer_type
- household_id
- business_id
- tax_id_reference
- KYC_status
- risk_rating
- segment
- branch
- relationship_manager
- products
- accounts
- loans
- cards
- communications
- consents
- complaints
- service_cases
- profitability
- lifetime_value
- digital_adoption
- next_best_action

## Household Object

Fields:

- household_id
- primary_customer
- members
- shared_accounts
- loans
- beneficiaries
- trusts
- businesses
- combined_deposits
- combined_loans
- financial_goals
- retention_risk
- relationship_score

## Business Customer Object

Fields:

- business_id
- legal_name
- DBA
- entity_type
- NAICS
- revenue
- employees
- owners
- beneficial_owners
- guarantors
- deposit_products
- credit_products
- treasury_services
- merchant_services
- payroll
- tax_documents
- financial_statements
- relationship_manager
- risk_rating

## Account Object

Fields:

- account_id
- account_type
- owner
- authorized_signers
- balance
- available_balance
- rate
- fees
- opened_date
- status
- restrictions
- statement_cycle
- interest_accrual
- overdraft_status
- risk_flags
- source_system
- related_cards
- related_payments

## Account Opening Workflow

Lead → Identity Verification → Customer Due Diligence → Eligibility → Product Selection → Disclosures → Account Creation → Funding → Digital Enrollment → Card/Checks → Welcome → Monitoring

## Servicing Workflows

- address change
- signer change
- beneficiary update
- dispute
- statement request
- fee waiver
- account closure
- overdraft review
- fraud investigation
- dormant account review
- escheatment

## Customer KPIs

- customer growth
- household growth
- retention
- churn
- products per customer
- digital active users
- branch utilization
- contact center volume
- complaint rate
- resolution time
- customer profitability
- deposit balances
- loan balances
- next-best-action conversion

## AI Opportunities

- customer 360 summary
- relationship manager briefing
- dormant account detection
- deposit attrition prediction
- product recommendation
- complaint summarization
- service case routing
- identity verification support
- document request automation
- suspicious account behavior detection

## Dispatch Truth Statement

A customer is not a CIF record. A customer is a relationship object that connects identity, accounts, behaviors, risk, communications, products, and institutional value.
