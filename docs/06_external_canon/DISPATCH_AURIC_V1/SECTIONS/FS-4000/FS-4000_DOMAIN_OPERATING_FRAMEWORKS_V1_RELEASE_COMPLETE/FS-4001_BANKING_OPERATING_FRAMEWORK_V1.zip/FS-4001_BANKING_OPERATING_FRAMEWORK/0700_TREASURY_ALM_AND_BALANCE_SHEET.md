# Treasury, ALM & Balance Sheet Management

## Purpose

This document defines bank treasury, asset-liability management, liquidity, funding, capital, and investment operations.

## Treasury Domains

- cash position
- liquidity
- funding
- investments
- capital
- ALM
- interest rate risk
- deposit pricing
- loan pricing
- borrowing
- correspondent relationships
- Fed access
- FHLB access
- stress testing
- contingency funding
- securities portfolio

## Balance Sheet Objects

- Asset
- Liability
- Equity
- Cash
- Deposit
- Loan
- Investment Security
- Borrowing
- Capital
- Allowance
- Interest Income
- Interest Expense
- Duration
- Liquidity Position
- Funding Source
- Gap Report
- ALM Scenario

## ALCO Object

Fields:

- committee_id
- members
- authority
- meeting_cadence
- policies
- reports
- liquidity_limits
- interest_rate_risk_limits
- investment_policy
- funding_plan
- deposit_pricing_actions
- loan_pricing_actions
- decisions
- action_items

## ALCO Package

Sections:

- executive summary
- balance sheet trends
- loan growth
- deposit growth
- margin analysis
- investment portfolio
- liquidity
- funding sources
- cost of funds
- interest rate risk
- stress scenarios
- policy exceptions
- recommended actions

## Liquidity Lifecycle

Daily Position → Forecast → Stress Scenario → Funding Need → Source Selection → Approval → Execution → Reporting → Review

## Funding Sources

- deposits
- wholesale funding
- FHLB borrowings
- Fed discount window
- brokered deposits
- correspondent lines
- repurchase agreements
- securitization
- loan sales
- capital issuance

## Treasury KPIs

- net interest margin
- cost of funds
- loan-to-deposit ratio
- liquidity coverage
- borrowing capacity
- investment yield
- duration
- gap ratio
- deposit beta
- sensitivity to rates
- capital ratio
- unrealized gain/loss
- cash position
- stress liquidity days

## AI Opportunities

- ALCO package generation
- liquidity forecasting
- deposit runoff prediction
- interest rate scenario analysis
- pricing recommendations
- investment portfolio summary
- funding source prioritization
- stress test narrative
- board treasury summary

## Dispatch Truth Statement

Treasury is where strategy becomes survivability. Dispatch links liquidity, capital, rates, deposits, loans, investments, and risk into one continuously monitored operating model.
