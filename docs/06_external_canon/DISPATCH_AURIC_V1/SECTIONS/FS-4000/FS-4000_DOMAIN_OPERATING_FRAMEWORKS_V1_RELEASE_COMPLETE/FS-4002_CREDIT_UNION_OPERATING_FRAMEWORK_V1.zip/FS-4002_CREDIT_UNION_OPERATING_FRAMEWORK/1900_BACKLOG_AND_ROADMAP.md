# Backlog & Roadmap

## Purpose

This file defines remaining build work after Volume FS-4002 v1.

## Priority 1 — Data Model

- implement Credit Union object extensions
- implement Member, Household, Business Member
- implement Board and Committee objects
- implement Product object taxonomy
- implement Loan object taxonomy
- implement Vendor object taxonomy
- implement Policy, Control, Evidence objects
- implement Institution Profile object

## Priority 2 — Workflows

- board packet workflow
- exam prep workflow
- vendor review workflow
- commercial loan workflow
- member onboarding workflow
- daily liquidity workflow
- innovation pilot workflow
- policy review workflow

## Priority 3 — Agents

- Executive Briefing Agent
- Board Packet Writer
- Credit Memo Writer
- Vendor Risk Reviewer
- Exam Prep Agent
- Liquidity Monitor
- Innovation Scout
- Policy Writer
- Evidence Collector
- Technology Analyst

## Priority 4 — Dashboards

- board dashboard
- CEO dashboard
- CFO dashboard
- lending dashboard
- treasury dashboard
- compliance dashboard
- vendor dashboard
- innovation dashboard
- AI operations dashboard

## Priority 5 — Connectors

- Microsoft 365
- Google Workspace
- SharePoint
- document storage
- email/calendar
- CSV import
- GL import
- core export parser
- CRM integration
- AI provider
- web/source ingestion

## Priority 6 — Knowledge Packs

- Credit Union Foundation
- NCUA Exam
- Board Governance
- Lending
- Treasury
- Compliance
- Vendor Management
- Innovation
- AI Governance

## Priority 7 — Auric Intelligence

- institution profile schema
- executive profile schema
- vendor profile schema
- technology stack map
- relationship graph
- market signal ingestion
- innovation opportunity detection
- cooperative network mapping

## Priority 8 — Production Hardening

- permissions
- audit
- tenant isolation
- evidence lineage
- version control
- error handling
- automated tests
- documentation

## Immediate Sprint Tasks

1. Load this volume into repo.
2. Generate JSON/YAML registries from objects.
3. Create test fixture institution.
4. Create sample board packet.
5. Create sample vendor review.
6. Create sample commercial credit memo.
7. Create sample liquidity dashboard.
8. Create sample innovation pilot.
9. Wire agents to workflows.
10. Run acceptance tests.

## Dispatch Truth Statement

The roadmap should not expand architecture. It should convert this knowledge volume into executable product assets.
