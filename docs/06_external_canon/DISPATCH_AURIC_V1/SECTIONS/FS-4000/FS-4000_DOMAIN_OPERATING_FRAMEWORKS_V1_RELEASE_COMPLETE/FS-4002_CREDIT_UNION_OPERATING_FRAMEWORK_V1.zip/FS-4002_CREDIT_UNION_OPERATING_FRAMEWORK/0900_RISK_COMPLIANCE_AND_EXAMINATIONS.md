# Risk, Compliance & Examinations

## Purpose

This file defines risk, compliance, regulatory, audit, and examination operations for credit unions inside Dispatch.

## Risk Domains

- credit risk
- liquidity risk
- interest rate risk
- operational risk
- technology risk
- cybersecurity risk
- vendor risk
- fraud risk
- compliance risk
- reputation risk
- strategic risk
- model risk
- AI risk
- concentration risk
- business continuity risk

## Compliance Domains

- BSA
- AML
- OFAC
- KYC
- KYB
- CDD
- EDD
- SAR
- CTR
- Fair Lending
- HMDA
- TRID
- RESPA
- TILA
- UDAAP
- GLBA
- Privacy
- Vendor Management
- Complaint Management
- Records Retention
- AI Governance

## Risk Object

Fields:

- risk_id
- category
- description
- owner
- probability
- impact
- velocity
- inherent_risk
- controls
- residual_risk
- mitigation
- review_date
- related_objects
- related_policies
- related_regulations
- related_workflows
- evidence

## Control Object

Fields:

- control_id
- control_type
- objective
- owner
- frequency
- evidence
- testing
- effectiveness
- exceptions
- failures
- remediation

## Examination Lifecycle

Notice → Request List → Evidence Collection → Management Prep → Examiner Interviews → Fieldwork → Findings → Management Response → Corrective Action → Board Reporting → Validation → Closure → Knowledge Archive

## Exam Package

- institution profile
- governance
- financials
- risk profile
- lending reports
- liquidity reports
- investment reports
- compliance program
- BSA/AML evidence
- audit reports
- board minutes
- committee minutes
- policies
- procedures
- vendor risk
- technology
- cybersecurity
- corrective actions
- management responses

## Compliance Workflows

Policy Review → Control Mapping → Evidence Collection → Testing → Findings → Remediation → Validation → Reporting → Archive

## Risk KPIs

- open findings
- overdue findings
- control effectiveness
- policy currency
- training completion
- exam readiness
- audit readiness
- vendor reviews complete
- SAR timeliness
- OFAC alerts
- complaint trends
- cybersecurity incidents
- residual risk trend
- AI governance score

## AI Agents

- Chief Compliance Advisor
- BSA Analyst
- OFAC Monitor
- Exam Prep Agent
- Evidence Collector
- Control Tester
- Policy Writer
- Regulatory Change Monitor
- Vendor Risk Reviewer
- Complaint Investigator
- Cyber Risk Analyst
- AI Governance Officer

## Dispatch Truth Statement

Compliance is not a periodic scramble before an exam. It is continuous operational evidence generation connected to policies, controls, workflows, risks, and institutional knowledge.
