# Credit Union Knowledge Packs

## Purpose

Knowledge Packs are installable intelligence assets. Each pack contains terminology, objects, workflows, rules, KPIs, documents, citations, playbooks, and agent context.

## Required Knowledge Packs

### Credit Union Foundation Pack

Includes cooperative finance principles, credit union terminology, institution types, governance model, member ownership, common departments, basic product map, core regulatory context.

### NCUA Examination Pack

Includes exam lifecycle, call report objects, evidence checklist, CAMELS mapping, board reporting, management response templates, corrective action workflows.

### Board Governance Pack

Includes board roles, committee structures, agenda templates, board packet templates, resolution templates, minutes framework, KPI dashboards.

### Lending Pack

Includes consumer lending, mortgage, commercial lending, credit memo structure, underwriting workflows, approval matrices, annual review, collections and workout.

### Treasury & ALM Pack

Includes liquidity, ALCO, deposit pricing, investment portfolio, interest rate risk, stress scenarios, daily liquidity review.

### Compliance Pack

Includes BSA/AML, OFAC, KYC/KYB, vendor management, privacy, complaints, fair lending, evidence management.

### Vendor Management Pack

Includes vendor lifecycle, security review, compliance review, renewal management, risk scoring, exit planning, SOC review.

### Innovation Pack

Includes innovation committee, vendor discovery, pilot framework, business case, ROI measurement, implementation playbook, partnership and investment review.

### AI Governance Pack

Includes agent registry, model registry, confidence thresholds, human approval, prompt governance, audit trails, sensitive decision rules.

## Knowledge Pack Schema

- pack_id
- name
- domain
- purpose
- objects
- relationships
- workflows
- rules
- KPIs
- documents
- agents
- connectors
- policies
- acceptance_tests
- version
- owner

## Dispatch Truth Statement

Knowledge Packs are how Dispatch distributes institutional expertise. They turn domain knowledge into reusable operating intelligence.
