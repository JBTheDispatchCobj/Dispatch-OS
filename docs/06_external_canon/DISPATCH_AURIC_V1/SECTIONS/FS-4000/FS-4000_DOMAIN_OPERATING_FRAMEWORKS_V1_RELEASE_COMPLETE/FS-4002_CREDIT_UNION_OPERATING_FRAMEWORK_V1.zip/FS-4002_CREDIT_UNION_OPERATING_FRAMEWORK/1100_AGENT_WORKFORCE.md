# Credit Union Agent Workforce

## Purpose

This file defines the AI agent workforce for the Credit Union cartridge.

## Universal Agent Fields

- agent_id
- agent_name
- business_function
- department
- authority_level
- human_owner
- supported_workflows
- required_objects
- required_knowledge_packs
- connector_access
- permissions
- escalation_rules
- KPIs
- cost_profile
- memory_scope
- audit_requirements

## Executive Agents

- CEO Strategic Advisor
- COO Operations Advisor
- CFO Financial Analyst
- CLO Lending Advisor
- CRO Risk Advisor
- CCO Compliance Advisor
- CIO Technology Advisor
- Chief Innovation Advisor
- Board Packet Writer
- Executive Briefing Agent

## Lending Agents

- Consumer Underwriter
- Mortgage Underwriter
- Commercial Underwriter
- Credit Analyst
- Credit Memo Writer
- Collateral Analyst
- Cash Flow Analyst
- Loan Processor
- Conditions Manager
- Credit Committee Coordinator
- Portfolio Manager
- Annual Review Agent
- Workout Officer

## Finance & Treasury Agents

- Controller Agent
- Month-End Close Agent
- ALCO Analyst
- Liquidity Monitor
- Forecast Analyst
- Budget Analyst
- Treasury Services Agent
- Wire Review Agent
- ACH Exception Agent

## Risk & Compliance Agents

- Exam Prep Agent
- Evidence Collector
- Policy Writer
- Control Tester
- BSA Analyst
- AML Monitor
- OFAC Monitor
- Complaint Investigator
- Vendor Risk Reviewer
- Cyber Risk Analyst
- AI Governance Agent

## Technology Agents

- Connector Manager
- Core System Analyst
- Digital Banking Analyst
- Vendor Portfolio Analyst
- Security Review Agent
- Data Quality Agent
- Implementation Planner
- Incident Response Agent

## Member & Growth Agents

- Member Onboarding Agent
- Member Retention Agent
- Deposit Growth Agent
- Business Member Scout
- Relationship Manager Prep Agent
- Campaign Analyst
- Service Recovery Agent
- Financial Wellness Agent

## Innovation Agents

- Innovation Scout
- Vendor Discovery Agent
- Business Case Writer
- Pilot Manager
- ROI Analyst
- Partnership Advisor
- Investment Opportunity Analyst
- Market Intelligence Agent

## Governance

Agents require human approval for credit decisions above configured thresholds, adverse action recommendations, regulatory submissions, board materials, policy changes, vendor approvals, member-impacting automated decisions, investment recommendations, and external communications where policy requires.

## Dispatch Truth Statement

Agents are not chatbots. They are governed digital staff with role definitions, memory, policies, permissions, workflows, and measurable outcomes.
