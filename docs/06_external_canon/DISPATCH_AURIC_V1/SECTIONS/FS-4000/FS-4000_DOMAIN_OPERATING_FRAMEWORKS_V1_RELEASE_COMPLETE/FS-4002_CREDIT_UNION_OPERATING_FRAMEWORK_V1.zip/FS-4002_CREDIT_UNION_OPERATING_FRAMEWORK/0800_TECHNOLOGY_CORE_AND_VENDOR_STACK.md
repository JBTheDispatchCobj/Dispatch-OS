# Technology, Core & Vendor Stack

## Purpose

This file defines the credit union technology ecosystem and how Dispatch models vendors, systems, integrations, and modernization.

## Technology Categories

- core processor
- digital banking
- mobile banking
- payments
- card processing
- LOS
- mortgage LOS
- CRM
- contact center
- document management
- digital signature
- accounting/GL
- data warehouse
- BI/analytics
- fraud
- AML
- identity
- cybersecurity
- vendor management
- marketing automation
- collections
- HRIS
- project management
- AI platform

## Core Processor Object

Fields:

- provider
- platform
- version
- hosted_model
- account_objects
- loan_objects
- transaction_objects
- GL_objects
- API_availability
- batch_windows
- integration_methods
- reporting_exports
- conversion_history
- contract_terms
- support_model
- operational_risk
- replacement_risk

## Major Core Providers

- Symitar
- Corelation Keystone
- Fiserv DNA
- Fiserv Premier
- Jack Henry
- FIS Horizon
- FIS IBS
- Temenos
- Mambu
- Thought Machine
- Finxact
- Nymbus

## Digital Banking Providers

- Alkami
- Q2
- Tyfone
- Narmi
- Mahalo
- Backbase
- Banno
- Apiture
- Lumin Digital
- MX

## Vendor Object

Fields:

- vendor_id
- vendor_name
- category
- products
- capabilities
- customers
- integrations
- APIs
- SOC_reports
- security_reviews
- contract
- renewal_date
- pricing
- support_model
- implementation_status
- incident_history
- relationship_owner
- risk_rating
- strategic_value
- replacement_options
- Dispatch_connector_status

## Vendor Lifecycle

Discovery → Qualification → Security Review → Compliance Review → Architecture Review → Business Case → Legal → Contract → Implementation → Production → Monitoring → Renewal → Expansion or Replacement

## Core Conversion Workflow

Business Case → Vendor Selection → Contract → Data Mapping → Integration Planning → Testing → Training → Conversion Weekend → Stabilization → Post-Conversion Audit → Knowledge Capture

## Technology KPIs

- uptime
- incident count
- resolution time
- vendor health
- API availability
- connector health
- digital adoption
- mobile adoption
- cost per member
- technical debt
- contract renewal risk
- implementation success
- AI readiness
- data quality
- cybersecurity score

## AI Agents

- CIO Advisor
- Technology Portfolio Analyst
- Vendor Risk Analyst
- Core Conversion Planner
- Connector Manager
- Cybersecurity Analyst
- Data Quality Agent
- Digital Banking Analyst
- Technology Roadmap Agent

## Dispatch Truth Statement

Technology inside a credit union is not a collection of vendors. It is the operating infrastructure through which member service, payments, lending, compliance, finance, and strategy are executed.
