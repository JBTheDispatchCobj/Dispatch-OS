# Member & Relationship Lifecycle

## Purpose

Credit unions are relationship institutions. Dispatch models the member as owner, customer, participant, borrower, depositor, and community node.

## Member Object

Fields:

- member_id
- member_number
- name
- household_id
- membership_date
- field_of_membership_basis
- status
- segment
- age_band
- geography
- employer
- products
- accounts
- loans
- cards
- digital_adoption
- service_history
- communication_preferences
- risk_flags
- profitability
- lifetime_value
- relationship_score
- community_links
- consent_records
- complaints
- opportunities
- next_best_action

## Household Object

Fields:

- household_id
- primary_member
- related_members
- shared_accounts
- shared_loans
- dependents
- business_entities
- wealth_relationships
- estate_relationships
- financial_goals
- household_value
- risk_flags

## Business Member Object

Fields:

- business_id
- legal_name
- DBA
- tax_id
- entity_type
- NAICS
- owners
- guarantors
- revenue
- employees
- deposits
- treasury_services
- loans
- merchant_services
- payroll
- insurance
- cash_management_needs
- relationship_manager
- risk_rating
- profitability
- growth_opportunities

## Member Lifecycle

Prospect → Eligibility → Application → Identity Verification → Membership Approval → Account Opening → Funding → Digital Enrollment → Product Expansion → Relationship Deepening → Retention → Dormancy → Reactivation or Closure

## Business Relationship Lifecycle

Prospect → Discovery → Deposit Need → Treasury Need → Credit Need → Business Case → Account Opening → Treasury Onboarding → Commercial Loan → Portfolio Management → Expansion → Strategic Relationship

## Relationship Events

- new account opened
- loan application submitted
- payment behavior changed
- digital login frequency changed
- direct deposit started/stopped
- complaint submitted
- service recovery event
- branch visit
- call center interaction
- email interaction
- campaign response
- business opportunity identified
- fraud event
- hardship event
- delinquency event
- cross-sell recommendation

## Relationship KPIs

- member growth
- member retention
- household penetration
- product penetration
- services per member
- direct deposit adoption
- digital banking adoption
- mobile app adoption
- loan penetration
- deposit growth
- business member growth
- net promoter score
- complaint rate
- service recovery rate
- relationship profitability
- lifetime value
- relationship density

## AI Opportunities

- next best action
- member retention prediction
- member profitability analysis
- household opportunity discovery
- dormant member reactivation
- complaint summarization
- business member cross-sell
- service recovery recommendation
- member financial wellness insights
- relationship manager prep
- meeting briefing
- campaign targeting
- deposit flight risk
- loan opportunity identification

## Dispatch Truth Statement

A member is not a customer record. A member is a relationship graph that connects people, accounts, loans, behaviors, communications, community, ownership, and institutional value.
