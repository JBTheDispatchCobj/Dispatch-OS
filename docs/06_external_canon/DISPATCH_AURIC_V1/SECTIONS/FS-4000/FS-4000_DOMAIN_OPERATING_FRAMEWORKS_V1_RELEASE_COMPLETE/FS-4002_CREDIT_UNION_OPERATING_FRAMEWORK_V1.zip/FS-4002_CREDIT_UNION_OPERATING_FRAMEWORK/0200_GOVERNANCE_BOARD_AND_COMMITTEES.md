# Governance, Board & Committees

## Governance Principle

The board governs. Management executes. Dispatch connects governance to operational evidence.

## Board Object

Fields:

- board_id
- institution_id
- board_name
- charter
- bylaws
- chair
- vice_chair
- secretary
- treasurer
- directors
- supervisory_committee
- meeting_cadence
- committees
- policies_owned
- resolutions
- strategic_plan
- risk_appetite
- audit_plan
- technology_plan
- innovation_plan
- AI_governance_position
- knowledge_repository

## Board Member Object

Fields:

- director_id
- name
- role
- term_start
- term_end
- independence
- committee_memberships
- expertise
- attendance
- education
- conflicts
- voting_history
- relationships
- knowledge_contributions
- strategic_interests

## Primary Committees

### Supervisory Committee

Responsibilities:

- audit oversight
- member account verification
- internal controls
- external audit coordination
- risk and compliance review
- issue escalation
- board reporting

### Credit Committee

Responsibilities:

- approve loans within authority
- review exceptions
- monitor credit policy
- review delinquencies
- evaluate concentrations
- approve workout actions where required

### ALCO

Responsibilities:

- liquidity
- interest rate risk
- investment portfolio
- deposit pricing
- loan pricing
- funding sources
- balance sheet strategy
- capital planning

### Audit Committee

Responsibilities:

- audit plan
- auditor engagement
- internal audit results
- findings
- remediation
- financial reporting controls

### Risk Committee

Responsibilities:

- enterprise risk profile
- risk appetite
- emerging risks
- cyber risk
- third-party risk
- operational resilience
- model risk
- AI risk

### Technology Committee

Responsibilities:

- technology roadmap
- core system decisions
- cybersecurity posture
- vendor dependencies
- data strategy
- AI enablement
- digital channel strategy

### Innovation Committee

Responsibilities:

- business problem intake
- vendor discovery
- pilot authorization
- ROI tracking
- fintech relationships
- strategic partnerships
- investment opportunities
- CUSO opportunities

### Investment Committee

Responsibilities:

- investment portfolio
- CUSO investments
- strategic investments
- credit union service investments
- liquidity-related investment decisions
- alternative investment review where permitted

## Governance Workflows

### Board Packet Workflow

Inputs:

- financial package
- CEO report
- risk dashboard
- compliance status
- lending dashboard
- liquidity report
- technology status
- innovation update
- audit findings
- proposed resolutions
- policy changes

Outputs:

- final board packet
- AI executive summary
- key decision list
- open questions
- resolutions
- meeting minutes
- follow-up tasks
- knowledge objects

### Resolution Workflow

Draft → Review → Committee Approval → Board Vote → Effective → Assigned → Monitored → Closed → Archived

### Policy Approval Workflow

Policy Owner Draft → Legal/Compliance Review → Executive Review → Committee Review → Board Approval → Publication → Training → Evidence Collection → Annual Review

## Board KPIs

- meeting attendance
- packet delivery timeliness
- policy currency
- open findings
- strategic initiative completion
- board education hours
- decision cycle time
- resolution completion rate
- risk trend
- innovation adoption
- executive goal achievement

## Board AI Agents

- Board Secretary
- Board Packet Writer
- Resolution Drafter
- Governance Analyst
- Risk Briefing Agent
- Compliance Briefing Agent
- Financial Summary Agent
- Technology Briefing Agent
- Innovation Briefing Agent
- Meeting Minutes Agent
- Follow-Up Task Agent

## Dispatch Truth Statement

Governance inside Dispatch is not meeting management. It is the permanent connection between authority, strategy, risk, evidence, decisions, and execution.
