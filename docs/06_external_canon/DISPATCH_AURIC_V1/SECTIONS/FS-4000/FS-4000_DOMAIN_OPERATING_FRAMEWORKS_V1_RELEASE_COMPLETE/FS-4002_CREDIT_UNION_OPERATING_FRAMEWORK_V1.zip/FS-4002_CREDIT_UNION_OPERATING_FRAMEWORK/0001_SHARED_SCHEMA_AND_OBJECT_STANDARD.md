# Shared Schema & Object Standard

## Purpose

This file defines the inherited object structure used by every Credit Union object in Dispatch.

No credit union-specific object may bypass the universal Dispatch object contract.

## Universal Object Fields

Every object inherits:

- object_id
- object_type
- canonical_name
- display_name
- aliases
- description
- institution_id
- workspace_id
- owner_id
- lifecycle_state
- status
- version
- created_at
- modified_at
- created_by
- modified_by
- effective_date
- review_date
- expiration_date
- relationships
- documents
- evidence
- policies
- controls
- workflows
- tasks
- communications
- meetings
- knowledge_links
- telemetry
- audit_history
- security_classification
- permissions
- tags
- labels
- embeddings
- ai_context
- connector_references
- external_ids
- source_systems

## Credit Union Extension Fields

Credit union objects may additionally include:

- charter_type
- charter_number
- field_of_membership
- regulator
- insurer
- call_report_cycle
- asset_size_band
- member_count
- branch_count
- employee_count
- core_processor
- digital_banking_platform
- corporate_credit_union
- league_membership
- CUSO_relationships
- CAMELS_profile
- net_worth_ratio
- loan_to_share_ratio
- delinquency_rate
- charge_off_rate
- liquidity_position
- innovation_readiness_score
- AI_readiness_score
- technology_maturity_score
- operational_maturity_score
- cooperative_participation_score

## Object Categories

### Institution Objects

- Credit Union
- Federal Credit Union
- State Chartered Credit Union
- Corporate Credit Union
- CUSO
- League
- Trade Association
- Regulator
- Vendor
- FinTech
- Sponsor Bank
- Payment Network
- Core Provider
- Digital Banking Provider
- Insurance Provider
- Investment Partner
- Community Partner

### People Objects

- Member
- Business Member
- Household
- Borrower
- Guarantor
- Depositor
- Board Member
- Supervisory Committee Member
- CEO
- CFO
- COO
- CLO
- CRO
- CCO
- CIO
- CTO
- Branch Manager
- Relationship Manager
- Loan Officer
- Processor
- Underwriter
- Collector
- Vendor Contact
- Examiner
- Regulator
- Attorney
- CPA
- Consultant

### Financial Product Objects

- Share Account
- Checking Account
- Money Market
- Certificate
- IRA
- HSA
- Business Deposit
- Escrow
- Custodial Account
- Consumer Loan
- Auto Loan
- Credit Card
- Mortgage
- HELOC
- Commercial Loan
- Commercial Real Estate Loan
- Construction Loan
- Equipment Loan
- SBA Loan
- Participation Loan
- Line of Credit
- Treasury Service
- Merchant Service
- Wealth Product
- Insurance Product

### Operational Objects

- Workflow
- Task
- Queue
- Approval
- Committee Decision
- Exception
- Policy
- Procedure
- Control
- Evidence
- Finding
- Corrective Action
- Member Case
- Service Request
- Fraud Alert
- Compliance Review
- Vendor Review
- Technology Review
- Board Packet
- Executive Brief
- Call Report Package
- Exam Package

### Technology Objects

- Core Processor
- Digital Banking Platform
- LOS
- CRM
- Accounting System
- GL
- Data Warehouse
- Business Intelligence Platform
- Identity Provider
- API
- Connector
- Payment Processor
- Card Processor
- Fraud Platform
- Document Management System
- AI Model
- Agent
- Knowledge Pack
- Dashboard

## Relationship Standard

Every object should define upstream dependencies, downstream dependencies, owner, approver, regulator, policy source, data source, workflow participation, AI agent visibility, reporting use, and evidence requirements.

## Lifecycle Standard

Default lifecycle:

Discovered → Registered → Validated → Active → Reviewed → Modified → Archived → Historical

For operational workflows:

Requested → Assigned → In Progress → Waiting → Escalated → Approved/Rejected → Completed → Reviewed → Archived

For vendors:

Identified → Evaluated → Approved → Contracted → Implemented → Production → Reviewed → Renewed/Replaced → Archived

## Dispatch Truth Statement

The shared schema allows a credit union, a core processor, a member, a loan, a policy, a board decision, a vendor, an AI agent, and a regulatory finding to be treated as first-class canonical objects inside the same operating system.
