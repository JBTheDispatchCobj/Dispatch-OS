# Data Sources & Connector Priorities

## Purpose

This file defines the data and integration priorities for the Credit Union cartridge.

## Source Categories

### Internal Systems

- core processor
- digital banking
- loan origination
- mortgage LOS
- CRM
- accounting/GL
- card processor
- ACH/wire platform
- fraud platform
- compliance platform
- document management
- board portal
- data warehouse
- BI
- helpdesk
- contact center
- email/calendar
- HRIS

### External Sources

- regulator publications
- call reports
- state regulator information
- league publications
- vendor websites
- fintech websites
- funding databases
- SEC filings
- UCC records
- corporate CU publications
- conference agendas
- press releases
- podcasts/interviews
- board/public documents where available

## Tier 1 Connectors

- Microsoft 365
- Google Workspace
- SharePoint
- core processor export/import
- accounting/GL
- CRM
- document storage
- calendar
- email
- Slack/Teams
- QuickBooks/NetSuite/Sage where applicable
- data warehouse
- OpenAI/Anthropic/AI provider
- web research connector

## Tier 2 Connectors

- Symitar
- Corelation
- Fiserv DNA
- Jack Henry
- Q2
- Alkami
- MeridianLink
- Encompass
- Salesforce
- HubSpot
- DocuSign
- Box
- Snowflake
- Power BI
- Tableau

## Tier 3 Connectors

- payment processors
- card processors
- fraud systems
- BSA/AML systems
- board portals
- HRIS
- LMS/training systems
- vendor risk tools
- security tools
- SOC report repositories

## Data Objects to Prioritize

- institution profile
- executive profile
- vendor profile
- product catalog
- workflow inventory
- policy library
- board packet
- loan pipeline
- member product relationships
- GL and financials
- liquidity
- KPI dashboard
- open findings
- vendor contracts
- technology stack
- meeting transcripts
- email intelligence

## Connector Acceptance Criteria

A connector is production-ready when it can authenticate securely, map source records to canonical objects, preserve lineage, sync incrementally, emit telemetry, support error recovery, honor permissions, produce audit history, expose AI context, and participate in workflows.

## Dispatch Truth Statement

Connectors are not integrations. They are the mechanism through which external systems become part of Dispatch's canonical institutional intelligence model.
