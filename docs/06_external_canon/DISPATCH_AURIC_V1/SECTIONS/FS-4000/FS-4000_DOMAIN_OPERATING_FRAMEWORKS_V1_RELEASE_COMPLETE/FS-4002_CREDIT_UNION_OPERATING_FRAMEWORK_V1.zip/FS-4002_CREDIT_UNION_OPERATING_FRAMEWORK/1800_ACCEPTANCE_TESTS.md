# Acceptance Tests

## Purpose

This file defines acceptance tests for the Credit Union Operating Framework.

## Object Tests

- Can create a Federal Credit Union object.
- Can create a State Chartered Credit Union object.
- Can create a Corporate Credit Union object.
- Can create a CUSO object.
- Can create Member, Household, Business Member, Borrower, Guarantor objects.
- Can create Deposit, Loan, Treasury, Vendor, Policy, Workflow, Board Packet objects.
- Every object inherits universal fields.
- Every object supports relationships and audit history.

## Relationship Tests

- Credit Union can be linked to regulator.
- Credit Union can be linked to corporate credit union.
- Credit Union can be linked to league.
- Credit Union can be linked to CUSO.
- Credit Union can use a core processor.
- Credit Union can pilot a fintech.
- Member can hold accounts and loans.
- Board can approve policy.
- Committee can approve decision.
- Vendor can provide product capability.

## Workflow Tests

- Board packet workflow produces packet, summary, decisions, tasks.
- Commercial loan workflow produces credit memo, conditions, approval, funding package.
- Vendor review workflow produces security, compliance, commercial, and risk reviews.
- Exam prep workflow produces evidence inventory and management response.
- Liquidity workflow produces daily liquidity dashboard.
- Innovation workflow produces pilot business case and ROI summary.

## Agent Tests

- Executive Briefing Agent summarizes institution status.
- Board Packet Writer creates board-ready packet.
- Credit Memo Writer creates structured memo.
- Vendor Risk Agent produces review.
- Exam Prep Agent maps evidence to request list.
- Innovation Scout recommends vendors based on capability gaps.

## KPI Tests

- System calculates loan growth.
- System calculates deposit growth.
- System calculates net worth ratio.
- System calculates delinquency.
- System calculates efficiency ratio.
- System calculates liquidity ratio.
- System tracks innovation pipeline.

## Connector Tests

- Connector maps external records to canonical objects.
- Connector preserves source lineage.
- Connector emits telemetry.
- Connector respects permissions.
- Connector supports failure recovery.

## Governance Tests

- Policy approvals require correct authority.
- Board resolutions are archived.
- Committee decisions are linked to workflows.
- Exceptions require expiration dates.
- AI decisions are explainable.

## Demo Acceptance

A demo is acceptable when it can show:

- a complete institution profile
- technology stack
- executive dashboard
- board packet generation
- lending workflow
- compliance evidence
- vendor intelligence
- innovation pipeline
- cooperative relationship graph
- AI agent output with citations/context
- audit trail

## Dispatch Truth Statement

Acceptance is achieved when Dispatch can represent, explain, execute, monitor, and improve the operating reality of a credit union through canonical objects, relationships, workflows, agents, and knowledge.
