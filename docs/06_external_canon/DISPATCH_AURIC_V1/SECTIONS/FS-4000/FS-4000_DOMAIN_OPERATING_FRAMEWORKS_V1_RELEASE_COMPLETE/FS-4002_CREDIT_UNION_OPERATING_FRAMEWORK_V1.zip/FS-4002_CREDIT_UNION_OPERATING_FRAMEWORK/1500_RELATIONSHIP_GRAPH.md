# Credit Union Relationship Graph

## Purpose

This file defines the relationship model for cooperative finance.

## Institution Relationships

Credit Union MEMBER_OF League  
Credit Union MEMBER_OF Corporate Credit Union  
Credit Union REGULATED_BY NCUA  
Credit Union REGULATED_BY State Regulator  
Credit Union INSURED_BY Share Insurance Fund  
Credit Union OWNS CUSO  
Credit Union INVESTS_IN CUSO  
Credit Union PARTNERS_WITH FinTech  
Credit Union USES Core Processor  
Credit Union USES Digital Banking Platform  
Credit Union USES Payment Network  
Credit Union PARTICIPATES_IN Shared Service  
Credit Union SELLS Participation  
Credit Union BUYS Participation  

## People Relationships

Member OWNS Credit Union Interest  
Member HOLDS Account  
Member BORROWS Loan  
Executive MANAGES Department  
Board GOVERNS Institution  
Committee APPROVES Decision  
Examiner EXAMINES Institution  
Relationship Manager SERVES Business Member  

## Vendor Relationships

Vendor PROVIDES Product  
Product ENABLES Capability  
Capability SUPPORTS Workflow  
Connector SYNCHRONIZES Object  
Vendor INTEGRATES_WITH Core Processor  
Vendor COMPETES_WITH Vendor  

## Cooperative Relationships

CUSO OWNED_BY Credit Unions  
Corporate CU PROVIDES Liquidity  
League PROVIDES Advocacy  
Trade Association PROVIDES Research  
Innovation Consortium PILOTS Vendor  
Credit Union SHARES Knowledge  

## Relationship Attributes

- strength
- confidence
- evidence
- source
- owner
- effective date
- last verified
- business context
- operational importance
- AI visibility

## Relationship Intelligence

Auric should detect institutions with similar technology stacks, vendors with common customer bases, executives with shared networks, CUSO ownership clusters, participation market relationships, innovation pilots, partnership opportunities, merger/acquisition relationships, league influence networks, and corporate CU network effects.

## Dispatch Truth Statement

The credit union industry is a cooperative relationship graph. The more relationships Auric maps, the more accurately Dispatch can recommend innovation, partnerships, vendors, capital, and operational improvements.
