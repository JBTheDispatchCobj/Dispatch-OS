# Workflows & Operating Cadence

## Purpose

This file defines the canonical credit union workflow library.

## Universal Workflow Fields

- workflow_id
- workflow_name
- domain
- trigger
- owner
- participants
- agents
- required_objects
- required_documents
- policies
- controls
- decision_points
- SLAs
- KPIs
- output
- evidence
- audit_history

## Executive Workflows

- Strategic Planning
- Annual Budget
- Board Packet
- Executive Committee
- Policy Approval
- Technology Roadmap
- Innovation Portfolio Review
- Risk Appetite Review
- ALCO Review
- Acquisition/Merger Review

## Member Workflows

- Member Onboarding
- Account Opening
- Identity Verification
- Digital Enrollment
- Complaint Management
- Service Recovery
- Dormant Member Reactivation
- Cross-Sell Campaign
- Fraud Case

## Lending Workflows

- Consumer Loan Origination
- Mortgage Origination
- Commercial Loan Origination
- Commercial Annual Review
- Participation Review
- Loan Renewal
- Collections
- Workout
- Charge-Off
- Recovery

## Treasury Workflows

- Daily Liquidity Review
- Wire Review
- ACH Exception
- Positive Pay Exception
- Fraud Alert
- Treasury Services Onboarding
- ALCO Package

## Technology Workflows

- Vendor Evaluation
- Security Review
- Access Request
- Incident Response
- Change Management
- Core Conversion
- Connector Deployment
- AI Agent Deployment

## Compliance Workflows

- Policy Review
- Control Testing
- Exam Preparation
- Audit Response
- Evidence Collection
- Corrective Action
- Regulatory Change
- Training Certification

## Innovation Workflows

- Problem Intake
- Vendor Discovery
- Business Case
- Pilot Approval
- Pilot Measurement
- Production Deployment
- Partnership Review
- Investment Opportunity Review

## Cadence Model

Daily:

- liquidity
- operations
- fraud
- lending pipeline
- service levels

Weekly:

- executive priorities
- loan production
- member growth
- vendor issues
- technology incidents

Monthly:

- financial close
- board package
- ALCO
- risk and compliance status
- KPI dashboard

Quarterly:

- call report
- strategic progress
- exam readiness
- peer benchmarking

Annual:

- strategy
- budget
- policies
- audit plan
- technology roadmap

## Dispatch Truth Statement

Workflows are the executable representation of institutional knowledge. Every repeated activity should become a workflow, every workflow should create evidence, and every evidence object should improve future execution.
