# Treasury, Payments & Liquidity

## Purpose

This file defines treasury services, payments operations, liquidity management, settlement, and balance sheet execution for credit unions.

## Treasury Functions

- cash position
- liquidity management
- investment portfolio
- ALCO support
- wire operations
- ACH operations
- Fed services
- corporate credit union services
- borrowing capacity
- contingency funding
- deposit pricing
- cost of funds
- settlement
- safekeeping
- business treasury services

## Liquidity Object

Fields:

- liquidity_position_id
- available_cash
- overnight_funds
- investment_liquidity
- borrowing_capacity
- corporate_CU_capacity
- FHLB_capacity
- Federal_Reserve_access
- stressed_outflow_assumption
- liquidity_ratio
- forecast_horizon
- contingency_plan
- owner
- review_date

## Payments Rails

- ACH
- Same Day ACH
- Fedwire
- FedNow
- RTP
- checks
- debit card
- credit card
- ATM
- POS
- P2P
- bill pay
- wires
- SWIFT for applicable institutions
- card networks
- wallet tokenization

## Payment Object

Fields:

- payment_id
- rail
- originator
- receiver
- amount
- currency
- effective_date
- settlement_date
- status
- exception_status
- fraud_score
- OFAC_status
- return_code
- trace_number
- system_of_record
- workflow
- audit_evidence

## Treasury Services for Business Members

- ACH origination
- wire origination
- remote deposit capture
- positive pay
- account analysis
- merchant services
- lockbox
- sweep
- zero balance accounts
- cash concentration
- fraud controls
- payroll
- business bill pay
- liquidity planning

## Liquidity Workflows

### Daily Liquidity Review

Inputs:

- cash position
- settlement forecast
- expected inflows
- expected outflows
- large depositor movements
- loan funding forecast
- investment maturities
- borrowing availability

Outputs:

- liquidity dashboard
- alerts
- recommendations
- ALCO notes
- executive summary

### Contingency Funding Workflow

Trigger:

- liquidity threshold breach
- deposit runoff
- settlement stress
- market disruption
- operational event

Steps:

- scenario classification
- management notification
- source prioritization
- draw request
- approval
- execution
- documentation
- board reporting
- post-event review

## Treasury KPIs

- liquidity ratio
- cost of funds
- loan-to-share ratio
- deposit beta
- investment yield
- duration
- interest rate sensitivity
- borrowing availability
- wire volume
- ACH volume
- payment exceptions
- fraud losses
- settlement failures
- treasury fee income
- business treasury adoption

## AI Agents

- Treasury Manager
- Liquidity Monitor
- ALCO Analyst
- Payments Operations Agent
- Wire Review Agent
- ACH Exception Agent
- Fraud Monitor
- Deposit Pricing Advisor
- Business Treasury Advisor

## Dispatch Truth Statement

Treasury is the circulatory system of a credit union. Dispatch must continuously understand cash, settlement, liquidity, payments, risk, and member behavior as one connected operating model.
