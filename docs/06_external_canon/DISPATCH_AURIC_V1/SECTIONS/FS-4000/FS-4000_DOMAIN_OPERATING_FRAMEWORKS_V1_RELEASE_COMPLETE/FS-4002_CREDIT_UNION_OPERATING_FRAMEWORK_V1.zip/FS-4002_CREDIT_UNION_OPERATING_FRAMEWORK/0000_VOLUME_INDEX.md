# FS-4002 Credit Union Operating Framework

Version: 1.0  
Owner: Auric Works  
Library: Dispatch Institutional Intelligence Library  
Domain: Cooperative Finance / Credit Unions  
Status: Production Knowledge Volume

## Purpose

This volume defines the canonical operating framework for credit unions inside Dispatch OS and the Auric Institutional Intelligence Network.

It is written as an installable knowledge volume. Claude, Dispatch, agents, cartridges, and implementation teams can use it to build, configure, test, and operate a Credit Union cartridge without needing external context.

## Strategic Lens

Credit unions are not simply depository institutions. They are cooperative financial networks that combine member ownership, community trust, regulated financial services, shared infrastructure, vendor ecosystems, payments networks, lending engines, capital and liquidity management, board governance, compliance obligations, cooperative partnerships, and innovation demand.

Dispatch operationalizes the institution. Auric maps the ecosystem. Together they make institutions innovative and innovation institutional-grade.

## Volume Contents

1. Shared Schema & Object Standard
2. Credit Union Operating Model
3. Governance, Board & Committees
4. Member & Relationship Lifecycle
5. Products, Services & Revenue Model
6. Lending Operations
7. Treasury, Payments & Liquidity
8. Finance, Accounting & ALM
9. Technology, Core & Vendor Stack
10. Risk, Compliance & Examinations
11. Workflows & Operating Cadence
12. Agent Workforce
13. KPI & Benchmark Registry
14. Knowledge Packs
15. Playbooks
16. Relationship Graph
17. Data Sources & Connector Priorities
18. Implementation Guide
19. Acceptance Tests
20. Backlog & Roadmap

## Completion Standard

This volume is complete when Dispatch can represent a credit union as a living operational system with canonical objects, relationships, workflows, KPIs, policies, rules, agents, connectors, documents, evidence, dashboards, intelligence outputs, and implementation paths.

## Exclusions

Hospitality is intentionally omitted from this volume.

## Primary Audiences

- Claude / engineering agents
- Dispatch product builders
- Auric intelligence researchers
- implementation consultants
- credit union executives
- CUSO operators
- corporate credit union partners
- fintech integration teams
- compliance and risk reviewers
