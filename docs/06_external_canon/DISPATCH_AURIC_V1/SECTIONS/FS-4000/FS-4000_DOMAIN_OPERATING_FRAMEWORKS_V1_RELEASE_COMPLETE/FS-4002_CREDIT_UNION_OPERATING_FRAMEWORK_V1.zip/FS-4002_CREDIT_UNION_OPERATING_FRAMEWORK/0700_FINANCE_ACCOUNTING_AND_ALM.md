# Finance, Accounting & ALM

## Purpose

This file defines the finance, accounting, financial reporting, forecasting, and ALM operating model for credit unions.

## Finance Functions

- general ledger
- month-end close
- financial statements
- budgeting
- forecasting
- variance analysis
- treasury accounting
- loan accounting
- allowance
- investments
- fixed assets
- accounts payable
- regulatory reporting
- board reporting
- ALM support
- capital planning

## Core Finance Objects

- GL Account
- Journal Entry
- Trial Balance
- Balance Sheet
- Income Statement
- Cash Flow Statement
- Budget
- Forecast
- Variance
- Invoice
- Payment
- Accrual
- Prepaid Expense
- Fixed Asset
- Depreciation
- Investment Security
- Allowance
- Capital Account
- Net Worth Calculation
- ALM Scenario

## Monthly Close Workflow

Transaction Cutoff → Reconciliation → Accruals → Journal Entries → Review → Financial Statements → Variance Analysis → CFO Review → Executive Review → Board Package → Archive

## ALM Framework

Objects:

- ALCO
- balance sheet
- interest rate risk
- liquidity risk
- gap report
- duration
- deposit beta
- loan repricing
- investment portfolio
- stress scenario
- policy limits
- management actions

## ALCO Package

Sections:

- executive summary
- balance sheet trends
- loan growth
- deposit growth
- liquidity
- investment portfolio
- interest rate risk
- margin analysis
- cost of funds
- pricing recommendations
- policy exceptions
- stress scenarios
- recommended actions

## Finance KPIs

- ROA
- ROE
- net worth ratio
- net interest margin
- efficiency ratio
- operating expense ratio
- non-interest income
- non-interest expense
- provision expense
- charge-offs
- liquidity ratio
- loan-to-share ratio
- budget variance
- forecast accuracy
- close cycle time

## AI Agents

- Controller Agent
- Month-End Close Agent
- Variance Analyst
- CFO Briefing Agent
- ALCO Analyst
- Forecasting Agent
- Budget Analyst
- Invoice Review Agent
- Board Financial Summary Agent

## Dispatch Truth Statement

Finance is not reporting. Finance is the translation of institutional operations into capital, liquidity, profitability, and strategic capacity.
