# KPI & Benchmark Registry

## Purpose

This file defines canonical KPIs for credit union operations.

## Financial KPIs

- total assets
- asset growth
- net worth ratio
- ROA
- ROE
- net interest margin
- efficiency ratio
- operating expense ratio
- non-interest income
- provision expense
- cost of funds
- yield on loans
- yield on investments
- budget variance
- forecast accuracy

## Member KPIs

- member growth
- member retention
- new members
- household penetration
- services per member
- product penetration
- member satisfaction
- complaint rate
- digital adoption
- mobile adoption
- direct deposit adoption
- dormant member count

## Deposit KPIs

- deposit growth
- share growth
- checking growth
- money market growth
- certificate growth
- business deposit growth
- deposit concentration
- deposit beta
- average balance
- cost of deposits

## Loan KPIs

- loan growth
- loan-to-share ratio
- originations
- funded volume
- pipeline
- approval rate
- average loan size
- portfolio yield
- weighted risk grade
- delinquency rate
- charge-off rate
- recovery rate
- annual reviews complete
- exceptions

## Commercial KPIs

- business members
- commercial deposits
- commercial loan volume
- treasury revenue
- merchant revenue
- commercial profitability
- participation volume
- commercial concentration
- relationship manager productivity

## Treasury & Liquidity KPIs

- liquidity ratio
- borrowing availability
- cash position
- investment yield
- duration
- ALM sensitivity
- wire volume
- ACH volume
- payment exceptions
- fraud losses

## Risk & Compliance KPIs

- open findings
- overdue findings
- policy currency
- training completion
- control effectiveness
- SAR timeliness
- vendor review completion
- cybersecurity incidents
- audit readiness
- exam readiness

## Technology KPIs

- uptime
- incident count
- mean time to recover
- digital banking active users
- core health
- connector health
- API errors
- vendor renewal risk
- AI utilization
- automation percentage

## Innovation KPIs

- ideas submitted
- pilots launched
- pilot success rate
- time to pilot
- time to production
- ROI realized
- vendor adoption
- AI adoption
- strategic partnerships
- investment opportunities

## Knowledge KPIs

- knowledge objects created
- relationship density
- profile completeness
- workflow coverage
- rule coverage
- agent utilization
- publication usage
- institutional memory growth

## Dashboard Hierarchy

Board Dashboard → Executive Dashboard → Department Dashboard → Workflow Dashboard → Object Dashboard → Agent Dashboard

## Dispatch Truth Statement

KPIs are not static report numbers. They are continuously updated operating signals connected to objects, workflows, relationships, agents, and decisions.
