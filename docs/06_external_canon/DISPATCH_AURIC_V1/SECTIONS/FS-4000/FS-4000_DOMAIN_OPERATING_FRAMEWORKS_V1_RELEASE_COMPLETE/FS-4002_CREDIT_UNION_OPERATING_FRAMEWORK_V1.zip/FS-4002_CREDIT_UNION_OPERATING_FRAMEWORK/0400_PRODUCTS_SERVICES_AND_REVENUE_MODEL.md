# Products, Services & Revenue Model

## Purpose

This document maps the credit union product and service universe into canonical Dispatch objects.

## Product Categories

### Deposits

- Share Savings
- Checking
- Rewards Checking
- Money Market
- Certificate
- IRA
- HSA
- Business Checking
- Business Money Market
- Escrow
- Custodial
- Trust
- Sweep
- Brokered Deposit
- ICS/CDARS-type reciprocal products where applicable

### Consumer Credit

- Auto Loan
- Indirect Auto
- RV Loan
- Boat Loan
- Motorcycle Loan
- Personal Loan
- Share Secured Loan
- Credit Card
- HELOC
- Student Loan
- Buy Now Pay Later where offered

### Mortgage

- First Mortgage
- Home Equity
- HELOC
- Construction Mortgage
- Portfolio Mortgage
- Secondary Market Mortgage
- Jumbo
- FHA
- VA
- USDA

### Commercial

- Business Checking
- Commercial Money Market
- Merchant Services
- ACH Origination
- Wire Services
- Remote Deposit Capture
- Positive Pay
- Commercial Real Estate Loan
- Equipment Loan
- Working Capital Line
- SBA Loan
- Construction Loan
- Participation Loan
- Letter of Credit
- Treasury Management

### Wealth & Insurance

- Investment Services
- Brokerage
- Retirement Planning
- Financial Planning
- Trust Referral
- Insurance
- GAP
- Warranty
- Debt Protection

## Product Object

Fields:

- product_id
- product_name
- product_family
- eligibility
- pricing
- rate
- fees
- term
- compliance_requirements
- documents
- operational_owner
- system_of_record
- workflow
- profitability
- risk_profile
- KPIs
- cross_sell_links
- required_disclosures
- servicing_model
- member_segment

## Revenue Sources

- net interest income
- loan interest
- investment income
- interchange
- card fees
- account fees
- treasury services
- mortgage origination
- loan servicing
- insurance commissions
- wealth referrals
- commercial service charges
- merchant services
- late fees
- NSF/overdraft where applicable
- CUSO distributions
- participation income
- gain on sale
- secondary market income

## Expense Categories

- interest expense
- salaries and benefits
- occupancy
- technology
- core processor
- digital banking
- card processing
- fraud losses
- loan losses
- marketing
- compliance
- audit
- professional services
- insurance
- vendor contracts
- regulatory fees
- training

## Product Lifecycle

Ideation → Business Case → Policy Review → Compliance Review → System Configuration → Staff Training → Launch → Monitoring → Pricing Review → Risk Review → Optimization → Retire/Replace

## AI Opportunities

- profitability analysis
- product overlap detection
- pricing recommendations
- fee sensitivity analysis
- cross-sell discovery
- deposit pricing optimization
- loan pricing optimization
- disclosure checklist generation
- system configuration checklist
- product retirement analysis
- member segment matching

## Dispatch Truth Statement

Products inside a credit union are not static offerings. They are operational systems with pricing, risk, compliance, workflows, technology, member behavior, and financial performance.
