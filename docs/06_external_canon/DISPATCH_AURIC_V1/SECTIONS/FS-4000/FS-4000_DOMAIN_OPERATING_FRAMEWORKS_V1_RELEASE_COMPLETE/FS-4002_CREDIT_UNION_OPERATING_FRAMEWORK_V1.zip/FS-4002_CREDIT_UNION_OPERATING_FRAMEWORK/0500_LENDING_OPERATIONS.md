# Lending Operations

## Purpose

This document defines the lending operating system for credit unions.

## Lending Domains

- Consumer Lending
- Indirect Lending
- Mortgage Lending
- Home Equity
- Commercial Lending
- Member Business Lending
- Construction Lending
- Equipment Finance
- Participation Lending
- SBA/USDA Lending
- Collections
- Servicing
- Workout
- Charge-Off and Recovery

## Universal Loan Object

Fields:

- loan_id
- borrower_id
- co_borrowers
- guarantors
- product_type
- purpose
- amount_requested
- amount_approved
- current_balance
- interest_rate
- term
- amortization
- collateral
- LTV
- CLTV
- DSCR
- DTI
- credit_score
- risk_grade
- pricing
- fees
- approval_authority
- conditions
- documents
- servicing_status
- delinquency_status
- charge_off_status
- recovery_status
- related_workflows

## Lending Lifecycle

Lead → Application → Document Collection → Verification → Underwriting → Pricing → Approval → Conditions → Documentation → Closing → Funding → Boarding → Servicing → Monitoring → Renewal → Workout → Payoff → Archive

## Commercial Lending Detail

Objects:

- borrower
- operating company
- guarantor
- owner
- collateral
- property
- appraisal
- environmental
- title
- survey
- financial statements
- tax returns
- global cash flow
- credit memo
- loan agreement
- UCC
- covenant
- annual review
- watchlist
- participation

## Credit Memo Sections

- executive summary
- borrower overview
- ownership
- request
- purpose
- repayment source
- financial analysis
- global cash flow
- collateral analysis
- guarantor analysis
- industry analysis
- management assessment
- risk rating
- policy exceptions
- strengths
- weaknesses
- mitigants
- recommendation
- conditions
- approval signature

## Lending Rules

- eligibility rules
- underwriting thresholds
- credit score rules
- DTI/DSCR requirements
- collateral requirements
- appraisal requirements
- documentation requirements
- approval authority
- exception process
- concentration limits
- annual review requirements
- delinquency escalation
- charge-off policy
- recovery workflow

## Lending KPIs

- applications
- approvals
- approval rate
- funded volume
- average loan size
- pipeline velocity
- fallout rate
- decision time
- funding time
- portfolio yield
- weighted risk grade
- delinquency rate
- charge-off rate
- recovery rate
- policy exception rate
- annual review completion
- concentration exposure

## Lending AI Agents

- Consumer Underwriter
- Commercial Underwriter
- Mortgage Underwriter
- Credit Analyst
- Document Collector
- Conditions Manager
- Collateral Analyst
- Cash Flow Analyst
- Credit Memo Writer
- Credit Committee Coordinator
- Portfolio Manager
- Annual Review Agent
- Collections Agent
- Workout Officer
- Participation Analyst

## Dispatch Truth Statement

Lending is not a product workflow. It is the operational conversion of member relationships, financial evidence, risk judgment, policy, collateral, capital, and compliance into a governed credit decision.
