# Credit Union Operating Model

## Definition

A credit union is a member-owned financial cooperative that provides financial services under a regulated governance structure while returning value to members through service, access, pricing, community commitment, and cooperative participation.

Dispatch models a credit union as a living operating system made of governance, members, products, capital, liquidity, lending, treasury, payments, operations, technology, risk, compliance, vendors, employees, knowledge, relationships, and market context.

## Operating Model Layers

### Layer 1 — Cooperative Governance

The institution is accountable to members through a board. Governance includes bylaws, board duties, committee structures, policies, risk appetite, strategic planning, audit, and executive accountability.

### Layer 2 — Member Relationship System

Members are owners and customers. Every member relationship includes identity, eligibility, household, product usage, communications, service history, financial behavior, digital adoption, and lifetime value.

### Layer 3 — Financial Product Engine

Products include deposits, loans, cards, payments, treasury, mortgage, commercial services, wealth, and insurance. Each product has pricing, risk, compliance, servicing, profitability, and operational workflows.

### Layer 4 — Balance Sheet & Capital System

The institution manages assets, liabilities, liquidity, investments, deposits, loans, capital, net worth, interest rate risk, profitability, and resilience.

### Layer 5 — Operational Execution System

Daily work is performed through queues, tasks, workflows, service channels, branches, contact centers, loan operations, accounting, technology, fraud, risk, and compliance.

### Layer 6 — Technology & Vendor System

The core processor, digital banking, LOS, CRM, GL, payments rails, document systems, contact center, identity, analytics, and AI platforms form the institution's technical spine.

### Layer 7 — Regulatory & Evidence System

Compliance obligations generate policies, procedures, controls, evidence, reports, exams, audits, findings, corrective actions, and board oversight.

### Layer 8 — Innovation & Network System

Credit unions participate in CUSOs, leagues, corporate credit unions, vendors, fintech pilots, strategic partnerships, cooperative liquidity, shared services, and institutional intelligence networks.

## Canonical Departments

- Board & Governance
- Executive Office
- Finance & Accounting
- Treasury & ALM
- Lending
- Commercial Banking
- Mortgage
- Collections
- Branch Operations
- Contact Center
- Member Experience
- Digital Banking
- Marketing
- Business Development
- Compliance
- BSA/AML
- Risk Management
- Audit
- Technology
- Information Security
- Data & Analytics
- Vendor Management
- Human Resources
- Training
- Facilities
- Innovation

## Credit Union Strategic Themes

Dispatch should track every strategic theme as an object.

Common themes:

- member growth
- deposit growth
- loan growth
- digital transformation
- core modernization
- commercial expansion
- treasury services buildout
- branch optimization
- operational efficiency
- AI adoption
- fraud reduction
- liquidity resilience
- compliance modernization
- CUSO participation
- fintech partnerships
- market expansion
- merger readiness
- succession planning
- board modernization
- community impact

## Operating Cadence

Daily:

- liquidity review
- branch and channel activity
- service levels
- fraud alerts
- loan pipeline
- operational exceptions
- critical technology incidents
- AI agent performance

Weekly:

- lending pipeline
- collections
- deposit trends
- member growth
- technology health
- vendor issues
- executive priorities
- workflow bottlenecks

Monthly:

- financial close
- ALCO package
- loan portfolio review
- risk review
- compliance status
- vendor review
- board packet
- KPI dashboard
- member experience review

Quarterly:

- call report
- board strategic review
- audit update
- exam readiness
- investment portfolio review
- capital planning
- peer benchmarking
- innovation portfolio review

Annual:

- strategic planning
- budget
- policy review
- board education
- audit plan
- compensation review
- technology roadmap
- vendor renewal plan
- risk appetite update

## Dispatch Product Implications

The Credit Union cartridge must provide an institution profile, board dashboard, CEO dashboard, lending dashboard, liquidity dashboard, compliance dashboard, vendor dashboard, technology dashboard, innovation dashboard, AI operations dashboard, call report workspace, exam preparation workspace, member relationship workspace, and fintech/vendor evaluation workspace.

## Truth Statement

A credit union is both a regulated financial institution and a cooperative network. Dispatch must support both identities simultaneously: the internal operating company and the external cooperative ecosystem.
