# Mortgage Operating Model

## Definition

Mortgage banking is the system for originating, underwriting, closing, funding, selling, servicing, and monitoring loans secured by residential real estate.

## Operating Layers

### 1. Demand & Lead Generation

Sources include branches, digital channels, realtors, builders, refinance campaigns, member/customer relationships, call center, commercial referrals, and financial wellness programs.

### 2. Application & Disclosure

Captures borrower intent, property, purpose, income, assets, liabilities, credit, consent, and regulatory disclosure timing.

### 3. Processing

Collects documents, verifies information, orders services, manages conditions, coordinates borrower communication, and prepares the file for underwriting.

### 4. Underwriting

Evaluates credit, capacity, collateral, capital, compliance, program eligibility, investor requirements, and compensating factors.

### 5. Closing & Funding

Coordinates closing disclosure, title, settlement, documents, signing, funding authorization, wire, and post-closing quality.

### 6. Secondary Market / Portfolio

Determines whether the loan is retained, sold, delivered to investor, securitized, or serviced by the institution.

### 7. Servicing

Manages payment posting, escrow, customer service, investor reporting, default, loss mitigation, payoff, and release.

### 8. Compliance & Quality Control

Monitors TRID, RESPA, TILA, ECOA, fair lending, HMDA, flood, appraisal independence, QC, investor defects, and repurchase risk.

## Mortgage Departments

- Mortgage Sales
- Loan Officers
- Processing
- Underwriting
- Closing
- Funding
- Post-Closing
- Secondary Marketing
- Lock Desk
- Servicing
- Default Servicing
- Quality Control
- Compliance
- Appraisal Desk
- Title Coordination
- Investor Delivery
- Mortgage Operations
- Mortgage Technology

## Operating Cadence

Daily:
- pipeline
- rate locks
- disclosure timing
- conditions
- closing calendar
- funding calendar
- appraisal status
- title status
- expiring locks
- compliance alerts

Weekly:
- fallout review
- production
- underwriting turn times
- closing delays
- investor suspense
- QC findings
- capacity planning

Monthly:
- funded volume
- gain on sale
- portfolio retention
- servicing performance
- delinquency
- HMDA data quality
- compliance exceptions
- vendor performance

Quarterly:
- fair lending review
- investor performance
- QC trend
- product profitability
- secondary market review
- board reporting

## Dispatch Truth Statement

Mortgage operations succeed when every deadline, document, condition, party, regulation, and capital market requirement is visible and coordinated.
