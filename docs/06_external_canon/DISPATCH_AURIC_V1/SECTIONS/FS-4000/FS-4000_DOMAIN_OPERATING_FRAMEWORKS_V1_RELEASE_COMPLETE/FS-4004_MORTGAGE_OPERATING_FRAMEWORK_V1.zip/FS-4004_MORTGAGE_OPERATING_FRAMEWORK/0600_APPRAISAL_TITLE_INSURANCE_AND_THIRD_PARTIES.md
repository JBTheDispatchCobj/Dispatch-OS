# Appraisal, Title, Insurance & Third Parties

## Purpose

This document defines third-party dependencies in mortgage operations.

## Appraisal Object

Fields:
- appraisal_id
- property_id
- appraiser
- order_date
- due_date
- received_date
- appraised_value
- condition
- property_type
- comparable_sales
- required_repairs
- review_status
- reconsideration_status
- transfer_status
- investor_acceptance

## Title Object

Fields:
- title_id
- title_company
- commitment_date
- vesting
- liens
- exceptions
- judgments
- taxes
- legal_description
- closing_protection_letter
- title_policy
- clearance_status

## Insurance Object

Fields:
- insurance_id
- carrier
- coverage_type
- dwelling_coverage
- deductible
- effective_date
- mortgagee_clause
- flood_status
- premium
- escrow_status
- expiration_date

## Third Party Objects

- Appraiser
- AMC
- Title Company
- Closing Agent
- Settlement Agent
- Realtor
- Builder
- Insurance Agent
- Flood Vendor
- Credit Bureau
- VOE Provider
- VOI Provider
- Tax Transcript Provider
- Mortgage Insurer

## Appraisal Workflow

Order → Assignment → Inspection → Report → Review → Conditions → Reconsideration if needed → Acceptance → Archive

## Title Workflow

Order → Commitment → Review → Exception Clearance → Closing Protection → Final Policy → Post-Closing → Archive

## Insurance Workflow

Request → Quote/Policy → Coverage Review → Mortgagee Clause → Flood Review → Escrow Setup → Final Verification

## Third-Party KPIs

- appraisal turn time
- title turn time
- appraisal revision rate
- title exception count
- closing delay due to third party
- insurance issue rate
- vendor performance
- borrower satisfaction impact

## AI Opportunities

- appraisal summary
- appraisal issue detection
- title exception summary
- insurance coverage checklist
- vendor delay prediction
- third-party status dashboard
- borrower update drafting

## Dispatch Truth Statement

Mortgage execution depends on third parties. Dispatch must model each dependency as an object with timing, evidence, ownership, and risk.
