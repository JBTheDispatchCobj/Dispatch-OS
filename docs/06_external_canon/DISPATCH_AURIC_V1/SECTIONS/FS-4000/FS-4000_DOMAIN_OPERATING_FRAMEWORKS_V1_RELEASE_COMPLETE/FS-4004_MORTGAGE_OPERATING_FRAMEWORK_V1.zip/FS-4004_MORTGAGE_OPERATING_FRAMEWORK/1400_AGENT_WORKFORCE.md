# Mortgage Agent Workforce

## Executive Agents

- Mortgage Executive Advisor
- Production Analyst
- Secondary Market Advisor
- Mortgage Compliance Advisor
- Mortgage Operations Advisor

## Sales Agents

- Loan Officer Assistant
- Lead Response Agent
- Prequalification Agent
- Borrower Education Agent
- Realtor Partner Agent
- Product Recommendation Agent

## Processing Agents

- Document Request Agent
- Document Classifier
- Condition Manager
- Processor Work Queue Agent
- Borrower Follow-Up Agent
- Third-Party Status Agent

## Underwriting Agents

- Income Analysis Agent
- Asset Review Agent
- Credit Summary Agent
- Collateral Review Agent
- Underwriting Decision Support Agent
- Conditions Recommendation Agent
- Investor Guideline Comparison Agent

## Closing & Post-Closing Agents

- Closing Checklist Agent
- CD Timing Agent
- Funding Review Agent
- Post-Closing Defect Agent
- Trailing Document Agent
- Investor Suspense Agent

## Servicing Agents

- Servicing Transfer Agent
- Escrow Analysis Agent
- Delinquency Monitor
- Loss Mitigation Agent
- Payoff Agent
- Complaint Analyst

## Compliance & QC Agents

- TRID Monitor
- HMDA Data Quality Agent
- QC Reviewer
- Defect Classifier
- Fair Lending Monitor
- Flood Compliance Agent
- Repurchase Risk Agent

## Agent Governance

Human approval required for:
- underwriting decisions
- adverse action
- disclosure changes
- rate lock commitments
- closing authorization
- funding authorization
- loss mitigation decision
- external regulatory response

## Dispatch Truth Statement

Mortgage agents are specialized operational staff. They reduce cycle time, catch defects, explain conditions, monitor deadlines, and preserve evidence without replacing required human authority.
