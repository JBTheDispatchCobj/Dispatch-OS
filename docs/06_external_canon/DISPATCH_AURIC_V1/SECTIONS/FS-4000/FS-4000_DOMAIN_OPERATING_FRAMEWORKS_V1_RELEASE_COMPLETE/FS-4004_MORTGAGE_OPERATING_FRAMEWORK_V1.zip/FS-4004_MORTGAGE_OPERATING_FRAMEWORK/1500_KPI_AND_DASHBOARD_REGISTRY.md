# KPI & Dashboard Registry

## Production KPIs

- leads
- applications
- pull-through
- approval rate
- denial rate
- fallout rate
- funded volume
- average loan size
- lock volume
- gain on sale
- channel mix
- product mix

## Cycle-Time KPIs

- lead response time
- application to disclosure
- application to underwriting
- underwriting turn time
- condition cycle time
- clear to close time
- closing cycle time
- funding time
- post-closing time
- investor purchase time

## Quality KPIs

- defect rate
- critical defect rate
- investor suspense
- repurchase requests
- missing documents
- trailing document aging
- HMDA edit rate
- TRID exceptions
- QC findings

## Servicing KPIs

- loans serviced
- delinquency
- roll rate
- loss mitigation
- escrow exceptions
- servicing complaints
- payoff time
- release timeliness

## Risk KPIs

- DTI
- LTV
- CLTV
- credit score distribution
- product risk
- channel risk
- early payment default
- fraud alerts
- appraisal variance
- concentration

## Dashboards

- Mortgage Executive Dashboard
- Loan Officer Dashboard
- Processor Dashboard
- Underwriter Dashboard
- Closing Dashboard
- Secondary Market Dashboard
- Compliance Dashboard
- QC Dashboard
- Servicing Dashboard
- Vendor Dashboard

## Dispatch Truth Statement

Mortgage KPIs must show not only volume, but timing, quality, compliance, borrower experience, investor delivery, and servicing risk.
