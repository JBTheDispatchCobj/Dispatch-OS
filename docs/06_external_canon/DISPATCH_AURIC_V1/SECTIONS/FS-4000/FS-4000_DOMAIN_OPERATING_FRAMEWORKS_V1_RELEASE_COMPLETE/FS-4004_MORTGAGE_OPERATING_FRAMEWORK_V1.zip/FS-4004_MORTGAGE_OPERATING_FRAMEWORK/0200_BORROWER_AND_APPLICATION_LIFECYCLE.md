# Borrower & Application Lifecycle

## Borrower Object

Fields:

- borrower_id
- name
- household_id
- contact_information
- consent_records
- credit_profile
- income_sources
- employment
- assets
- liabilities
- declarations
- demographic_reporting_fields_where_required
- occupancy_intent
- real_estate_owned
- relationship_history
- communication_history
- document_status
- risk_flags

## Application Object

Fields:

- application_id
- borrower
- co_borrower
- loan_purpose
- property
- product
- loan_amount
- estimated_value
- purchase_price
- income
- assets
- liabilities
- declarations
- credit_authorization
- submission_date
- disclosure_due_date
- status
- milestone
- assigned_processor
- assigned_LO
- compliance_events

## Application Lifecycle

Lead → Prequalification → Application → Credit Authorization → Initial Disclosures → Intent to Proceed → Document Collection → Processing → Underwriting → Conditional Approval → Clear to Close → Closing → Funding → Post-Closing → Servicing/Delivery

## Borrower Communication Events

- lead response
- application reminder
- disclosure delivery
- document request
- condition request
- appraisal update
- title update
- rate lock update
- closing scheduling
- funding confirmation
- servicing transfer notice
- adverse action where applicable

## Application Risks

- incomplete application
- disclosure timing breach
- credit issue
- income instability
- asset insufficiency
- property issue
- appraisal shortfall
- title issue
- insurance issue
- rate lock expiration
- borrower communication failure
- document staleness
- fraud indicator

## AI Opportunities

- borrower checklist generation
- document request drafting
- borrower summary
- application completeness review
- condition explanation
- communication timeline monitoring
- rate lock expiration warning
- borrower responsiveness scoring
- missing data detection

## Dispatch Truth Statement

The mortgage application is not a form. It is the beginning of a regulated evidence lifecycle that determines what the institution may offer, disclose, underwrite, close, and sell.
