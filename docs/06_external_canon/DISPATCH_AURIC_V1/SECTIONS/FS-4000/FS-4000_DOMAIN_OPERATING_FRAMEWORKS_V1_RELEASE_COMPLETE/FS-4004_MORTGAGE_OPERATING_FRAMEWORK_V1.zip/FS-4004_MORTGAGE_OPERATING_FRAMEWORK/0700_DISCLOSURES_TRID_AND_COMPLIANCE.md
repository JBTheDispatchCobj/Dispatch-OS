# Disclosures, TRID & Compliance

## Purpose

This document defines mortgage compliance operations.

## Compliance Domains

- TRID
- TILA
- RESPA
- ECOA
- Fair Lending
- HMDA
- Flood
- Appraisal Independence
- Ability-to-Repay
- Qualified Mortgage
- Privacy
- Servicemembers Civil Relief Act where applicable
- UDAAP
- FCRA
- FACTA
- State Lending Rules
- Advertising Rules

## Disclosure Objects

- Loan Estimate
- Closing Disclosure
- Intent to Proceed
- Written List of Service Providers
- Servicing Disclosure
- Appraisal Notice
- ECOA Notice
- Adverse Action Notice
- Privacy Notice
- Affiliated Business Arrangement Disclosure
- Right of Rescission
- Escrow Disclosure
- Flood Notice
- Rate Lock Agreement

## TRID Workflow

Application Trigger → LE Clock Starts → Fee Data → Loan Estimate → Delivery Evidence → Change Event Monitoring → Revised LE if Valid → Closing Disclosure → Waiting Period → Consummation → Post-Closing Cure if Needed

## HMDA Object

Fields:
- application_id
- loan_purpose
- action_taken
- action_date
- loan_type
- occupancy
- property_type
- ethnicity_race_sex_age_fields_where_required
- income
- loan_amount
- rate_spread
- denial_reasons
- data_quality_status
- reporting_period

## Compliance Risk Events

- late disclosure
- incorrect fee tolerance
- missing intent
- changed circumstance issue
- CD timing issue
- appraisal notice issue
- adverse action delay
- HMDA data quality issue
- flood determination issue
- fair lending concern
- missing evidence

## Compliance KPIs

- LE timeliness
- CD timeliness
- cure count
- tolerance violations
- HMDA edit rate
- adverse action timeliness
- fair lending exceptions
- flood exceptions
- QC compliance defects
- exam findings
- training completion

## AI Opportunities

- disclosure checklist
- TRID clock monitoring
- changed circumstance review
- HMDA data quality check
- adverse action draft support
- fee tolerance comparison
- compliance exception summary
- audit evidence package

## Dispatch Truth Statement

Mortgage compliance is a timing-and-evidence operating system. Dispatch must track every trigger, deadline, disclosure, fee, change, delivery event, and exception.
