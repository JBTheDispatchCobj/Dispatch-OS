# Mortgage Schema & Object Standard

## Purpose

This document defines canonical mortgage objects used by Dispatch.

## Universal Mortgage Loan Object

Fields:

- mortgage_id
- loan_number
- borrower_id
- co_borrower_ids
- property_id
- product_type
- purpose
- occupancy
- loan_amount
- purchase_price
- appraised_value
- LTV
- CLTV
- DTI
- credit_score
- rate
- APR
- points
- term
- amortization_type
- lien_position
- investor
- channel
- loan_officer
- processor
- underwriter
- closer
- status
- milestone
- disclosures
- conditions
- documents
- appraisal
- title
- insurance
- compliance_tests
- closing_package
- funding_status
- post_closing_status
- servicing_status
- secondary_market_status
- audit_history

## Primary Mortgage Objects

- Borrower
- Co-Borrower
- Household
- Property
- Application
- Loan Estimate
- Closing Disclosure
- Intent to Proceed
- Credit Report
- Income Verification
- Asset Verification
- Employment Verification
- Appraisal
- Title Commitment
- Homeowners Insurance
- Flood Determination
- Conditions
- Underwriting Decision
- Rate Lock
- Closing Package
- Funding Authorization
- Investor Delivery
- Servicing Transfer
- Escrow Account
- Default Case
- Loss Mitigation Plan

## Party Objects

- Borrower
- Co-Borrower
- Seller
- Realtor
- Loan Officer
- Processor
- Underwriter
- Closer
- Funder
- Appraiser
- Title Agent
- Settlement Agent
- Insurance Agent
- Investor
- Warehouse Lender
- Servicer
- Subservicer
- Mortgage Insurer
- Government Agency

## Mortgage Product Objects

- Conventional Fixed
- Conventional ARM
- FHA
- VA
- USDA
- Jumbo
- Portfolio Mortgage
- Construction-to-Permanent
- HELOC
- Home Equity Loan
- Bridge Loan
- Non-QM
- DSCR Investor Loan
- Reverse Mortgage where applicable
- Second Mortgage
- Refinance
- Cash-Out Refinance
- Rate-Term Refinance

## Dispatch Truth Statement

Mortgage objects connect borrower, property, collateral, documentation, regulation, third parties, capital market outlet, and servicing obligations into one continuous institutional workflow.
