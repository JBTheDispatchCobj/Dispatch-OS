# Quality Control, Audit & Defect Management

## Purpose

This document defines mortgage quality control and defect management.

## QC Types

- Pre-Funding QC
- Post-Closing QC
- Investor QC
- Servicing QC
- Compliance QC
- Targeted QC
- Random QC
- Early Payment Default Review
- Repurchase Review

## Defect Object

Fields:
- defect_id
- loan_id
- category
- severity
- source
- description
- responsible_area
- root_cause
- remediation
- investor_impact
- repurchase_risk
- status
- due_date
- evidence
- trend

## Defect Categories

- income
- assets
- credit
- collateral
- title
- insurance
- disclosure
- TRID
- HMDA
- closing
- funding
- investor delivery
- servicing
- documentation
- fraud
- data quality

## QC Workflow

Sample Selection → File Review → Defect Identification → Severity Rating → Response → Remediation → Trend Analysis → Training → Policy/Workflow Update → Archive

## Early Payment Default Review

Triggers:
- delinquency within defined early period
- fraud concern
- underwriting defect
- occupancy concern
- borrower misrepresentation
- income instability

## QC KPIs

- defect rate
- critical defect rate
- investor suspense
- repurchase requests
- cure rate
- root cause distribution
- repeat defects
- training completion
- cycle time
- QC sample coverage

## AI Opportunities

- file review checklist
- defect classification
- root cause analysis
- investor response drafting
- trend summary
- training recommendation
- repurchase risk detection
- QC dashboard commentary

## Dispatch Truth Statement

Mortgage QC is institutional learning. Every defect should improve underwriting, processing, closing, training, workflow design, and risk controls.
