# Mortgage Knowledge Packs & Playbooks

## Required Knowledge Packs

### Mortgage Foundation Pack

- terminology
- product taxonomy
- party taxonomy
- workflow map
- document map
- compliance overview

### Processing Pack

- document checklists
- borrower follow-up
- condition management
- third-party tracking
- milestone management

### Underwriting Pack

- income analysis
- asset analysis
- credit review
- collateral review
- compensating factors
- investor overlays

### TRID & Compliance Pack

- disclosure timing
- fee tolerance
- changed circumstance
- ECOA
- HMDA
- fair lending
- flood

### Closing & Funding Pack

- CD workflow
- closing documents
- wire/funding controls
- post-closing
- trailing documents

### Secondary Market Pack

- rate locks
- best execution
- investor delivery
- warehouse
- suspense
- gain on sale

### Servicing Pack

- escrow
- payment posting
- default
- loss mitigation
- payoff
- release

## Playbooks

- Mortgage Pipeline Management
- Borrower Document Collection
- Underwriting Submission
- Conditions Clearing
- TRID Monitoring
- Closing Readiness
- Post-Closing Defect Reduction
- Investor Delivery
- Warehouse Aging Reduction
- Servicing Transfer
- Early Default Review
- HMDA Data Quality

## Dispatch Truth Statement

Mortgage knowledge packs turn complex regulatory and operational expertise into reusable, executable intelligence.
