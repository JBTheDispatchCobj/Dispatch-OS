# Mortgage Products & Channels

## Mortgage Product Taxonomy

### Agency / Conventional

- fixed-rate conventional
- adjustable-rate conventional
- conforming
- high-balance
- HomeReady/Home Possible-type products where applicable
- investment property conventional
- second home conventional

### Government

- FHA purchase
- FHA refinance
- VA purchase
- VA IRRRL
- USDA rural housing
- state housing finance agency programs

### Portfolio

- jumbo portfolio
- relationship mortgage
- community mortgage
- unique property loan
- non-saleable retained loan
- construction-to-permanent
- bridge
- first lien HELOC where offered

### Home Equity

- HELOC
- closed-end second
- home improvement loan
- piggyback second

### Refinance

- rate-term refinance
- cash-out refinance
- streamline refinance
- construction refinance
- debt consolidation refinance

### Specialized / Investor

- DSCR investor loan
- non-QM
- bank statement loan
- asset depletion
- foreign national where offered
- rehab loan

## Channel Objects

- Retail
- Branch Referral
- Digital Application
- Call Center
- Realtor Referral
- Builder Referral
- Correspondent
- Broker
- Consumer Direct
- Credit Union Member Referral
- Commercial Relationship Referral

## Product Object Fields

- product_id
- product_type
- investor
- eligibility
- max_LTV
- max_DTI
- minimum_credit_score
- occupancy
- property_type
- income_rules
- asset_rules
- mortgage_insurance
- pricing_adjustments
- disclosures
- required_documents
- servicing_model
- secondary_market_outlet
- compliance_requirements

## Product Lifecycle

Product Selection → Eligibility Check → Pricing → Disclosure → Underwriting → Closing → Delivery/Portfolio → Servicing → Monitoring

## Product KPIs

- applications
- approval rate
- fallout
- funded volume
- average loan size
- gain on sale
- portfolio yield
- repurchase/defect rate
- servicing retention
- delinquency
- borrower satisfaction

## AI Opportunities

- product eligibility support
- product comparison
- pricing scenario
- borrower suitability summary
- investor overlay identification
- portfolio vs sale recommendation
- channel performance analysis

## Dispatch Truth Statement

Mortgage products are not rate sheets. They are program rule sets connected to borrower eligibility, property eligibility, disclosures, underwriting, investor delivery, servicing, and compliance.
