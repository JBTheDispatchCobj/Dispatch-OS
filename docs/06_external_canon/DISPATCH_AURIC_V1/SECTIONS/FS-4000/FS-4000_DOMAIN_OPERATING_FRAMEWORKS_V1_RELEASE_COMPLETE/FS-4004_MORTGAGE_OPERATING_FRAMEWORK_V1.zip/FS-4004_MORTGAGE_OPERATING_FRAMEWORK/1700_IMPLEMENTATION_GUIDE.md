# Mortgage Implementation Guide

## Phase 1 — Setup

- define mortgage department
- configure product taxonomy
- define roles
- define approval authority
- configure milestones
- configure document checklist
- configure compliance clocks
- define investors
- define servicing model

## Phase 2 — Objects

- borrower
- application
- loan
- property
- disclosure
- condition
- appraisal
- title
- insurance
- rate lock
- closing
- funding
- servicing
- QC defect

## Phase 3 — Connectors

- LOS
- POS
- document storage
- email/calendar
- CRM
- e-sign
- credit bureau
- appraisal
- title
- compliance testing
- secondary market
- servicing

## Phase 4 — Agents

Deploy:
- Loan Officer Assistant
- Document Classifier
- Condition Manager
- Underwriting Summary Agent
- TRID Monitor
- Closing Checklist Agent
- Post-Closing Defect Agent
- Secondary Market Advisor
- HMDA Quality Agent

## Phase 5 — Workflows

Activate:
- lead to application
- initial disclosure
- processing
- underwriting
- appraisal
- title
- closing
- post-closing
- investor delivery
- servicing transfer

## Demo Flow

1. Open mortgage pipeline.
2. Select borrower and loan.
3. Generate borrower checklist.
4. Show disclosure clock.
5. Run processing completeness review.
6. Generate underwriting summary.
7. Show conditions.
8. Show closing readiness.
9. Show investor delivery status.
10. Show QC defect dashboard.

## Dispatch Truth Statement

Mortgage implementation should focus first on milestone visibility, document completeness, disclosure timing, and human-in-the-loop decision support.
