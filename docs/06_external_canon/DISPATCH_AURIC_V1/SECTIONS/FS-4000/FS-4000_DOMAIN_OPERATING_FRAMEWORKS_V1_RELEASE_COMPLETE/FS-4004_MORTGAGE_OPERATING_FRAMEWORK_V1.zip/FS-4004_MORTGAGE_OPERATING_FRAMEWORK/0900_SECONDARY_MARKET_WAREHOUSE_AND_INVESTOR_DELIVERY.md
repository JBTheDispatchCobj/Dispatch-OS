# Secondary Market, Warehouse & Investor Delivery

## Purpose

This document defines mortgage secondary market, warehouse lending, investor delivery, and portfolio strategy.

## Secondary Market Objects

- Investor
- Agency
- Aggregator
- Correspondent
- Lock Desk
- Rate Lock
- Best Execution
- Commitment
- Delivery Package
- Suspense
- Purchase Advice
- Gain on Sale
- Servicing Released Premium
- Servicing Retained Asset
- Repurchase Request
- Indemnification

## Warehouse Facility Object

Fields:
- warehouse_id
- lender
- line_amount
- availability
- advance_rate
- eligibility
- collateral
- aged_loans
- dwell_time
- interest_rate
- covenants
- reporting
- bailee
- investor_takeout
- exceptions

## Rate Lock Object

Fields:
- lock_id
- loan_id
- product
- rate
- price
- lock_date
- expiration
- extension
- investor
- margin
- hedge_status
- fallout_risk

## Best Execution

Inputs:
- product
- rate
- price
- investor options
- servicing value
- delivery timeline
- eligibility
- gain on sale
- portfolio value
- liquidity need
- risk appetite

## Investor Delivery Workflow

Loan Funded → Post-Closing Review → Investor Package → Delivery → Suspense Review → Conditions Cleared → Purchase Advice → Warehouse Payoff → Gain on Sale Recognition → Archive

## Portfolio Retention Decision

Dispatch evaluates:
- relationship value
- yield
- duration
- credit risk
- liquidity
- capital
- servicing capability
- interest rate risk
- market sale price
- strategic purpose

## KPIs

- gain on sale
- lock fallout
- pull-through rate
- warehouse dwell time
- investor suspense
- purchase time
- repurchase requests
- delivery defects
- servicing retained value
- portfolio yield

## AI Opportunities

- best execution support
- lock expiration monitoring
- fallout prediction
- investor eligibility check
- suspense response drafting
- portfolio vs sale recommendation
- warehouse aging dashboard
- gain on sale commentary

## Dispatch Truth Statement

Secondary market execution connects mortgage operations to capital markets. Dispatch must track the loan from rate lock through delivery, purchase, warehouse payoff, and post-sale risk.
