# Acceptance Tests & Roadmap

## Object Tests

- Can create Borrower.
- Can create Mortgage Application.
- Can create Mortgage Loan.
- Can create Property.
- Can create Loan Estimate.
- Can create Closing Disclosure.
- Can create Condition.
- Can create Appraisal.
- Can create Title.
- Can create Rate Lock.
- Can create Closing Package.
- Can create Funding Authorization.
- Can create Servicing Transfer.
- Can create QC Defect.

## Relationship Tests

- Borrower APPLIES_FOR Loan.
- Loan SECURED_BY Property.
- Loan HAS Disclosure.
- Loan HAS Conditions.
- Appraisal VALUES Property.
- Title SUPPORTS Closing.
- Rate Lock PRICES Loan.
- Investor PURCHASES Loan.
- Servicer SERVICES Loan.
- Defect IMPACTS Loan.

## Workflow Tests

- Initial disclosure workflow tracks timing.
- Processing workflow identifies missing documents.
- Underwriting workflow produces summary and conditions.
- Closing workflow validates CD and funding.
- Post-closing workflow tracks defects.
- Investor delivery workflow tracks suspense.
- Servicing workflow boards loan.

## Agent Tests

- Document Classifier categorizes uploaded documents.
- Condition Manager identifies open conditions.
- Underwriting Summary Agent explains file.
- TRID Monitor flags timing issues.
- Closing Checklist Agent identifies blockers.
- Post-Closing Defect Agent classifies defect.
- Secondary Market Advisor summarizes delivery.

## Roadmap

Priority 1:
- machine-readable mortgage object registry
- fixture mortgage loan
- sample borrower package
- sample underwriting summary
- sample closing checklist

Priority 2:
- disclosure clock engine
- conditions workflow
- document classifier
- investor delivery status
- QC defect registry

Priority 3:
- servicing extension
- loss mitigation workflow
- warehouse monitoring
- secondary market analytics
- HMDA data quality engine

## Dispatch Truth Statement

The Mortgage cartridge is accepted when Dispatch can manage the mortgage lifecycle as a regulated, evidence-based, multi-party operating workflow from application through servicing.
