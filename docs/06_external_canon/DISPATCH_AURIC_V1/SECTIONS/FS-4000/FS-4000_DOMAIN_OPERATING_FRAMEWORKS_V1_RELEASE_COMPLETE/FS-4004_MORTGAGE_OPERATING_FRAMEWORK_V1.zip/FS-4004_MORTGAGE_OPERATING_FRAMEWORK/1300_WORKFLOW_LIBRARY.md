# Mortgage Workflow Library

## Universal Workflow Schema

- workflow_id
- name
- trigger
- owner
- participants
- agents
- required_objects
- required_documents
- rules
- disclosures
- conditions
- KPIs
- outputs
- evidence
- audit_history

## Required Workflows

### Lead to Application

Lead → Contact → Prequalification → Product Discussion → Application → Credit Authorization → Submission

### Initial Disclosure

Application Trigger → Fee Collection → LE Generation → Delivery → Evidence → Intent to Proceed

### Processing

Document Request → Document Intake → Verification → Third-Party Orders → Conditions → Submission to Underwriting

### Underwriting

File Review → Income/Asset/Credit/Collateral Analysis → Decision → Conditions → Resubmission → Clear to Close

### Appraisal

Order → Inspection → Report → Review → Conditions → Reconsideration → Acceptance

### Title

Order → Commitment → Exception Review → Clearance → Final Policy

### Closing

Clear to Close → CD → Closing Schedule → Docs → Signing → Funding

### Post-Closing

File Review → Trailing Docs → Investor Delivery → Suspense → Purchase → Archive

### Servicing Transfer

Boarding → Welcome → Payment Setup → Escrow → Investor Reporting

### Default / Loss Mitigation

Delinquency → Contact → Hardship Review → Options → Approval → Execution → Monitoring

## Workflow KPIs

- cycle time
- milestone aging
- disclosure timing
- underwriting turn time
- condition aging
- closing delay
- funding errors
- post-closing defects
- investor suspense
- borrower satisfaction

## Dispatch Truth Statement

Mortgage workflows are time-bound evidence chains. Dispatch must coordinate documents, people, systems, deadlines, decisions, and capital market outputs.
