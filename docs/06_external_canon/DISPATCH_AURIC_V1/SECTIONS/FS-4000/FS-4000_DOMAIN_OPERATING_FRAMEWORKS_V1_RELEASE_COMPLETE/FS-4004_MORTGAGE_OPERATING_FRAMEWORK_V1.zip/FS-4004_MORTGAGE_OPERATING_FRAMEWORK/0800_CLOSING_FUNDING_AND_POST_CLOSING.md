# Closing, Funding & Post-Closing

## Purpose

This document defines mortgage closing, funding, post-closing, and delivery operations.

## Closing Object

Fields:
- closing_id
- loan_id
- scheduled_date
- settlement_agent
- title_company
- signing_location
- closing_disclosure
- cash_to_close
- closing_package
- conditions
- funding_status
- wire_status
- recording_status
- rescission_status
- post_closing_status

## Closing Workflow

Clear to Close → CD Finalization → Closing Scheduled → Docs Prepared → Docs Sent → Signing → Funding Review → Wire → Recording → Post-Closing Review → Delivery/Boarding

## Funding Object

Fields:
- funding_id
- loan_id
- amount
- wire_destination
- authorization
- funding_conditions
- review_status
- release_time
- confirmation
- exceptions
- audit_evidence

## Post-Closing Object

Fields:
- post_closing_id
- loan_id
- document_review
- missing_documents
- trailing_documents
- recorded_mortgage
- final_title_policy
- investor_delivery_status
- suspense_items
- cure_items
- QC_status
- archive_status

## Trailing Documents

- recorded mortgage/deed of trust
- final title policy
- original note
- assignments
- endorsements
- insurance updates
- final CD
- recorded riders
- investor-specific documents

## Closing Risks

- CD timing
- cash-to-close mismatch
- title issue
- wire fraud
- missing signatures
- funding condition
- rescission issue
- recording delay
- investor suspense
- post-closing defect
- repurchase risk

## KPIs

- clear-to-close to closing time
- closing delay rate
- funding error rate
- wire exception rate
- post-closing defects
- trailing document aging
- investor suspense
- delivery time
- cure count
- borrower satisfaction

## AI Opportunities

- closing package checklist
- funding condition review
- wire fraud warning
- post-closing defect detection
- trailing document tracker
- investor suspense response draft
- closing delay root cause

## Dispatch Truth Statement

Closing is the point where regulatory compliance, collateral, borrower commitment, capital, and legal documentation converge. Dispatch must treat it as a controlled execution event.
