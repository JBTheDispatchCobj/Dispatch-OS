# Servicing, Default & Loss Mitigation

## Purpose

This document defines mortgage servicing, escrow, default, loss mitigation, foreclosure, payoff, and release.

## Servicing Object

Fields:
- servicing_id
- loan_id
- servicer
- subservicer
- payment_status
- escrow_status
- investor
- customer_service_history
- delinquency_status
- loss_mitigation_status
- payoff_status
- release_status

## Servicing Functions

- payment processing
- escrow administration
- tax payments
- insurance tracking
- investor reporting
- customer service
- ARM adjustments
- payoff
- lien release
- default management
- loss mitigation
- foreclosure coordination
- bankruptcy tracking

## Escrow Object

Fields:
- escrow_id
- taxes
- insurance
- cushion
- analysis_date
- shortage
- surplus
- disbursements
- next_analysis
- exceptions

## Default Lifecycle

Current → 30 Days → 60 Days → 90 Days → Demand → Loss Mitigation → Foreclosure Referral → Foreclosure → REO → Liquidation → Recovery/Charge-Off

## Loss Mitigation Options

- repayment plan
- forbearance
- deferral
- modification
- short sale
- deed in lieu
- partial claim where applicable
- refinance
- reinstatement

## Payoff Workflow

Request → Quote → Verification → Payment → Satisfaction → Release → Archive

## Servicing KPIs

- delinquency rate
- roll rate
- cure rate
- foreclosure starts
- loss mitigation approvals
- escrow exceptions
- tax/insurance exceptions
- customer service complaints
- payoff turn time
- release timeliness
- servicing cost per loan

## AI Opportunities

- borrower hardship summary
- loss mitigation checklist
- delinquency trend analysis
- escrow exception summary
- payoff letter support
- investor reporting summary
- servicing complaint analysis
- default risk forecast

## Dispatch Truth Statement

Servicing is the long tail of mortgage trust. Dispatch must maintain borrower history, investor obligations, collateral protection, compliance evidence, and default intelligence for the full life of the loan.
