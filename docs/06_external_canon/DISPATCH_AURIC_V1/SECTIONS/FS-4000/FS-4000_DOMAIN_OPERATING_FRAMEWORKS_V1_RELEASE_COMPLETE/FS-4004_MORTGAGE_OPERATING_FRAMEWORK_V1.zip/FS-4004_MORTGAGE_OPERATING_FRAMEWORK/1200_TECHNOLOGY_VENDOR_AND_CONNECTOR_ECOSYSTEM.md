# Technology, Vendor & Connector Ecosystem

## Purpose

This document defines the mortgage technology stack and connector priorities.

## Mortgage Technology Categories

- POS
- LOS
- PPE
- Credit Reporting
- AUS
- Document Management
- E-Signature
- E-Closing
- Appraisal Management
- Title Platform
- Verification of Income
- Verification of Assets
- Fraud Detection
- Compliance Testing
- HMDA Reporting
- Secondary Marketing
- Lock Desk
- Servicing Platform
- CRM
- Marketing Automation
- Data Warehouse
- BI
- AI Platform

## Vendor Objects

- LOS Vendor
- POS Vendor
- Credit Bureau
- AUS Provider
- Appraisal Management Company
- Title Provider
- Compliance Vendor
- Document Vendor
- E-Sign Vendor
- Servicer
- Subservicer
- Investor
- Warehouse Lender
- PPE Vendor
- Verification Vendor

## Common Systems

Examples:
- Encompass
- Blend
- MeridianLink
- Mortgage Cadence
- Byte
- LendingQB / ICE Mortgage
- Black Knight / MSP
- Fannie Mae DU
- Freddie Mac LPA
- MERS
- DocuSign
- DocMagic
- Optimal Blue
- Polly
- Credit bureaus
- Appraisal platforms
- Title platforms

## Connector Priorities

Tier 1:
- LOS
- document storage
- email/calendar
- CRM
- e-sign
- spreadsheet/CSV
- AI provider

Tier 2:
- POS
- PPE
- AUS
- credit report
- appraisal
- title
- compliance testing
- HMDA
- secondary marketing

Tier 3:
- servicing
- warehouse
- investor delivery
- QC platform
- fraud tools
- verification providers

## Connector Objects

Each connector maps:
- loan
- borrower
- property
- milestone
- document
- condition
- disclosure
- appraisal
- title
- lock
- closing
- funding
- delivery
- servicing

## AI Opportunities

- connector mapping
- loan status normalization
- document classification
- data quality checks
- milestone exception alerts
- vendor performance analysis
- pipeline reconciliation

## Dispatch Truth Statement

Mortgage systems are fragmented by function. Dispatch makes them coherent by mapping every vendor record back to canonical mortgage objects.
