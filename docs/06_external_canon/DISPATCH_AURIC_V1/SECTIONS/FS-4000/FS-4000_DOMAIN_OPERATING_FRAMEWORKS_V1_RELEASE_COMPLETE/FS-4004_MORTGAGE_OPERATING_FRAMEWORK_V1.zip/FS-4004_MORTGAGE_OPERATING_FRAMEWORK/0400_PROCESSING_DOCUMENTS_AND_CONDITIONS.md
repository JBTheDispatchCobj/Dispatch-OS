# Processing, Documents & Conditions

## Purpose

This document defines mortgage processing operations.

## Processor Role

The processor coordinates the file from application through underwriting and closing readiness.

Responsibilities:

- document collection
- borrower communication
- verification ordering
- appraisal ordering coordination
- title ordering coordination
- insurance tracking
- condition management
- disclosure support
- milestone management
- file completeness
- closing readiness

## Document Categories

### Borrower Documents

- government ID
- pay stubs
- W-2s
- tax returns
- bank statements
- retirement statements
- gift letter
- divorce decree
- child support documentation
- rent history
- explanation letters

### Property Documents

- purchase contract
- appraisal
- title commitment
- homeowners insurance
- flood determination
- survey where required
- condo documents
- HOA documents
- property tax
- inspection where required

### Credit Documents

- credit report
- liabilities
- payoff statements
- mortgage statements
- student loan documentation
- bankruptcy/discharge documentation
- derogatory explanations

### Closing Documents

- closing disclosure
- note
- mortgage/deed of trust
- riders
- affidavits
- escrow documents
- right of rescission where applicable
- settlement statement

## Condition Object

Fields:
- condition_id
- loan_id
- condition_type
- requested_by
- description
- required_document
- owner
- due_date
- status
- borrower_visible
- underwriting_signoff
- clearing_evidence
- expiration
- escalation

## Condition Lifecycle

Created → Assigned → Requested → Received → Reviewed → Cleared / Rejected → Resubmitted → Cleared → Archived

## Processing KPIs

- file completeness
- documents outstanding
- average condition count
- condition aging
- processing turn time
- borrower response time
- appraisal outstanding
- title outstanding
- insurance outstanding
- clear-to-close rate
- closing delay rate

## AI Opportunities

- document checklist generation
- condition explanation
- borrower reminder drafting
- document classification
- missing document detection
- stale document alerting
- condition clearing summary
- processor daily work queue
- file completeness scoring

## Dispatch Truth Statement

Processing is not clerical work. It is regulated evidence orchestration that determines whether a loan can move through underwriting, closing, funding, and delivery.
