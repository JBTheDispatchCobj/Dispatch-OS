# Underwriting & Decisioning

## Purpose

This document defines mortgage underwriting operations.

## Underwriting Framework

Underwriting evaluates:

- credit
- capacity
- capital
- collateral
- conditions
- compliance
- program eligibility
- investor overlays
- fraud indicators
- compensating factors

## Underwriting Decision Object

Fields:
- decision_id
- loan_id
- underwriter
- decision_type
- approval_status
- conditions
- exceptions
- overlays
- ratios
- credit_assessment
- income_assessment
- asset_assessment
- collateral_assessment
- fraud_assessment
- compliance_assessment
- notes
- date
- version

## Decision Types

- Approved
- Approved with Conditions
- Suspended
- Denied
- Counteroffer
- Withdrawn
- Incomplete
- Clear to Close
- Investor Suspense
- Final Approval

## Income Analysis

Objects:
- employment
- base income
- overtime
- bonus
- commission
- self-employment
- rental income
- retirement income
- alimony/child support
- asset depletion
- tax returns
- transcripts
- VOE
- income calculation

## Asset Analysis

Objects:
- checking
- savings
- investment accounts
- retirement
- gift funds
- reserves
- large deposits
- source of funds
- down payment
- closing costs
- seller credits
- interested party contributions

## Credit Analysis

Objects:
- credit report
- score
- tradelines
- mortgage history
- late payments
- collections
- judgments
- bankruptcy
- foreclosure
- credit inquiries
- liabilities
- disputed accounts

## Collateral Analysis

Objects:
- appraisal
- property type
- occupancy
- marketability
- condition
- value
- comparable sales
- required repairs
- condo eligibility
- flood
- title

## Underwriting KPIs

- underwriting turn time
- approval rate
- suspension rate
- denial rate
- average condition count
- resubmission count
- exception rate
- defect rate
- investor suspense rate
- clear-to-close cycle time

## AI Opportunities

- underwriting summary
- income calculation support
- asset review
- credit issue summary
- collateral risk summary
- condition recommendation
- compensating factor identification
- denial reason draft support
- investor guideline comparison

## Dispatch Truth Statement

Underwriting is not a black-box decision. It is evidence-based reasoning over borrower capacity, credit, collateral, program rules, and investor requirements.
