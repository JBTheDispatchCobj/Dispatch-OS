# Portfolio Management & Special Assets

## Purpose

This document defines ongoing commercial portfolio management, watchlist, collections, workout, and special assets operations.

## Portfolio Object

Fields:
- portfolio_id
- owner
- segment
- total_exposure
- borrowers
- industries
- geographies
- products
- risk_distribution
- yield
- delinquency
- criticized_classified
- concentrations
- maturity_ladder
- covenant_status
- exception_status
- profitability

## Portfolio Management Lifecycle

Boarding → Relationship Monitoring → Financial Updates → Covenant Testing → Annual Review → Risk Rating Update → Renewal → Expansion → Watchlist or Continue

## Watchlist Object

Fields:
- watchlist_id
- borrower
- loan
- reason
- risk_rating
- triggers
- action_plan
- owner
- review_frequency
- collateral_status
- guarantor_status
- liquidity_status
- exit_strategy

## Special Assets Lifecycle

Early Warning → Watchlist → Special Mention → Workout → Forbearance → Modification → Liquidation → Charge-Off → Recovery → Archive

## Early Warning Indicators

- missed payments
- declining deposits
- overdraft increase
- covenant breach
- delayed financials
- management change
- customer loss
- supplier disruption
- industry decline
- tax lien
- lawsuit
- collateral deterioration
- insurance lapse
- liquidity stress

## Workout Tools

- payment modification
- forbearance
- interest-only period
- maturity extension
- collateral sale
- guarantor support
- refinance
- recapitalization
- liquidation
- bankruptcy strategy
- charge-off
- recovery plan

## Portfolio KPIs

- total exposure
- weighted average risk grade
- delinquency
- nonaccrual
- criticized/classified
- watchlist percentage
- annual review completion
- covenant breaches
- exception count
- charge-offs
- recoveries
- yield
- concentration
- maturity risk

## AI Opportunities

- early warning detection
- portfolio summary
- watchlist memo
- annual review drafting
- borrower risk update
- workout strategy support
- collateral liquidation summary
- recovery tracking
- board credit dashboard commentary

## Dispatch Truth Statement

Portfolio management is the ongoing institutional memory of credit decisions. Every credit outcome should improve future underwriting, monitoring, pricing, and risk selection.
