# Commercial Banking Workflow Library

## Universal Workflow Schema

- workflow_id
- name
- trigger
- business_owner
- participants
- agents
- inputs
- documents
- rules
- approvals
- outputs
- KPIs
- evidence
- audit

## Required Workflows

### Business Prospecting

Target Market → Lead → Research → Outreach → Meeting → Qualification → Relationship Plan → Opportunity

### Relationship Review

Portfolio Pull → Relationship Summary → Product Usage → Profitability → Risk Status → Opportunities → Next Actions

### Treasury Needs Assessment

Discovery → Payment Flows → Fraud Controls → Account Structure → Product Recommendation → Pricing → Implementation

### Commercial Loan Origination

Opportunity → Application → Documents → Underwriting → Credit Memo → Approval → Closing → Funding → Boarding

### Annual Review

Due List → Request Financials → Spread → Covenant Test → Risk Rating → Relationship Update → Approval → Archive

### Covenant Monitoring

Tickler → Evidence Collection → Calculation → Pass/Fail → Exception/Waiver → Escalation → Portfolio Update

### Construction Draw

Draw Request → Inspection → Lien Waivers → Budget Review → Approval → Funding → Update Project

### Vendor/Fintech Referral

Capability Gap → Vendor Search → Fit Review → Introduction → Pilot → Measurement → Relationship Expansion

### Watchlist Review

Early Warning → Analyst Review → Action Plan → Committee Review → Monitoring → Upgrade/Downgrade

### Workout

Default Trigger → Borrower Contact → Collateral Review → Strategy → Forbearance/Modification/Liquidation → Recovery

## Workflow KPIs

- cycle time
- approval time
- touch time
- rework
- exception rate
- automation percentage
- document completeness
- SLA compliance
- revenue impact
- risk reduction

## Dispatch Truth Statement

Commercial banking workflows are the operational path from relationship intelligence to financial outcome.
