# Commercial Banking Operating Model

## Definition

Commercial banking is the institutional function that serves businesses through credit, deposit, treasury, payment, advisory, and relationship management services.

## Operating Layers

### 1. Market Coverage

Defines target markets, industries, geographies, customer segments, relationship manager coverage, referral sources, and growth strategy.

### 2. Relationship Management

Owns business development, customer discovery, relationship planning, cross-sell, meetings, renewal discussions, and strategic account management.

### 3. Deposit & Treasury

Owns commercial operating accounts, business deposits, merchant services, ACH, wires, positive pay, cash management, fraud controls, sweeps, and liquidity services.

### 4. Credit Origination

Owns loan opportunities, applications, underwriting requests, term sheets, pricing, structure, credit memos, and approvals.

### 5. Credit Administration

Owns documentation, closing, funding, boarding, collateral perfection, covenant setup, ticklers, annual reviews, exceptions, and file quality.

### 6. Portfolio Management

Owns ongoing monitoring, risk ratings, renewals, financial statement collection, covenant testing, watchlist management, and customer health.

### 7. Special Assets

Owns delinquency, workout, modification, forbearance, liquidation, bankruptcy, charge-off, recovery, and lessons learned.

### 8. Risk & Compliance

Owns policy compliance, concentration monitoring, fair lending, BSA/KYB, beneficial ownership, credit exceptions, documentation exceptions, and audit readiness.

### 9. Technology & Data

Owns CRM, LOS, credit spreading, document management, tickler systems, core integration, treasury platforms, dashboards, and AI agents.

## Commercial Banking Departments

- Commercial Banking
- Business Banking
- Treasury Management
- Credit Administration
- Underwriting
- Portfolio Management
- Loan Operations
- Loan Servicing
- Special Assets
- Collections
- Business Development
- SBA Department
- Construction Lending
- CRE Lending
- Equipment Finance
- Merchant Services
- Cash Management Support

## Commercial Operating Cadence

Daily:
- pipeline updates
- treasury exceptions
- upcoming closings
- past-due loans
- covenant alerts
- high-priority customer issues

Weekly:
- relationship manager pipeline
- credit approvals
- loan documentation status
- exception clearing
- deposit movement
- treasury implementations
- watchlist review

Monthly:
- portfolio dashboard
- risk rating migration
- past dues
- concentration review
- production report
- profitability report
- treasury revenue
- annual review status

Quarterly:
- credit committee
- board lending package
- regulatory reporting support
- policy exceptions
- stress testing
- industry review
- portfolio segmentation

Annual:
- relationship plans
- annual reviews
- policy review
- market strategy
- compensation plan
- credit concentration limits
- technology roadmap

## Dispatch Truth Statement

Commercial banking is an operating system for business relationships. Credit is one component; deposits, treasury, payments, risk, profitability, and knowledge are equally critical.
