# Commercial Real Estate

## Purpose

This document defines CRE lending, collateral, underwriting, risk, monitoring, and portfolio management.

## CRE Property Types

- Office
- Retail
- Industrial
- Warehouse
- Multifamily
- Mixed-Use
- Hospitality
- Medical Office
- Self Storage
- Mobile Home Park
- Senior Housing
- Student Housing
- Land
- Special Purpose
- Owner-Occupied
- Investor-Owned

## CRE Loan Object

Fields:
- loan_id
- borrower
- sponsor
- property
- property_type
- location
- loan_amount
- current_balance
- LTV
- DSCR
- debt_yield
- NOI
- occupancy
- cap_rate
- appraisal
- environmental
- title
- survey
- leases
- tenant_roll
- maturity
- amortization
- covenants
- risk_rating

## Property Object

Fields:
- property_id
- address
- property_type
- units
- square_feet
- occupancy
- tenants
- leases
- NOI
- expenses
- valuation
- appraisal_date
- environmental_status
- insurance
- taxes
- zoning
- condition
- capital_needs

## CRE Underwriting

- sponsor analysis
- borrower structure
- property cash flow
- tenant quality
- lease rollover
- market analysis
- appraisal review
- environmental review
- title review
- insurance
- debt service coverage
- exit/refinance risk
- sensitivity analysis

## CRE Documents

- rent roll
- operating statements
- appraisal
- environmental phase I/II
- title commitment
- survey
- leases
- insurance
- property tax bills
- purchase agreement
- management agreement
- borrower organizational docs

## CRE Monitoring

- annual financials
- rent roll updates
- occupancy changes
- covenant testing
- property inspections
- insurance renewal
- tax payments
- appraisal updates
- market changes
- tenant concentration
- maturity management

## CRE KPIs

- CRE portfolio balance
- weighted LTV
- weighted DSCR
- property type concentration
- geographic concentration
- occupancy trend
- maturity ladder
- exception rate
- criticized/classified CRE
- past due
- charge-off
- covenant breaches

## AI Opportunities

- appraisal review summary
- rent roll analysis
- NOI normalization
- lease rollover risk
- CRE market brief
- covenant monitoring
- property inspection summary
- maturity/refinance risk alert
- portfolio concentration summary

## Dispatch Truth Statement

CRE lending is collateral-intensive relationship lending. Dispatch must understand the sponsor, property, tenants, cash flow, market, documents, covenants, and exit risk as one connected object graph.
