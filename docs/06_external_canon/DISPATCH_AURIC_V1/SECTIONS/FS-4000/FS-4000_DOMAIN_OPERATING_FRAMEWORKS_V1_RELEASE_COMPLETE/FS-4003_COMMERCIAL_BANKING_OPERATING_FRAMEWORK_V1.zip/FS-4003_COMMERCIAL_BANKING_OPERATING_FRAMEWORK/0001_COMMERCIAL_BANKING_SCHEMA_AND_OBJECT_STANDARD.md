# Commercial Banking Schema & Object Standard

## Purpose

This document defines the canonical commercial banking objects used across Dispatch.

## Universal Commercial Relationship Object

Fields:

- relationship_id
- institution_id
- business_customer_id
- relationship_manager_id
- portfolio_manager_id
- customer_segment
- industry
- NAICS
- geography
- relationship_status
- deposits
- treasury_services
- loans
- guarantees
- collateral
- profitability
- risk_rating
- opportunity_pipeline
- meetings
- communications
- documents
- policies
- workflows
- KPIs
- AI_context
- knowledge_links
- audit_history

## Business Customer Object

Fields:

- business_id
- legal_name
- DBA
- entity_type
- tax_id_reference
- NAICS
- industry
- ownership
- beneficial_owners
- guarantors
- management_team
- revenue
- EBITDA
- employees
- locations
- products_services
- customer_base
- suppliers
- seasonality
- financial_statements
- tax_returns
- deposit_accounts
- treasury_services
- loans
- collateral
- risk_rating
- compliance_profile
- relationship_score

## Commercial Product Objects

- Commercial DDA
- Business Checking
- Business Money Market
- Commercial Savings
- Escrow Account
- Operating Account
- Payroll Account
- Merchant Account
- ACH Origination
- Wire Services
- Remote Deposit Capture
- Positive Pay
- Lockbox
- Sweep Account
- Zero Balance Account
- Commercial Line of Credit
- Term Loan
- Equipment Loan
- Owner-Occupied CRE Loan
- Investor CRE Loan
- Construction Loan
- SBA 7(a)
- SBA 504
- USDA Loan
- Letter of Credit
- Participation Loan
- Syndicated Loan
- Treasury Management Package
- Merchant Services

## Credit Objects

- Credit Request
- Credit Memo
- Borrower
- Guarantor
- Collateral
- Appraisal
- Environmental Report
- Title
- Survey
- UCC Filing
- Covenant
- Risk Rating
- Approval
- Condition
- Loan Agreement
- Promissory Note
- Security Agreement
- Annual Review
- Renewal
- Watchlist
- Workout
- Charge-Off
- Recovery

## Relationship Rule

Commercial banking must never model a business customer as only a borrower. Every business customer should be evaluated across deposits, treasury, credit, payments, profitability, risk, and strategic opportunity.

## Dispatch Truth Statement

Commercial banking objects are relationship objects before they are product records. This enables Dispatch to reason across the full customer relationship instead of isolated loan or deposit systems.
