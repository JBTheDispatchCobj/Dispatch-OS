# Technology, Data & Connectors

## Purpose

This document defines the technology stack required for commercial banking operations.

## Commercial Banking Systems

- CRM
- LOS
- Credit Spreading
- Document Management
- Core Banking
- Treasury Platform
- Payments Platform
- Covenant Tracking
- Tickler System
- Portfolio Management
- Collateral Management
- Appraisal Management
- Risk Rating System
- BI Dashboard
- Data Warehouse
- Digital Signature
- Email/Calendar
- Board/Credit Committee Portal
- AI Platform

## Key Connectors

Tier 1:
- CRM
- LOS
- document storage
- email/calendar
- core exports
- GL/accounting
- spreadsheet import
- AI provider

Tier 2:
- treasury platform
- credit spreading
- covenant tracking
- portfolio management
- digital signature
- BI/data warehouse
- payment systems

Tier 3:
- appraisal management
- lien/UCC search
- tax transcript
- entity verification
- insurance verification
- construction inspection
- environmental reports

## Data Objects

- business customer
- beneficial owner
- relationship
- pipeline
- loan application
- credit memo
- collateral
- covenant
- tickler
- document
- approval
- deposit account
- treasury service
- payment volume
- profitability
- KPI

## Data Quality Rules

- borrower IDs must resolve to canonical business objects
- guarantors must link to individuals
- collateral must link to loans
- covenants must link to tested evidence
- documents must link to workflow stage
- approvals must link to authority source
- all external IDs must preserve source lineage

## AI Opportunities

- data mapping
- duplicate borrower detection
- missing document detection
- stale financial statement alerts
- system reconciliation
- relationship graph enrichment
- connector error summarization

## Dispatch Truth Statement

Commercial banking technology should not trap relationship intelligence inside separate systems. Dispatch makes every system legible through canonical objects and connectors.
