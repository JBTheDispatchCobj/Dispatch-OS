# Commercial Lending & Credit

## Purpose

This document defines commercial credit origination, underwriting, approval, documentation, funding, and monitoring.

## Commercial Credit Products

- Working Capital Line
- Revolving Line of Credit
- Term Loan
- Equipment Loan
- Owner-Occupied CRE
- Investor CRE
- Construction Loan
- Acquisition Loan
- SBA 7(a)
- SBA 504
- USDA Loan
- Letter of Credit
- Guidance Line
- Borrowing Base Facility
- Floor Plan Line
- Franchise Loan
- Professional Practice Loan
- Participation Loan
- Syndicated Loan

## Commercial Credit Request Object

Fields:
- request_id
- borrower
- guarantors
- amount_requested
- product_type
- purpose
- repayment_source
- collateral
- requested_terms
- pricing
- risk_rating
- policy_exceptions
- relationship_context
- deposit_relationship
- treasury_relationship
- financials
- documents
- approval_authority

## Underwriting Framework

### Borrower Analysis

- business history
- ownership
- management
- industry
- revenue streams
- customers
- suppliers
- competitive position
- legal structure

### Financial Analysis

- revenue
- gross margin
- EBITDA
- cash flow
- leverage
- liquidity
- working capital
- debt service coverage
- trends
- seasonality
- projections

### Collateral Analysis

- collateral type
- valuation
- advance rate
- lien position
- perfection
- insurance
- monitoring frequency
- liquidation value

### Guarantor Analysis

- net worth
- liquidity
- contingent liabilities
- credit history
- income
- willingness
- enforceability

## Credit Memo Workflow

Request → Data Collection → Spreading → Analysis → Structure → Risk Rating → Pricing → Memo Draft → Review → Committee → Approval → Conditions → Closing

## Approval Matrix Inputs

- total exposure
- borrower group exposure
- risk rating
- policy exceptions
- collateral
- industry
- structure
- term
- unsecured exposure
- concentration
- officer authority

## Credit KPIs

- commercial loan growth
- funded volume
- pipeline
- approval rate
- decision time
- funding time
- average DSCR
- average LTV
- weighted risk grade
- exception rate
- portfolio yield
- past due
- charge-off
- annual review completion

## AI Opportunities

- credit memo drafting
- financial spreading
- cash flow analysis
- risk rating support
- covenant recommendation
- pricing recommendation
- policy exception detection
- approval memo summary
- borrower meeting prep
- annual review drafting

## Dispatch Truth Statement

Commercial lending converts business understanding into structured risk. Dispatch must connect the borrower, relationship, collateral, financials, policy, approval, documentation, and monitoring into one continuous lifecycle.
