# Commercial Banking Implementation Guide

## Phase 1 — Setup

- create commercial banking department
- define relationship manager roles
- define credit roles
- define treasury roles
- define approval authority
- configure portfolio segments
- configure product taxonomy
- configure risk rating scale

## Phase 2 — Objects

- business customers
- beneficial owners
- guarantors
- relationships
- products
- loans
- deposits
- treasury services
- collateral
- covenants
- documents
- KPIs

## Phase 3 — Workflows

Activate:
- relationship plan
- treasury needs assessment
- commercial loan origination
- credit memo
- annual review
- covenant monitoring
- construction draw
- watchlist
- workout

## Phase 4 — Agents

Deploy:
- RM Prep Agent
- Credit Memo Writer
- Financial Spreading Agent
- Covenant Monitor
- Annual Review Agent
- Treasury Needs Agent
- Portfolio Risk Agent
- Watchlist Agent

## Phase 5 — Dashboards

Configure:
- commercial executive
- RM
- pipeline
- portfolio risk
- treasury
- annual review
- covenant
- watchlist

## Phase 6 — Demo Flow

1. Open business customer profile.
2. Show relationship graph.
3. Generate RM meeting brief.
4. Identify treasury opportunity.
5. Start commercial loan workflow.
6. Generate credit memo.
7. Show collateral/covenants.
8. Show portfolio dashboard.
9. Trigger annual review.
10. Show board commercial report.

## Dispatch Truth Statement

Commercial banking implementation should begin with relationship truth, then credit structure, then workflows, then agents.
