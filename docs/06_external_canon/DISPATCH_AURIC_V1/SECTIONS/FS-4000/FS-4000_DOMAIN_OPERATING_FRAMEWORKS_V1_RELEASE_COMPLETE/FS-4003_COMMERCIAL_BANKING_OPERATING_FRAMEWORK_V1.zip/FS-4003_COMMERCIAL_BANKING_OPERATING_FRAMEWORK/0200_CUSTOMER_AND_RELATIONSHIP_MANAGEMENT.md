# Customer & Relationship Management

## Purpose

This document defines the commercial relationship lifecycle.

## Commercial Relationship Lifecycle

Target Market → Prospect → Lead → Discovery → Qualification → Relationship Plan → Deposit Opportunity → Treasury Opportunity → Credit Opportunity → Proposal → Onboarding → Expansion → Renewal → Strategic Relationship → Retention or Exit

## Relationship Manager Object

Fields:

- rm_id
- name
- market
- portfolio
- industry_focus
- customer_count
- deposit_portfolio
- loan_portfolio
- treasury_revenue
- pipeline
- calling_activity
- relationship_plans
- referrals
- cross_sell_opportunities
- risk_flags
- production_goals
- profitability_goals

## Relationship Plan Object

Fields:

- plan_id
- business_customer
- relationship_manager
- current_products
- wallet_share
- customer_priorities
- business_goals
- upcoming_events
- financial_needs
- credit_needs
- treasury_needs
- deposit_opportunities
- risk_concerns
- next_actions
- expected_revenue
- timeline
- meeting_history

## Business Discovery Framework

Dispatch should capture:

- business model
- revenue streams
- customers
- suppliers
- seasonality
- working capital cycle
- payment flows
- payroll
- inventory
- receivables
- payables
- tax obligations
- growth plans
- succession plans
- capital needs
- technology needs
- pain points
- risk events
- competitive environment

## Meeting Prep Object

Inputs:
- customer profile
- product usage
- recent transactions
- deposit trends
- loan balances
- covenant status
- treasury services
- open tasks
- service issues
- market news
- related executives
- next best actions

Outputs:
- meeting brief
- question list
- opportunity list
- risk alerts
- follow-up tasks
- CRM update

## Customer Segments

- Microbusiness
- Small Business
- Lower Middle Market
- Middle Market
- Large Corporate
- Professional Services
- Real Estate Investor
- Developer
- Nonprofit
- Municipality
- Healthcare Provider
- Manufacturer
- Contractor
- Hospitality Operator
- Franchisee
- Agricultural Producer
- Technology Company

## Relationship KPIs

- customer count
- relationship profitability
- deposit balances
- treasury revenue
- loan balances
- wallet share
- cross-sell ratio
- meetings per month
- pipeline conversion
- retention rate
- risk migration
- annual reviews completed
- customer satisfaction
- referral generation

## AI Opportunities

- relationship plan generation
- meeting prep
- next best product
- deposit opportunity detection
- treasury opportunity detection
- credit need prediction
- customer risk alert
- renewal prep
- call report generation
- CRM note summarization

## Dispatch Truth Statement

Commercial relationship management is not CRM activity tracking. It is the continuous understanding of how a business operates and how the institution can support, finance, and deepen that relationship.
