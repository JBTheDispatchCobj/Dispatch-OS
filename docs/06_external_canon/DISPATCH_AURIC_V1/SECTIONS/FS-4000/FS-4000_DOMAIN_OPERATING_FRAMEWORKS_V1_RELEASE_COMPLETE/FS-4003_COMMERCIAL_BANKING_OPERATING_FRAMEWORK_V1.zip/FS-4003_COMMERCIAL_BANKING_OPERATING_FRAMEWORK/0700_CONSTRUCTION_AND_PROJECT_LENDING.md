# Construction & Project Lending

## Purpose

This document defines construction lending and project finance operations.

## Construction Loan Object

Fields:
- construction_loan_id
- borrower
- sponsor
- project
- property
- total_project_cost
- loan_amount
- equity_required
- equity_contributed
- budget
- contingency
- draw_schedule
- inspector
- contractor
- architect
- permits
- lien_status
- completion_status
- interest_reserve
- takeout_source
- completion_guaranty

## Project Object

Fields:
- project_id
- project_type
- location
- scope
- timeline
- budget
- contractor
- subcontractors
- permits
- inspections
- change_orders
- completion_percentage
- risks
- milestones
- sources_and_uses

## Construction Lifecycle

Application → Budget Review → Plans/Specs → Appraisal → Environmental → Contractor Review → Approval → Closing → Equity Verification → Draw Requests → Inspections → Funding Draws → Change Orders → Completion → Stabilization → Takeout/Conversion

## Draw Workflow

Draw Request → Required Documents → Inspection → Lien Waiver Review → Budget Reconciliation → Approval → Funding → Update Budget → Archive Evidence

## Risk Areas

- cost overrun
- delay
- contractor failure
- lien risk
- permit delay
- weather
- market change
- leasing risk
- completion risk
- takeout risk
- guarantor risk
- budget fraud
- insufficient equity

## Construction Documents

- plans
- specifications
- budget
- construction contract
- permits
- inspection reports
- lien waivers
- draw requests
- change orders
- appraisal
- environmental
- title endorsements
- insurance
- completion guaranty

## KPIs

- budget utilization
- contingency remaining
- completion percentage
- draws funded
- inspection exceptions
- change orders
- equity remaining
- project delay
- cost overrun
- takeout readiness
- lien exceptions

## AI Opportunities

- draw package review
- budget variance detection
- lien waiver checklist
- inspection summary
- completion risk forecast
- cost overrun alert
- takeout readiness summary
- project status report

## Dispatch Truth Statement

Construction lending is not a loan file. It is a dynamic project control system where capital, collateral, contractors, permits, inspections, lien rights, and completion risk must be monitored continuously.
