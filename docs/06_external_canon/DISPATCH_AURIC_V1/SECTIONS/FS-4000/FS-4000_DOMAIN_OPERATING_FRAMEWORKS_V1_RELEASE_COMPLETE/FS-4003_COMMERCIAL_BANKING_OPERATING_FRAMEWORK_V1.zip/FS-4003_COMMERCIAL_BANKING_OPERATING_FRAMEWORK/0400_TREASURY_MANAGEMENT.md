# Treasury Management

## Purpose

This document defines commercial treasury management products, workflows, risks, and revenue opportunities.

## Treasury Product Categories

### Payables

- ACH Origination
- Wire Transfers
- Bill Pay
- Commercial Card
- Purchasing Card
- Payroll
- Tax Payments
- Vendor Payments
- Positive Pay
- Reverse Positive Pay

### Receivables

- Remote Deposit Capture
- Lockbox
- Merchant Services
- ACH Debit
- Card Acceptance
- Invoice Payments
- Cash Vault
- Mobile Deposit
- Integrated Receivables

### Liquidity

- Sweep Accounts
- Zero Balance Accounts
- Money Market
- Investment Sweep
- Line Sweep
- Concentration Accounts
- Notional Pooling where applicable
- Target Balancing

### Information

- Online Treasury Portal
- Account Reporting
- Alerts
- File Transmission
- API Banking
- ERP Integration
- Reconciliation Files
- Cash Forecasting

### Fraud Controls

- ACH Positive Pay
- Check Positive Pay
- Dual Approval
- Limits
- Tokens
- User Entitlements
- Payee Verification
- Velocity Monitoring
- Out-of-Band Verification

## Treasury Service Object

Fields:

- service_id
- business_customer_id
- service_type
- accounts_linked
- users
- entitlements
- limits
- approvals
- implementation_status
- pricing
- monthly_revenue
- risk_rating
- fraud_controls
- training_status
- support_history
- renewal_status

## Treasury Onboarding Workflow

Needs Assessment → Product Proposal → Pricing → Agreements → Risk Review → User Setup → Entitlements → Testing → Training → Go-Live → Monitoring → Optimization

## Treasury Risk

- payment fraud
- entitlement misuse
- wire fraud
- ACH returns
- unauthorized originations
- operational errors
- customer training failure
- system downtime
- file transmission failure
- limits breach

## Treasury KPIs

- treasury revenue
- products per business
- ACH volume
- wire volume
- RDC volume
- merchant volume
- positive pay adoption
- implementation time
- support tickets
- fraud prevented
- monthly fees
- customer utilization
- profitability

## AI Opportunities

- treasury needs assessment
- proposal generation
- implementation checklist
- entitlement review
- fraud risk alerts
- cash flow insight
- account structure design
- pricing recommendation
- customer training content
- support ticket summarization

## Dispatch Truth Statement

Treasury management is where commercial banking becomes operationally embedded inside the customer's business.
