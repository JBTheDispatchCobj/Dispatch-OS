# SBA & Government-Guaranteed Lending

## Purpose

This document defines SBA and government-guaranteed commercial lending operations.

## Program Types

- SBA 7(a)
- SBA 504
- SBA Express
- USDA Business & Industry
- State Guarantee Programs
- Export Finance Programs
- Government Contract Lending where applicable

## SBA Loan Object

Fields:
- loan_id
- borrower
- program
- guarantee_percentage
- eligibility_status
- use_of_proceeds
- loan_amount
- term
- collateral
- guarantors
- SBA_forms
- authorization
- closing_requirements
- servicing_requirements
- secondary_market_status
- guarantee_status

## Eligibility Workflow

Business Profile → Size Standard → Use of Proceeds → Ownership → Credit Elsewhere → Franchise Check → Required Equity → Collateral Review → Eligibility Decision → Documentation

## SBA Documentation

- borrower application
- lender application
- personal financial statements
- tax returns
- business financials
- debt schedule
- use of proceeds
- purchase agreement
- franchise documents
- environmental
- SBA authorization
- guarantee documents
- closing checklist

## Servicing Requirements

- payment monitoring
- collateral monitoring
- insurance
- financial statements
- annual review
- borrower changes
- collateral release
- deferment
- liquidation
- guarantee purchase package

## Secondary Market

Objects:
- guaranteed portion
- investor
- premium
- sale
- settlement
- servicing retained
- reporting
- remittance

## KPIs

- SBA applications
- approvals
- funded volume
- guarantee percentage
- premium income
- liquidation rate
- guarantee repairs/denials
- documentation exceptions
- servicing compliance
- secondary market gain

## AI Opportunities

- eligibility checklist
- document request generation
- SBA form preparation support
- credit memo drafting
- closing checklist review
- servicing requirement alerts
- liquidation package preparation
- secondary market sale summary

## Dispatch Truth Statement

Government-guaranteed lending is commercial credit plus program compliance. Dispatch must preserve eligibility, documentation, servicing, guarantee integrity, and risk evidence throughout the life of the loan.
