# Commercial Banking Agent Workforce

## Executive Agents

- Chief Lending Officer Advisor
- Chief Credit Officer Advisor
- Commercial Banking Strategy Agent
- Credit Committee Briefing Agent
- Board Lending Package Agent

## Relationship Agents

- Relationship Manager Prep Agent
- Business Prospect Researcher
- Relationship Plan Writer
- Meeting Brief Agent
- Cross-Sell Discovery Agent
- Treasury Opportunity Agent

## Credit Agents

- Commercial Underwriter
- Credit Analyst
- Credit Memo Writer
- Financial Spreading Agent
- Cash Flow Analyst
- Global Cash Flow Agent
- Collateral Analyst
- Guarantor Analyst
- Risk Rating Agent
- Policy Exception Agent

## Operations Agents

- Loan Processor
- Conditions Manager
- Closing Checklist Agent
- Funding Coordinator
- Tickler Manager
- Covenant Monitor
- Annual Review Agent
- Portfolio Manager Agent

## Special Assets Agents

- Early Warning Agent
- Watchlist Analyst
- Workout Strategy Agent
- Collateral Liquidation Agent
- Recovery Tracker

## Treasury Agents

- Treasury Needs Agent
- Cash Management Proposal Agent
- Positive Pay Advisor
- Merchant Services Analyst
- ACH/Wire Risk Agent

## Governance

Agents require human approval for:
- credit decision
- loan terms
- adverse action
- waiver approval
- collateral release
- charge-off
- legal action
- regulatory communication
- external customer commitments

## Agent KPIs

- time saved
- memo quality
- missing document detection
- forecast accuracy
- covenant testing accuracy
- portfolio alert precision
- human override rate
- approval cycle reduction

## Dispatch Truth Statement

Commercial banking agents act like specialized staff inside a governed credit and relationship operating model.
