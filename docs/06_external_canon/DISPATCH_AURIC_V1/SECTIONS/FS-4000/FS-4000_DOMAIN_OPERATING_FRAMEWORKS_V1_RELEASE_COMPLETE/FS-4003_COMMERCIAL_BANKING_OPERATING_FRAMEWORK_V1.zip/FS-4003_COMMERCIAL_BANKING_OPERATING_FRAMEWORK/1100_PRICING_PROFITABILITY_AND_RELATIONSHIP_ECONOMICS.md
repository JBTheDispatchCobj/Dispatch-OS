# Pricing, Profitability & Relationship Economics

## Purpose

This document defines commercial relationship profitability, pricing, capital allocation, and return analysis.

## Relationship Profitability Object

Fields:
- relationship_id
- customer
- deposits
- loans
- treasury_revenue
- merchant_revenue
- fees
- credit_cost
- capital_allocation
- operating_cost
- profitability
- ROE
- ROA
- risk_adjusted_return
- lifetime_value
- wallet_share
- opportunity_value

## Pricing Inputs

- cost of funds
- risk grade
- collateral
- term
- structure
- relationship value
- treasury revenue
- deposit balances
- competition
- capital allocation
- expected loss
- operating cost
- profitability target
- strategic value

## Loan Pricing Components

- index
- spread
- floor
- origination fee
- unused fee
- commitment fee
- prepayment fee
- collateral cost
- monitoring cost
- legal/documentation cost
- capital charge
- expected loss

## Treasury Pricing Components

- monthly maintenance
- ACH fees
- wire fees
- RDC fees
- positive pay fees
- lockbox fees
- merchant fees
- file transmission fees
- implementation fees
- account analysis offsets

## Profitability Workflow

Relationship Data → Product Revenue → Cost Allocation → Credit Cost → Capital Charge → Risk Adjustment → Scenario → Recommendation → Approval → Monitoring

## KPIs

- relationship profitability
- RAROC
- loan spread
- treasury revenue
- deposit value
- non-interest income
- wallet share
- cross-sell ratio
- cost to serve
- capital usage
- pricing exceptions
- relationship ROE

## AI Opportunities

- relationship profitability summary
- pricing recommendation
- negotiation prep
- treasury bundle recommendation
- deposit value analysis
- risk-adjusted return calculation
- exception justification drafting
- competitor pricing comparison
- relationship expansion recommendation

## Dispatch Truth Statement

Commercial banking profitability is relationship economics. The right price cannot be determined from the loan alone; it must include deposits, treasury, risk, capital, costs, and strategic value.
