# Acceptance Tests & Roadmap

## Object Tests

- Can create Business Customer.
- Can create Relationship Plan.
- Can create Commercial Deposit Account.
- Can create Treasury Service.
- Can create Commercial Loan.
- Can create Collateral.
- Can create Covenant.
- Can create Credit Memo.
- Can create Annual Review.
- Can create Watchlist.
- Can create Workout Plan.

## Relationship Tests

- Business Customer HAS Beneficial Owner.
- Business Customer HOLDS Deposit.
- Business Customer USES Treasury Service.
- Business Customer BORROWS Loan.
- Guarantor GUARANTEES Loan.
- Collateral SECURES Loan.
- Covenant GOVERNS Loan.
- Relationship Manager SERVES Customer.
- Credit Committee APPROVES Loan.

## Workflow Tests

- Relationship Plan workflow completes.
- Treasury Needs workflow produces recommendations.
- Commercial Loan workflow produces credit memo.
- Annual Review workflow updates risk rating.
- Covenant workflow detects pass/fail.
- Construction Draw workflow validates documents.
- Watchlist workflow creates action plan.
- Workout workflow tracks recovery.

## Agent Tests

- RM Prep Agent creates meeting brief.
- Credit Memo Writer drafts complete memo.
- Financial Spreading Agent extracts metrics.
- Covenant Monitor tests covenant.
- Portfolio Risk Agent identifies watchlist candidates.
- Treasury Needs Agent recommends products.
- Workout Agent drafts action plan.

## Roadmap

Priority 1:
- machine-readable object registry
- fixture commercial customer
- fixture credit memo
- fixture annual review
- fixture treasury needs assessment

Priority 2:
- workflow implementation
- agent implementation
- dashboard implementation
- connector mapping

Priority 3:
- industry-specific underwriting packs
- construction lending specialization
- CRE specialization
- SBA specialization
- participation lending specialization

## Dispatch Truth Statement

The Commercial Banking cartridge is accepted when Dispatch can understand a business customer across deposits, treasury, credit, risk, profitability, workflows, documents, and institutional knowledge.
