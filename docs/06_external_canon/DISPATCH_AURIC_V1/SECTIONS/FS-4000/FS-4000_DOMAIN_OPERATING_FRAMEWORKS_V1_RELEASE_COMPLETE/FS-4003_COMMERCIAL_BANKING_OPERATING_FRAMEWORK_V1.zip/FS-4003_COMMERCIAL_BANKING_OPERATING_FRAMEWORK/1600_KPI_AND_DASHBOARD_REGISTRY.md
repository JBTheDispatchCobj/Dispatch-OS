# KPI & Dashboard Registry

## Production KPIs

- leads created
- qualified prospects
- opportunities
- pipeline value
- approved commitments
- funded volume
- outstanding balances
- deposit balances
- treasury revenue
- merchant revenue
- relationship profitability
- cross-sell ratio
- wallet share

## Credit KPIs

- approval rate
- decision time
- funding time
- weighted average risk grade
- exception rate
- policy exception count
- LTV
- DSCR
- debt yield
- covenant breach rate
- annual review completion
- risk grade migration

## Portfolio KPIs

- total exposure
- industry concentration
- geographic concentration
- CRE concentration
- top borrower concentration
- watchlist exposure
- criticized/classified
- delinquency
- nonaccrual
- charge-offs
- recoveries
- maturity ladder

## Treasury KPIs

- products per customer
- ACH volume
- wire volume
- RDC volume
- positive pay adoption
- treasury fee income
- fraud prevented
- implementation cycle time
- monthly active treasury users

## Relationship KPIs

- meetings
- relationship plans complete
- next actions complete
- revenue per relationship
- deposit-to-loan ratio
- profitability
- retention
- new business referrals

## Dashboards

- Commercial Executive Dashboard
- Relationship Manager Dashboard
- Credit Pipeline Dashboard
- Portfolio Risk Dashboard
- Treasury Management Dashboard
- Annual Review Dashboard
- Covenant Dashboard
- Watchlist Dashboard
- Special Assets Dashboard
- Board Commercial Lending Dashboard

## Dispatch Truth Statement

Commercial banking KPIs must show relationship health, credit risk, portfolio performance, treasury adoption, profitability, and execution quality in one view.
