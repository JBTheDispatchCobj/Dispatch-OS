# Collateral, Covenants & Monitoring

## Purpose

This document defines collateral, covenant, tickler, and monitoring operations for commercial banking.

## Collateral Types

- Real Estate
- Equipment
- Vehicles
- Accounts Receivable
- Inventory
- Cash
- Securities
- Deposits
- Life Insurance
- Intellectual Property
- Contracts
- Franchise Rights
- Ownership Interests
- Personal Guarantee
- Corporate Guarantee
- Letter of Credit
- Assignment of Rents
- UCC Collateral

## Collateral Object

Fields:
- collateral_id
- type
- owner
- borrower
- loan
- valuation
- valuation_date
- advance_rate
- lien_position
- perfection_status
- insurance
- monitoring_frequency
- inspection_status
- release_status
- liquidation_value
- risk_notes

## Covenant Types

- DSCR
- Debt to EBITDA
- Current Ratio
- Liquidity
- Net Worth
- Debt Service Reserve
- Borrowing Base
- Reporting
- Leverage
- Fixed Charge Coverage
- Minimum EBITDA
- CapEx Limits
- Distribution Restrictions
- Additional Debt Restrictions
- Ownership Change Restrictions

## Covenant Object

Fields:
- covenant_id
- loan_id
- borrower_id
- covenant_type
- threshold
- test_frequency
- test_date
- actual_value
- status
- waiver_status
- breach_date
- cure_period
- evidence
- owner
- escalation

## Monitoring Lifecycle

Covenant Setup → Tickler Creation → Evidence Request → Evidence Collection → Calculation → Pass/Fail → Exception/Waiver → Escalation → Portfolio Update → Archive

## Tickler Object

Fields:
- tickler_id
- required_item
- borrower
- loan
- due_date
- owner
- status
- reminder_schedule
- evidence
- exception
- escalation

## Monitoring KPIs

- ticklers due
- ticklers overdue
- covenant breaches
- waiver requests
- collateral exceptions
- insurance exceptions
- UCC exceptions
- annual reviews due
- financial statements missing
- appraisal updates due
- risk rating changes

## AI Opportunities

- covenant calculation
- tickler follow-up drafts
- collateral exception detection
- insurance review
- UCC/lien checklist
- borrower reporting summary
- waiver memo drafting
- monitoring dashboard commentary

## Dispatch Truth Statement

Monitoring is where underwriting becomes accountability. Dispatch must continuously connect credit structure, borrower performance, collateral, covenants, evidence, and risk migration.
