# Risk, Compliance & Documentation

## Purpose

This document defines commercial banking compliance, documentation, legal, and evidence requirements.

## Compliance Areas

- KYB
- beneficial ownership
- customer due diligence
- enhanced due diligence
- OFAC
- AML
- BSA
- fair lending
- UDAAP
- flood insurance
- appraisal rules
- environmental diligence
- HMDA where applicable
- CRA where applicable
- Reg B
- adverse action
- privacy
- records retention
- vendor/third-party risk

## Documentation Categories

### Entity Documents

- articles
- operating agreement
- bylaws
- partnership agreement
- good standing
- tax ID
- ownership chart
- resolutions
- incumbency certificate

### Financial Documents

- tax returns
- financial statements
- interim statements
- accounts receivable aging
- accounts payable aging
- debt schedule
- projections
- bank statements
- borrowing base

### Collateral Documents

- appraisal
- environmental
- title
- survey
- insurance
- UCC
- lien search
- collateral schedule
- landlord waiver
- assignment

### Legal Documents

- loan agreement
- promissory note
- security agreement
- guaranty
- mortgage/deed of trust
- assignment of rents
- intercreditor
- subordination
- participation agreement

## Documentation Exception Object

Fields:
- exception_id
- loan_id
- document
- requirement
- reason
- risk_level
- owner
- due_date
- approval
- status
- resolution

## Compliance Workflow

Requirement → Evidence Request → Collection → Review → Exception → Approval/Escalation → Archive → Monitoring

## AI Opportunities

- document checklist generation
- entity document review
- beneficial ownership summary
- flood determination workflow support
- appraisal review summary
- loan document comparison
- exception memo drafting
- adverse action draft support
- file completeness review

## Dispatch Truth Statement

Commercial documentation is not paperwork. It is the legal and regulatory evidence that supports enforceability, compliance, risk control, and institutional memory.
