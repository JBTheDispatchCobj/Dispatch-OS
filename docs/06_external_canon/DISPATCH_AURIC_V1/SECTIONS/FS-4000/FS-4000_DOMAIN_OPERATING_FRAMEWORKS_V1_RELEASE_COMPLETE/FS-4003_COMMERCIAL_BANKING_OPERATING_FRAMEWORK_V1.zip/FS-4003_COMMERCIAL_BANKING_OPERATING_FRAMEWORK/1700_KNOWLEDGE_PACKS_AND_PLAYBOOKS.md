# Knowledge Packs & Playbooks

## Required Knowledge Packs

### Commercial Banking Foundation Pack

- terminology
- product taxonomy
- customer segments
- relationship lifecycle
- workflow maps
- KPI definitions

### Commercial Credit Pack

- underwriting standards
- credit memo format
- risk rating
- collateral analysis
- approval matrix
- policy exceptions

### Treasury Management Pack

- treasury products
- implementation workflows
- fraud controls
- pricing
- customer discovery

### CRE Pack

- property types
- underwriting
- documents
- appraisal review
- monitoring
- concentration risk

### Construction Lending Pack

- draw workflows
- budgets
- inspections
- lien waivers
- takeout risk
- project monitoring

### Portfolio Management Pack

- annual reviews
- covenants
- ticklers
- watchlist
- risk migration
- board reporting

### Special Assets Pack

- workout options
- restructuring
- collateral liquidation
- charge-off
- recovery
- bankruptcy basics

## Playbooks

- Relationship Plan Playbook
- Treasury Cross-Sell Playbook
- Commercial Loan Origination Playbook
- Credit Memo Playbook
- Annual Review Playbook
- Covenant Monitoring Playbook
- CRE Review Playbook
- Construction Draw Playbook
- Watchlist Playbook
- Workout Playbook
- Deposit Growth Playbook
- Relationship Profitability Playbook

## Dispatch Truth Statement

Knowledge Packs and Playbooks are how commercial banking expertise becomes reusable, executable, and teachable inside Dispatch.
