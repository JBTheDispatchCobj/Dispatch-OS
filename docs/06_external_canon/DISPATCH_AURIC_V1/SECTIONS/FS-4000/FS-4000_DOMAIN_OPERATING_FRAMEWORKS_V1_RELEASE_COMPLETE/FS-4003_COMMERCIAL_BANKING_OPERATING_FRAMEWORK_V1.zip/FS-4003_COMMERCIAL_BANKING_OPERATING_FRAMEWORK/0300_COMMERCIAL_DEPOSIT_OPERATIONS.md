# Commercial Deposit Operations

## Purpose

This document defines commercial deposit strategy, operations, pricing, risk, and growth.

## Commercial Deposit Products

- Business Checking
- Analyzed Checking
- Commercial DDA
- Interest Checking
- Business Money Market
- Business Savings
- Certificate
- Escrow Account
- Trust Account
- IOLTA
- Payroll Account
- Operating Account
- Tax Account
- Reserve Account
- Sweep Account
- Zero Balance Account
- Public Funds Account
- Property Management Account
- HOA Account
- Merchant Settlement Account

## Commercial Deposit Object

Fields:

- account_id
- business_customer_id
- account_purpose
- average_balance
- current_balance
- collected_balance
- rate
- fees
- earnings_credit_rate
- analysis_status
- transaction_volume
- wire_volume
- ACH_volume
- check_volume
- RDC_volume
- fraud_controls
- authorized_signers
- beneficial_owners
- concentration_flag
- liquidity_value
- relationship_profitability

## Account Analysis

Commercial accounts may use account analysis.

Objects:
- analyzed account
- compensating balance
- earnings credit
- service charges
- transaction fees
- fee waiver
- account analysis statement
- profitability calculation

## Commercial Deposit Lifecycle

Prospect → Needs Assessment → Account Structure → KYB/KYC → Documentation → Account Opening → Treasury Setup → Funding → Monitoring → Pricing Review → Expansion → Retention → Closure

## Deposit Risk

- concentration risk
- uninsured deposit exposure
- volatility
- rate sensitivity
- operational risk
- fraud risk
- beneficial ownership risk
- dormant/inactive accounts
- public funds collateralization
- restricted funds
- escrow/fiduciary responsibility

## Deposit Growth Playbook

1. define target industries
2. identify operating account opportunities
3. map payment flows
4. identify treasury pain
5. propose account structure
6. bundle fraud controls
7. cross-sell credit
8. monitor balances
9. price based on relationship
10. retain at renewal/event triggers

## Deposit KPIs

- commercial deposit growth
- average collected balance
- DDA growth
- non-interest-bearing deposits
- account profitability
- cost of funds
- treasury attachment rate
- deposit concentration
- deposit retention
- new commercial accounts
- cross-sell ratio
- uninsured deposit exposure

## AI Opportunities

- deposit volatility forecast
- relationship pricing recommendation
- account structure recommendation
- treasury attachment recommendation
- concentration alerting
- business deposit prospecting
- retention offer generation
- uninsured deposit analysis

## Dispatch Truth Statement

Commercial deposits are not account balances. They are operating relationships that reveal payment flows, liquidity behavior, treasury needs, credit opportunities, and business health.
